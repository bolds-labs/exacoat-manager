<?php
/**
 * Exacoat Core Universal Native Email Engine
 * Directly renders pixel-perfect responsive dark-mode HTML templates and dispatches via Zoho ZeptoMail API.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Exacoat_Email_Engine' ) ) {

class Exacoat_Email_Engine {

	public static function init() {
		// AJAX Test / Preview Handlers
		add_action( 'wp_ajax_artmatter_send_native_test_email', [ __CLASS__, 'ajax_send_test_email' ] );
		add_action( 'wp_ajax_exacoat_send_native_test_email', [ __CLASS__, 'ajax_send_test_email' ] );
		add_action( 'wp_ajax_artmatter_preview_email_html', [ __CLASS__, 'ajax_preview_email_html' ] );
		add_action( 'wp_ajax_exacoat_preview_email_html', [ __CLASS__, 'ajax_preview_email_html' ] );

		// Action Scheduler async worker for sending emails in background
		add_action( 'artmatter_async_send_email_job', [ __CLASS__, 'process_async_email_job' ], 10, 4 );
		add_action( 'exacoat_async_send_email_job', [ __CLASS__, 'process_async_email_job' ], 10, 4 );

		// 1. Automatically suppress default WooCommerce core duplicate emails
		$suppressed_emails = [
			'customer_processing_order',
			'customer_completed_order',
			'customer_refunded_order',
			'customer_partially_refunded_order',
			'customer_on_hold_order',
			'customer_note',
			'customer_invoice',
			'customer_reset_password',
			'customer_new_account',
			'failed_order',
		];
		foreach ( $suppressed_emails as $email_id ) {
			add_filter( "woocommerce_email_recipient_{$email_id}", '__return_empty_string', 999 );
			add_filter( "woocommerce_email_enabled_{$email_id}", '__return_false', 999 );
		}

		// 2. Intercept Customer Note Created
		add_action( 'woocommerce_new_customer_note', [ __CLASS__, 'handle_woocommerce_new_customer_note' ], 10, 1 );

		// 3. Intercept Customer Password Reset Notification
		add_action( 'woocommerce_reset_password_notification', [ __CLASS__, 'handle_woocommerce_reset_password_notification' ], 10, 2 );

		// 4. Intercept Customer Account Created
		add_action( 'woocommerce_created_customer', [ __CLASS__, 'handle_woocommerce_created_customer' ], 10, 3 );

		// 5. Intercept Manual Resend Order Details / Invoice
		add_action( 'woocommerce_before_resend_order_emails', [ __CLASS__, 'handle_woocommerce_resend_order_emails' ], 10, 2 );
	}

	/**
	 * Configuration Accessor
	 */
	/**
	 * Official Exacoat Brand Logo Image (Universal HTML Email Compatible)
	 * Resolves to high-res PNG for complete support across all email clients (Gmail, Outlook, Yahoo, Apple Mail).
	 */
	public static function get_brand_logo_url( bool $is_white = false ): string {
		$filename = $is_white ? 'exacoat-logo-white.png' : 'exacoat-logo.png';
		return 'https://exacoat.com/assets/brand/' . $filename;
	}

	public static function get_brand_logo_html( bool $is_white = false ): string {
		$url = self::get_brand_logo_url( $is_white );
		return '<a href="https://exacoat.com" target="_blank" rel="noopener noreferrer" style="display:inline-block;text-decoration:none;"><img src="' . esc_url( $url ) . '" alt="Exacoat" width="136" height="24" border="0" style="display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic;width:136px;height:24px;max-width:136px;" /></a>';
	}

	public static function get_config(): array {
		$settings = Exacoat_Core::get_settings();
		$token    = trim( $settings['zeptomail_token'] ?? '' );

		// Auto-discover ZeptoMail token from transmail plugin configuration if not explicitly set
		if ( empty( $token ) ) {
			$raw_agents = get_option( 'transmail_additional_mail_agents' );
			if ( ! empty( $raw_agents ) ) {
				$decoded = json_decode( base64_decode( $raw_agents ), true );
				if ( is_array( $decoded ) ) {
					foreach ( $decoded as $agent_email => $agents_list ) {
						if ( is_array( $agents_list ) ) {
							foreach ( $agents_list as $ag ) {
								if ( ! empty( $ag['Token'] ) ) {
									$token = $ag['Token'];
									break 2;
								}
							}
						}
					}
				}
			}
		}

		return [
			'zeptomail_token' => $token,
			'from_email'      => trim( $settings['email_from_address'] ?? 'support@exacoat.com' ),
			'from_name'       => trim( $settings['email_from_name'] ?? 'Exacoat Support' ),
			'reply_to'        => 'support@exacoat.com',
		];
	}

	/**
	 * Helper: Clean price string for transactional emails (strips HTML tags & entities, normalizes spacing)
	 */
	public static function clean_email_price( $val ): string {
		if ( null === $val || '' === $val ) {
			return '';
		}
		$str = is_scalar( $val ) ? (string) $val : '';
		if ( '' === $str ) {
			return '';
		}
		$clean = html_entity_decode( wp_strip_all_tags( $str ), ENT_QUOTES, 'UTF-8' );
		$clean = str_replace( [ "\xc2\xa0", "\u{00A0}", "&nbsp;" ], ' ', $clean );
		return trim( preg_replace( '/\s+/', ' ', $clean ) );
	}

	/**
	 * Helper: Determine if a price value is zero, empty, or effectively zero
	 */
	public static function is_price_zero( $val ): bool {
		if ( null === $val || '' === $val ) {
			return true;
		}
		if ( is_numeric( $val ) ) {
			return (float) $val == 0.0;
		}
		$clean = self::clean_email_price( $val );
		if ( '' === $clean || '0' === $clean || '0.00' === $clean || '-' === $clean || 'free' === strtolower( $clean ) ) {
			return true;
		}
		$digits = preg_replace( '/[^\d]/', '', $clean );
		if ( '' === $digits || intval( $digits ) === 0 ) {
			return true;
		}
		return false;
	}

	/**
	 * Standard Icon URL Resolver (Supports official Artmatter PNGs + Lucide Icons fallback)
	 */
	public static function resolve_icon_url( string $icon_name_or_url ): string {
		if ( filter_var( $icon_name_or_url, FILTER_VALIDATE_URL ) ) {
			return $icon_name_or_url;
		}

		$official_map = [
			'security'            => 'https://media.artmatter.co/assets/icons-png/security.png',
																		'document_submitted'  => 'https://media.artmatter.co/assets/icons-png/document-submitted.png',
			'document_verified'   => 'https://media.artmatter.co/assets/icons-png/document-verified.png',
			'document_alert'      => 'https://media.artmatter.co/assets/icons-png/document-alert.png',
			'commission_pending'  => 'https://media.artmatter.co/assets/icons-png/commission-pending.png',
			'commission_approved' => 'https://media.artmatter.co/assets/icons-png/commission-approved.png',
			'payout_pending'      => 'https://media.artmatter.co/assets/icons-png/payout-pending.png',
			'payout_completed'    => 'https://media.artmatter.co/assets/icons-png/document-verified.png',
		];

		$key = strtolower( str_replace( [ '-', ' ' ], '_', $icon_name_or_url ) );
		if ( isset( $official_map[ $key ] ) ) {
			return $official_map[ $key ];
		}

		// Fallback to Lucide CDN SVG rendered dynamically
		$clean_lucide = strtolower( str_replace( '_', '-', $icon_name_or_url ) );
		return "https://cdn.jsdelivr.net/npm/lucide-static@0.460.0/icons/{$clean_lucide}.svg";
	}

	/**
	 * Complete Registry of Dynamic Email Event Templates
	 */
	public static function get_template_registry(): array {
		return [
			// 1. Customer Authentication & Accounts
			'customer_otp' => [
				'category'       => 'Authentication',
				'label'          => '🔑 Customer OTP Verification Code',
				'subject'        => 'Your verification code for Exacoat',
				'badge'          => 'Security verification',
				'icon'           => 'security',
				'title'          => 'Verify your identity',
				'body_primary'   => 'Use the code below to complete verification.',
				'type'           => 'otp',
				'defaults'       => [
					'otp_code' => '849201',
				],
			],
			'customer_new_account' => [
				'category'       => 'Authentication',
				'label'          => 'Customer Account Created (Welcome)',
				'subject'        => 'Welcome to Exacoat',
				'badge'          => 'Account created',
				'icon'           => 'security',
				'title'          => 'Welcome to Exacoat',
				'body_primary'   => 'Your Exacoat account has been created. You can use your account to review orders, save delivery details, and track shipments.',
				'type'           => 'customer_account',
				'defaults'       => [
					'customer_first_name' => 'Customer',
					'account_url'         => 'https://exacoat.com/my-account',
				],
			],
			'customer_reset_password' => [
				'category'       => 'Authentication',
				'label'          => 'Customer Password Reset',
				'subject'        => 'Password reset request for Exacoat',
				'badge'          => 'Account security',
				'icon'           => 'security',
				'title'          => 'Reset your password',
				'body_primary'   => 'Someone has requested a password reset for your Exacoat account.',
				'type'           => 'customer_account',
				'defaults'       => [
					'customer_first_name' => 'Customer',
					'reset_url'           => 'https://exacoat.com/my-account/lost-password/?key=sample_key',
				],
			],
			'website_contact_confirmation' => [
				'category'       => 'Support & Inquiries',
				'label'          => 'Customer Contact Inquiry Confirmation',
				'subject'        => "We've received your inquiry: {{subject}} | Exacoat",
				'badge'          => 'Inquiry received',
				'icon'           => 'document_verified',
				'title'          => "We've received your message",
				'body_primary'   => 'Thank you for reaching out to Exacoat. We’ve received your inquiry and our support team is reviewing the details.',
				'type'           => 'contact_confirmation',
				'defaults'       => [
					'name'         => 'Customer',
					'customer_name'=> 'Customer',
					'topic_label'  => 'General inquiry',
					'subject'      => 'Product inquiry',
					'order_number' => '',
					'message'      => 'Hello, I have a question about my device.',
				],
			],

			// 2. Customer Orders & Fulfillment
			'customer_order_processing' => [
				'category'       => 'Orders',
				'label'          => 'Order Confirmed',
				'subject'        => 'Your Exacoat order #{{order_number}} is confirmed',
				'badge'          => 'Order confirmed',
				'icon'           => 'security',
				'title'          => 'Order confirmed',
				'body_primary'   => 'Thank you for your order. We’ve received order #{{order_number}} and our production team will begin preparing your order shortly.',
				'body_secondary' => 'You can review your order and delivery details below.',
				'type'           => 'customer_order',
				'defaults'       => self::get_mock_order_defaults( '14589' ),
			],
			'customer_order_in_production' => [
				'category'       => 'Orders',
				'label'          => 'In Production',
				'subject'        => 'Your Exacoat order #{{order_number}} is in production',
				'badge'          => 'In production',
				'icon'           => 'security',
				'title'          => 'In production',
				'body_primary'   => 'Your order #{{order_number}} is now on our production line.',
				'body_secondary' => 'We will notify you as soon as your order is packaged and ready to ship.',
				'type'           => 'customer_order',
				'defaults'       => self::get_mock_order_defaults( '14589' ),
			],
			'customer_order_awaiting_pickup' => [
				'category'       => 'Orders',
				'label'          => 'Ready to Ship',
				'subject'        => 'Your Exacoat order #{{order_number}} is ready to ship',
				'badge'          => 'Ready to ship',
				'icon'           => 'document_verified',
				'title'          => 'Ready to ship',
				'body_primary'   => 'Your order #{{order_number}} has passed quality inspection and has been packaged for courier pickup.',
				'body_secondary' => 'Your tracking number will be activated once scanned at the logistics hub.',
				'type'           => 'customer_order',
				'defaults'       => self::get_mock_order_defaults( '14589' ),
			],
			'customer_order_shipped' => [
				'category'       => 'Orders',
				'label'          => 'Shipped',
				'subject'        => 'Your Exacoat order #{{order_number}} is on its way',
				'badge'          => 'On its way',
				'icon'           => 'document_verified',
				'title'          => 'On its way to you',
				'body_primary'   => 'Your order #{{order_number}} has been dispatched and is on its way.',
				'body_secondary' => 'You can find your tracking details and order summary below.',
				'type'           => 'customer_order',
				'defaults'       => self::get_mock_order_defaults( '14589', [
					'courier'         => 'JNE Express',
					'tracking_number' => 'JNE9842194829',
					'tracking_url'    => 'https://exacoat.com/track?order_id=14589',
				] ),
			],
			'customer_order_completed' => [
				'category'       => 'Orders',
				'label'          => 'Delivered',
				'subject'        => 'Your Exacoat order #{{order_number}} has arrived',
				'badge'          => 'Delivered',
				'icon'           => 'document_verified',
				'title'          => 'Delivered',
				'body_primary'   => 'Your order #{{order_number}} has been delivered by the courier.',
				'body_secondary' => 'We hope you enjoy your new products. If you need any assistance, our support team is always here to help.',
				'type'           => 'customer_order',
				'defaults'       => self::get_mock_order_defaults( '14589' ),
			],
			'customer_order_delivered' => [
				'category'       => 'Orders',
				'label'          => 'Delivered',
				'subject'        => 'Your Exacoat order #{{order_number}} has arrived',
				'badge'          => 'Delivered',
				'icon'           => 'document_verified',
				'title'          => 'Delivered',
				'body_primary'   => 'Your order #{{order_number}} has been delivered by the courier.',
				'body_secondary' => 'We hope you enjoy your new products. If you need any assistance, our support team is always here to help.',
				'type'           => 'customer_order',
				'defaults'       => self::get_mock_order_defaults( '14589' ),
			],
			'customer_order_store_pickup_ready' => [
				'category'       => 'Orders',
				'label'          => 'Store Pickup Ready (SMB)',
				'subject'        => '{customer_first_name}, your order (#{order_number}) is ready for pick up',
				'preheader'      => 'Ready to protect your device?',
				'badge'          => 'Ready for pick up',
				'icon'           => 'document_verified',
				'title'          => 'Your order is ready for pick up',
				'body_primary'   => 'Your order <b>(#{order_number})</b> is ready for pick up.<br>Bring your order number and get it installed for free on:',
				'body_secondary' => '',
				'is_store_pickup'=> true,
				'pickup_ready'   => true,
				'type'           => 'customer_order',
				'defaults'       => self::get_mock_order_defaults( '14589', [
					'is_store_pickup'      => true,
					'pickup_ready'         => true,
					'shipping_total'       => 'Rp 0',
					'shipping_method_name' => 'Store Pickup (Summarecon Bekasi)',
					'courier'              => '',
					'tracking_number'      => '',
					'tracking_url'         => '',
				] ),
			],
			'customer_order_store_pickup_completed' => [
				'category'       => 'Orders',
				'label'          => 'Store Pickup Completed',
				'subject'        => '{customer_first_name}, your order has been picked up',
				'preheader'      => 'Thank you for coming!',
				'badge'          => 'Picked up',
				'icon'           => 'document_verified',
				'title'          => 'Order picked up',
				'body_primary'   => 'Your order <b>(#{order_number})</b> has been picked up.<br>Leave a review and tell us about your experience!',
				'body_secondary' => '',
				'is_store_pickup'=> true,
				'pickup_review'  => true,
				'type'           => 'customer_order',
				'defaults'       => self::get_mock_order_defaults( '14589', [
					'is_store_pickup'      => true,
					'pickup_review'        => true,
					'shipping_total'       => 'Rp 0',
					'shipping_method_name' => 'Store Pickup (Summarecon Bekasi)',
					'courier'              => '',
					'tracking_number'      => '',
					'tracking_url'         => '',
				] ),
			],
			'customer_order_review_invitation' => [
				'category'       => 'Orders',
				'label'          => 'Product Review Invitation',
				'subject'        => 'Review {{product_title}} and get a special offer on your next order',
				'badge'          => 'Product Review',
				'icon'           => 'document_verified',
				'title'          => 'How is your new order?',
				'body_primary'   => 'Your Exacoat order was delivered recently. We hope you love your new items.',
				'body_secondary' => 'Take a moment to share your review and a photo of your item to earn store credit for your next order.',
				'cta_text'       => 'Write a Review',
				'type'           => 'review_invitation',
				'defaults'       => [
					'order_number'        => '14589',
					'customer_first_name' => 'Alex',
					'product_title'       => 'iPhone 16 Pro',
					'artwork_title'       => 'iPhone 16 Pro',
					'artwork_image'       => 'https://media.exacoat.com/wp-content/uploads/Black-Camo-Texture-Thumbnail.jpg',
					'review_url'          => 'https://exacoat.com/review?order_id=14589',
				],
			],
			'customer_order_refunded' => [
				'category'       => 'Orders',
				'label'          => 'Refunded',
				'subject'        => 'Refund confirmation for order #{{order_number}}',
				'badge'          => 'Refund processed',
				'icon'           => 'document_alert',
				'title'          => 'Refund processed',
				'body_primary'   => 'We have processed a refund of {{refund_amount}} for order #{{order_number}}.',
				'body_secondary' => 'Depending on your payment method or bank, the funds will reflect in your account within 3 to 5 business days.',
				'type'           => 'customer_order',
				'defaults'       => self::get_mock_order_defaults( '14589', [
					'refund_amount'  => 'Rp 149.000',
					'total_refunded' => 'Rp 149.000',
				] ),
			],
			'customer_order_partially_refunded' => [
				'category'       => 'Orders',
				'label'          => 'Partially Refunded',
				'subject'        => 'Partial refund confirmation for order #{{order_number}}',
				'badge'          => 'Partial refund',
				'icon'           => 'document_alert',
				'title'          => 'Partial refund processed',
				'body_primary'   => 'We have processed a partial refund of {{refund_amount}} for order #{{order_number}}.',
				'body_secondary' => 'Depending on your payment method or bank, the funds will reflect in your account within 3 to 5 business days.',
				'type'           => 'customer_order',
				'defaults'       => self::get_mock_order_defaults( '14589', [
					'refund_amount'  => 'Rp 50.000',
					'total_refunded' => 'Rp 50.000',
				] ),
			],
			'customer_order_on_hold' => [
				'category'       => 'Orders',
				'label'          => 'Order On Hold',
				'subject'        => 'Your Exacoat order #{{order_number}} is on hold',
				'badge'          => 'Payment pending',
				'icon'           => 'security',
				'title'          => 'Order on hold',
				'body_primary'   => 'We’ve received your order #{{order_number}} and are awaiting payment confirmation.',
				'body_secondary' => 'Your order will enter production as soon as payment is confirmed.',
				'type'           => 'customer_order',
				'defaults'       => self::get_mock_order_defaults( '14589' ),
			],
			'customer_order_failed' => [
				'category'       => 'Orders',
				'label'          => 'Payment Failed',
				'subject'        => 'Payment incomplete for order #{{order_number}}',
				'badge'          => 'Payment not completed',
				'icon'           => 'document_alert',
				'title'          => 'Payment not completed',
				'body_primary'   => 'We were unable to process payment for order #{{order_number}}.',
				'body_secondary' => 'Your items remain saved in your cart. You can retry checkout with an alternative payment method.',
				'type'           => 'customer_order',
				'defaults'       => self::get_mock_order_defaults( '14589' ),
			],
			'customer_order_note' => [
				'category'       => 'Orders',
				'label'          => 'Customer Order Note Added',
				'subject'        => 'Update regarding your Exacoat order #{{order_number}}',
				'badge'          => 'Order update',
				'icon'           => 'document_verified',
				'title'          => 'Note regarding your order',
				'body_primary'   => 'A note has been added to your order #{{order_number}}:',
				'body_secondary' => '',
				'type'           => 'customer_order',
				'defaults'       => self::get_mock_order_defaults( '14589', [
					'customer_note' => 'Your order has completed quality inspection and packaging.',
				] ),
			],
			'customer_order_invoice' => [
				'category'       => 'Orders',
				'label'          => 'Order Summary Resend',
				'subject'        => 'Order summary for order #{{order_number}}',
				'badge'          => 'Order summary',
				'icon'           => 'document_verified',
				'title'          => 'Your order summary',
				'body_primary'   => 'Here is a copy of your order details for order #{{order_number}}.',
				'body_secondary' => 'You can review your complete order breakdown and delivery details below.',
				'type'           => 'customer_order',
				'defaults'       => self::get_mock_order_defaults( '14589' ),
			],
			'customer_cashback_earned' => [
				'category'       => 'Store Credits',
				'label'          => 'Cashback Credited (Store Credit)',
				'subject'        => 'You received {{cashback_amount}} cashback on order #{{order_number}}',
				'badge'          => 'Store Credit',
				'icon'           => 'document_verified',
				'title'          => 'Your cashback is ready to use',
				'body_primary'   => 'Your cashback of {{cashback_amount}} from order #{{order_number}} has been credited to your Exacoat store credit balance.',
				'body_secondary' => 'Your available store credit balance is now {{store_credit_balance}}. You can apply it directly during checkout on your next order.',
				'cta_text'       => 'Explore Catalog',
				'type'           => 'store_credit',
				'defaults'       => [
					'customer_first_name'  => 'Alex',
					'cashback_amount'      => 'Rp 25.000',
					'store_credit_balance' => 'Rp 25.000',
					'order_number'         => '14589',
					'expiry_date'          => date( 'F j, Y', strtotime( '+1 year' ) ),
					'shop_url'             => 'https://exacoat.com/shop/',
				],
			],
			'customer_store_credit_reminder' => [
				'category'       => 'Store Credits',
				'label'          => 'Store Credit Balance Reminder',
				'subject'        => 'You have {{store_credit_balance}} store credit waiting in your Exacoat account',
				'badge'          => 'Store Credit',
				'icon'           => 'document_verified',
				'title'          => 'Your store credit is waiting',
				'body_primary'   => 'You still have {{store_credit_balance}} in store credit available in your Exacoat account.',
				'body_secondary' => 'Use it on your next order across our entire catalog. Simply log in and apply your balance at checkout.',
				'cta_text'       => 'Use Your Credit',
				'type'           => 'store_credit',
				'defaults'       => [
					'customer_first_name'  => 'Alex',
					'store_credit_balance' => 'Rp 50.000',
					'expiry_date'          => date( 'F j, Y', strtotime( '+1 year' ) ),
					'shop_url'             => 'https://exacoat.com/shop/',
				],
			],
						'customer_store_credit_pre_expiry' => [
				'category'       => 'Store Credits',
				'label'          => 'Store Credit Pre-Expiry Warning (30 Days Left)',
				'subject'        => 'Your {{store_credit_balance}} store credit expires in 30 days',
				'badge'          => 'Expiring Soon',
				'icon'           => 'document_verified',
				'title'          => 'Your store credit is expiring soon',
				'body_primary'   => 'A friendly reminder that your store credit balance of {{store_credit_balance}} is scheduled to expire in 30 days.',
				'body_secondary' => 'Apply your balance during checkout on any items across our catalog before it expires.',
				'cta_text'       => 'Use Credit Before It Expires',
				'type'           => 'store_credit',
				'defaults'       => [
					'customer_first_name'  => 'Alex',
					'store_credit_balance' => 'Rp 50.000',
					'expiry_date'          => date( 'F j, Y', strtotime( '+30 days' ) ),
					'shop_url'             => 'https://exacoat.com/shop/',
				],
			],
			'customer_order_review_reward' => [
				'category'       => 'Orders',
				'label'          => 'Exacoat Perks Promo Code',
				'subject'        => 'Your Exacoat Perks promo code is here',
				'badge'          => 'Exacoat Perks',
				'icon'           => 'document_verified',
				'title'          => 'Your Exacoat Perks',
				'body_primary'   => 'Thank you for sharing your experience with the Exacoat community. Here is your exclusive 20% promo code for your next order.',
				'body_secondary' => 'This promo code applies to any items across our entire catalog.',
				'cta_text'       => 'Explore The Collection',
				'type'           => 'review_reward',
				'defaults'       => [
					'customer_first_name' => 'Alex',
					'coupon_code'         => 'EXACOAT20-X8K9P',
					'discount_percent'    => '20',
					'discount_amount'     => '20%',
					'expiry_date'         => date( 'F j, Y', strtotime( '+30 days' ) ),
					'product_title'       => 'Product',
					'shop_url'            => 'https://exacoat.com/shop/',
				],
			],

			// 6. Abandoned Cart Recovery (2-Email Sequence)
			'customer_cart_abandoned_1' => [
				'category'       => 'Marketing / Cart Recovery',
				'label'          => 'Abandoned Cart Reminder (1 Hour)',
				'subject'        => 'Something was left in your bag...',
				'preheader'      => 'We saved your items and configuration before your cart clears.',
				'badge'          => 'Cart Saved',
				'icon'           => 'security',
				'title'          => 'Still on your mind?',
				'body_primary'   => 'We noticed you left your items behind. We’ve kept your selections and device configuration saved so you can pick up right where you left off.',
				'body_secondary' => 'Your items are reserved in your cart for a limited time.',
				'cta_text'       => 'Return to Checkout',
				'type'           => 'abandoned_cart',
				'defaults'       => self::get_mock_abandoned_cart_defaults( '1' ),
			],
			'customer_cart_abandoned_2' => [
				'category'       => 'Marketing / Cart Recovery',
				'label'          => 'Abandoned Cart Urgency (24 Hours)',
				'subject'        => 'Before your cart clears...',
				'preheader'      => 'Your reserved order is expiring soon. Complete your checkout before it clears.',
				'badge'          => 'Expiring Soon',
				'icon'           => 'document_verified',
				'title'          => 'Ready to complete your order?',
				'body_primary'   => 'Your selected items are still reserved, but your cart will clear soon. If you are still deciding, your setup is ready to go whenever you are.',
				'body_secondary' => 'Once the timer expires, reserved items return to public inventory.',
				'cta_text'       => 'Complete Your Order',
				'type'           => 'abandoned_cart',
				'defaults'       => self::get_mock_abandoned_cart_defaults( '2' ),
			],

			// 7. Affiliate & Creator Program Notifications
			'creator_commission_available' => [
				'category'       => 'Affiliate & Creator Program',
				'label'          => 'Commission Available to Withdraw',
				'subject'        => 'Commission Available: {{commission_amount}} from Order #{{order_number}}',
				'badge'          => 'Commission Available',
				'icon'           => 'document_verified',
				'title'          => 'Commission ready to withdraw',
				'body_primary'   => 'Order #{{order_number}} has cleared the 7-day post-delivery grace period. Your commission of {{commission_amount}} is now unlocked and available in your withdrawable balance.',
				'body_secondary' => 'You can request a payout anytime to your configured BCA or Bank Mandiri account once your balance meets the minimum threshold of Rp 250.000.',
				'cta_text'       => 'Go to Creator Workstation',
				'type'           => 'creator',
				'defaults'       => [
					'creator_name'      => 'Dimas Sampurno',
					'commission_amount' => 'Rp 74.500',
					'order_number'      => '14890',
					'unpaid_balance'    => 'Rp 324.500',
					'dashboard_url'     => 'https://exacoat.com/?portal=affiliate',
				],
			],
			'creator_commission_recorded' => [
				'category'       => 'Affiliate & Creator Program',
				'label'          => 'New Referral Sale Recorded',
				'subject'        => 'New Referral Sale Recorded: Order #{{order_number}}',
				'badge'          => 'Referral Sale',
				'icon'           => 'document_verified',
				'title'          => 'New commission earned',
				'body_primary'   => 'A customer just completed an order (#{{order_number}}) using your referral link or coupon.',
				'body_secondary' => 'Your commission of {{commission_amount}} has been recorded and will mature into your withdrawable balance 7 days after the order is delivered.',
				'cta_text'       => 'View Creator Workstation',
				'type'           => 'creator',
				'defaults'       => [
					'creator_name'      => 'Dimas Sampurno',
					'commission_amount' => 'Rp 74.500',
					'order_number'      => '14890',
					'unpaid_balance'    => 'Rp 250.000',
					'dashboard_url'     => 'https://exacoat.com/?portal=affiliate',
				],
			],
			'creator_payout_requested' => [
				'category'       => 'Affiliate & Creator Program',
				'label'          => 'Creator Payout Request Received',
				'subject'        => 'Payout Request Received: {{payout_amount}}',
				'badge'          => 'Payout Requested',
				'icon'           => 'document_verified',
				'title'          => 'Payout request received',
				'body_primary'   => 'We received your payout request for {{payout_amount}} to your {{bank_name}} account ({{bank_account_number}}). Our finance team processes payouts on a regular schedule and you will receive a confirmation once transferred.',
				'body_secondary' => 'Account Holder: {{bank_account_name}}',
				'cta_text'       => 'View Creator Workstation',
				'type'           => 'creator',
				'defaults'       => [
					'creator_name'        => 'Dimas Sampurno',
					'payout_amount'       => 'Rp 500.000',
					'bank_name'           => 'BCA',
					'bank_account_number' => '8830192831',
					'bank_account_name'   => 'Dimas Sampurno',
					'dashboard_url'       => 'https://exacoat.com/?portal=affiliate',
				],
			],
			'creator_payout_transferred' => [
				'category'       => 'Affiliate & Creator Program',
				'label'          => 'Creator Payout Transferred',
				'subject'        => 'Payout Transferred: {{payout_amount}} sent to your bank account',
				'badge'          => 'Payout Sent',
				'icon'           => 'document_verified',
				'title'          => 'Your payout is on the way',
				'body_primary'   => 'We have processed your payout request of {{payout_amount}} and transferred the funds to your {{bank_name}} account.',
				'body_secondary' => 'Account Number: {{bank_account_number}}',
				'cta_text'       => 'View Payout History',
				'type'           => 'creator',
				'defaults'       => [
					'creator_name'        => 'Dimas Sampurno',
					'payout_amount'       => 'Rp 500.000',
					'bank_name'           => 'BCA',
					'bank_account_number' => '8830192831',
					'bank_account_name'   => 'Dimas Sampurno',
					'transfer_reference'  => 'TRX-BCA-8921',
					'dashboard_url'       => 'https://exacoat.com/?portal=affiliate',
				],
			],

			// 8. Installation Warranty & RMA Notifications
			'warranty_approved' => [
				'category'       => 'Warranty & RMA',
				'label'          => 'Warranty Claim Approved (Awaiting Shipping Payment)',
				'subject'        => '[Exacoat] Klaim Garansi Pemasangan Disetujui #{{order_number}}',
				'badge'          => 'Installation Warranty & QC',
				'icon'           => 'document_verified',
				'title'          => 'Klaim Garansi Disetujui',
				'body_primary'   => 'Klaim garansi pemasangan 48 jam Exacoat Anda untuk pesanan #{{order_number}} telah ditinjau dan disetujui oleh tim Quality Control kami.',
				'body_secondary' => 'Silakan selesaikan pembayaran ongkos kirim ekspedisi kurir sebesar {{shipping_cost_fmt}} melalui tautan resmi di bawah ini agar pesanan penggantian dapat segera kami proses dan kirimkan.',
				'cta_text'       => 'Bayar Ongkos Kirim',
				'type'           => 'warranty_approved',
				'defaults'       => [
					'customer_name'       => 'Celine',
					'customer_first_name' => 'Celine',
					'order_id'            => '542699',
					'order_number'        => '542699',
					'parent_order_id'     => '2610192AB512H7',
					'parent_order_number' => '2610192AB512H7',
					'shipping_cost'       => 9000,
					'shipping_cost_fmt'   => 'Rp 9.000',
					'courier_name'        => 'SICEPAT - REG',
					'payment_url'         => 'https://exacoat.com/pay/542699?key=wc_order_demo',
					'items'               => [
						[
							'name'          => 'Samsung Galaxy S24 Ultra Skin',
							'quantity'      => 1,
							'claimed_parts' => [ 'Back' ],
							'note'          => 'Back skin misalignment',
						],
					],
				],
			],
		];
	}

	/**
	 * Helper: Mock Order Defaults for Customer Order Email Previews
	 */
	/**
	 * Helper: Mock Abandoned Cart Defaults for Email Previews
	 */
	public static function get_mock_abandoned_cart_defaults( string $sequence = '1' ): array {
		$storefront_base = function_exists( 'exacoat_storefront_url' ) ? exacoat_storefront_url() : home_url();
		return [
			'customer_first_name' => 'Alex',
			'customer_email'      => 'alex@example.com',
			'cart_token'          => 'mock_cart_token_98234',
			'restore_url'         => trailingslashit( $storefront_base ) . 'checkout/?restore_cart=mock_cart_token_98234',
			'unsubscribe_url'     => trailingslashit( $storefront_base ) . 'cart/?unsubscribe_cart=mock_cart_token_98234',
			'items'               => [
				[
					'name'          => 'iPhone 16 Pro',
					'image_url'     => 'https://media.exacoat.com/wp-content/uploads/Black-Camo-Texture-Thumbnail.jpg',
					'quantity'      => 1,
					'price'         => 'Rp 149.000',
					'meta'          => "Coverage: Model Cut\nTexture: Black Camo",
				],
			],
			'item_count'          => 1,
			'subtotal'            => 'Rp 149.000',
			'total'               => 'Rp 149.000',
			'currency'            => 'IDR',
			'sequence'            => $sequence,
		];
	}

	public static function get_mock_order_defaults( string $order_number = '14589', array $extra = [] ): array {
		return array_merge( [
			'order_number'         => $order_number,
			'customer_first_name'  => 'William',
			'currency'             => 'IDR',
			'items'                => [
				[
					'name'          => 'iPhone 16 Pro',
					'image_url'     => 'https://media.exacoat.com/wp-content/uploads/Black-Camo-Texture-Thumbnail.jpg',
					'quantity'      => 1,
					'subtotal'      => 'Rp 149.000',
					'total'         => 'Rp 149.000',
					'meta'          => "Variant: Full Body\nTexture: Matrix Black",
				],
			],
			'item_count'           => 1,
			'subtotal'             => 'Rp 149.000',
			'discount_total'       => '',
			'coupon_codes'         => [],
			'shipping_total'       => 'Rp 15.000',
			'shipping_method_name' => 'JNE Reguler',
			'total_tax'            => '',
			'total'                => 'Rp 164.000',
			'total_refunded'       => '',
			'payment_method_title' => 'Midtrans / QRIS',
			'shipping_address'     => "William Vance\nJl. Sudirman No. 42\nJakarta Selatan 12190\nIndonesia",
			'billing_address'      => "William Vance\nJl. Sudirman No. 42\nJakarta Selatan 12190\nIndonesia",
			'courier'              => 'JNE Express',
			'tracking_number'      => '',
			'tracking_url'         => '',
		], $extra );
	}

	/**
	 * Master HTML Email Renderer
	 * Generates pixel-perfect, responsive dark-mode HTML matching Artmatter's brand guidelines.
	 */
	public static function render_html( string $event, array $data = [] ): array {
		// Normalize alias event names
		$aliases = [
			'customer_order_completed' => 'customer_order_delivered',
			'commission_earned'        => 'commission_pending',
			'payout_completed'   => 'payout_sent',
			'payout_processed'   => 'payout_sent',
			'otp'                => 'artist_otp_code',
			'artist_otp'         => 'artist_otp_code',
			'welcome'            => 'artist_applied',
			'approved'           => 'artist_approved',
			'rejected'           => 'artist_rejected',
		];
		if ( isset( $aliases[ $event ] ) ) {
			$event = $aliases[ $event ];
		}

		$registry = self::get_template_registry();
		$tmpl     = $registry[ $event ] ?? $registry['artist_otp_code'];

		// Merge defaults with provided data
		$merged_data = array_merge( $tmpl['defaults'] ?? [], $data );

		$type = $tmpl['type'] ?? 'notice';

		// Branch directly to Light-Mode Customer Account Layout
		if ( $type === 'customer_account' || $type === 'otp' || in_array( $event, [ 'customer_reset_password', 'customer_new_account', 'customer_otp' ], true ) ) {
			return self::render_customer_account_html( $event, $merged_data, $tmpl );
		}

		// Branch directly to Customer Contact Confirmation Layout
		if ( $event === 'website_contact_confirmation' || $type === 'contact_confirmation' ) {
			return [
				'subject'   => sprintf( "We've received your inquiry: %s | Exacoat", $merged_data['subject'] ?? 'Contact inquiry' ),
				'html'      => class_exists( 'Exacoat_Core' ) ? Exacoat_Core::render_contact_confirmation_html( [
					'name'         => $merged_data['name'] ?? ( $merged_data['customer_name'] ?? 'Customer' ),
					'topic_label'  => $merged_data['topic_label'] ?? 'General inquiry',
					'subject'      => $merged_data['subject'] ?? 'Contact inquiry',
					'order_number' => $merged_data['order_number'] ?? '',
					'message'      => $merged_data['message'] ?? '',
				] ) : '',
				'tmpl_info' => $tmpl,
			];
		}

		// Branch directly to Light-Mode Custom Poster Order Layout
		if ( $event === 'custom_order_link' || $type === 'custom_order' || $type === 'custom_order_link' ) {
			return self::render_custom_poster_order_html( $event, $merged_data, $tmpl );
		}

		// Branch directly to Product Review Invitation Layout
		if ( $event === 'customer_order_review_invitation' || $type === 'review_invitation' ) {
			return self::render_review_invitation_html( $event, $merged_data, $tmpl );
		}

		// Branch directly to Light-Mode Store Credit / Cashback Layout
		if ( $type === 'store_credit' || in_array( $event, [ 'customer_cashback_earned', 'customer_store_credit_reminder', 'customer_store_credit_pre_expiry' ], true ) ) {
			return self::render_store_credit_html( $event, $merged_data, $tmpl );
		}

		// Branch directly to Exacoat Perks Promo Code Reward Layout
		if ( $event === 'customer_order_review_reward' || $type === 'review_reward' ) {
			return self::render_review_reward_html( $event, $merged_data, $tmpl );
		}

		// Branch directly to Abandoned Cart Recovery Layout
		if ( $type === 'abandoned_cart' || str_starts_with( $event, 'customer_cart_abandoned_' ) ) {
			return self::render_abandoned_cart_html( $event, $merged_data, $tmpl );
		}

		// Branch directly to Light-Mode Customer Order Layout for customer orders
		if ( $type === 'customer_order' || str_starts_with( $event, 'customer_order_' ) ) {
			return self::render_customer_order_html( $event, $merged_data, $tmpl );
		}

		// Branch directly to Creator / Affiliate Program Layout
		if ( $type === 'creator' || str_starts_with( $event, 'creator_' ) || str_starts_with( $event, 'affiliate_' ) ) {
			return self::render_creator_email_html( $event, $merged_data, $tmpl );
		}

		// Branch directly to Warranty Claim Approved Layout
		if ( $event === 'warranty_approved' || $type === 'warranty_approved' ) {
			return self::render_warranty_approved_html( $merged_data, $tmpl );
		}

		$customer_name = esc_html( $merged_data['customer_name'] ?? $merged_data['display_name'] ?? 'Customer' );
		$badge_text    = esc_html( $merged_data['badge_text'] ?? $tmpl['badge'] ?? 'Exacoat' );
		$title         = esc_html( $merged_data['title'] ?? $tmpl['title'] ?? 'Notification' );
		$icon_url      = self::resolve_icon_url( $merged_data['icon_image'] ?? $tmpl['icon'] ?? 'security' );
		$body_primary  = $merged_data['body_primary'] ?? $tmpl['body_primary'] ?? '';
		$body_secondary= $merged_data['body_secondary'] ?? $tmpl['body_secondary'] ?? '';
		$body_additional=$merged_data['body_additional'] ?? $tmpl['body_additional'] ?? '';
		$type          = $tmpl['type'] ?? 'notice';

		// Dynamically build replacement map for ALL scalar keys in $merged_data (supports both {{key}} and {key})
		$replacements = [];
		foreach ( $merged_data as $k => $v ) {
			if ( is_scalar( $v ) ) {
				$val_str = (string) $v;
				$replacements[ '{{' . $k . '}}' ] = $val_str;
				$replacements[ '{' . $k . '}' ]   = $val_str;
			}
		}

		// Ensure primary canonical fallbacks
		if ( ! isset( $replacements['{{customer_name}}'] ) ) {
			$replacements['{{customer_name}}'] = $customer_name;
			$replacements['{customer_name}']   = $customer_name;
		}
		if ( ! empty( $merged_data['order_code'] ) ) {
			$replacements['{{order_code}}'] = (string) $merged_data['order_code'];
			$replacements['{order_code}']   = (string) $merged_data['order_code'];
		}

		$subject         = str_replace( array_keys( $replacements ), array_values( $replacements ), $tmpl['subject'] );
		$title           = str_replace( array_keys( $replacements ), array_values( $replacements ), $title );
		$body_primary    = str_replace( array_keys( $replacements ), array_values( $replacements ), $body_primary );
		$body_secondary  = str_replace( array_keys( $replacements ), array_values( $replacements ), $body_secondary );
		$body_additional = str_replace( array_keys( $replacements ), array_values( $replacements ), $body_additional );

		// Clean up any remaining orphan {{tags}} and dangling # symbols in text components
		$tag_pattern     = '/\{\{[a-zA-Z0-9_-]+\}\}|\{[a-zA-Z0-9_-]+\}/';
		$subject         = preg_replace( $tag_pattern, '', $subject );
		$subject         = preg_replace( '/\(\s*#\s*\)/', '', $subject );
		$subject         = preg_replace( '/#(?=\s|$)/', '', $subject );
		$subject         = preg_replace( '/\s{2,}/', ' ', trim( $subject ) );

		$title           = preg_replace( $tag_pattern, '', $title );
		$title           = preg_replace( '/\s{2,}/', ' ', trim( $title ) );
		$body_primary    = preg_replace( $tag_pattern, '', $body_primary );
		$body_secondary  = preg_replace( $tag_pattern, '', $body_secondary );
		$body_additional = preg_replace( $tag_pattern, '', $body_additional );

		// Render Type-Specific Content Slot
		$slot_html = '';

		if ( $type === 'otp' ) {
			$otp_code = esc_html( $merged_data['otp_code'] ?? '849201' );
			$slot_html = "
			<tr>
				<td align=\"center\" style=\"padding:0 36px 28px;\" class=\"mobile-padding\">
					<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"background:#fafafa;border:1px solid #eaeaea;border-radius:16px;\">
						<tbody>
							<tr>
								<td align=\"center\" style=\"padding:28px 20px 8px;\">
									<span style=\"color:#111111;font-size:40px;display:inline-block;font-weight:800;letter-spacing:12px;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;\">{$otp_code}</span>
								</td>
							</tr>
							<tr>
								<td align=\"center\" style=\"padding:0 20px 24px;\">
									<p style=\"margin:0;font-size:12.5px;color:#71717a;font-family:'Plus Jakarta Sans',sans-serif;\">This code is valid for <b>5 minutes</b></p>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
			</tr>";
		} elseif ( $type === 'commission' ) {
			$art_img   = esc_url( $merged_data['artwork_image'] ?? '' );
			$art_title = esc_html( $merged_data['product_title'] ?? ( $merged_data['artwork_title'] ?? 'Exacoat Product' ) );
			$quantity  = intval( $merged_data['quantity'] ?? 1 );
			$comm_stat = esc_html( $merged_data['commission_status'] ?? 'Pending' );
			$comm_amt  = esc_html( $merged_data['commission_amount'] ?? '$15.00' );

			$img_tr = '';
			if ( $art_img ) {
				$img_tr = "
							<tr>
								<td align=\"center\" style=\"padding:20px 20px 0;\">
									<img src=\"{$art_img}\" alt=\"{$art_title}\" style=\"width:100%;max-width:380px;height:auto;border-radius:12px;display:block;\">
								</td>
							</tr>";
			}

			$slot_html = "
			<tr>
				<td align=\"center\" style=\"padding:0 36px 28px;\" class=\"mobile-padding\">
					<table width=\"100%\" style=\"background:#fafafa;border:1px solid #eaeaea;border-radius:16px;overflow:hidden;\">
						<tbody>
							{$img_tr}
							<tr>
								<td align=\"center\" style=\"padding:20px 20px 24px;\">
									<p style=\"margin:0 0 6px;font-size:16px;font-weight:700;color:#111111;\">{$art_title}</p>
									<p style=\"margin:0 0 16px;font-size:13px;color:#71717a;\">Quantity: {$quantity}</p>
									<table cellpadding=\"0\" cellspacing=\"0\" align=\"center\">
										<tbody>
											<tr>
												<td style=\"padding:5px 12px;font-size:11px;font-weight:600;background:#f4f4f5;color:#52525b;border-radius:999px;border:1px solid #e4e4e7;\">
													{$comm_stat}
												</td>
												<td style=\"padding-left:8px;\"></td>
												<td style=\"padding:5px 14px;font-size:12px;font-weight:700;background:#111111;color:#ffffff;border-radius:999px;\">
													{$comm_amt}
												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
			</tr>
			<tr>
				<td align=\"center\" style=\"padding:0 36px 20px;\" class=\"mobile-padding\">
					<a href=\"https://exacoat.com\" target=\"_blank\" style=\"display:inline-block;padding:13px 28px;font-size:14px;font-weight:600;color:#ffffff;background:#111111;border-radius:100px;text-decoration:none;\">
						View Dashboard &rarr;
					</a>
				</td>
			</tr>";
		} elseif ( $type === 'artwork_rejection' ) {
			$art_img   = esc_url( $merged_data['artwork_image'] ?? '' );
			$art_title = esc_html( $merged_data['product_title'] ?? ( $merged_data['artwork_title'] ?? 'Exacoat Product' ) );
			$reason    = esc_html( $merged_data['rejection_reason'] ?? 'Submission does not meet curation criteria.' );
			$cta_text  = esc_html( $tmpl['cta_text'] ?? 'Go to Dashboard' );
			$cta_url   = esc_url( $tmpl['cta_url'] ?? 'https://exacoat.com' );

			$img_html = '';
			if ( ! empty( $art_img ) ) {
				$img_html = "
				<tr>
					<td align=\"center\" style=\"padding:20px 20px 0;\">
						<img src=\"{$art_img}\" alt=\"{$art_title}\" style=\"width:100%;max-width:380px;height:auto;border-radius:12px;display:block;\">
					</td>
				</tr>";
			}

			$slot_html = "
			<tr>
				<td align=\"center\" style=\"padding:0 36px 24px;\" class=\"mobile-padding\">
					<table width=\"100%\" style=\"background:#fafafa;border:1px solid #eaeaea;border-radius:16px;overflow:hidden;\">
						<tbody>
							{$img_html}
							<tr>
								<td align=\"center\" style=\"padding:18px 20px 14px;\">
									<p style=\"margin:0 0 8px;font-size:16px;font-weight:700;color:#111111;\">{$art_title}</p>
									<span style=\"display:inline-block;padding:4px 12px;font-size:11px;font-weight:700;background:#fee2e2;color:#dc2626;border-radius:999px;text-transform:uppercase;letter-spacing:0.5px;\">Declined / Not Approved</span>
								</td>
							</tr>
							<tr>
								<td style=\"padding:0 20px 20px;\">
									<div style=\"background:#ffffff;border:1px solid #fee2e2;border-left:3px solid #ef4444;border-radius:8px;padding:14px 16px;text-align:left;\">
										<p style=\"margin:0 0 4px;font-size:11px;font-weight:700;color:#dc2626;text-transform:uppercase;letter-spacing:0.5px;\">Feedback:</p>
										<p style=\"margin:0;font-size:13px;line-height:1.6;color:#52525b;\">{$reason}</p>
									</div>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
			</tr>
			<tr>
				<td align=\"center\" style=\"padding:0 36px 20px;\" class=\"mobile-padding\">
					<a href=\"{$cta_url}\" target=\"_blank\" style=\"display:inline-block;padding:13px 28px;font-size:14px;font-weight:600;color:#ffffff;background:#111111;border-radius:100px;text-decoration:none;\">
						{$cta_text} &rarr;
					</a>
				</td>
			</tr>";
		} elseif ( $type === 'action_list' ) {
			$cta_text = esc_html( $tmpl['cta_text'] ?? 'Go to Store' );
			$cta_url  = esc_url( $tmpl['cta_url'] ?? 'https://exacoat.com' );
			$sec_text = ! empty( $tmpl['secondary_link_text'] ) ? esc_html( $tmpl['secondary_link_text'] ) : '';
			$sec_url  = ! empty( $merged_data['artist_page_url'] ) ? esc_url( $merged_data['artist_page_url'] ) : ( ! empty( $tmpl['secondary_link_url'] ) ? esc_url( $tmpl['secondary_link_url'] ) : '' );

			$checklist_items = '';
			if ( ! empty( $tmpl['checklist'] ) && is_array( $tmpl['checklist'] ) ) {
				foreach ( $tmpl['checklist'] as $item ) {
					$checklist_items .= "<li style=\"margin-bottom:8px;\">" . esc_html( $item ) . "</li>";
				}
			}

			$checklist_title = esc_html( $tmpl['checklist_title'] ?? 'What you can do next' );

			$slot_html = "
			<tr>
				<td align=\"center\" style=\"padding:0 36px 28px;\" class=\"mobile-padding\">
					<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" align=\"center\">
						<tbody>
							<tr>
								<td align=\"center\">
									<a href=\"{$cta_url}\" target=\"_blank\" style=\"display:inline-block;padding:13px 28px;font-size:14px;font-weight:600;color:#ffffff;background:#111111;text-decoration:none;border-radius:100px;\">
										{$cta_text} &rarr;
									</a>
								</td>
							</tr>
						</tbody>
					</table>";

			if ( $sec_text && $sec_url ) {
				$slot_html .= "
					<p style=\"margin:12px 0 0 0;\">
						<span style=\"font-size:13px;color:#71717a;\">or <a href=\"{$sec_url}\" style=\"color:#111111;text-decoration:underline;font-weight:500;\">" . esc_html( str_replace( 'or ', '', $sec_text ) ) . "</a></span>
					</p>";
			}

			if ( $checklist_items ) {
				$slot_html .= "
					<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" style=\"margin-top:24px;background-color:#fafafa;border:1px solid #eaeaea;border-radius:16px;\">
						<tbody>
							<tr>
								<td style=\"padding:22px 24px;text-align:left;\">
									<p style=\"margin:0 0 10px 0;font-weight:700;font-size:14px;color:#111111;\">{$checklist_title}</p>
									<ul style=\"margin:0;padding-left:18px;font-size:13.5px;line-height:1.65;color:#52525b;\">
										{$checklist_items}
									</ul>
								</td>
							</tr>
						</tbody>
					</table>";
			}

			$slot_html .= "</td></tr>";
		} elseif ( $type === 'payout' ) {
			$payout_amt  = esc_html( $merged_data['payout_amount'] ?? '$71.73' );
			$payout_rec  = esc_html( $merged_data['payout_record_id'] ?? $merged_data['payout_id'] ?? 'P-8108' );
			$payout_meth = esc_html( $merged_data['payout_method'] ?? 'Bank Transfer' );
			$cta_url     = esc_url( $tmpl['cta_url'] ?? 'https://exacoat.com' );
			$cta_text    = esc_html( $tmpl['cta_text'] ?? 'View Statement' );

			$slot_html = "
			<tr>
				<td align=\"center\" style=\"padding:0 36px 28px;\" class=\"mobile-padding\">
					<table width=\"100%\" style=\"background:#fafafa;border:1px solid #eaeaea;border-radius:16px;overflow:hidden;\">
						<tbody>
							<tr>
								<td align=\"center\" style=\"padding:28px 20px 24px;\">
									<p style=\"margin:0 0 4px;font-size:11px;color:#71717a;text-transform:uppercase;letter-spacing:0.8px;font-weight:600;\">Total Settlement Transferred</p>
									<p style=\"margin:0 0 16px;font-size:36px;font-weight:800;color:#111111;letter-spacing:-0.5px;\">{$payout_amt}</p>
									<table cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"font-size:12px;\">
										<tbody>
											<tr>
												<td style=\"padding:6px 12px;background:#f4f4f5;color:#52525b;border-radius:999px;font-family:monospace;border:1px solid #e4e4e7;\">
													Payout ID: <b>{$payout_rec}</b>
												</td>
												<td style=\"padding-left:8px;\"></td>
												<td style=\"padding:6px 12px;background:#e0f2fe;color:#0369a1;border-radius:999px;font-weight:600;\">
													{$payout_meth}
												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
			</tr>
			<tr>
				<td align=\"center\" style=\"padding:0 36px 20px;\" class=\"mobile-padding\">
					<a href=\"{$cta_url}\" target=\"_blank\" style=\"display:inline-block;padding:13px 28px;font-size:14px;font-weight:600;color:#ffffff;background:#111111;border-radius:100px;text-decoration:none;\">
						{$cta_text} &rarr;
					</a>
				</td>
			</tr>";
		} elseif ( $type === 'custom_order' ) {
			$art_img    = esc_url( $merged_data['artwork_image'] ?? '' );
			$order_code = esc_html( $merged_data['order_code'] ?? 'CUSTOM' );
			$order_url  = esc_url( $merged_data['order_url'] ?? ( home_url( '/product/custom-order-' . strtolower( $order_code ) ) ) );
			$cta_text   = esc_html( $tmpl['cta_text'] ?? 'Complete Custom Order' );

			$slot_html = "
			<tr>
				<td align=\"center\" style=\"padding:0 36px 28px;\" class=\"mobile-padding\">
					<table width=\"100%\" style=\"background:#fafafa;border:1px solid #eaeaea;border-radius:16px;overflow:hidden;\">
						<tbody>";
			if ( $art_img ) {
				$slot_html .= "
							<tr>
								<td align=\"center\" style=\"padding:20px 20px 0;\">
									<img src=\"{$art_img}\" alt=\"Custom Order #{$order_code}\" style=\"width:100%;max-width:380px;height:auto;border-radius:12px;display:block;\">
								</td>
							</tr>";
			}
			$slot_html .= "
							<tr>
								<td align=\"center\" style=\"padding:20px 20px 24px;\">
									<p style=\"margin:0 0 4px;font-size:11px;color:#71717a;text-transform:uppercase;letter-spacing:0.8px;font-weight:600;\">Order Code</p>
									<p style=\"margin:0 0 16px;font-size:24px;font-weight:800;color:#111111;letter-spacing:1px;font-family:monospace;\">#{$order_code}</p>
									<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" align=\"center\">
										<tbody>
											<tr>
												<td align=\"center\">
													<a href=\"{$order_url}\" target=\"_blank\" style=\"display:inline-block;padding:13px 28px;font-size:14px;font-weight:600;color:#111111;background:#f3aa18;text-decoration:none;border-radius:100px;\">
														{$cta_text} &rarr;
													</a>
												</td>
											</tr>
										</tbody>
									</table>
									<p style=\"margin:16px 0 0;font-size:12px;color:#71717a;\">
										Link expires in 48 hours: <a href=\"{$order_url}\" style=\"color:#111111;text-decoration:underline;\">{$order_url}</a>
									</p>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
			</tr>";
		}

		$secondary_p  = $body_secondary ? "<p style=\"margin:0 0 16px;font-size:14.5px;line-height:1.7;color:#52525b;\">{$body_secondary}</p>" : '';
		$additional_p = $body_additional ? "<tr><td align=\"center\" style=\"padding:0 36px 24px;\" class=\"mobile-padding\"><p style=\"margin:0;font-size:13px;line-height:1.6;color:#71717a;\">{$body_additional}</p></td></tr>" : '';

		// Assemble Full Responsive Modern Light Transactional HTML
		$html = "<!doctype html>
<html lang=\"en\" xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:o=\"urn:schemas-microsoft-com:office:office\">
<head>
  <meta charset=\"utf-8\">
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
  <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
  <title>" . esc_html( $subject ) . "</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
    body {
      margin: 0;
      padding: 0;
      width: 100% !important;
      -webkit-text-size-adjust: 100%;
      -ms-text-size-adjust: 100%;
      background-color: #f7f7f7;
      font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      -webkit-font-smoothing: antialiased;
    }
    table {
      border-collapse: collapse;
      mso-table-lspace: 0pt;
      mso-table-rspace: 0pt;
    }
    img {
      border: 0;
      outline: none;
      text-decoration: none;
      display: block;
    }
    a[x-apple-data-detectors],
    u+#body a,
    #MessageViewBody a {
      color: inherit !important;
      text-decoration: none !important;
    }
    @media screen and (max-width: 600px) {
      .mobile-padding {
        padding-left: 20px !important;
        padding-right: 20px !important;
      }
      .h1-mobile {
        font-size: 22px !important;
        line-height: 28px !important;
      }
    }
  </style>
</head>
<body bgcolor=\"#f7f7f7\">
  <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" bgcolor=\"#f7f7f7\" style=\"border-collapse:collapse;background-color:#f7f7f7;\">
    <tbody>
      <tr>
        <td height=\"40\" style=\"height:40px;line-height:40px;font-size:0;mso-line-height-rule:exactly;\">&nbsp;</td>
      </tr>
      <tr>
        <td align=\"center\" style=\"padding:0 16px;\">
          <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" style=\"max-width:600px;background-color:#ffffff;border:1px solid #e5e5e5;border-radius:20px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,0.04);\" bgcolor=\"#ffffff\">
            <tbody>
              <!-- Header: Logo & Badge -->
              <tr>
                <td style=\"padding:28px 36px 24px;border-bottom:1px solid #f0f0f0;\" class=\"mobile-padding\">
                  <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
                    <tr>
                      <td align=\"left\" valign=\"middle\">
                        " . self::get_brand_logo_html() . "
                      </td>
                      <td align=\"right\" valign=\"middle\">
                        <span style=\"display:inline-block;padding:6px 14px;background:#f4f4f5;border:1px solid #e4e4e7;border-radius:999px;font-size:11px;font-weight:600;color:#52525b;text-transform:uppercase;letter-spacing:0.5px;\">
                          {$badge_text}
                        </span>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>

              <!-- Main Content -->
              <tr>
                <td style=\"padding:36px 36px 28px;\" class=\"mobile-padding\">
                  <h1 class=\"h1-mobile\" style=\"margin:0 0 16px;font-size:26px;font-weight:800;color:#111111;letter-spacing:-0.6px;line-height:1.25;\">
                    {$title}
                  </h1>
                  <p style=\"margin:0 0 14px;font-size:15px;font-weight:600;color:#111111;\">Hi {$customer_name},</p>
                  <p style=\"margin:0 0 16px;font-size:14.5px;line-height:1.7;color:#3f3f46;\">{$body_primary}</p>
                  {$secondary_p}
                </td>
              </tr>

              <!-- Dynamic Content Slot -->
              {$slot_html}
              {$additional_p}

              <!-- Support & Copyright Footer -->
              <tr>
                <td style=\"padding:24px 36px 28px;background:#ffffff;border-top:1px solid #f0f0f0;text-align:center;\" class=\"mobile-padding\">
                  <p style=\"margin:0 0 8px;font-size:12px;line-height:1.65;color:#71717a;\">
                    Have questions or need help?<br>
                    Reach our team at <a href=\"mailto:support@exacoat.com\" style=\"color:#111111;text-decoration:underline;font-weight:500;\">support@exacoat.com</a>
                  </p>
                  <p style=\"margin:0;font-size:11px;color:#a1a1aa;letter-spacing:0.2px;\">
                    &copy; Exacoat. All rights reserved.
                  </p>
                </td>
              </tr>
            </tbody>
          </table>

          <!-- Outer Legal Note -->
          <table width=\"600\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" style=\"max-width:600px;margin-top:24px;\">
            <tbody>
              <tr>
                <td align=\"center\">
                  <p style=\"margin:0;font-size:12px;color:#a1a1aa;\">You&rsquo;re receiving this email regarding your Exacoat account.</p>
                </td>
              </tr>
            </tbody>
          </table>
        </td>
      </tr>
      <tr>
        <td height=\"40\" style=\"height:40px;line-height:40px;font-size:0;mso-line-height-rule:exactly;\">&nbsp;</td>
      </tr>
    </tbody>
  </table>
</body>
</html>";

		// Final Safety: Replace any stray unsubscribe tags with valid cart link before stripping orphan tags
		$storefront_base = function_exists( 'exacoat_storefront_url' ) ? exacoat_storefront_url() : home_url();
		$cart_unsub_url  = trailingslashit( $storefront_base ) . 'cart/';
		$html = preg_replace( '/(?:https?:\/\/)?(?:%7B%7B|\{\{)\s*(?:unsubscribe_url|unsubscribe)\s*(?:%7D%7D|\}\})\/?/i', $cart_unsub_url, $html );
		$html = preg_replace( '/(?:https?:\/\/)?\{\s*(?:unsubscribe_url|unsubscribe)\s*\}\/?/i', $cart_unsub_url, $html );
		$html = str_replace( '*|UNSUBSCRIBE_URL|*', $cart_unsub_url, $html );

		// Final Pass: Ensure ZERO raw template tags exist anywhere in output HTML or Subject
		$html    = preg_replace( '/\{\{[a-zA-Z0-9_-]+\}\}|\{[a-zA-Z0-9_-]+\}/', '', $html );
		$subject = preg_replace( '/\{\{[a-zA-Z0-9_-]+\}\}|\{[a-zA-Z0-9_-]+\}/', '', $subject );
		$subject = preg_replace( '/\(\s*#\s*\)/', '', $subject );
		$subject = preg_replace( '/#(?=\s|$)/', '', $subject );
		$subject = preg_replace( '/\s{2,}/', ' ', trim( $subject ) );

		return [
			'subject'  => $subject,
			'html'     => $html,
			'tmpl_info'=> $tmpl,
		];
	}

	/**
	 * Generate Official Settlement Statement HTML Document
	 */
	public static function generate_payout_statement_html( array $data ): string {
		$payout_id     = esc_html( $data['payout_id'] ?? 'PO-8108' );
		$artist_name   = esc_html( $data['artist_name'] ?? ( $data['artist_username'] ?? 'Vendor / Beneficiary' ) );
		$amount        = esc_html( $data['payout_amount'] ?? '$0.00' );
		$method        = esc_html( $data['payout_method'] ?? 'Bank Transfer / PayPal' );
		$destination   = esc_html( $data['payout_destination'] ?? 'Account on file' );
		$date          = esc_html( $data['processed_date'] ?? date( 'F j, Y' ) );

		return "<!DOCTYPE html>
		<html>
		<head>
			<meta charset=\"utf-8\">
			<title>Payout Settlement Statement - {$payout_id}</title>
			<link href=\"https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&display=swap\" rel=\"stylesheet\">
			<style>
				body { font-family: 'Inter', sans-serif; margin: 0; padding: 30px; color: #111827; background: #ffffff; }
				.box { max-width: 700px; margin: 0 auto; border: 1px solid #e5e7eb; border-radius: 12px; padding: 28px; background: #ffffff; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
				.header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #111827; padding-bottom: 18px; margin-bottom: 20px; }
				.badge { background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; padding: 4px 10px; border-radius: 6px; font-size: 11px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; }
				.row { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #f3f4f6; font-size: 13px; }
				.grand-box { background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 8px; padding: 18px; margin: 24px 0; display: flex; justify-content: space-between; align-items: center; }
			</style>
		</head>
		<body>
			<div class=\"box\">
				<div class=\"header\">
					<div>
						<img src=\"" . esc_url( self::get_brand_logo_url() ) . "\" alt=\"Exacoat\" style=\"height:22px;display:block;margin-bottom:6px;\" />
						<div style=\"font-size:11px;color:#4b5563;font-weight:500;\">Exacoat Operations &bull; Settlement Statement</div>
						<div style=\"font-size:11px;color:#4b5563;\">support@exacoat.com &bull; https://exacoat.com</div>
					</div>
					<div style=\"text-align:right;\">
						<div style=\"font-size:18px;font-weight:900;text-transform:uppercase;\">PAYOUT STATEMENT</div>
						<div style=\"font-size:11.5px;color:#4b5563;font-family:monospace;margin-top:2px;\">#{$payout_id}</div>
						<div style=\"margin-top:6px;\"><span class=\"badge\">&#10003; SETTLEMENT COMPLETED</span></div>
					</div>
				</div>
				<div style=\"margin-bottom:20px;\">
					<div class=\"row\"><span style=\"color:#6b7280;font-weight:600;\">Vendor / Beneficiary:</span><strong style=\"color:#111827;\">{$artist_name}</strong></div>
					<div class=\"row\"><span style=\"color:#6b7280;font-weight:600;\">Settlement Date:</span><strong style=\"color:#111827;\">{$date}</strong></div>
					<div class=\"row\"><span style=\"color:#6b7280;font-weight:600;\">Payment Channel:</span><strong style=\"color:#111827;\">{$method}</strong></div>
					<div class=\"row\"><span style=\"color:#6b7280;font-weight:600;\">Account Destination:</span><strong style=\"font-family:monospace;color:#111827;\">{$destination}</strong></div>
				</div>
				<div class=\"grand-box\">
					<span style=\"font-weight:800;font-size:14px;color:#111827;\">Total Net Commission Transferred:</span>
					<span style=\"font-size:22px;font-weight:900;color:#059669;font-family:monospace;\">{$amount}</span>
				</div>
				<div style=\"font-size:11px;color:#6b7280;text-align:center;margin-top:20px;border-top:1px solid #e5e7eb;padding-top:14px;\">
					Exacoat Core Platform &bull; Certified Operations Engine &bull; support@exacoat.com
				</div>
			</div>
		</body>
		</html>";
	}

	/**
	 * Render Professional Light-Mode Customer Order Transactional Email
	 */
	public static function render_customer_order_html( string $event, array $data, array $tmpl ): array {
		$price_keys = [ 'subtotal', 'discount_total', 'discount_tax', 'shipping_total', 'shipping_tax', 'total_tax', 'total', 'total_refunded', 'refund_amount' ];
		foreach ( $price_keys as $pk ) {
			if ( isset( $data[ $pk ] ) ) {
				$data[ $pk ] = self::clean_email_price( $data[ $pk ] );
			}
		}

		$replacements = [];
		foreach ( $data as $k => $v ) {
			if ( is_scalar( $v ) ) {
				$val_str = (string) $v;
				$replacements[ '{{' . $k . '}}' ] = $val_str;
				$replacements[ '{' . $k . '}' ]   = $val_str;
			}
		}

		$order_num = esc_html( $data['order_number'] ?? '14589' );
		$cust_name = esc_html( $data['customer_first_name'] ?? ( $data['artist_name'] ?? 'Customer' ) );
		$badge_text = esc_html( $data['badge_text'] ?? $tmpl['badge'] ?? "Order #{$order_num}" );
		$title      = esc_html( $data['title'] ?? $tmpl['title'] ?? 'Order Update' );

		$subject         = str_replace( array_keys( $replacements ), array_values( $replacements ), $tmpl['subject'] );
		$title           = str_replace( array_keys( $replacements ), array_values( $replacements ), $title );
		$body_primary    = str_replace( array_keys( $replacements ), array_values( $replacements ), $tmpl['body_primary'] ?? '' );
		$body_secondary  = str_replace( array_keys( $replacements ), array_values( $replacements ), $tmpl['body_secondary'] ?? '' );

		// Clean up orphan tags
		$tag_pattern = '/\{\{[a-zA-Z0-9_-]+\}\}|\{[a-zA-Z0-9_-]+\}/';
		$subject     = preg_replace( $tag_pattern, '', $subject );
		$subject     = preg_replace( '/\s{2,}/', ' ', trim( $subject ) );
		$title       = preg_replace( $tag_pattern, '', $title );
		$body_primary= preg_replace( $tag_pattern, '', $body_primary );
		$body_secondary = preg_replace( $tag_pattern, '', $body_secondary );

		$preheader = $tmpl['preheader'] ?? $data['preheader'] ?? '';
		if ( ! empty( $preheader ) ) {
			$preheader = str_replace( array_keys( $replacements ), array_values( $replacements ), $preheader );
			$preheader = preg_replace( $tag_pattern, '', $preheader );
		}

		$is_store_pickup = ! empty( $tmpl['is_store_pickup'] ) || ! empty( $data['is_store_pickup'] );

		$pickup_action_html = '';
		if ( ! empty( $tmpl['pickup_ready'] ) || ! empty( $data['pickup_ready'] ) ) {
			$pickup_action_html = '
			<table width="100%" cellpadding="0" cellspacing="0" style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:16px;margin:24px 0;">
				<tr>
					<td style="padding:22px 24px;">
						<p style="margin:0 0 4px;font-size:16px;font-weight:700;color:#111827;letter-spacing:-0.2px;">Exacoat Store Bekasi</p>
						<p style="margin:0 0 16px;font-size:13.5px;color:#4b5563;line-height:1.5;">Ruby Commercial TB-12, Summarecon Bekasi, Bekasi Utara</p>
						<a href="https://maps.app.goo.gl/B9Z2n98o5kM33k4q9" target="_blank" style="display:inline-block;padding:10px 20px;background:#111111;color:#ffffff;font-size:13px;font-weight:600;border-radius:100px;text-decoration:none;letter-spacing:0.2px;">Open in Google Maps &rarr;</a>
					</td>
				</tr>
			</table>
			<p style="margin:16px 0 0;font-size:13px;color:#71717a;">Need help? <a href="https://exacoat.com/cs" style="color:#f3aa18;text-decoration:underline;font-weight:600;">Contact admin</a></p>';
		} elseif ( ! empty( $tmpl['pickup_review'] ) || ! empty( $data['pickup_review'] ) ) {
			$pickup_action_html = '
			<table width="100%" cellpadding="0" cellspacing="0" style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:16px;margin:24px 0;">
				<tr>
					<td style="padding:24px;text-align:center;">
						<p style="margin:0 0 16px;font-size:14.5px;color:#374151;font-weight:500;">Leave a review and tell us about your experience!</p>
						<a href="https://g.page/r/CZZ440l0WvPWEBM/review" target="_blank" style="display:inline-block;padding:12px 28px;background:#111111;color:#ffffff;font-size:13.5px;font-weight:700;border-radius:100px;text-decoration:none;letter-spacing:0.2px;">Write a review &rarr;</a>
					</td>
				</tr>
			</table>
			<p style="margin:16px 0 0;font-size:13px;color:#71717a;text-align:center;">Need help? <a href="https://exacoat.com/cs" style="color:#f3aa18;text-decoration:underline;font-weight:600;">Contact admin</a></p>';
		}

		$clean_email_note = trim( preg_replace( '/(?:shipping courier|jasa kirim|courier)\s*:\s*[^\r\n]+/i', '', (string) ( $data['customer_note'] ?? '' ) ) );
		if ( ! empty( $clean_email_note ) ) {
			$note_content = esc_html( $clean_email_note );
			$body_secondary .= "
			<div style=\"background:#fafafa;border:1px solid #e5e7eb;border-left:3px solid #111111;padding:14px 18px;border-radius:0 12px 12px 0;margin:16px 0;font-size:14px;color:#18181b;line-height:1.6;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">
				{$note_content}
			</div>";
		}

		$courier         = esc_html( $data['courier'] ?? '' );
		$tracking_number = esc_html( $data['tracking_number'] ?? '' );

		// Always direct customers to Exacoat's native /track page prefilled with their order details
		$track_order_id    = $data['order_id'] ?? ( $data['order_number'] ?? '' );
		$track_order_email = $data['customer_email'] ?? ( $data['billing_email'] ?? '' );
		$track_order_key   = $data['order_key'] ?? '';

		$native_track_url = '';
		if ( ! empty( $track_order_id ) ) {
			$track_base = function_exists( 'exacoat_storefront_url' ) ? exacoat_storefront_url( 'track' ) : 'https://exacoat.com/track';
			$native_track_url = add_query_arg( array_filter( [
				'order_id'    => ltrim( (string) $track_order_id, '#' ),
				'order_email' => $track_order_email,
				'key'         => $track_order_key,
			] ), $track_base );
		}

		$raw_tracking_url = ! empty( $data['tracking_url'] ) ? (string) $data['tracking_url'] : '';
		$is_cms_or_internal = ! empty( $raw_tracking_url ) && (
			stripos( $raw_tracking_url, 'cms.exacoat.com' ) !== false
			|| stripos( $raw_tracking_url, 'order-received' ) !== false
			|| stripos( $raw_tracking_url, 'artmatter' ) !== false
			|| stripos( $raw_tracking_url, 'checkout' ) !== false
		);
		$is_external_portal = ! empty( $raw_tracking_url ) && (
			stripos( $raw_tracking_url, 'parcelsapp.com' ) !== false
			|| stripos( $raw_tracking_url, 'jne.co.id' ) !== false
			|| stripos( $raw_tracking_url, 'biteship.com' ) !== false
			|| stripos( $raw_tracking_url, 'sicepat.com' ) !== false
			|| stripos( $raw_tracking_url, '17track.net' ) !== false
			|| stripos( $raw_tracking_url, 'trackingmore.com' ) !== false
		);

		// Strictly point to native Exacoat /track page whenever order details exist; sanitize away all CMS / internal URLs
		if ( ! empty( $native_track_url ) ) {
			$tracking_url = esc_url( $native_track_url );
		} elseif ( ! empty( $raw_tracking_url ) && ! $is_cms_or_internal && ! $is_external_portal ) {
			$tracking_url = esc_url( $raw_tracking_url );
		} else {
			$tracking_url = esc_url( function_exists( 'exacoat_storefront_url' ) ? exacoat_storefront_url( 'track' ) : 'https://exacoat.com/track' );
		}

		// Shipment Block (strictly ONLY shown in emails when order has shipped)
		$is_shipped_email = in_array( $event, [ 'customer_order_shipped', 'customer_completed_order' ], true )
			|| ! empty( $tmpl['show_shipment'] )
			|| ! empty( $data['is_shipped'] );

		$shipment_html = '';
		if ( $is_shipped_email && ! empty( $tracking_number ) ) {
			$track_btn = $tracking_url 
				? "<a href=\"{$tracking_url}\" target=\"_blank\" style=\"display:inline-block;padding:11px 22px;background:#111111;color:#ffffff;font-size:13px;font-weight:600;border-radius:100px;text-decoration:none;letter-spacing:0.2px;box-shadow:0 2px 6px rgba(0,0,0,0.08);white-space:nowrap;\">Track Package &rarr;</a>"
				: "";

			$shipment_html = "
			<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"background:#f9fafb;border:1px solid #e5e7eb;border-radius:16px;margin:28px 0;\">
				<tr>
					<td style=\"padding:22px 24px;\">
						<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
							<tr>
								<td valign=\"middle\" style=\"padding-bottom:12px;\">
									<span style=\"display:inline-block;padding:3px 9px;background:#e5e7eb;color:#374151;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;border-radius:6px;margin-bottom:8px;\">Courier Dispatch</span>
									" . ( $courier ? "<p style=\"margin:0 0 5px;font-size:15px;font-weight:700;color:#111827;letter-spacing:-0.2px;\">{$courier}</p>" : "" ) . "
									<p style=\"margin:0;font-size:12.5px;color:#6b7280;\">Tracking: <span style=\"font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;font-weight:700;color:#111827;background:#ffffff;padding:2px 8px;border-radius:6px;border:1px solid #e5e7eb;display:inline-block;font-size:13px;margin-left:4px;\">{$tracking_number}</span></p>
								</td>
								<td align=\"right\" valign=\"middle\" style=\"padding-left:16px;padding-bottom:12px;\">
									{$track_btn}
								</td>
							</tr>
							<tr>
								<td colspan=\"2\" style=\"padding-top:12px;border-top:1px solid #e5e7eb;\">
									<p style=\"margin:0;font-size:11.5px;color:#6b7280;line-height:1.45;\">Please note: Tracking numbers usually take some time to update on the courier&rsquo;s database.</p>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>";
		}

		// Items Table
		$items = $data['items'] ?? [];
		if ( empty( $items ) || ! is_array( $items ) ) {
			$items = [
				[
					'name'          => 'iPhone 16 Pro',
					'image_url'     => 'https://media.exacoat.com/wp-content/uploads/Black-Camo-Texture-Thumbnail.jpg',
					'quantity'      => 1,
					'subtotal'      => $data['subtotal'] ?? 'Rp 149.000',
					'total'         => $data['total'] ?? 'Rp 149.000',
					'meta'          => "Variant: Full Body\nTexture: Matrix Black",
				]
			];
		}

		$items_rows = '';
		foreach ( $items as $item ) {
			$raw_name = $item['name'] ?? 'Exacoat Product';
			$clean_name = trim( preg_replace( '/\s*\(\s*feelform.*?\s*\)/i', '', (string) $raw_name ) );
			$i_name = esc_html( $clean_name );
			$i_img  = esc_url( $item['image_url'] ?? ( $item['image'] ?? 'https://media.exacoat.com/wp-content/uploads/Black-Camo-Texture-Thumbnail.jpg' ) );
			$i_qty  = intval( $item['quantity'] ?? ( $item['qty'] ?? 1 ) );
			$raw_item_price = $item['subtotal'] ?? ( $item['price'] ?? ( $item['total'] ?? 'Rp 149.000' ) );
			$i_tot  = esc_html( self::clean_email_price( $raw_item_price ) );
			
			$specs = [];
			if ( ! empty( $item['parsed_configurator'] ) && is_array( $item['parsed_configurator'] ) ) {
				foreach ( $item['parsed_configurator'] as $c ) {
					$layer  = trim( (string) ( $c['layer_name'] ?? ( $c['name'] ?? '' ) ) );
					$choice = trim( (string) ( $c['choice_name'] ?? ( $c['choice_title'] ?? ( $c['name'] ?? '' ) ) ) );
					if ( '' !== $layer && '' !== $choice && strtolower( $layer ) !== strtolower( $choice ) ) {
						$specs[] = esc_html( $layer ) . ': ' . esc_html( $choice );
					} elseif ( '' !== $choice ) {
						$specs[] = esc_html( $choice );
					}
				}
			} elseif ( ! empty( $item['meta'] ) ) {
				$raw_meta = (string) $item['meta'];
				$parts    = preg_split( '/\s*(?:&bull;|•|<br\s*\/?>|\r?\n|\|)\s*/i', $raw_meta );
				if ( is_array( $parts ) ) {
					foreach ( $parts as $p ) {
						$clean = trim( str_replace( [ '&bull;', '•' ], '', $p ) );
						if ( '' !== $clean ) {
							$specs[] = esc_html( $clean );
						}
					}
				}
			} elseif ( ! empty( $item['device_model'] ) ) {
				$specs[] = esc_html( trim( (string) $item['device_model'] ) );
			}
			$specs_str = ! empty( $specs ) ? implode( '<br>', $specs ) : '';

			$items_rows .= "
			<tr>
				<td style=\"padding:18px 0;border-bottom:1px solid #f4f4f5;\">
					<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
						<tr>
							<td width=\"80\" valign=\"top\" style=\"padding-right:18px;\">
								<img src=\"{$i_img}\" width=\"80\" height=\"80\" alt=\"{$i_name}\" style=\"width:80px;height:80px;object-fit:cover;border-radius:12px;border:1px solid #e4e4e7;display:block;\">
							</td>
							<td valign=\"top\">
								<p style=\"margin:0 0 5px;font-size:15px;font-weight:600;color:#111111;line-height:1.4;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">{$i_name}</p>
								" . ( $specs_str ? "<p style=\"margin:0 0 6px;font-size:12px;color:#71717a;line-height:1.5;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">{$specs_str}</p>" : "" ) . "
								<p style=\"margin:0;font-size:12.5px;color:#52525b;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">Qty: <strong style=\"color:#111111;\">{$i_qty}</strong></p>
							</td>
							<td align=\"right\" valign=\"top\" style=\"white-space:nowrap;padding-left:14px;\">
								<span style=\"font-size:15px;font-weight:700;color:#111111;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">{$i_tot}</span>
							</td>
						</tr>
					</table>
				</td>
			</tr>";
		}

		$subtotal_clean = self::clean_email_price( $data['subtotal'] ?? 'Rp 149.000' );
		$subtotal       = esc_html( $subtotal_clean ?: 'Rp 149.000' );
		$discount_total = esc_html( self::clean_email_price( $data['discount_total'] ?? '' ) );
		$coupons        = $data['coupon_codes'] ?? [];
		$shipping_clean = self::clean_email_price( $data['shipping_total'] ?? 'Rp 15.000' );
		$raw_shipping_name   = $data['shipping_method_name'] ?? 'Standard Tracked Delivery';
		$clean_shipping_name = preg_replace( '/\s*[\(\[]\s*[^)\]]*applied[^)\]]*[\)\]]/i', '', $raw_shipping_name );
		$clean_shipping_name = preg_replace( '/\s*[\(\[]\s*free\s*shipping\s*[\)\]]/i', '', $clean_shipping_name );
		$clean_shipping_name = trim( preg_replace( '/\s{2,}/', ' ', $clean_shipping_name ) );
		$shipping_name       = esc_html( $clean_shipping_name ?: 'Standard Tracked Delivery' );
		$total_tax      = esc_html( self::clean_email_price( $data['total_tax'] ?? '' ) );
		$total_clean    = self::clean_email_price( $data['total'] ?? 'Rp 164.000' );
		$total          = esc_html( $total_clean ?: 'Rp 164.000' );
		$total_refunded = esc_html( self::clean_email_price( $data['total_refunded'] ?? '' ) );
		$payment_meth   = esc_html( $data['payment_method_title'] ?? 'Midtrans / QRIS' );
		$shipping_addr  = nl2br( esc_html( $data['shipping_address'] ?? "William Vance\nJl. Sudirman No. 42\nJakarta Selatan 12190\nIndonesia" ) );

		$coupons_row = '';
		if ( ! empty( $discount_total ) && ! self::is_price_zero( $discount_total ) ) {
			$c_code = ! empty( $coupons ) ? ' (' . implode( ', ', array_map( 'esc_html', (array) $coupons ) ) . ')' : '';
			$coupons_row = "
			<tr>
				<td style=\"padding:8px 0;font-size:13.5px;color:#52525b;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">Discount{$c_code}</td>
				<td align=\"right\" style=\"padding:8px 0;font-size:13.5px;color:#059669;font-weight:600;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">-{$discount_total}</td>
			</tr>";
		}

		$tax_row = '';
		if ( ! empty( $total_tax ) && ! self::is_price_zero( $total_tax ) ) {
			$tax_row = "
			<tr>
				<td style=\"padding:8px 0;font-size:13.5px;color:#52525b;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">Taxes / DDP</td>
				<td align=\"right\" style=\"padding:8px 0;font-size:13.5px;color:#111111;font-weight:500;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">{$total_tax}</td>
			</tr>";
		}

		$refund_row = '';
		if ( ! empty( $total_refunded ) && ! self::is_price_zero( $total_refunded ) ) {
			$refund_row = "
			<tr>
				<td style=\"padding:8px 0;font-size:13.5px;color:#dc2626;font-weight:600;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">Refunded Amount</td>
				<td align=\"right\" style=\"padding:8px 0;font-size:13.5px;color:#dc2626;font-weight:700;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">-{$total_refunded}</td>
			</tr>";
		}

		$html = "<!doctype html>
<html lang=\"en\" xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:o=\"urn:schemas-microsoft-com:office:office\">
<head>
  <meta charset=\"utf-8\">
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
  <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
  <title>" . esc_html( $subject ) . "</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
    body {
      margin: 0;
      padding: 0;
      width: 100% !important;
      -webkit-text-size-adjust: 100%;
      -ms-text-size-adjust: 100%;
      background-color: #f7f7f7;
      font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      -webkit-font-smoothing: antialiased;
    }
    table {
      border-collapse: collapse;
      mso-table-lspace: 0pt;
      mso-table-rspace: 0pt;
    }
    img {
      border: 0;
      outline: none;
      text-decoration: none;
      display: block;
    }
    @media only screen and (max-width: 620px) {
      .container-table { width: 100% !important; border-radius: 0 !important; }
      .mobile-padding { padding-left: 24px !important; padding-right: 24px !important; }
      .address-col { display: block !important; width: 100% !important; border-right: none !important; border-bottom: 1px solid #eeeeee !important; padding-bottom: 20px !important; margin-bottom: 20px !important; }
    }
  </style>
</head>
<body bgcolor=\"#f7f7f7\" style=\"margin:0;padding:0;background-color:#f7f7f7;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;\">
  " . ( ! empty( $preheader ) ? "<div style=\"display:none;font-size:1px;color:#333333;line-height:1px;max-height:0px;max-width:0px;opacity:0;overflow:hidden;mso-hide:all;\">" . esc_html( $preheader ) . "</div>" : "" ) . "
  <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" bgcolor=\"#f7f7f7\" style=\"border-collapse:collapse;background-color:#f7f7f7;\">
    <tbody>
      <tr>
        <td height=\"48\" style=\"height:48px;line-height:48px;font-size:0;mso-line-height-rule:exactly;\">&nbsp;</td>
      </tr>
      <tr>
        <td align=\"center\" style=\"padding:0 16px;\">
          <!-- Main Card -->
          <table class=\"container-table\" width=\"600\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" style=\"max-width:600px;background:#ffffff;border:1px solid #e5e5e5;border-radius:20px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,0.04);\">
          <tbody>
            <!-- Top Header (Logo + Badge) -->
            <tr>
              <td style=\"padding:28px 40px 22px;border-bottom:1px solid #f0f0f0;\" class=\"mobile-padding\">
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
                  <tr>
                    <td valign=\"middle\">
                      " . self::get_brand_logo_html() . "
                    </td>
                    <td align=\"right\" valign=\"middle\">
                      <span style=\"display:inline-block;padding:5px 13px;background:#f4f4f5;color:#3f3f46;font-size:11px;font-weight:600;border-radius:999px;border:1px solid #e4e4e7;letter-spacing:0.3px;\">{$badge_text}</span>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>

            <!-- Message Headline & Body -->
            <tr>
              <td style=\"padding:36px 40px 32px;\" class=\"mobile-padding\">
                <h1 style=\"margin:0 0 20px;font-size:26px;font-weight:800;color:#111111;letter-spacing:-0.6px;line-height:1.25;\">{$title}</h1>
                <p style=\"margin:0 0 14px;font-size:15px;font-weight:600;color:#18181b;\">Hi {$cust_name},</p>
                <p style=\"margin:0 0 16px;font-size:14.5px;line-height:1.7;color:#3f3f46;\">{$body_primary}</p>
                " . ( $body_secondary ? "<p style=\"margin:0 0 24px;font-size:14.5px;line-height:1.7;color:#52525b;\">{$body_secondary}</p>" : "" ) . "
                
                {$shipment_html}
                {$pickup_action_html}

                <!-- Dedicated Spacer above Order Summary -->
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
                  <tr>
                    <td height=\"36\" style=\"height:36px;font-size:0;line-height:0;\">&nbsp;</td>
                  </tr>
                </table>

                <!-- Order Items Table -->
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"border-top:1px solid #f0f0f0;\">
                  <tr>
                    <td style=\"padding-top:24px;padding-bottom:12px;\">
                      <p style=\"margin:0;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:#71717a;\">Order Summary</p>
                    </td>
                  </tr>
                  {$items_rows}
                </table>

                <!-- Financial Breakdown -->
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"margin-top:20px;margin-bottom:32px;\">
                  <tr>
                    <td style=\"padding:8px 0;font-size:13.5px;color:#52525b;\">Subtotal</td>
                    <td align=\"right\" style=\"padding:8px 0;font-size:13.5px;color:#111111;font-weight:500;\">{$subtotal}</td>
                  </tr>
                  {$coupons_row}
                  <tr>
                    <td style=\"padding:8px 0;font-size:13.5px;color:#52525b;\">Shipping ({$shipping_name})</td>
                    <td align=\"right\" style=\"padding:8px 0;font-size:13.5px;color:#111111;font-weight:500;\">{$shipping_total}</td>
                  </tr>
                  {$tax_row}
                  {$refund_row}
                  <tr>
                    <td style=\"padding:16px 0 0;border-top:1px solid #e4e4e7;font-size:15px;font-weight:700;color:#111111;\">Total</td>
                    <td align=\"right\" style=\"padding:16px 0 0;border-top:1px solid #e4e4e7;font-size:17px;font-weight:800;color:#111111;\">{$total}</td>
                  </tr>
                </table>

                <!-- Delivery & Payment Information Card (Shipping address & Payment method only) -->
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"background:#fafafa;border:1px solid #eaeaea;border-radius:16px;margin-bottom:32px;\">
                  <tr>
                    <td class=\"address-col\" width=\"58%\" valign=\"top\" style=\"padding:22px 24px;border-right:1px solid #eaeaea;\">
                      " . ( $is_store_pickup
                        ? "<p style=\"margin:0 0 8px;font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:#71717a;\">Store Pickup Location</p>
                           <p style=\"margin:0;font-size:13px;line-height:1.65;color:#3f3f46;\">Exacoat Store Bekasi<br>Ruby Commercial TB-12, Summarecon Bekasi, Bekasi Utara</p>"
                        : "<p style=\"margin:0 0 8px;font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:#71717a;\">Shipping Address</p>
                           <p style=\"margin:0;font-size:13px;line-height:1.65;color:#3f3f46;\">{$shipping_addr}</p>"
                      ) . "
                    </td>
                    <td class=\"address-col\" width=\"42%\" valign=\"top\" style=\"padding:22px 24px;\">
                      <p style=\"margin:0 0 8px;font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:#71717a;\">Payment Method</p>
                      <p style=\"margin:0;font-size:14px;color:#111111;font-weight:600;line-height:1.4;\">{$payment_meth}</p>
                    </td>
                  </tr>
                </table>

                <!-- Dedicated Spacer above Concierge Support -->
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
                  <tr>
                    <td height=\"36\" style=\"height:36px;font-size:0;line-height:0;\">&nbsp;</td>
                  </tr>
                </table>

                <!-- Help & Assistance Section -->
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"border-top:1px solid #f0f0f0;text-align:center;\">
                  <tr>
                    <td align=\"center\" style=\"padding-top:28px;\">
                      <p style=\"margin:0 0 10px;font-size:12px;line-height:1.65;color:#71717a;\">
                        Have questions about your order? Reach our team at <a href=\"mailto:support@exacoat.com\" style=\"color:#111111;text-decoration:underline;font-weight:500;\">support@exacoat.com</a>
                      </p>
                      <p style=\"margin:0;font-size:11px;color:#a1a1aa;letter-spacing:0.2px;\">
                        &copy; Exacoat
                      </p>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </tbody>
        </table>
      </td>
    </tr>
    <tr>
      <td height=\"48\" style=\"height:48px;line-height:48px;font-size:0;mso-line-height-rule:exactly;\">&nbsp;</td>
    </tr>
  </tbody>
</table>
</body>
</html>";

		// Clean up any remaining tags
		$html    = preg_replace( $tag_pattern, '', $html );
		$subject = preg_replace( $tag_pattern, '', $subject );
		$subject = preg_replace( '/\s{2,}/', ' ', trim( $subject ) );

		return [
			'subject'   => $subject,
			'html'      => $html,
			'tmpl_info' => $tmpl,
		];
	}

	/**
	 * Render Quiet-Luxury Product Review Invitation Email
	 */
	public static function render_review_invitation_html( string $event, array $data, array $tmpl ): array {
		$replacements = [];
		foreach ( $data as $k => $v ) {
			if ( is_scalar( $v ) ) {
				$val_str = (string) $v;
				$replacements[ '{{' . $k . '}}' ] = $val_str;
				$replacements[ '{' . $k . '}' ]   = $val_str;
			}
		}

		$order_num     = esc_html( $data['order_number'] ?? '14589' );
		$cust_name     = esc_html( $data['customer_first_name'] ?? 'Customer' );
		$badge_text    = esc_html( $data['badge_text'] ?? $tmpl['badge'] ?? 'Product Review' );
		$title         = esc_html( $data['title'] ?? $tmpl['title'] ?? 'How does your new order look?' );
		$art_title     = esc_html( $data['product_title'] ?? ( $data['artwork_title'] ?? 'Exacoat Product' ) );
		$art_img       = esc_url( $data['artwork_image'] ?? 'https://media.exacoat.com/wp-content/uploads/Black-Camo-Texture-Thumbnail.jpg' );
		$artist_name   = esc_html( $data['artist_name'] ?? 'Exacoat' );
		$review_url    = esc_url( $data['review_url'] ?? ( function_exists( 'exacoat_storefront_url' ) ? exacoat_storefront_url( 'review?order_id=' . $order_num ) : home_url( '/review?order_id=' . $order_num ) ) );

		$has_reward   = ! empty( $data['has_reward'] ) || ! empty( $data['discount_percent'] );
		$discount_pct = max( 0, (int) ( $data['discount_percent'] ?? 0 ) );

		$subject        = str_replace( array_keys( $replacements ), array_values( $replacements ), $tmpl['subject'] );
		$title          = str_replace( array_keys( $replacements ), array_values( $replacements ), $title );
		$body_primary   = str_replace( array_keys( $replacements ), array_values( $replacements ), $tmpl['body_primary'] ?? '' );
		$body_secondary = str_replace( array_keys( $replacements ), array_values( $replacements ), $tmpl['body_secondary'] ?? '' );

		if ( $has_reward && $discount_pct > 0 ) {
			$badge_text     = "Special Offer";
			$subject        = "Review {$art_title} and get special offer on your next piece";
			$body_secondary .= " Submit your review with a photo or video to receive an exclusive {$discount_pct}% promo code on your next purchase.";
			$cta_text       = "Submit Review & Claim Special Offer";
		} else {
			$subject        = "Review {$art_title} and get special offer on your next piece";
			$cta_text       = "Share your thoughts";
		}

		// Clean up orphan tags & double spaces
		$tag_pattern = '/\{\{[a-zA-Z0-9_-]+\}\}|\{[a-zA-Z0-9_-]+\}/';
		$subject     = preg_replace( $tag_pattern, '', $subject );
		$subject     = preg_replace( '/\s{2,}/', ' ', trim( $subject ) );
		$title       = preg_replace( $tag_pattern, '', $title );
		$body_primary   = preg_replace( $tag_pattern, '', $body_primary );
		$body_secondary = preg_replace( $tag_pattern, '', $body_secondary );

		$html = "<!doctype html>
<html lang=\"en\" xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:o=\"urn:schemas-microsoft-com:office:office\">
<head>
  <meta charset=\"utf-8\">
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
  <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
  <title>" . esc_html( $subject ) . "</title>
  <style>
    body { margin:0; padding:0; width:100% !important; background-color:#f8f8fa; font-family:'Neue Haas Display','Neue Haas Grotesk Text Pro',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif; }
    table { border-collapse:collapse; }
    img { border:0; outline:none; text-decoration:none; display:block; }
    @media only screen and (max-width:620px) {
      .container-table { width:100% !important; border-radius:0 !important; border-left:none !important; border-right:none !important; }
      .mobile-padding { padding:24px 20px !important; }
    }
  </style>
</head>
<body style=\"margin:0;padding:0;background-color:#f8f8fa;\">
  <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" bgcolor=\"#f8f8fa\" style=\"border-collapse:collapse;background-color:#f8f8fa;\">
    <tbody>
      <tr>
        <td height=\"48\" style=\"height:48px;line-height:48px;font-size:0;mso-line-height-rule:exactly;\">&nbsp;</td>
      </tr>
      <tr>
        <td align=\"center\" style=\"padding:0 16px;\">
        <table class=\"container-table\" width=\"580\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" style=\"max-width:580px;background:#ffffff;border:1px solid #eaeaea;border-radius:18px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.03);\">
          <tbody>
            <!-- Header -->
            <tr>
              <td style=\"padding:28px 36px 20px;border-bottom:1px solid #f0f0f2;\" class=\"mobile-padding\">
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
                  <tr>
                    <td valign=\"middle\">
                      " . self::get_brand_logo_html() . "
                    </td>
                    <td align=\"right\" valign=\"middle\">
                      <span style=\"display:inline-block;padding:4px 10px;background:#f4f4f5;color:#52525b;font-size:11px;font-weight:500;border-radius:9999px;\">{$badge_text}</span>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>

            <!-- Main Content -->
            <tr>
              <td style=\"padding:36px 36px 28px;\" class=\"mobile-padding\">
                <h1 style=\"margin:0 0 16px;font-size:24px;font-weight:600;color:#111111;letter-spacing:-0.4px;line-height:1.3;\">{$title}</h1>
                <p style=\"margin:0 0 12px;font-size:15px;font-weight:500;color:#18181b;\">Hi {$cust_name},</p>
                <p style=\"margin:0 0 14px;font-size:14px;line-height:1.7;color:#3f3f46;\">{$body_primary}</p>
                <p style=\"margin:0 0 24px;font-size:14px;line-height:1.7;color:#52525b;\">{$body_secondary}</p>

                <!-- Product Card -->
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"background:#fafafa;border:1px solid #ebebeb;border-radius:14px;overflow:hidden;margin-bottom:28px;\">
                  <tr>
                    <td width=\"100\" valign=\"middle\" style=\"padding:12px;width:100px;\">
                      <img src=\"{$art_img}\" alt=\"{$art_title}\" width=\"80\" height=\"100\" style=\"width:80px;height:100px;object-fit:cover;border-radius:8px;display:block;\" />
                    </td>
                    <td valign=\"middle\" style=\"padding:12px 16px;\">
                      <p style=\"margin:0 0 4px;font-size:15px;font-weight:600;color:#111111;\">{$art_title}</p>
                      <p style=\"margin:0;font-size:13px;color:#71717a;\">Exacoat Item</p>
                      <p style=\"margin:6px 0 0;font-size:11px;color:#a1a1aa;text-transform:uppercase;letter-spacing:0.5px;\">Order #{$order_num}</p>
                    </td>
                  </tr>
                </table>

                <!-- Action Button -->
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
                  <tr>
                    <td align=\"center\" style=\"padding:6px 0 12px;\">
                      <a href=\"{$review_url}\" target=\"_blank\" style=\"display:inline-block;padding:15px 36px;font-size:14px;font-weight:600;color:#ffffff;background:#111111;border-radius:12px;text-decoration:none;letter-spacing:0.2px;\">
                        {$cta_text} &rarr;
                      </a>
                    </td>
                  </tr>
                  <tr>
                    <td align=\"center\" style=\"padding-top:8px;\">
                      <span style=\"font-size:12px;color:#71717a;\">Takes less than a minute. You can also share an optional photo of your device.</span>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>

            <!-- Footer -->
            <tr>
              <td style=\"padding:24px 36px 28px;background:#fcfcfd;border-top:1px solid #f0f0f2;text-align:center;\" class=\"mobile-padding\">
                <p style=\"margin:0 0 8px;font-size:12px;line-height:1.65;color:#71717a;\">
                  Have questions about your order? Reach our team at <a href=\"mailto:support@exacoat.com\" style=\"color:#111111;text-decoration:underline;font-weight:500;\">support@exacoat.com</a>
                </p>
                <p style=\"margin:0 0 8px;font-size:11px;color:#a1a1aa;\">
                  Direct review link: <a href=\"{$review_url}\" style=\"color:#71717a;text-decoration:underline;\">{$review_url}</a>
                </p>
                <p style=\"margin:0;font-size:11px;color:#a1a1aa;letter-spacing:0.2px;\">
                  &copy; Exacoat
                </p>
              </td>
            </tr>
          </tbody>
        </table>
      </td>
    </tr>
    <tr>
      <td height=\"48\" style=\"height:48px;line-height:48px;font-size:0;mso-line-height-rule:exactly;\">&nbsp;</td>
    </tr>
  </tbody>
</table>
</body>
</html>";

		return [
			'subject'   => $subject,
			'html'      => $html,
			'tmpl_info' => $tmpl,
		];
	}

	/**
	 * Render Professional Light-Mode Exacoat Perks Promo Code Reward Email
	 */
	public static function render_review_reward_html( string $event, array $data, array $tmpl ): array {
		$replacements = [];
		foreach ( $data as $k => $v ) {
			if ( is_scalar( $v ) ) {
				$val_str = (string) $v;
				$replacements[ '{{' . $k . '}}' ] = $val_str;
				$replacements[ '{' . $k . '}' ]   = $val_str;
			}
		}

		$cust_name    = esc_html( $data['customer_first_name'] ?? ( $data['artist_name'] ?? 'Collector' ) );
		$coupon_code  = esc_html( $data['coupon_code'] ?? 'EXACOAT20-X8K9P' );
		$discount_pct = esc_html( $data['discount_percent'] ?? '20' );
		$expiry_date  = esc_html( $data['expiry_date'] ?? date( 'F j, Y', strtotime( '+30 days' ) ) );
		$shop_url     = esc_url( $data['shop_url'] ?? home_url( '/shop/' ) );
		$badge_text   = esc_html( $tmpl['badge'] ?? 'Exacoat Perks' );
		$title        = esc_html( $tmpl['title'] ?? 'Your Exacoat Perks' );
		$cta_text     = esc_html( $tmpl['cta_text'] ?? 'Explore The Collection' );

		$subject        = str_replace( array_keys( $replacements ), array_values( $replacements ), $tmpl['subject'] );
		$title          = str_replace( array_keys( $replacements ), array_values( $replacements ), $title );
		$body_primary   = str_replace( array_keys( $replacements ), array_values( $replacements ), $tmpl['body_primary'] ?? '' );
		$body_secondary = str_replace( array_keys( $replacements ), array_values( $replacements ), $tmpl['body_secondary'] ?? '' );

		// Clean up tags
		$tag_pattern    = '/\{\{[a-zA-Z0-9_-]+\}\}|\{[a-zA-Z0-9_-]+\}/';
		$subject        = preg_replace( $tag_pattern, '', $subject );
		$subject        = preg_replace( '/\s{2,}/', ' ', trim( $subject ) );
		$title          = preg_replace( $tag_pattern, '', $title );
		$body_primary   = preg_replace( $tag_pattern, '', $body_primary );
		$body_secondary = preg_replace( $tag_pattern, '', $body_secondary );

		$html = "<!doctype html>
<html lang=\"en\" xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:o=\"urn:schemas-microsoft-com:office:office\">
<head>
  <meta charset=\"utf-8\">
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
  <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
  <title>" . esc_html( $subject ) . "</title>
  <style>
    body { margin:0; padding:0; width:100% !important; background-color:#f8f8fa; font-family:'Neue Haas Display','Neue Haas Grotesk Text Pro',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif; }
    table { border-collapse:collapse; }
    img { border:0; outline:none; text-decoration:none; display:block; }
    @media only screen and (max-width:620px) {
      .container-table { width:100% !important; border-radius:0 !important; border-left:none !important; border-right:none !important; }
      .mobile-padding { padding:24px 20px !important; }
      .promo-code-text { font-size:24px !important; letter-spacing:4px !important; }
    }
  </style>
</head>
<body style=\"margin:0;padding:0;background-color:#f8f8fa;\">
  <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" bgcolor=\"#f8f8fa\" style=\"border-collapse:collapse;background-color:#f8f8fa;\">
    <tbody>
      <tr>
        <td height=\"48\" style=\"height:48px;line-height:48px;font-size:0;mso-line-height-rule:exactly;\">&nbsp;</td>
      </tr>
      <tr>
        <td align=\"center\" style=\"padding:0 16px;\">
        <table class=\"container-table\" width=\"580\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" style=\"max-width:580px;background:#ffffff;border:1px solid #eaeaea;border-radius:18px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.03);\">
          <tbody>
            <!-- Header -->
            <tr>
              <td style=\"padding:28px 36px 20px;border-bottom:1px solid #f0f0f2;\" class=\"mobile-padding\">
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
                  <tr>
                    <td valign=\"middle\">
                      " . self::get_brand_logo_html() . "
                    </td>
                    <td align=\"right\" valign=\"middle\">
                      <span style=\"display:inline-block;padding:5px 12px;background:#f4f4f5;color:#18181b;font-size:11px;font-weight:600;border-radius:9999px;border:1px solid #e4e4e7;\">{$badge_text}</span>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>

            <!-- Main Content -->
            <tr>
              <td style=\"padding:36px 36px 28px;\" class=\"mobile-padding\">
                <h1 style=\"margin:0 0 16px;font-size:24px;font-weight:600;color:#111111;letter-spacing:-0.4px;line-height:1.3;\">{$title}</h1>
                <p style=\"margin:0 0 12px;font-size:15px;font-weight:500;color:#18181b;\">Hi {$cust_name},</p>
                <p style=\"margin:0 0 14px;font-size:14px;line-height:1.7;color:#3f3f46;\">{$body_primary}</p>
                <p style=\"margin:0 0 24px;font-size:14px;line-height:1.7;color:#52525b;\">{$body_secondary}</p>

                <!-- Luxury Promo Code Card -->
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"background:#fafafa;border:1.5px dashed #22c55e;border-radius:14px;overflow:hidden;margin-bottom:28px;\">
                  <tr>
                    <td align=\"center\" style=\"padding:24px 20px;\">
                      <p style=\"margin:0 0 8px;font-size:11px;font-weight:700;color:#16a34a;text-transform:uppercase;letter-spacing:1px;\">Exclusive Exacoat Promo Code ({$discount_pct}% Off)</p>
                      <div style=\"display:inline-block;padding:12px 24px;background:#ffffff;border:1px solid #e4e4e7;border-radius:10px;box-shadow:0 2px 8px rgba(0,0,0,0.04);margin:8px 0 12px;\">
                        <span class=\"promo-code-text\" style=\"font-size:28px;font-weight:800;letter-spacing:6px;color:#111111;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;\">{$coupon_code}</span>
                      </div>
                      <p style=\"margin:4px 0 0;font-size:12px;color:#71717a;\">
                        Single-use promo code &bull; Valid through <strong>{$expiry_date}</strong>
                      </p>
                    </td>
                  </tr>
                </table>

                <!-- Action Button -->
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
                  <tr>
                    <td align=\"center\" style=\"padding:6px 0 12px;\">
                      <a href=\"{$shop_url}\" target=\"_blank\" style=\"display:inline-block;padding:15px 36px;font-size:14px;font-weight:600;color:#ffffff;background:#111111;border-radius:12px;text-decoration:none;letter-spacing:0.2px;\">
                        {$cta_text} &rarr;
                      </a>
                    </td>
                  </tr>
                  <tr>
                    <td align=\"center\" style=\"padding-top:8px;\">
                      <span style=\"font-size:12px;color:#71717a;\">Apply promo code at checkout on your next order.</span>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>

            <!-- Footer -->
            <tr>
              <td style=\"padding:24px 36px 28px;background:#fcfcfd;border-top:1px solid #f0f0f2;text-align:center;\" class=\"mobile-padding\">
                <p style=\"margin:0 0 8px;font-size:12px;line-height:1.65;color:#71717a;\">
                  Have questions about your order? Reach our team at <a href=\"mailto:support@exacoat.com\" style=\"color:#111111;text-decoration:underline;font-weight:500;\">support@exacoat.com</a>
                </p>
                <p style=\"margin:0;font-size:11px;color:#a1a1aa;letter-spacing:0.2px;\">
                  &copy; Exacoat
                </p>
              </td>
            </tr>
          </tbody>
        </table>
      </td>
    </tr>
    <tr>
      <td height=\"48\" style=\"height:48px;line-height:48px;font-size:0;mso-line-height-rule:exactly;\">&nbsp;</td>
    </tr>
  </tbody>
</table>
</body>
</html>";

		return [
			'subject'   => $subject,
			'html'      => $html,
			'tmpl_info' => $tmpl,
		];
	}

	/**
	 * Render Professional Light-Mode Store Credit & Cashback Notification Email
	 */
	public static function render_store_credit_html( string $event, array $data, array $tmpl ): array {
		$price_keys = [ 'store_credit_balance', 'cashback_amount' ];
		foreach ( $price_keys as $pk ) {
			if ( isset( $data[ $pk ] ) ) {
				$data[ $pk ] = self::clean_email_price( $data[ $pk ] );
			}
		}

		$replacements = [];
		foreach ( $data as $k => $v ) {
			if ( is_scalar( $v ) ) {
				$val_str = (string) $v;
				$replacements[ '{{' . $k . '}}' ] = $val_str;
				$replacements[ '{' . $k . '}' ]   = $val_str;
			}
		}

		$cust_name       = esc_html( $data['customer_first_name'] ?? ( $data['customer_name'] ?? 'Customer' ) );
		$balance         = esc_html( self::clean_email_price( $data['store_credit_balance'] ?? 'Rp 25.000' ) );
		$cashback_amount = esc_html( self::clean_email_price( $data['cashback_amount'] ?? '' ) );
		$order_num       = esc_html( $data['order_number'] ?? '' );
		$expiry_date     = esc_html( $data['expiry_date'] ?? '' );
		$shop_url        = esc_url( $data['shop_url'] ?? ( function_exists( 'exacoat_storefront_url' ) ? exacoat_storefront_url( 'shop' ) : home_url( '/shop/' ) ) );
		$badge_text      = esc_html( $data['badge_text'] ?? ( $tmpl['badge'] ?? 'Store Credit' ) );
		$title           = esc_html( $data['title'] ?? ( $tmpl['title'] ?? 'Your store credit is ready' ) );
		$cta_text        = esc_html( $data['cta_text'] ?? ( $tmpl['cta_text'] ?? 'Explore Catalog' ) );

		$subject        = str_replace( array_keys( $replacements ), array_values( $replacements ), $tmpl['subject'] );
		$title          = str_replace( array_keys( $replacements ), array_values( $replacements ), $title );
		$body_primary   = str_replace( array_keys( $replacements ), array_values( $replacements ), $tmpl['body_primary'] ?? '' );
		$body_secondary = str_replace( array_keys( $replacements ), array_values( $replacements ), $tmpl['body_secondary'] ?? '' );

		// Clean up tags
		$tag_pattern    = '/\{\{[a-zA-Z0-9_-]+\}\}|\{[a-zA-Z0-9_-]+\}/';
		$subject        = preg_replace( $tag_pattern, '', $subject );
		$subject        = preg_replace( '/\s{2,}/', ' ', trim( $subject ) );
		$title          = preg_replace( $tag_pattern, '', $title );
		$body_primary   = preg_replace( $tag_pattern, '', $body_primary );
		$body_secondary = preg_replace( $tag_pattern, '', $body_secondary );

		$cashback_pill = '';
		if ( ! empty( $cashback_amount ) && ! self::is_price_zero( $cashback_amount ) ) {
			$order_label = ! empty( $order_num ) ? " from Order #{$order_num}" : '';
			$cashback_pill = "<div style=\"display:inline-block;padding:4px 12px;background:#ecfdf5;color:#047857;font-size:12px;font-weight:700;border-radius:9999px;border:1px solid #a7f3d0;margin-top:10px;\">
				+{$cashback_amount} Cashback{$order_label}
			</div>";
		}

		$html = "<!doctype html>
<html lang=\"en\" xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:o=\"urn:schemas-microsoft-com:office:office\">
<head>
  <meta charset=\"utf-8\">
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
  <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
  <title>" . esc_html( $subject ) . "</title>
  <style>
    body { margin:0; padding:0; width:100% !important; background-color:#f8f8fa; font-family:'Neue Haas Display','Neue Haas Grotesk Text Pro',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif; }
    table { border-collapse:collapse; }
    img { border:0; outline:none; text-decoration:none; display:block; }
    @media only screen and (max-width:620px) {
      .container-table { width:100% !important; border-radius:0 !important; border-left:none !important; border-right:none !important; }
      .mobile-padding { padding:24px 20px !important; }
      .balance-text { font-size:28px !important; }
    }
  </style>
</head>
<body style=\"margin:0;padding:0;background-color:#f8f8fa;\">
  <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" bgcolor=\"#f8f8fa\" style=\"border-collapse:collapse;background-color:#f8f8fa;\">
    <tbody>
      <tr>
        <td height=\"48\" style=\"height:48px;line-height:48px;font-size:0;mso-line-height-rule:exactly;\">&nbsp;</td>
      </tr>
      <tr>
        <td align=\"center\" style=\"padding:0 16px;\">
        <table class=\"container-table\" width=\"580\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" style=\"max-width:580px;background:#ffffff;border:1px solid #eaeaea;border-radius:18px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.03);\">
          <tbody>
            <!-- Header -->
            <tr>
              <td style=\"padding:28px 36px 20px;border-bottom:1px solid #f0f0f2;\" class=\"mobile-padding\">
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
                  <tr>
                    <td valign=\"middle\">
                      " . self::get_brand_logo_html() . "
                    </td>
                    <td align=\"right\" valign=\"middle\">
                      <span style=\"display:inline-block;padding:5px 12px;background:#f4f4f5;color:#18181b;font-size:11px;font-weight:600;border-radius:9999px;border:1px solid #e4e4e7;\">{$badge_text}</span>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>

            <!-- Main Content -->
            <tr>
              <td style=\"padding:36px 36px 28px;\" class=\"mobile-padding\">
                <h1 style=\"margin:0 0 16px;font-size:24px;font-weight:600;color:#111111;letter-spacing:-0.4px;line-height:1.3;\">{$title}</h1>
                <p style=\"margin:0 0 12px;font-size:15px;font-weight:500;color:#18181b;\">Hi {$cust_name},</p>
                <p style=\"margin:0 0 14px;font-size:14px;line-height:1.7;color:#3f3f46;\">{$body_primary}</p>
                <p style=\"margin:0 0 24px;font-size:14px;line-height:1.7;color:#52525b;\">{$body_secondary}</p>

                <!-- Store Credit Card -->
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"background:#fafafa;border:1px solid #e4e4e7;border-radius:14px;overflow:hidden;margin-bottom:28px;\">
                  <tr>
                    <td align=\"center\" style=\"padding:26px 20px;\">
                      <p style=\"margin:0 0 6px;font-size:11px;font-weight:700;color:#71717a;text-transform:uppercase;letter-spacing:1px;\">Available Store Credit</p>
                      <div style=\"margin:6px 0;\">
                        <span class=\"balance-text\" style=\"font-size:34px;font-weight:800;letter-spacing:-0.5px;color:#111111;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,sans-serif;\">{$balance}</span>
                      </div>
                      {$cashback_pill}
                      <p style=\"margin:12px 0 0;font-size:12px;color:#71717a;\">
                        Applied automatically at checkout when signed in
                      </p>
                    </td>
                  </tr>
                </table>

                <!-- Action Button -->
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
                  <tr>
                    <td align=\"center\" style=\"padding:6px 0 12px;\">
                      <a href=\"{$shop_url}\" target=\"_blank\" style=\"display:inline-block;padding:15px 36px;font-size:14px;font-weight:600;color:#ffffff;background:#111111;border-radius:12px;text-decoration:none;letter-spacing:0.2px;\">
                        {$cta_text} &rarr;
                      </a>
                    </td>
                  </tr>
                  <tr>
                    <td align=\"center\" style=\"padding-top:8px;\">
                      <span style=\"font-size:12px;color:#71717a;\">Store credit is valid for 1 year from the date earned and applies automatically at checkout.</span>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>

            <!-- Footer -->
            <tr>
              <td style=\"padding:24px 36px 28px;background:#fcfcfd;border-top:1px solid #f0f0f2;text-align:center;\" class=\"mobile-padding\">
                <p style=\"margin:0 0 8px;font-size:12px;line-height:1.65;color:#71717a;\">
                  Have questions about your order or store credit? Reach our team at <a href=\"mailto:support@exacoat.com\" style=\"color:#111111;text-decoration:underline;font-weight:500;\">support@exacoat.com</a>
                </p>
                <p style=\"margin:0;font-size:11px;color:#a1a1aa;letter-spacing:0.2px;\">
                  &copy; Exacoat
                </p>
              </td>
            </tr>
          </tbody>
        </table>
      </td>
    </tr>
    <tr>
      <td height=\"48\" style=\"height:48px;line-height:48px;font-size:0;mso-line-height-rule:exactly;\">&nbsp;</td>
    </tr>
  </tbody>
</table>
</body>
</html>";

		return [
			'subject'   => $subject,
			'html'      => $html,
			'tmpl_info' => $tmpl,
		];
	}

	/**
	 * Render Professional Light-Mode Affiliate & Creator Program Email Notifications
	 */
	public static function render_creator_email_html( string $event, array $data, array $tmpl ): array {
		$price_keys = [ 'commission_amount', 'payout_amount', 'unpaid_balance' ];
		foreach ( $price_keys as $pk ) {
			if ( isset( $data[ $pk ] ) ) {
				$data[ $pk ] = self::clean_email_price( $data[ $pk ] );
			}
		}

		$replacements = [];
		foreach ( $data as $k => $v ) {
			if ( is_scalar( $v ) ) {
				$val_str = (string) $v;
				$replacements[ '{{' . $k . '}}' ] = $val_str;
				$replacements[ '{' . $k . '}' ]   = $val_str;
			}
		}

		$creator_name      = esc_html( $data['creator_name'] ?? ( $data['display_name'] ?? ( $data['customer_name'] ?? 'Creator' ) ) );
		$commission_amount = esc_html( self::clean_email_price( $data['commission_amount'] ?? 'Rp 74.500' ) );
		$payout_amount     = esc_html( self::clean_email_price( $data['payout_amount'] ?? 'Rp 500.000' ) );
		$order_number      = esc_html( $data['order_number'] ?? '' );
		$unpaid_balance    = esc_html( self::clean_email_price( $data['unpaid_balance'] ?? '' ) );
		$bank_name         = esc_html( $data['bank_name'] ?? 'BCA' );
		$bank_acc          = esc_html( $data['bank_account_number'] ?? '' );
		$bank_acc_name     = esc_html( $data['bank_account_name'] ?? '' );
		$ref               = esc_html( $data['transfer_reference'] ?? '' );
		$default_portal    = defined( 'EXACOAT_WEB_URL' ) ? trailingslashit( EXACOAT_WEB_URL ) . '?portal=affiliate' : home_url( '/?portal=affiliate' );
		$dashboard_url     = esc_url( $data['dashboard_url'] ?? $default_portal );
		$badge_text        = esc_html( $data['badge_text'] ?? ( $tmpl['badge'] ?? 'Creator Program' ) );
		$title             = esc_html( $data['title'] ?? ( $tmpl['title'] ?? 'Commission ready to withdraw' ) );
		$cta_text          = esc_html( $data['cta_text'] ?? ( $tmpl['cta_text'] ?? 'Go to Creator Workstation' ) );

		$subject        = str_replace( array_keys( $replacements ), array_values( $replacements ), $tmpl['subject'] );
		$title          = str_replace( array_keys( $replacements ), array_values( $replacements ), $title );
		$body_primary   = str_replace( array_keys( $replacements ), array_values( $replacements ), $tmpl['body_primary'] ?? '' );
		$body_secondary = str_replace( array_keys( $replacements ), array_values( $replacements ), $tmpl['body_secondary'] ?? '' );

		// Clean leftover tags
		$tag_pattern    = '/\{\{[a-zA-Z0-9_-]+\}\}|\{[a-zA-Z0-9_-]+\}/';
		$subject        = preg_replace( $tag_pattern, '', $subject );
		$subject        = preg_replace( '/\s{2,}/', ' ', trim( $subject ) );
		$title          = preg_replace( $tag_pattern, '', $title );
		$body_primary   = preg_replace( $tag_pattern, '', $body_primary );
		$body_secondary = preg_replace( $tag_pattern, '', $body_secondary );

		// Highlight block rendering based on event
		if ( 'creator_payout_transferred' === $event ) {
			$ref_html = ! empty( $ref ) ? "<p style=\"margin:12px 0 0;font-size:12px;color:#71717a;\">Reference: <strong style=\"color:#18181b;\">{$ref}</strong></p>" : "";
			$card_content = "
				<p style=\"margin:0 0 6px;font-size:11px;font-weight:700;color:#71717a;text-transform:uppercase;letter-spacing:1px;\">Transferred Payout</p>
				<div style=\"margin:6px 0;\">
					<span class=\"balance-text\" style=\"font-size:34px;font-weight:800;letter-spacing:-0.5px;color:#111111;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,sans-serif;\">{$payout_amount}</span>
				</div>
				<div style=\"display:inline-block;padding:4px 12px;background:#ecfdf5;color:#047857;font-size:12px;font-weight:700;border-radius:9999px;border:1px solid #a7f3d0;margin-top:10px;\">
					Transferred to {$bank_name} &bull; {$bank_acc}
				</div>
				{$ref_html}";
			$footer_note = "Bank transfers typically reflect within 1-2 business days depending on interbank clearing.";
		} elseif ( 'creator_payout_requested' === $event ) {
			$acc_line = ! empty( $bank_acc_name ) ? " ({$bank_acc_name})" : "";
			$card_content = "
				<p style=\"margin:0 0 6px;font-size:11px;font-weight:700;color:#71717a;text-transform:uppercase;letter-spacing:1px;\">Requested Payout</p>
				<div style=\"margin:6px 0;\">
					<span class=\"balance-text\" style=\"font-size:34px;font-weight:800;letter-spacing:-0.5px;color:#111111;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,sans-serif;\">{$payout_amount}</span>
				</div>
				<div style=\"display:inline-block;padding:4px 12px;background:#fef3c7;color:#92400e;font-size:12px;font-weight:700;border-radius:9999px;border:1px solid #fde68a;margin-top:10px;\">
					Destination: {$bank_name} &bull; {$bank_acc}{$acc_line}
				</div>
				<p style=\"margin:12px 0 0;font-size:12px;color:#71717a;\">
					Our finance team is reviewing your request.
				</p>";
			$footer_note = "You will receive an email confirmation once the transfer is completed.";
		} elseif ( 'creator_commission_recorded' === $event ) {
			$order_label = ! empty( $order_number ) ? "Order #{$order_number}" : "Referral Sale";
			$card_content = "
				<p style=\"margin:0 0 6px;font-size:11px;font-weight:700;color:#71717a;text-transform:uppercase;letter-spacing:1px;\">Pending Commission</p>
				<div style=\"margin:6px 0;\">
					<span class=\"balance-text\" style=\"font-size:34px;font-weight:800;letter-spacing:-0.5px;color:#f3aa18;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,sans-serif;\">{$commission_amount}</span>
				</div>
				<div style=\"display:inline-block;padding:4px 12px;background:#fef3c7;color:#92400e;font-size:12px;font-weight:700;border-radius:9999px;border:1px solid #fde68a;margin-top:10px;\">
					{$order_label} &bull; Pending Grace Period
				</div>
				<p style=\"margin:12px 0 0;font-size:12px;color:#71717a;\">
					Matures into withdrawable balance 7 days after delivery
				</p>";
			$footer_note = "Track real-time visits, clicks, and conversion rates directly in your workstation.";
		} else {
			// creator_commission_available
			$order_label = ! empty( $order_number ) ? "Order #{$order_number}" : "Commission";
			$unpaid_line = ! empty( $unpaid_balance ) ? "<p style=\"margin:12px 0 0;font-size:12px;color:#71717a;\">Current Withdrawable Balance: <strong style=\"color:#18181b;\">{$unpaid_balance}</strong></p>" : "";
			$card_content = "
				<p style=\"margin:0 0 6px;font-size:11px;font-weight:700;color:#71717a;text-transform:uppercase;letter-spacing:1px;\">Withdrawable Commission</p>
				<div style=\"margin:6px 0;\">
					<span class=\"balance-text\" style=\"font-size:34px;font-weight:800;letter-spacing:-0.5px;color:#10b981;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,sans-serif;\">{$commission_amount}</span>
				</div>
				<div style=\"display:inline-block;padding:4px 12px;background:#ecfdf5;color:#047857;font-size:12px;font-weight:700;border-radius:9999px;border:1px solid #a7f3d0;margin-top:10px;\">
					{$order_label} &bull; Cleared Grace Period
				</div>
				{$unpaid_line}";
			$footer_note = "Payouts can be requested anytime once your balance reaches the minimum threshold of Rp 250.000.";
		}

		$brand_logo = self::get_brand_logo_html();

		$html = "<!doctype html>
<html lang=\"en\" xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:o=\"urn:schemas-microsoft-com:office:office\">
<head>
  <meta charset=\"utf-8\">
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
  <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
  <title>" . esc_html( $subject ) . "</title>
  <style>
    body { margin:0; padding:0; width:100% !important; background-color:#f8f8fa; font-family:'Neue Haas Display','Neue Haas Grotesk Text Pro',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif; }
    table { border-collapse:collapse; }
    img { border:0; outline:none; text-decoration:none; display:block; }
    @media only screen and (max-width:620px) {
      .container-table { width:100% !important; border-radius:0 !important; border-left:none !important; border-right:none !important; }
      .mobile-padding { padding:24px 20px !important; }
      .balance-text { font-size:28px !important; }
    }
  </style>
</head>
<body style=\"margin:0;padding:0;background-color:#f8f8fa;\">
  <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" bgcolor=\"#f8f8fa\" style=\"border-collapse:collapse;background-color:#f8f8fa;\">
    <tbody>
      <tr>
        <td height=\"48\" style=\"height:48px;line-height:48px;font-size:0;mso-line-height-rule:exactly;\">&nbsp;</td>
      </tr>
      <tr>
        <td align=\"center\" style=\"padding:0 16px;\">
        <table class=\"container-table\" width=\"580\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" style=\"max-width:580px;background:#ffffff;border:1px solid #eaeaea;border-radius:18px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.03);\">
          <tbody>
            <!-- Header -->
            <tr>
              <td style=\"padding:28px 36px 20px;border-bottom:1px solid #f0f0f2;\" class=\"mobile-padding\">
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
                  <tr>
                    <td valign=\"middle\">
                      {$brand_logo}
                    </td>
                    <td align=\"right\" valign=\"middle\">
                      <span style=\"display:inline-block;padding:5px 12px;background:#f4f4f5;color:#18181b;font-size:11px;font-weight:600;border-radius:9999px;border:1px solid #e4e4e7;\">{$badge_text}</span>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>

            <!-- Main Content -->
            <tr>
              <td style=\"padding:36px 36px 28px;\" class=\"mobile-padding\">
                <h1 style=\"margin:0 0 16px;font-size:24px;font-weight:600;color:#111111;letter-spacing:-0.4px;line-height:1.3;\">{$title}</h1>
                <p style=\"margin:0 0 12px;font-size:15px;font-weight:500;color:#18181b;\">Hi {$creator_name},</p>
                <p style=\"margin:0 0 14px;font-size:14px;line-height:1.7;color:#3f3f46;\">{$body_primary}</p>
                <p style=\"margin:0 0 24px;font-size:14px;line-height:1.7;color:#52525b;\">{$body_secondary}</p>

                <!-- Metric Card -->
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"background:#fafafa;border:1px solid #e4e4e7;border-radius:14px;overflow:hidden;margin-bottom:28px;\">
                  <tr>
                    <td align=\"center\" style=\"padding:26px 20px;\">
                      {$card_content}
                    </td>
                  </tr>
                </table>

                <!-- Action Button -->
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
                  <tr>
                    <td align=\"center\" style=\"padding:6px 0 12px;\">
                      <a href=\"{$dashboard_url}\" target=\"_blank\" style=\"display:inline-block;padding:15px 36px;font-size:14px;font-weight:600;color:#ffffff;background:#111111;border-radius:12px;text-decoration:none;letter-spacing:0.2px;\">
                        {$cta_text} &rarr;
                      </a>
                    </td>
                  </tr>
                  <tr>
                    <td align=\"center\" style=\"padding-top:8px;\">
                      <span style=\"font-size:12px;color:#71717a;\">{$footer_note}</span>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>

            <!-- Footer -->
            <tr>
              <td style=\"padding:24px 36px 28px;background:#fcfcfd;border-top:1px solid #f0f0f2;text-align:center;\" class=\"mobile-padding\">
                <p style=\"margin:0 0 8px;font-size:12px;line-height:1.65;color:#71717a;\">
                  Questions regarding your commissions or payout? Reach our partnership team at <a href=\"mailto:creators@exacoat.com\" style=\"color:#111111;text-decoration:underline;font-weight:500;\">creators@exacoat.com</a>
                </p>
                <p style=\"margin:0;font-size:11px;color:#a1a1aa;letter-spacing:0.2px;\">
                  &copy; Exacoat Creator Program
                </p>
              </td>
            </tr>
          </tbody>
        </table>
      </td>
    </tr>
    <tr>
      <td height=\"48\" style=\"height:48px;line-height:48px;font-size:0;mso-line-height-rule:exactly;\">&nbsp;</td>
    </tr>
  </tbody>
</table>
</body>
</html>";

		return [
			'subject'   => $subject,
			'html'      => $html,
			'tmpl_info' => $tmpl,
		];
	}

	/**
	 * Render Professional Light-Mode Warranty Claim Approved Notification Email
	 */
	public static function render_warranty_approved_html( array $data, array $tmpl = [] ): array {
		$cust_name     = esc_html( $data['customer_first_name'] ?? ( $data['customer_name'] ?? 'Customer' ) );
		$order_num     = esc_html( (string) ( $data['order_number'] ?? ( $data['order_id'] ?? '' ) ) );
		$parent_num    = esc_html( (string) ( $data['parent_order_number'] ?? ( $data['parent_order_id'] ?? '' ) ) );
		$shipping_cost = (float) ( $data['shipping_cost'] ?? 0 );
		$shipping_fmt  = esc_html( $data['shipping_cost_fmt'] ?? ( 'Rp ' . number_format( $shipping_cost, 0, ',', '.' ) ) );
		$courier_name  = esc_html( $data['courier_name'] ?? 'Standard Courier' );
		$payment_url   = esc_url( $data['payment_url'] ?? ( 'https://exacoat.com/pay/' . $order_num ) );
		$badge_text    = esc_html( $data['badge_text'] ?? ( $tmpl['badge'] ?? 'Installation Warranty & QC' ) );
		$order_ref     = ! empty( $parent_num ) ? $parent_num : $order_num;

		$subject = "[Exacoat] Klaim Garansi Pemasangan Disetujui #{$order_ref}";

		// Extract items
		$items = $data['items'] ?? [];
		$items_html = '';
		if ( ! empty( $items ) && is_array( $items ) ) {
			foreach ( $items as $it ) {
				$it_name = esc_html( $it['name'] ?? 'Exacoat Skin Replacement' );
				$parts   = ! empty( $it['claimed_parts'] ) && is_array( $it['claimed_parts'] ) ? implode( ', ', array_map( 'esc_html', $it['claimed_parts'] ) ) : ( ! empty( $it['note'] ) ? esc_html( $it['note'] ) : '' );

				$items_html .= '
				<div style="padding:12px 14px;background:#ffffff;border:1px solid #e5e7eb;border-radius:10px;margin-bottom:8px;">
					<table width="100%" cellpadding="0" cellspacing="0">
						<tr>
							<td valign="middle">
								<p style="margin:0;font-size:13.5px;font-weight:600;color:#111827;">' . $it_name . '</p>' .
								( $parts ? '<p style="margin:3px 0 0;font-size:12px;color:#6b7280;">Bagian: <strong style="color:#374151;">' . $parts . '</strong></p>' : '' ) . '
							</td>
							<td align="right" valign="middle">
								<span style="display:inline-block;padding:3px 9px;font-size:11px;font-weight:700;background:#ecfdf5;color:#059669;border-radius:9999px;border:1px solid #a7f3d0;">Rp 0 (Garansi)</span>
							</td>
						</tr>
					</table>
				</div>';
			}
		}

		$parent_ref_html = '';
		if ( ! empty( $parent_num ) && $parent_num !== $order_num ) {
			$parent_ref_html = '
			<tr>
				<td style="padding:6px 0;font-size:12.5px;color:#6b7280;">Invoice Pembelian Asal</td>
				<td align="right" style="padding:6px 0;font-size:13px;font-weight:600;color:#374151;font-family:ui-monospace,Menlo,monospace;">#' . $parent_num . '</td>
			</tr>';
		}

		$html = '<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>' . esc_html( $subject ) . '</title>
  <style>
    body { margin:0; padding:0; width:100% !important; background-color:#f8f8fa; font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,Helvetica,Arial,sans-serif; }
    table { border-collapse:collapse; }
    img { border:0; display:block; }
    @media only screen and (max-width:620px) {
      .container-table { width:100% !important; border-radius:0 !important; }
      .mobile-padding { padding:24px 20px !important; }
    }
  </style>
</head>
<body style="margin:0;padding:0;background-color:#f8f8fa;">
  <table width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#f8f8fa" style="border-collapse:collapse;background-color:#f8f8fa;">
    <tbody>
      <tr>
        <td height="40" style="height:40px;line-height:40px;font-size:0;">&nbsp;</td>
      </tr>
      <tr>
        <td align="center" style="padding:0 16px;">
        <table class="container-table" width="580" cellpadding="0" cellspacing="0" border="0" style="max-width:580px;background:#ffffff;border:1px solid #eaeaea;border-radius:18px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.03);">
          <tbody>
            <!-- Header with Logo & QC Badge -->
            <tr>
              <td style="padding:26px 36px 20px;border-bottom:1px solid #f0f0f2;" class="mobile-padding">
                <table width="100%" cellpadding="0" cellspacing="0">
                  <tr>
                    <td valign="middle">
                      ' . self::get_brand_logo_html() . '
                    </td>
                    <td align="right" valign="middle">
                      <span style="display:inline-block;padding:5px 12px;background:#fef3c7;color:#92400e;font-size:11px;font-weight:700;border-radius:9999px;border:1px solid #fde68a;letter-spacing:0.2px;">' . $badge_text . '</span>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>

            <!-- Main Content -->
            <tr>
              <td style="padding:32px 36px 28px;" class="mobile-padding">
                <h1 style="margin:0 0 16px;font-size:23px;font-weight:700;color:#111827;letter-spacing:-0.4px;line-height:1.3;">Klaim Garansi Pemasangan Disetujui</h1>
                <p style="margin:0 0 14px;font-size:15px;font-weight:600;color:#18181b;">Halo kak ' . $cust_name . ',</p>
                <p style="margin:0 0 16px;font-size:14px;line-height:1.7;color:#374151;">
                  Klaim garansi pemasangan 48 jam Exacoat Anda untuk pesanan <strong>#' . $order_ref . '</strong> telah ditinjau dan <strong>disetujui</strong> oleh tim Quality Control kami.
                </p>
                <p style="margin:0 0 24px;font-size:14px;line-height:1.7;color:#374151;">
                  Silakan selesaikan pembayaran ongkos kirim ekspedisi kurir sebesar <strong>' . $shipping_fmt . '</strong> melalui tautan resmi di bawah ini agar pesanan penggantian Anda dapat langsung kami jadwalkan untuk proses produksi dan pengemasan:
                </p>

                <!-- Prominent Action CTA -->
                <div style="text-align:center;margin:28px 0;">
                  <a href="' . $payment_url . '" target="_blank" rel="noopener noreferrer" style="display:inline-block;padding:15px 34px;background:#f3aa18;color:#000000;font-size:14.5px;font-weight:700;border-radius:100px;text-decoration:none;letter-spacing:0.2px;box-shadow:0 4px 14px rgba(243,170,24,0.35);">
                    Bayar Ongkos Kirim (' . $shipping_fmt . ') &rarr;
                  </a>
                </div>

                <!-- Order Breakdown Card -->
                <table width="100%" cellpadding="0" cellspacing="0" style="background:#fafafa;border:1px solid #e5e7eb;border-radius:14px;overflow:hidden;margin-bottom:24px;">
                  <tr>
                    <td style="padding:18px 20px;">
                      <p style="margin:0 0 12px;font-size:11px;font-weight:700;color:#6b7280;text-transform:uppercase;letter-spacing:0.5px;">Rincian Penggantian Garansi</p>
                      ' . $items_html . '
                      <table width="100%" cellpadding="0" cellspacing="0" style="border-top:1px solid #e5e7eb;margin-top:12px;padding-top:10px;">
                        <tr>
                          <td style="padding:6px 0;font-size:12.5px;color:#6b7280;">No. Pesanan Penggantian</td>
                          <td align="right" style="padding:6px 0;font-size:13px;font-weight:600;color:#374151;font-family:ui-monospace,Menlo,monospace;">#' . $order_num . '</td>
                        </tr>
                        ' . $parent_ref_html . '
                        <tr>
                          <td style="padding:6px 0;font-size:12.5px;color:#6b7280;">Status</td>
                          <td align="right" style="padding:6px 0;font-size:12px;font-weight:700;color:#059669;">Disetujui QC (Menunggu Pembayaran Ongkir)</td>
                        </tr>
                        <tr>
                          <td style="padding:6px 0;font-size:12.5px;color:#6b7280;">Biaya Skin Penggantian</td>
                          <td align="right" style="padding:6px 0;font-size:13px;font-weight:700;color:#059669;">Rp 0 (Garansi)</td>
                        </tr>
                        <tr>
                          <td style="padding:6px 0;font-size:12.5px;color:#6b7280;">Ongkos Kirim Kurir (' . $courier_name . ')</td>
                          <td align="right" style="padding:6px 0;font-size:13px;font-weight:600;color:#111827;">' . $shipping_fmt . '</td>
                        </tr>
                        <tr>
                          <td style="padding:10px 0 4px;font-size:13.5px;font-weight:700;color:#111827;border-top:1px dashed #e5e7eb;">Total Pelunasan Ongkir</td>
                          <td align="right" style="padding:10px 0 4px;font-size:16px;font-weight:800;color:#d97706;border-top:1px dashed #e5e7eb;font-family:ui-monospace,Menlo,monospace;">' . $shipping_fmt . '</td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                </table>

                <p style="margin:0 0 16px;font-size:12px;color:#9ca3af;word-break:break-all;line-height:1.5;">
                  Tautan tidak dapat diklik? Salin tautan berikut ke browser Anda:<br>
                  <a href="' . $payment_url . '" style="color:#d97706;text-decoration:underline;">' . $payment_url . '</a>
                </p>

                <div style="border-top:1px solid #f0f0f2;padding-top:20px;margin-top:24px;">
                  <p style="margin:0 0 2px;font-size:13.5px;color:#4b5563;">Best regards,</p>
                  <p style="margin:0;font-size:14px;font-weight:700;color:#111827;">Aurelia</p>
                  <p style="margin:2px 0 0;font-size:12.5px;color:#6b7280;">Exacoat Customer Support</p>
                </div>
              </td>
            </tr>

            <!-- Footer -->
            <tr>
              <td style="padding:20px 36px 24px;background:#f9fafb;border-top:1px solid #f0f0f2;text-align:center;" class="mobile-padding">
                <p style="margin:0 0 6px;font-size:11.5px;color:#9ca3af;">
                  &copy; ' . date( 'Y' ) . ' Exacoat. All rights reserved.
                </p>
                <p style="margin:0;font-size:11.5px;color:#9ca3af;">
                  Pertanyaan seputar klaim garansi? Hubungi kami di <a href="mailto:support@exacoat.com" style="color:#6b7280;text-decoration:underline;">support@exacoat.com</a>
                </p>
              </td>
            </tr>
          </tbody>
        </table>
        </td>
      </tr>
      <tr>
        <td height="40" style="height:40px;line-height:40px;font-size:0;">&nbsp;</td>
      </tr>
    </tbody>
  </table>
</body>
</html>';

		return [
			'subject'   => $subject,
			'html'      => $html,
			'tmpl_info' => $tmpl,
		];
	}

	/**
	 * Render Professional Light-Mode Customer Account Email (Password Reset & Welcome)
	 */
	public static function render_customer_account_html( string $event, array $data, array $tmpl ): array {
		$replacements = [];
		foreach ( $data as $k => $v ) {
			if ( is_scalar( $v ) ) {
				$val_str = (string) $v;
				$replacements[ '{{' . $k . '}}' ] = $val_str;
				$replacements[ '{' . $k . '}' ]   = $val_str;
			}
		}

		$cust_name = esc_html( $data['customer_first_name'] ?? ( $data['display_name'] ?? 'Collector' ) );
		$subject   = str_replace( array_keys( $replacements ), array_values( $replacements ), $tmpl['subject'] );

		// Clean up tags
		$tag_pattern = '/\{\{[a-zA-Z0-9_-]+\}\}|\{[a-zA-Z0-9_-]+\}/';
		$subject     = preg_replace( $tag_pattern, '', $subject );
		$subject     = preg_replace( '/\s{2,}/', ' ', trim( $subject ) );

		if ( $event === 'customer_otp' || ( $tmpl['type'] ?? '' ) === 'otp' ) {
			$otp_code   = esc_html( $data['otp_code'] ?? '849201' );
			$badge_text = esc_html( $data['badge_text'] ?? ( $tmpl['badge'] ?? 'Security verification' ) );
			$title      = esc_html( $data['title'] ?? ( $tmpl['title'] ?? 'Verify your identity' ) );
			$content_html = "
			<p style=\"margin:0 0 16px;font-size:14.5px;line-height:1.7;color:#3f3f46;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">
				Use the verification code below to verify your account or complete your sign-in:
			</p>
			<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"background:#fafafa;border:1px solid #eaeaea;border-radius:16px;margin:24px 0;\">
				<tr>
					<td align=\"center\" style=\"padding:28px 20px 22px;\">
						<span style=\"font-size:40px;font-weight:800;letter-spacing:12px;color:#111111;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;display:inline-block;\">{$otp_code}</span>
						<p style=\"margin:12px 0 0;font-size:12.5px;color:#71717a;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">This code is valid for <strong>5 minutes</strong></p>
					</td>
				</tr>
			</table>
			<p style=\"margin:0 0 20px;font-size:13.5px;line-height:1.65;color:#71717a;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">
				If you did not request this verification code, you can safely ignore this email.
			</p>";
		} elseif ( $event === 'customer_reset_password' ) {
			$reset_url  = esc_url( $data['reset_url'] ?? home_url( '/my-account/lost-password' ) );
			$badge_text = 'Account security';
			$title      = 'Reset your password';
			$content_html = "
			<p style=\"margin:0 0 20px;font-size:14.5px;line-height:1.7;color:#3f3f46;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">
				Someone has requested a password reset for your Exacoat account. If this was you, you can choose a new password using the link below.
			</p>
			<div style=\"margin:28px 0;\">
				<a href=\"{$reset_url}\" target=\"_blank\" rel=\"noopener noreferrer\" style=\"display:inline-block;padding:13px 26px;background:#111111;color:#ffffff;font-size:14px;font-weight:600;border-radius:100px;text-decoration:none;letter-spacing:0.2px;box-shadow:0 2px 8px rgba(0,0,0,0.1);font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">
					Reset Password &rarr;
				</a>
			</div>
			<p style=\"margin:0 0 20px;font-size:13.5px;line-height:1.65;color:#71717a;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">
				If you didn't request a password reset, you can safely ignore this email. Your password will remain unchanged.
			</p>";
		} else {
			$account_url = esc_url( $data['account_url'] ?? ( function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/my-account' ) ) );
			$badge_text  = 'Account created';
			$title       = 'Welcome to Exacoat';
			$content_html = "
			<p style=\"margin:0 0 16px;font-size:14.5px;line-height:1.7;color:#3f3f46;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">
				Your Exacoat account has been created. You can use your account to review orders, save delivery details, and track shipments.
			</p>
			<div style=\"margin:28px 0;\">
				<a href=\"{$account_url}\" target=\"_blank\" rel=\"noopener noreferrer\" style=\"display:inline-block;padding:13px 26px;background:#111111;color:#ffffff;font-size:14px;font-weight:600;border-radius:100px;text-decoration:none;letter-spacing:0.2px;box-shadow:0 2px 8px rgba(0,0,0,0.1);font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">
					Visit Your Account &rarr;
				</a>
			</div>";
		}

		$html = "<!doctype html>
<html lang=\"en\" xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:o=\"urn:schemas-microsoft-com:office:office\">
<head>
  <meta charset=\"utf-8\">
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
  <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
  <title>" . esc_html( $subject ) . "</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
    body {
      margin: 0;
      padding: 0;
      width: 100% !important;
      -webkit-text-size-adjust: 100%;
      -ms-text-size-adjust: 100%;
      background-color: #f7f7f7;
      font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      -webkit-font-smoothing: antialiased;
    }
    table {
      border-collapse: collapse;
      mso-table-lspace: 0pt;
      mso-table-rspace: 0pt;
    }
    img {
      border: 0;
      outline: none;
      text-decoration: none;
      display: block;
    }
    @media only screen and (max-width: 620px) {
      .container-table { width: 100% !important; border-radius: 0 !important; }
      .mobile-padding { padding-left: 24px !important; padding-right: 24px !important; }
    }
  </style>
</head>
<body bgcolor=\"#f7f7f7\" style=\"margin:0;padding:0;background-color:#f7f7f7;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;\">
  <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" bgcolor=\"#f7f7f7\" style=\"border-collapse:collapse;background-color:#f7f7f7;\">
    <tbody>
      <tr>
        <td height=\"48\" style=\"height:48px;line-height:48px;font-size:0;mso-line-height-rule:exactly;\">&nbsp;</td>
      </tr>
      <tr>
        <td align=\"center\" style=\"padding:0 16px;\">
        <!-- Main Card -->
        <table class=\"container-table\" width=\"600\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" style=\"max-width:600px;background:#ffffff;border:1px solid #e5e5e5;border-radius:20px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,0.04);\">
          <tbody>
            <!-- Top Header (Logo + Badge) -->
            <tr>
              <td style=\"padding:28px 40px 22px;border-bottom:1px solid #f0f0f0;\" class=\"mobile-padding\">
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
                  <tr>
                    <td valign=\"middle\">
                      " . self::get_brand_logo_html() . "
                    </td>
                    <td align=\"right\" valign=\"middle\">
                      <span style=\"display:inline-block;padding:5px 13px;background:#f4f4f5;color:#3f3f46;font-size:11px;font-weight:600;border-radius:999px;border:1px solid #e4e4e7;letter-spacing:0.3px;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">{$badge_text}</span>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>

            <!-- Message Headline & Body -->
            <tr>
              <td style=\"padding:36px 40px 32px;\" class=\"mobile-padding\">
                <h1 style=\"margin:0 0 20px;font-size:26px;font-weight:800;color:#111111;letter-spacing:-0.6px;line-height:1.25;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">{$title}</h1>
                <p style=\"margin:0 0 14px;font-size:15px;font-weight:600;color:#18181b;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">Hi {$cust_name},</p>
                {$content_html}

                <!-- Dedicated Spacer above Concierge Support -->
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
                  <tr>
                    <td height=\"36\" style=\"height:36px;font-size:0;line-height:0;\">&nbsp;</td>
                  </tr>
                </table>

                <!-- Help & Assistance Section -->
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"border-top:1px solid #f0f0f0;text-align:center;\">
                  <tr>
                    <td align=\"center\" style=\"padding-top:28px;\">
                      <p style=\"margin:0 0 10px;font-size:12px;line-height:1.65;color:#71717a;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">
                        Have questions about your account? Reach our team at <a href=\"mailto:support@exacoat.com\" style=\"color:#111111;text-decoration:underline;font-weight:500;\">support@exacoat.com</a>
                      </p>
                      <p style=\"margin:0;font-size:11px;color:#a1a1aa;letter-spacing:0.2px;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">
                        &copy; Exacoat
                      </p>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </tbody>
        </table>
      </td>
    </tr>
    <tr>
      <td height=\"48\" style=\"height:48px;line-height:48px;font-size:0;mso-line-height-rule:exactly;\">&nbsp;</td>
    </tr>
  </tbody>
</table>
</body>
</html>";

		return [
			'subject'   => $subject,
			'html'      => $html,
			'tmpl_info' => $tmpl,
		];
	}

	/**
	 * Render Luxury Light-Mode Custom Poster Private Order Link Email
	 */
	public static function render_custom_poster_order_html( string $event, array $data, array $tmpl ): array {
		$replacements = [];
		foreach ( $data as $k => $v ) {
			if ( is_scalar( $v ) ) {
				$val_str = (string) $v;
				$replacements[ '{{' . $k . '}}' ] = $val_str;
				$replacements[ '{' . $k . '}' ]   = $val_str;
			}
		}

		$order_code = esc_html( $data['order_code'] ?? 'CUSTOM' );
		$cust_name  = esc_html( $data['customer_name'] ?? $data['customer_first_name'] ?? ( $data['display_name'] ?? 'there' ) );
		if ( strtolower( $cust_name ) === 'customer'  ) {
			$cust_name = 'there';
		}
		$art_img    = esc_url( $data['artwork_image'] ?? '' );
		$order_url  = esc_url( $data['order_url'] ?? home_url( "/product/custom-order-" . strtolower( $order_code ) ) );
		$cta_text   = esc_html( $tmpl['cta_text'] ?? 'Complete Custom Order' );
		$badge_text = esc_html( $tmpl['badge'] ?? 'Custom Poster Order' );
		$title      = esc_html( $tmpl['title'] ?? 'Your custom poster is ready' );
		$subject    = str_replace( array_keys( $replacements ), array_values( $replacements ), $tmpl['subject'] );

		// Clean up tags
		$tag_pattern = '/\{\{[a-zA-Z0-9_-]+\}\}|\{[a-zA-Z0-9_-]+\}/';
		$subject     = preg_replace( $tag_pattern, '', $subject );
		$subject     = preg_replace( '/\s{2,}/', ' ', trim( $subject ) );

		$img_preview_html = '';
		if ( ! empty( $art_img ) ) {
			$img_preview_html = "
			<div style=\"margin:24px 0;background:#fafafa;border:1px solid #eaeaea;border-radius:16px;padding:24px;text-align:center;\">
				<img src=\"{$art_img}\" alt=\"Custom Poster #{$order_code}\" style=\"width:100%;max-width:380px;height:auto;border-radius:10px;box-shadow:0 8px 24px rgba(0,0,0,0.08);display:block;margin:0 auto;border:1px solid #e4e4e7;\">
				<div style=\"margin-top:18px;\">
					<span style=\"display:inline-block;padding:4px 12px;background:#f4f4f5;border:1px solid #e4e4e7;border-radius:6px;font-size:11.5px;font-weight:700;color:#3f3f46;text-transform:uppercase;letter-spacing:0.8px;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;\">Order Code: #{$order_code}</span>
				</div>
			</div>";
		}

		$html = "<!doctype html>
<html lang=\"en\" xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:o=\"urn:schemas-microsoft-com:office:office\">
<head>
  <meta charset=\"utf-8\">
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
  <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
  <title>" . esc_html( $subject ) . "</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
    body {
      margin: 0;
      padding: 0;
      width: 100% !important;
      -webkit-text-size-adjust: 100%;
      -ms-text-size-adjust: 100%;
      background-color: #f7f7f7;
      font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      -webkit-font-smoothing: antialiased;
    }
    table {
      border-collapse: collapse;
      mso-table-lspace: 0pt;
      mso-table-rspace: 0pt;
    }
    img {
      border: 0;
      outline: none;
      text-decoration: none;
      display: block;
    }
    @media only screen and (max-width: 620px) {
      .container-table { width: 100% !important; border-radius: 0 !important; }
      .mobile-padding { padding-left: 24px !important; padding-right: 24px !important; }
    }
  </style>
</head>
<body bgcolor=\"#f7f7f7\" style=\"margin:0;padding:0;background-color:#f7f7f7;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;\">
  <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" bgcolor=\"#f7f7f7\" style=\"border-collapse:collapse;background-color:#f7f7f7;\">
    <tbody>
      <tr>
        <td height=\"48\" style=\"height:48px;line-height:48px;font-size:0;mso-line-height-rule:exactly;\">&nbsp;</td>
      </tr>
      <tr>
        <td align=\"center\" style=\"padding:0 16px;\">
        <!-- Main Card -->
        <table class=\"container-table\" width=\"600\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" style=\"max-width:600px;background:#ffffff;border:1px solid #e5e5e5;border-radius:20px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,0.04);\">
          <tbody>
            <!-- Top Header (Logo + Badge) -->
            <tr>
              <td style=\"padding:28px 40px 22px;border-bottom:1px solid #f0f0f0;\" class=\"mobile-padding\">
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
                  <tr>
                    <td valign=\"middle\">
                      " . self::get_brand_logo_html() . "
                    </td>
                    <td align=\"right\" valign=\"middle\">
                      <span style=\"display:inline-block;padding:5px 13px;background:#f4f4f5;color:#3f3f46;font-size:11px;font-weight:600;border-radius:999px;border:1px solid #e4e4e7;letter-spacing:0.3px;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">{$badge_text}</span>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>

            <!-- Message Headline & Body -->
            <tr>
              <td style=\"padding:36px 40px 32px;\" class=\"mobile-padding\">
                <h1 style=\"margin:0 0 20px;font-size:26px;font-weight:800;color:#111111;letter-spacing:-0.6px;line-height:1.25;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">{$title}</h1>
                <p style=\"margin:0 0 14px;font-size:15px;font-weight:600;color:#18181b;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">Hi {$cust_name},</p>
                <p style=\"margin:0 0 16px;font-size:14.5px;line-height:1.7;color:#3f3f46;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">
                  We have prepared your private custom order.
                </p>
                <p style=\"margin:0 0 20px;font-size:14.5px;line-height:1.7;color:#52525b;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">
                  This private order link is reserved for your email. Review your order details below and complete checkout.
                </p>

                {$img_preview_html}

                <!-- Primary CTA Button -->
                <div style=\"margin:32px 0 20px;text-align:center;\">
                  <a href=\"{$order_url}\" target=\"_blank\" rel=\"noopener noreferrer\" style=\"display:inline-block;padding:15px 36px;background:#111111;color:#ffffff;font-size:14px;font-weight:700;border-radius:100px;text-decoration:none;letter-spacing:0.2px;box-shadow:0 3px 10px rgba(0,0,0,0.12);font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">
                    {$cta_text} &rarr;
                  </a>
                </div>

                <p style=\"margin:0 0 24px;font-size:12px;color:#71717a;text-align:center;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">
                  Direct link: <a href=\"{$order_url}\" style=\"color:#111111;text-decoration:underline;\">{$order_url}</a>
                </p>

                <!-- Dedicated Spacer above Concierge Support -->
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
                  <tr>
                    <td height=\"36\" style=\"height:36px;font-size:0;line-height:0;\">&nbsp;</td>
                  </tr>
                </table>

                <!-- Help & Assistance Section -->
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"border-top:1px solid #f0f0f0;text-align:center;\">
                  <tr>
                    <td align=\"center\" style=\"padding-top:28px;\">
                      <p style=\"margin:0 0 10px;font-size:12px;line-height:1.65;color:#71717a;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">
                        Have questions about your custom order? Reach our team at <a href=\"mailto:support@exacoat.com\" style=\"color:#111111;text-decoration:underline;font-weight:500;\">support@exacoat.com</a>
                      </p>
                      <p style=\"margin:0 0 6px;font-size:11px;color:#a1a1aa;letter-spacing:0.2px;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">
                        &copy; Exacoat. All rights reserved.
                      </p>
                      <p style=\"margin:0;font-size:11px;color:#a1a1aa;font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;\">
                        You’re receiving this email regarding your custom order on exacoat.com.
                      </p>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </tbody>
        </table>
      </td>
    </tr>
    <tr>
      <td height=\"48\" style=\"height:48px;line-height:48px;font-size:0;mso-line-height-rule:exactly;\">&nbsp;</td>
    </tr>
  </tbody>
</table>
</body>
</html>";

		return [
			'subject'   => $subject,
			'html'      => $html,
			'tmpl_info' => $tmpl,
		];
	}

	/**
	 * Render High-Conversion, Responsive Abandoned Cart Transactional Email
	 * Fully compatible with antislop principles: clean typography, high-contrast CTA,
	 * genuine trust factors, and zero generic AI buzzwords.
	 */
	public static function render_abandoned_cart_html( string $event, array $data, array $tmpl ): array {
		$price_keys = [ 'subtotal', 'total' ];
		foreach ( $price_keys as $pk ) {
			if ( isset( $data[ $pk ] ) ) {
				$data[ $pk ] = self::clean_email_price( $data[ $pk ] );
			}
		}

		$replacements = [];
		foreach ( $data as $k => $v ) {
			if ( is_scalar( $v ) ) {
				$val_str = (string) $v;
				$replacements[ '{{' . $k . '}}' ] = $val_str;
				$replacements[ '{' . $k . '}' ]   = $val_str;
			}
		}

		$cust_name       = esc_html( $data['customer_first_name'] ?? 'there' );
		$badge_text      = esc_html( $data['badge_text'] ?? $tmpl['badge'] ?? 'Cart Saved' );
		$title           = esc_html( $data['title'] ?? $tmpl['title'] ?? 'Did you leave something behind?' );
		$cta_text        = esc_html( $data['cta_text'] ?? $tmpl['cta_text'] ?? 'Return to Checkout' );
		$restore_url     = esc_url( $data['restore_url'] ?? home_url( '/checkout/' ) );
		$raw_unsub       = (string) ( $data['unsubscribe_url'] ?? '' );
		$storefront_base = function_exists( 'exacoat_storefront_url' ) ? exacoat_storefront_url() : home_url();
		if ( empty( $raw_unsub ) || strpos( $raw_unsub, 'unsubscribe_url' ) !== false || strpos( $raw_unsub, '*|' ) !== false ) {
			$unsubscribe_url = trailingslashit( $storefront_base ) . 'cart/';
		} else {
			$unsubscribe_url = esc_url( $raw_unsub );
		}
		$is_second_email = ( $event === 'customer_cart_abandoned_2' || ( $data['sequence'] ?? '' ) === '2' );

		$subject        = str_replace( array_keys( $replacements ), array_values( $replacements ), $tmpl['subject'] );
		$title          = str_replace( array_keys( $replacements ), array_values( $replacements ), $title );
		$body_primary   = str_replace( array_keys( $replacements ), array_values( $replacements ), $tmpl['body_primary'] ?? '' );
		$body_secondary = str_replace( array_keys( $replacements ), array_values( $replacements ), $tmpl['body_secondary'] ?? '' );

		// Clean up orphan tags
		$tag_pattern    = '/\{\{[a-zA-Z0-9_-]+\}\}|\{[a-zA-Z0-9_-]+\}/';
		$subject        = preg_replace( $tag_pattern, '', $subject );
		$subject        = preg_replace( '/\s{2,}/', ' ', trim( $subject ) );
		$title          = preg_replace( $tag_pattern, '', $title );
		$body_primary   = preg_replace( $tag_pattern, '', $body_primary );
		$body_secondary = preg_replace( $tag_pattern, '', $body_secondary );

		$preheader = $tmpl['preheader'] ?? $data['preheader'] ?? '';
		if ( ! empty( $preheader ) ) {
			$preheader = str_replace( array_keys( $replacements ), array_values( $replacements ), $preheader );
			$preheader = preg_replace( $tag_pattern, '', $preheader );
		}

		// Build Item Rows
		$items      = $data['items'] ?? [];
		$items_rows = '';
		if ( is_array( $items ) && ! empty( $items ) ) {
			foreach ( $items as $item ) {
				$name      = esc_html( $item['name'] ?? 'Exacoat Device Protection' );
				$img       = esc_url( $item['image_url'] ?? 'https://media.exacoat.com/wp-content/uploads/Black-Camo-Texture-Thumbnail.jpg' );
				$qty       = (int) ( $item['quantity'] ?? 1 );
				$price     = esc_html( self::clean_email_price( $item['price'] ?? ( $item['subtotal'] ?? '' ) ) );
				$meta_raw  = $item['meta'] ?? '';
				$meta_html = '';
				if ( ! empty( $meta_raw ) ) {
					$lines = is_array( $meta_raw ) ? $meta_raw : explode( "\n", (string) $meta_raw );
					$clean_lines = array_filter( array_map( 'trim', $lines ), function( $l ) {
						return ! empty( $l ) && stripos( $l, 'image_url:' ) === false;
					} );
					if ( ! empty( $clean_lines ) ) {
						$meta_html = '<div style="margin-top:4px;">' . implode( '<br>', array_map( function( $l ) {
							return '<span style="font-size:12px;color:#71717a;line-height:1.4;">' . esc_html( $l ) . '</span>';
						}, $clean_lines ) ) . '</div>';
					}
				}

				$items_rows .= '
				<tr>
					<td style="padding:16px 0;border-bottom:1px solid #f4f4f5;" valign="middle">
						<table width="100%" cellpadding="0" cellspacing="0">
							<tr>
								<td width="72" valign="middle" style="width:72px;">
									<img src="' . $img . '" alt="' . $name . '" width="64" height="64" style="width:64px;height:64px;object-fit:cover;border-radius:10px;border:1px solid #e4e4e7;display:block;" />
								</td>
								<td valign="middle" style="padding-left:14px;">
									<p style="margin:0;font-size:14px;font-weight:700;color:#18181b;letter-spacing:-0.2px;">' . $name . '</p>
									' . $meta_html . '
									<p style="margin:4px 0 0;font-size:12px;font-weight:600;color:#a1a1aa;">Qty: ' . $qty . '</p>
								</td>
								<td align="right" valign="middle" style="white-space:nowrap;padding-left:12px;">
									<span style="font-size:14px;font-weight:700;color:#18181b;">' . $price . '</span>
								</td>
							</tr>
						</table>
					</td>
				</tr>';
			}
		}

		$subtotal = esc_html( self::clean_email_price( $data['subtotal'] ?? ( $data['total'] ?? '' ) ) );

		$logo_html = self::get_brand_logo_html();
		$preheader_html = $preheader ? '<div style="display:none;font-size:1px;color:#f4f4f5;line-height:1px;max-height:0px;max-width:0px;opacity:0;overflow:hidden;">' . esc_html( $preheader ) . '</div>' : '';
		$secondary_p = $body_secondary ? '<p style="margin:0 0 24px;font-size:14.5px;line-height:1.7;color:#52525b;">' . $body_secondary . '</p>' : '';

		$html = "<!doctype html>
<html lang=\"en\" xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:o=\"urn:schemas-microsoft-com:office:office\">
<head>
  <meta charset=\"utf-8\">
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
  <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
  <title>" . esc_html( $subject ) . "</title>
  <style>
    body { margin:0; padding:0; width:100% !important; background-color:#f4f4f5; font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif; }
    table { border-collapse:collapse; }
    img { border:0; outline:none; text-decoration:none; display:block; }
    @media only screen and (max-width:620px) {
      .container-table { width:100% !important; border-radius:0 !important; border-left:none !important; border-right:none !important; }
      .mobile-padding { padding:24px 20px !important; }
      .mobile-btn { width:100% !important; box-sizing:border-box !important; text-align:center !important; }
    }
  </style>
</head>
<body style=\"margin:0;padding:0;background-color:#f4f4f5;\">
  {$preheader_html}
  <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" bgcolor=\"#f4f4f5\" style=\"border-collapse:collapse;background-color:#f4f4f5;\">
    <tbody>
      <tr>
        <td height=\"48\" style=\"height:48px;line-height:48px;font-size:0;mso-line-height-rule:exactly;\">&nbsp;</td>
      </tr>
      <tr>
        <td align=\"center\" style=\"padding:0 16px;\">
        <table class=\"container-table\" width=\"580\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" style=\"max-width:580px;background:#ffffff;border:1px solid #e4e4e7;border-radius:18px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.03);\">
          <tbody>
            <!-- Header -->
            <tr>
              <td style=\"padding:28px 36px 20px;border-bottom:1px solid #f0f0f2;\" class=\"mobile-padding\">
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
                  <tr>
                    <td valign=\"middle\">
                      {$logo_html}
                    </td>
                    <td align=\"right\" valign=\"middle\">
                      <span style=\"display:inline-block;padding:5px 12px;background:#f4f4f5;color:#3f3f46;font-size:11px;font-weight:600;border-radius:999px;border:1px solid #e4e4e7;letter-spacing:0.3px;\">{$badge_text}</span>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>

            <!-- Main Content Area -->
            <tr>
              <td style=\"padding:36px 36px 28px;\" class=\"mobile-padding\">
                <h1 style=\"margin:0 0 16px;font-size:24px;font-weight:700;color:#111111;letter-spacing:-0.5px;line-height:1.3;\">{$title}</h1>
                <p style=\"margin:0 0 12px;font-size:15px;font-weight:600;color:#18181b;\">Hi {$cust_name},</p>
                <p style=\"margin:0 0 14px;font-size:14.5px;line-height:1.7;color:#3f3f46;\">{$body_primary}</p>
                {$secondary_p}

                <!-- Primary Action Button -->
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"margin:20px 0 32px;\">
                  <tr>
                    <td>
                      <a href=\"{$restore_url}\" target=\"_blank\" class=\"mobile-btn\" style=\"display:inline-block;padding:14px 32px;background:#111111;color:#ffffff;font-size:14px;font-weight:700;border-radius:12px;text-decoration:none;letter-spacing:0.2px;\">
                        {$cta_text} &rarr;
                      </a>
                    </td>
                  </tr>
                </table>

                <!-- Items In Cart Section -->
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"border-top:1px solid #f0f0f2;padding-top:16px;\">
                  <tr>
                    <td style=\"padding:12px 0 8px;\">
                      <p style=\"margin:0;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:#71717a;\">Items in Your Cart</p>
                    </td>
                  </tr>
                  {$items_rows}
                </table>

                <!-- Subtotal Breakdown -->
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"margin-top:16px;\">
                  <tr>
                    <td style=\"padding:10px 0;font-size:14px;font-weight:600;color:#3f3f46;\">Subtotal</td>
                    <td align=\"right\" style=\"padding:10px 0;font-size:15px;font-weight:700;color:#111111;\">{$subtotal}</td>
                  </tr>
                </table>

                <!-- Secondary Action Button -->
                <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"margin-top:24px;\">
                  <tr>
                    <td align=\"center\">
                      <a href=\"{$restore_url}\" target=\"_blank\" style=\"font-size:13.5px;font-weight:600;color:#18181b;text-decoration:underline;\">
                        Ready to proceed? Continue to checkout &rarr;
                      </a>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>

            <!-- Footer -->
            <tr>
              <td style=\"padding:24px 36px 28px;background:#fafafa;border-top:1px solid #f0f0f2;text-align:center;\" class=\"mobile-padding\">
                <p style=\"margin:0 0 10px;font-size:12px;line-height:1.65;color:#71717a;\">
                  Have questions about your order or device compatibility? Reply directly to this email or reach us at <a href=\"mailto:support@exacoat.com\" style=\"color:#111111;text-decoration:underline;font-weight:500;\">support@exacoat.com</a>.
                </p>
                <p style=\"margin:0 0 12px;font-size:11.5px;color:#a1a1aa;\">
                  <a href=\"{$unsubscribe_url}\" style=\"color:#71717a;text-decoration:underline;\">Unsubscribe from cart reminders</a>
                </p>
                <p style=\"margin:0;font-size:11px;color:#a1a1aa;letter-spacing:0.2px;\">
                  &copy; Exacoat
                </p>
              </td>
            </tr>
          </tbody>
        </table>
      </td>
    </tr>
    <tr>
      <td height=\"48\" style=\"height:48px;line-height:48px;font-size:0;mso-line-height-rule:exactly;\">&nbsp;</td>
    </tr>
  </tbody>
</table>
</body>
</html>";

		// Final Safety: Guarantee no raw or broken unsubscribe placeholder exists in final HTML
		$html = preg_replace( '/(?:https?:\/\/)?(?:%7B%7B|\{\{)\s*(?:unsubscribe_url|unsubscribe)\s*(?:%7D%7D|\}\})\/?/i', $unsubscribe_url, $html );
		$html = preg_replace( '/(?:https?:\/\/)?\{\s*(?:unsubscribe_url|unsubscribe)\s*\}\/?/i', $unsubscribe_url, $html );
		$html = str_replace( '*|UNSUBSCRIBE_URL|*', $unsubscribe_url, $html );

		return [
			'subject'   => $subject,
			'html'      => $html,
			'tmpl_info' => $tmpl,
		];
	}

	/**
	 * Handler: Customer Note Added
	 */
	public static function handle_woocommerce_new_customer_note( $args ) {
		$order_id      = is_array( $args ) ? ( $args['order_id'] ?? 0 ) : ( is_numeric( $args ) ? (int) $args : 0 );
		$customer_note = is_array( $args ) ? ( $args['customer_note'] ?? '' ) : '';
		
		if ( ! $order_id || ! function_exists( 'wc_get_order' ) ) return;
		$order = wc_get_order( $order_id );
		if ( ! $order ) return;

		$customer_email = $order->get_billing_email();
		$customer_name  = $order->get_formatted_billing_full_name() ?: 'Customer';
		if ( ! is_email( $customer_email ) ) return;

		$order_mgr_class = class_exists( 'Exacoat_Order_Manager' ) ? 'Exacoat_Order_Manager' : ( class_exists( 'Artmatter_Order_Manager' ) ? 'Artmatter_Order_Manager' : '' );
		$payload = ! empty( $order_mgr_class )
			? $order_mgr_class::get_email_order_payload( $order, [ 'customer_note' => $customer_note ] )
			: [ 'customer_note' => $customer_note ];

		self::send_email( 'customer_order_note', $customer_email, $customer_name, $payload );
	}

	/**
	 * Handler: WooCommerce Customer Reset Password
	 */
	public static function handle_woocommerce_reset_password_notification( $user_login, $reset_key ) {
		$user = get_user_by( 'login', $user_login );
		if ( ! $user || ! is_email( $user->user_email ) ) return;

		$storefront_base = function_exists( 'exacoat_storefront_url' )
			? exacoat_storefront_url( 'login' )
			: ( defined( 'EXACOAT_WEB_URL' ) ? EXACOAT_WEB_URL . '/login' : 'https://exacoat.com/login' );

		$reset_url = add_query_arg( [
			'mode'  => 'reset',
			'key'   => $reset_key,
			'login' => rawurlencode( $user_login ),
		], $storefront_base );

		$first_name = get_user_meta( $user->ID, 'first_name', true ) ?: ( $user->display_name ?: 'Collector' );

		self::send_email( 'customer_reset_password', $user->user_email, $first_name, [
			'customer_first_name' => $first_name,
			'reset_url'           => $reset_url,
		] );
	}

	/**
	 * Handler: WooCommerce Customer Account Created
	 */
	public static function handle_woocommerce_created_customer( $customer_id, $new_customer_data, $password_generated ) {
		$user = get_userdata( $customer_id );
		if ( ! $user || ! is_email( $user->user_email ) ) return;

		$first_name = get_user_meta( $customer_id, 'first_name', true ) ?: ( $user->display_name ?: 'Collector' );
		$account_url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/my-account' );

		self::send_email( 'customer_new_account', $user->user_email, $first_name, [
			'customer_first_name' => $first_name,
			'account_url'         => $account_url,
		] );
	}

	/**
	 * Handler: Manual Resend Order Details / Invoice
	 */
	public static function handle_woocommerce_resend_order_emails( $order, $email_type = '' ) {
		if ( ! $order || ! is_a( $order, 'WC_Order' ) ) return;
		$customer_email = $order->get_billing_email();
		$customer_name  = $order->get_formatted_billing_full_name() ?: 'Customer';
		if ( ! is_email( $customer_email ) ) return;

		$order_mgr_class = class_exists( 'Exacoat_Order_Manager' ) ? 'Exacoat_Order_Manager' : ( class_exists( 'Artmatter_Order_Manager' ) ? 'Artmatter_Order_Manager' : '' );
		$payload = ! empty( $order_mgr_class )
			? $order_mgr_class::get_email_order_payload( $order )
			: [];

		self::send_email( 'customer_order_invoice', $customer_email, $customer_name, $payload );
	}

	/**
	 * Send Transactional Email via Zoho ZeptoMail API (or wp_mail fallback)
	 */
	public static function send_email( string $event, string $recipient_email, string $recipient_name = '', array $data = [] ): array {
		if ( ! is_email( $recipient_email ) ) {
			return [ 'success' => false, 'message' => 'Invalid recipient email address' ];
		}

		// Temporary disable: 'customer_order_delivered' email is suppressed per admin request while tracking is being resolved
		if ( 'customer_order_delivered' === $event ) {
			if ( class_exists( 'Exacoat_Logger' ) ) {
				Exacoat_Logger::info( 'email', "Delivery email dispatch suppressed for {$recipient_email}: customer_order_delivered is temporarily disabled." );
			}
			return [
				'success' => false,
				'message' => 'Delivery email (customer_order_delivered) is temporarily disabled by admin.',
			];
		}

		$config     = self::get_config();
		$from_email = ! empty( $data['from_email'] ) && is_email( $data['from_email'] ) ? sanitize_email( $data['from_email'] ) : $config['from_email'];
		$from_name  = ! empty( $data['from_name'] ) ? sanitize_text_field( $data['from_name'] ) : $config['from_name'];

		if ( ! empty( $data['htmlbody'] ) || ! empty( $data['html'] ) ) {
			$html    = $data['htmlbody'] ?? $data['html'];
			$subject = $data['subject'] ?? 'Exacoat Update';
		} else {
			$rendered = self::render_html( $event, array_merge( [ 'customer_name' => $recipient_name ?: 'Customer' ], $data ) );
			$subject = $rendered['subject'];
			$html    = $rendered['html'];
		}

		// Direct ZeptoMail Send Mail API
		if ( ! empty( $config['zeptomail_token'] ) ) {
			$domain   = get_option( 'transmail_domain_name', 'zoho.com' );
			$base_url = 'https://api.zeptomail.com';
			if ( class_exists( 'Transmail_Helper' ) && method_exists( 'Transmail_Helper', 'getZeptoMailUrlForDomain' ) ) {
				$base_url = Transmail_Helper::getZeptoMailUrlForDomain( $domain );
			} elseif ( strpos( $domain, 'eu' ) !== false ) {
				$base_url = 'https://api.zeptomail.eu';
			} elseif ( strpos( $domain, 'in' ) !== false ) {
				$base_url = 'https://api.zeptomail.in';
			}
			$api_url = rtrim( $base_url, '/' ) . '/v1.1/email';
			$payload = [
				'from'     => [
					'address' => $from_email,
					'name'    => $from_name,
				],
				'to'       => [
					[
						'email_address' => [
							'address' => $recipient_email,
							'name'    => $recipient_name ?: 'Customer',
						],
					],
				],
				'subject'  => $subject,
				'htmlbody' => $html,
			];

			$reply_to = sanitize_email( $data['reply_to'] ?? '' );
			if ( is_email( $reply_to ) ) {
				$payload['reply_to'] = [
					[
						'address' => $reply_to,
						'name'    => sanitize_text_field( $data['reply_name'] ?? $from_name ),
					],
				];
			}

			// Process attachments (Custom Invoice, Payout Statement, etc.)
			$attachments = $data['attachments'] ?? [];
			if ( empty( $attachments ) ) {
				if ( 'payout_sent' === $event ) {
					$statement_html = self::generate_payout_statement_html( $data );
					$payout_id = $data['payout_id'] ?? 'Statement';
					$attachments[] = [
						'content'   => base64_encode( $statement_html ),
						'mime_type' => 'text/html',
						'name'      => "Payout-Statement-{$payout_id}.html",
					];
				}
			}

			if ( ! empty( $attachments ) ) {
				$payload['attachments'] = $attachments;
			}

			$clean_token = trim( $config['zeptomail_token'] );
			$auth_header = str_starts_with( $clean_token, 'Zoho-enczapikey ' )
				? $clean_token
				: 'Zoho-enczapikey ' . $clean_token;

			$start = microtime( true );
			$response = wp_remote_post( $api_url, [
				'headers' => [
					'Accept'        => 'application/json',
					'Content-Type'  => 'application/json',
					'Authorization' => $auth_header,
				],
				'body'    => wp_json_encode( $payload ),
				'timeout' => 15,
			] );
			$latency = round( ( microtime( true ) - $start ) * 1000 );

			$status_code = ! is_wp_error( $response ) ? wp_remote_retrieve_response_code( $response ) : 500;
			$body        = ! is_wp_error( $response ) ? json_decode( wp_remote_retrieve_body( $response ), true ) : null;
			$is_ok       = ( $status_code >= 200 && $status_code < 300 );
			$request_id  = $body['data'][0]['request_id'] ?? ( $body['request_id'] ?? '' );
			$err_msg     = ! $is_ok ? ( is_wp_error( $response ) ? $response->get_error_message() : ( $body['message'] ?? ( $body['error']['message'] ?? ( $body['error']['details'][0]['message'] ?? "HTTP {$status_code}" ) ) ) ) : null;

			if ( $is_ok ) {
				if ( class_exists( 'Exacoat_Logger' ) ) {
					Exacoat_Logger::log(
						'success',
						'email',
						"Direct ZeptoMail Email Sent: '{$event}' to {$recipient_email} from {$from_email} -> HTTP {$status_code} ({$latency}ms)",
						[
							'event'       => $event,
							'recipient'   => $recipient_email,
							'from'        => $from_email,
							'status_code' => $status_code,
							'latency_ms'  => $latency,
							'request_id'  => $request_id,
						]
					);
				} elseif ( class_exists( 'Artmatter_Logger' ) ) {
					Artmatter_Logger::log(
						'success',
						'email',
						"Direct ZeptoMail Email Sent: '{$event}' to {$recipient_email} from {$from_email} -> HTTP {$status_code} ({$latency}ms)",
						[
							'event'       => $event,
							'recipient'   => $recipient_email,
							'from'        => $from_email,
							'status_code' => $status_code,
							'latency_ms'  => $latency,
							'request_id'  => $request_id,
						]
					);
				}

				if ( class_exists( 'Exacoat_Email_Logger' ) ) {
					Exacoat_Email_Logger::log_outbound( [
						'request_id'      => $request_id,
						'provider'        => 'zeptomail',
						'event'           => $event,
						'order_id'        => intval( $data['order_id'] ?? $data['order_number'] ?? 0 ),
						'recipient_email' => $recipient_email,
						'recipient_name'  => $recipient_name ?: 'Customer',
						'subject'         => $subject,
						'status'          => 'sent',
						'status_code'     => $status_code,
						'latency_ms'      => $latency,
						'error_message'   => null,
						'metadata'        => $data,
					] );
				}

				return [
					'success'     => true,
					'status_code' => $status_code,
					'latency_ms'  => $latency,
					'message'     => "Email sent directly via ZeptoMail in {$latency}ms!",
					'response'    => $body,
				];
			}

			// If direct ZeptoMail API returned an error, log warning and gracefully fall through to wp_mail()
			if ( class_exists( 'Exacoat_Logger' ) ) {
				Exacoat_Logger::log(
					'warning',
					'email',
					"Direct ZeptoMail API returned {$status_code}: {$err_msg}. Falling back to wp_mail() delivery.",
					[ 'event' => $event, 'recipient' => $recipient_email, 'from' => $from_email, 'error' => $err_msg ]
				);
			}
		}

		// Fallback to WordPress standard wp_mail()
		if ( class_exists( 'Exacoat_Core' ) && method_exists( 'Exacoat_Core', 'maybe_sync_email_senders' ) ) {
			Exacoat_Core::maybe_sync_email_senders();
		}

		$headers  = [ 'Content-Type: text/html; charset=UTF-8', "From: {$from_name} <{$from_email}>" ];
		$reply_to = sanitize_email( $data['reply_to'] ?? '' );
		if ( is_email( $reply_to ) ) {
			$reply_name = sanitize_text_field( $data['reply_name'] ?? $from_name );
			$headers[]  = "Reply-To: {$reply_name} <{$reply_to}>";
		}

		$from_filter = function() use ( $from_email ) { return $from_email; };
		$name_filter = function() use ( $from_name ) { return $from_name; };

		// Intercept $args['headers'] in transMail and WP core wp_mail filter
		$wp_mail_filter = function( $args ) use ( $from_email, $from_name ) {
			if ( ! is_array( $args ) ) {
				return $args;
			}
			$h_list = $args['headers'] ?? [];
			if ( is_string( $h_list ) ) {
				$h_list = explode( "\n", str_replace( "\r\n", "\n", $h_list ) );
			}
			if ( is_array( $h_list ) ) {
				$h_list = array_values( array_filter( $h_list, function( $h ) {
					return stripos( trim( (string) $h ), 'from:' ) !== 0;
				} ) );
				$h_list[] = "From: {$from_name} <{$from_email}>";
				$args['headers'] = $h_list;
			}
			return $args;
		};

		// Intercept PHPMailer directly for core mailers and SMTP plugins
		$phpmailer_filter = function( $phpmailer ) use ( $from_email, $from_name ) {
			if ( ! empty( $from_email ) ) {
				$phpmailer->From   = $from_email;
				$phpmailer->Sender = $from_email;
			}
			if ( ! empty( $from_name ) ) {
				$phpmailer->FromName = $from_name;
			}
		};

		add_filter( 'wp_mail_from', $from_filter, 999 );
		add_filter( 'wp_mail_from_name', $name_filter, 999 );
		add_filter( 'wp_mail', $wp_mail_filter, 999 );
		add_action( 'phpmailer_init', $phpmailer_filter, 999999 );

		$sent = wp_mail( $recipient_email, $subject, $html, $headers );

		remove_filter( 'wp_mail_from', $from_filter, 999 );
		remove_filter( 'wp_mail_from_name', $name_filter, 999 );
		remove_filter( 'wp_mail', $wp_mail_filter, 999 );
		remove_action( 'phpmailer_init', $phpmailer_filter, 999999 );

		if ( class_exists( 'Exacoat_Logger' ) ) {
			Exacoat_Logger::log(
				$sent ? 'success' : 'error',
				'email',
				"Email Sent via wp_mail(): '{$event}' to {$recipient_email}",
				[ 'event' => $event, 'recipient' => $recipient_email ]
			);
		} elseif ( class_exists( 'Artmatter_Logger' ) ) {
			Artmatter_Logger::log(
				$sent ? 'success' : 'error',
				'email',
				"Email Sent via wp_mail(): '{$event}' to {$recipient_email}",
				[ 'event' => $event, 'recipient' => $recipient_email ]
			);
		}

		if ( class_exists( 'Exacoat_Email_Logger' ) ) {
			Exacoat_Email_Logger::log_outbound( [
				'request_id'      => '',
				'provider'        => 'wp_mail',
				'event'           => $event,
				'order_id'        => intval( $data['order_id'] ?? $data['order_number'] ?? 0 ),
				'recipient_email' => $recipient_email,
				'recipient_name'  => $recipient_name ?: 'Customer',
				'subject'         => $subject,
				'status'          => $sent ? 'sent' : 'failed',
				'status_code'     => $sent ? 200 : 500,
				'latency_ms'      => 0,
				'error_message'   => $sent ? null : 'wp_mail failed to dispatch',
				'metadata'        => $data,
			] );
		}

		return [
			'success' => $sent,
			'message' => $sent ? 'Email delivered via WordPress wp_mail()' : 'wp_mail failed to dispatch',
		];
	}

	public static function process_async_email_job( $event, $recipient_email, $recipient_name, $data ) {
		self::send_email( (string) $event, (string) $recipient_email, (string) $recipient_name, (array) $data );
	}

	/**
	 * AJAX Handler: Send Live Test Email
	 */
	public static function ajax_send_test_email() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => 'Unauthorized' ] );
		}

		$event     = sanitize_key( $_POST['event'] ?? 'artist_otp_code' );
		$recipient = sanitize_email( $_POST['recipient_email'] ?? '' );
		$name      = sanitize_text_field( $_POST['recipient_name'] ?? 'Customer' );

		$res = self::send_email( $event, $recipient, $name );
		if ( $res['success'] ) {
			wp_send_json_success( $res );
		} else {
			wp_send_json_error( $res );
		}
	}

	/**
	 * AJAX Handler: Live Visual HTML Preview
	 */
	public static function ajax_preview_email_html() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => 'Unauthorized' ] );
		}

		$event = sanitize_key( $_GET['event'] ?? ( $_POST['event'] ?? ( $_GET['template_key'] ?? ( $_POST['template_key'] ?? ( $_GET['template_slug'] ?? ( $_POST['template_slug'] ?? ( $_GET['slug'] ?? ( $_POST['slug'] ?? 'customer_order_processing' ) ) ) ) ) ) ) );
		$custom_data = $_POST['data'] ?? ( $_GET['data'] ?? [] );
		if ( is_string( $custom_data ) ) {
			$decoded = json_decode( stripslashes( $custom_data ), true );
			if ( is_array( $decoded ) ) {
				$custom_data = $decoded;
			}
		}
		$rendered = self::render_html( $event, is_array( $custom_data ) ? $custom_data : [] );

		wp_send_json_success( [
			'subject' => $rendered['subject'],
			'html'    => $rendered['html'],
		] );
	}

	/**
	 * Acumbamail Configuration Accessor
	 */
	public static function get_acumbamail_config(): array {
		$settings = Exacoat_Core::get_settings();
		return [
			'auth_token'   => trim( $settings['acumbamail_token'] ?? '' ),
			'from_email'   => trim( $settings['acumbamail_from_email'] ?? 'sales@exacoat.com' ),
			'from_name'    => trim( $settings['acumbamail_from_name'] ?? 'Exacoat' ),
			'default_list' => trim( $settings['acumbamail_default_list'] ?? '678690' ),
		];
	}

	/**
	 * Fetch subscriber lists from Acumbamail
	 */
	public static function get_acumbamail_lists( string $token = '' ): array {
		$config = self::get_acumbamail_config();
		$auth_token = $token ?: $config['auth_token'];
		if ( empty( $auth_token ) ) {
			return [ 'success' => false, 'error' => 'Acumbamail auth token is missing' ];
		}

		$response = wp_remote_post( 'https://acumbamail.com/api/1/getLists/', [
			'body'    => [
				'auth_token'    => $auth_token,
				'response_type' => 'json',
			],
			'timeout' => 15,
		] );

		if ( is_wp_error( $response ) ) {
			return [ 'success' => false, 'error' => $response->get_error_message() ];
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( ! is_array( $data ) ) {
			return [ 'success' => false, 'error' => 'Invalid response from Acumbamail' ];
		}

		$formatted = [];
		foreach ( $data as $id => $item ) {
			$formatted[] = [
				'id'          => (string) $id,
				'name'        => $item['name'] ?? "List #{$id}",
				'description' => $item['description'] ?? '',
			];
		}

		return [ 'success' => true, 'lists' => $formatted ];
	}

	/**
	 * Normalize Acumbamail Campaign HTML.
	 * Replaces any broken or legacy tags like https://{{unsubscribe_url}}/, {{unsubscribe_url}}, etc.
	 * with Acumbamail's official merge tags: *|UNSUBSCRIBE_URL|* and *|BROWSER_VIEW|*.
	 */
	public static function normalize_acumbamail_campaign_html( string $html ): string {
		if ( empty( $html ) ) {
			return '';
		}

		// Normalize Unsubscribe variations
		$html = preg_replace(
			'/(?:https?:\/\/)?(?:%7B%7B|\{\{)\s*(?:unsubscribe_url|unsubscribe)\s*(?:%7D%7D|\}\})\/?/i',
			'*|UNSUBSCRIBE_URL|*',
			$html
		);
		$html = preg_replace(
			'/(?:https?:\/\/)?\{\s*(?:unsubscribe_url|unsubscribe)\s*\}\/?/i',
			'*|UNSUBSCRIBE_URL|*',
			$html
		);
		$html = preg_replace( '/\*\|UNSUBSCRIBE\|\*/i', '*|UNSUBSCRIBE_URL|*', $html );

		// Normalize Webview / Browser View variations
		$html = preg_replace(
			'/(?:https?:\/\/)?(?:%7B%7B|\{\{)\s*(?:webview_url|webview|browser_view)\s*(?:%7D%7D|\}\})\/?/i',
			'*|BROWSER_VIEW|*',
			$html
		);
		$html = preg_replace(
			'/(?:https?:\/\/)?\{\s*(?:webview_url|webview|browser_view)\s*\}\/?/i',
			'*|BROWSER_VIEW|*',
			$html
		);
		$html = preg_replace( '/\*\|(?:WEBVIEW|WEBVIEW_URL)\|\*/i', '*|BROWSER_VIEW|*', $html );

		return $html;
	}

	/**
	 * Normalize Acumbamail Single 1-to-1 Email HTML.
	 * Because sendOne lacks subscriber list / campaign context, Acumbamail does not replace merge tags.
	 * Convert placeholders and merge tags to valid URLs so recipients never receive raw broken tags.
	 */
	public static function normalize_acumbamail_single_html( string $html, string $fallback_unsub = '', string $fallback_webview = '' ): string {
		if ( empty( $html ) ) {
			return '';
		}

		$storefront_base = function_exists( 'exacoat_storefront_url' ) ? exacoat_storefront_url() : home_url();
		$unsub_url       = ! empty( $fallback_unsub ) ? $fallback_unsub : trailingslashit( $storefront_base ) . 'cart/';
		$webview_url     = ! empty( $fallback_webview ) ? $fallback_webview : $storefront_base;

		// First normalize to standard tags
		$html = self::normalize_acumbamail_campaign_html( $html );

		// Then swap tags with working absolute URLs
		$html = str_replace( '*|UNSUBSCRIBE_URL|*', $unsub_url, $html );
		$html = str_replace( '*|BROWSER_VIEW|*', $webview_url, $html );

		return $html;
	}

	/**
	 * Send bulk campaign via Acumbamail
	 */
	public static function create_acumbamail_campaign( array $args ): array {
		$config = self::get_acumbamail_config();
		$auth_token = ! empty( $args['auth_token'] ) ? $args['auth_token'] : $config['auth_token'];

		if ( empty( $auth_token ) ) {
			return [ 'success' => false, 'error' => 'Acumbamail auth token missing' ];
		}

		$name       = sanitize_text_field( $args['name'] ?? 'Marketing Campaign ' . gmdate( 'Y-m-d H:i' ) );
		$from_name  = sanitize_text_field( $args['from_name'] ?? $config['from_name'] );
		$from_email = sanitize_email( $args['from_email'] ?? $config['from_email'] );
		$subject    = sanitize_text_field( $args['subject'] ?? 'Exacoat Update' );
		$raw_content= $args['content'] ?? $args['html'] ?? '';
		$content    = self::normalize_acumbamail_campaign_html( $raw_content );
		$lists      = $args['lists'] ?? ( ! empty( $config['default_list'] ) ? [ $config['default_list'] ] : [] );

		if ( empty( $content ) ) {
			return [ 'success' => false, 'error' => 'Email content cannot be empty' ];
		}
		if ( empty( $lists ) ) {
			return [ 'success' => false, 'error' => 'At least one subscriber list must be selected' ];
		}

		$post_data = [
			'auth_token'    => $auth_token,
			'response_type' => 'json',
			'name'          => $name,
			'from_name'     => $from_name,
			'from_email'    => $from_email,
			'subject'       => $subject,
			'content'       => $content,
			'https'         => 1,
		];

		if ( is_array( $lists ) ) {
			foreach ( $lists as $idx => $lid ) {
				$post_data["lists[{$idx}]"] = $lid;
			}
		}

		$start = microtime( true );
		$response = wp_remote_post( 'https://acumbamail.com/api/1/createCampaign/', [
			'body'    => $post_data,
			'timeout' => 25,
		] );
		$latency = (int) round( ( microtime( true ) - $start ) * 1000 );

		if ( is_wp_error( $response ) ) {
			return [ 'success' => false, 'error' => $response->get_error_message(), 'latency_ms' => $latency ];
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( $code >= 200 && $code < 300 ) {
			return [
				'success'     => true,
				'campaign_id' => is_numeric( $body ) ? (int) $body : ( $data['campaign_id'] ?? $body ),
				'latency_ms'  => $latency,
				'message'     => 'Campaign successfully created and queued in Acumbamail',
			];
		}

		return [
			'success'    => false,
			'error'      => is_array( $data ) && ! empty( $data['error'] ) ? ( is_string( $data['error'] ) ? $data['error'] : wp_json_encode( $data['error'] ) ) : ( $body ?: "HTTP {$code}" ),
			'latency_ms' => $latency,
		];
	}

	/**
	 * Send single 1-to-1 email via Acumbamail
	 */
	public static function send_acumbamail_single( string $to_email, string $subject, string $html, string $from_email = '', string $from_name = '' ): array {
		$config = self::get_acumbamail_config();
		$auth_token = $config['auth_token'];

		if ( empty( $auth_token ) ) {
			return [ 'success' => false, 'error' => 'Acumbamail auth token missing' ];
		}
		if ( ! is_email( $to_email ) ) {
			return [ 'success' => false, 'error' => 'Invalid recipient email address' ];
		}

		$sender_email = $from_email ?: $config['from_email'];
		$sender_name  = $from_name ?: ( $config['from_name'] ?: 'Exacoat' );

		$post_data = [
			'auth_token'    => $auth_token,
			'response_type' => 'json',
			'from_email'    => $sender_email,
			'from_name'     => $sender_name,
			'to_email'      => $to_email,
			'subject'       => $subject,
			'body'          => self::normalize_acumbamail_single_html( $html ),
		];

		$start = microtime( true );
		$response = wp_remote_post( 'https://acumbamail.com/api/1/sendOne/', [
			'body'    => $post_data,
			'timeout' => 20,
		] );
		$latency = (int) round( ( microtime( true ) - $start ) * 1000 );

		if ( is_wp_error( $response ) ) {
			return [ 'success' => false, 'error' => $response->get_error_message(), 'latency_ms' => $latency ];
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( $code >= 200 && $code < 300 ) {
			return [
				'success'    => true,
				'result'     => $data ?: $body,
				'latency_ms' => $latency,
				'message'    => 'Email dispatched via Acumbamail successfully',
			];
		}

		return [
			'success'    => false,
			'error'      => is_array( $data ) && ! empty( $data['error'] ) ? ( is_string( $data['error'] ) ? $data['error'] : wp_json_encode( $data['error'] ) ) : ( $body ?: "HTTP {$code}" ),
			'latency_ms' => $latency,
		];
	}

	/**
	 * Get past campaigns from Acumbamail
	 */
	public static function get_acumbamail_campaigns(): array {
		$config = self::get_acumbamail_config();
		$auth_token = $config['auth_token'];

		if ( empty( $auth_token ) ) {
			return [ 'success' => false, 'error' => 'Acumbamail auth token missing' ];
		}

		$start = microtime( true );
		$response = wp_remote_post( 'https://acumbamail.com/api/1/getCampaigns/', [
			'body'    => [
				'auth_token'    => $auth_token,
				'response_type' => 'json',
			],
			'timeout' => 15,
		] );
		$latency = (int) round( ( microtime( true ) - $start ) * 1000 );

		if ( is_wp_error( $response ) ) {
			return [ 'success' => false, 'error' => $response->get_error_message(), 'latency_ms' => $latency ];
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( is_array( $data ) ) {
			$campaigns = [];
			foreach ( $data as $item ) {
				if ( is_array( $item ) ) {
					foreach ( $item as $id => $name ) {
						$campaigns[] = [ 'id' => (string) $id, 'name' => (string) $name ];
					}
				}
			}
			return [ 'success' => true, 'campaigns' => $campaigns, 'latency_ms' => $latency ];
		}

		return [ 'success' => false, 'error' => $body ?: 'Failed to parse Acumbamail campaigns', 'latency_ms' => $latency ];
	}

	/**
	 * Get specific campaign detail and HTML from Acumbamail
	 */
	public static function get_acumbamail_campaign_detail( string $campaign_id ): array {
		$config = self::get_acumbamail_config();
		$auth_token = $config['auth_token'];

		if ( empty( $auth_token ) ) {
			return [ 'success' => false, 'error' => 'Acumbamail auth token missing' ];
		}

		// 1. Basic info
		$info_res = wp_remote_post( 'https://acumbamail.com/api/1/getCampaignBasicInformation/', [
			'body'    => [
				'auth_token'    => $auth_token,
				'response_type' => 'json',
				'campaign_id'   => $campaign_id,
			],
			'timeout' => 15,
		] );

		$info_data = [];
		if ( ! is_wp_error( $info_res ) ) {
			$info_body = wp_remote_retrieve_body( $info_res );
			$info_data = json_decode( $info_body, true ) ?: [];
		}

		// 2. HTML content
		$html_res = wp_remote_post( 'https://acumbamail.com/api/1/getCampaignHTML/', [
			'body'    => [
				'auth_token'    => $auth_token,
				'response_type' => 'json',
				'campaign_id'   => $campaign_id,
			],
			'timeout' => 15,
		] );

		$html_content = '';
		if ( ! is_wp_error( $html_res ) ) {
			$html_body = wp_remote_retrieve_body( $html_res );
			$html_parsed = json_decode( $html_body, true );
			$html_content = $html_parsed['html'] ?? ( is_string( $html_body ) ? $html_body : '' );
		}

		return [
			'success' => true,
			'id'      => $campaign_id,
			'name'    => $info_data['name'] ?? '',
			'subject' => $info_data['subject'] ?? '',
			'sent'    => $info_data['total_sent'] ?? 0,
			'date'    => $info_data['date_sent'] ?? $info_data['date'] ?? '',
			'html'    => $html_content,
		];
	}
}

}


