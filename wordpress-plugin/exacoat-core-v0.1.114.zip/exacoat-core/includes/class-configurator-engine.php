<?php
/**
 * Exacoat Configurator Engine
 *
 * Manages global finishes inventory, materials stock availability,
 * dynamic configurator data injection, and composable device profiles.
 *
 * @package Exacoat_Core
 * @version 0.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Exacoat_Configurator_Engine' ) ) {

class Exacoat_Configurator_Engine {

	const OPTION_KEY = 'exacoat_global_finishes';
	const LEGACY_OPTION_KEY = 'artmatter_global_finishes';
	const GROUPS_OPTION_KEY = 'exacoat_global_finish_groups';
	const GROUP_SETTINGS_OPTION_KEY = 'exacoat_finish_group_settings';
	const PRESETS_OPTION_KEY = 'exacoat_configurator_presets';
	const PROFILE_META_KEY = '_exacoat_configurator_profile';
	const CONFIGURATOR_FLAG_META_KEY = '_is_configurator';
	const AUDIT_TIME_META_KEY = '_configurator_last_audited';
	const AUDIT_STATUS_META_KEY = '_configurator_audit_status';
	const AUDIT_ISSUES_META_KEY = '_configurator_audit_issues';
	const AUDIT_DETAILS_META_KEY = '_configurator_audit_details';
	const SURCHARGE_TIERS_OPTION_KEY = 'exacoat_finish_surcharge_tiers';

	private static $cached_finishes = null;

	/**
	 * Recursively decode HTML entities from strings, arrays, or objects.
	 * Resolves &amp;, &#038;, &#38;, &quot;, &#039;, &apos;, &lt;, &gt;, &nbsp;, and others.
	 * Performs up to 3 passes to unwrap nested or double-encoded entities (e.g. &amp;amp;).
	 *
	 * @param mixed $data
	 * @return mixed
	 */
	public static function decode_entities( $data ) {
		if ( is_string( $data ) ) {
			if ( strpos( $data, '&' ) === false ) {
				return $data;
			}
			$decoded = $data;
			for ( $i = 0; $i < 3; $i++ ) {
				$prev = $decoded;
				$decoded = html_entity_decode( $decoded, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
				$decoded = str_replace( [ '&#038;', '&#38;' ], '&', $decoded );
				if ( $decoded === $prev ) {
					break;
				}
			}
			return $decoded;
		}

		if ( is_array( $data ) ) {
			$cleaned = [];
			foreach ( $data as $key => $val ) {
				$clean_key = is_string( $key ) ? self::decode_entities( $key ) : $key;
				$clean_val = self::decode_entities( $val );
				$cleaned[ $clean_key ] = $clean_val;
			}
			return $cleaned;
		}

		return $data;
	}

	public static function get_finish_groups(): array {
		$groups = get_option( self::GROUPS_OPTION_KEY, null );
		if ( empty( $groups ) || ! is_array( $groups ) ) {
			$finishes = self::get_finishes();
			$derived  = array_values( array_unique( array_filter( array_column( $finishes, 'group' ) ) ) );
			$groups   = ! empty( $derived ) ? $derived : [ 'Limited', 'Signature skins', 'Colors', 'Natural' ];
			update_option( self::GROUPS_OPTION_KEY, $groups );
		}

		// Preserve all user-configured groups; only prune known obsolete legacy sample groups if empty
		$finishes      = self::get_finishes();
		$active_groups = array_values( array_unique( array_filter( array_column( $finishes, 'group' ) ) ) );
		$sanitized     = array_values( array_unique( array_filter( array_map( 'sanitize_text_field', $groups ) ) ) );

		$obsolete_legacy_defaults = [ 'Pastels & Colors', 'Special editions' ];
		$valid_groups = array_values( array_filter( $sanitized, function( $g ) use ( $active_groups, $obsolete_legacy_defaults ) {
			if ( in_array( $g, $obsolete_legacy_defaults, true ) && ! in_array( $g, $active_groups, true ) ) {
				return false;
			}
			return true;
		} ) );

		// Append any active groups missing from the sequence
		foreach ( $active_groups as $ag ) {
			if ( ! in_array( $ag, $valid_groups, true ) ) {
				$valid_groups[] = $ag;
			}
		}

		if ( empty( $valid_groups ) ) {
			$valid_groups = [ 'Limited', 'Signature skins', 'Colors', 'Natural' ];
		}

		return self::decode_entities( $valid_groups );
	}

	public static function save_finish_groups( array $groups ): bool {
		$decoded   = array_map( [ __CLASS__, 'decode_entities' ], $groups );
		$sanitized = array_values( array_unique( array_filter( array_map( 'sanitize_text_field', $decoded ) ) ) );
		update_option( self::GROUPS_OPTION_KEY, $sanitized );
		return true;
	}

	public static function get_finish_group_settings(): array {
		$settings = get_option( self::GROUP_SETTINGS_OPTION_KEY, null );
		if ( ! is_array( $settings ) ) {
			// Sensible initial defaults: Colors as compact dots
			$settings = [
				'Colors' => [
					'display_style'        => 'compact_dots',
					'collapsed_by_default' => false,
					'show_more_limit'      => 0,
				],
			];
		}
		return self::decode_entities( $settings );
	}

	public static function save_finish_group_settings( array $settings ): bool {
		$sanitized = [];
		foreach ( $settings as $grp => $cfg ) {
			$clean_grp = sanitize_text_field( self::decode_entities( $grp ) );
			if ( empty( $clean_grp ) || ! is_array( $cfg ) ) {
				continue;
			}
			$sanitized[ $clean_grp ] = [
				'display_style'        => in_array( $cfg['display_style'] ?? '', [ 'cards', 'compact_dots' ], true ) ? $cfg['display_style'] : 'cards',
				'collapsed_by_default' => ! empty( $cfg['collapsed_by_default'] ),
				'show_more_limit'      => max( 0, (int) ( $cfg['show_more_limit'] ?? 0 ) ),
			];
		}
		update_option( self::GROUP_SETTINGS_OPTION_KEY, $sanitized );
		return true;
	}

	public static function get_configurator_presets(): array {
		$presets = get_option( self::PRESETS_OPTION_KEY, null );
		if ( ! is_array( $presets ) || empty( $presets ) ) {
			$presets = [
				[
					'id'          => 'stealth-bespoke',
					'title'       => 'The Stealth Bespoke',
					'tagline'     => 'Titanium+ with Matte Black Camera Plateau',
					'badge'       => 'POPULAR',
					'coverage'    => 'model_360',
					'logo_cutout' => false,
					'layers'      => [
						'back'   => 'titanium-plus',
						'camera' => 'matte-black',
						'frame'  => 'titanium-plus',
					],
					'triggers'    => [ 'titanium-plus', 'titanium' ],
				],
				[
					'id'          => 'shadow-hex',
					'title'       => 'Shadow Hex',
					'tagline'     => 'Swarm Hexagonal Back with Matte Black Accents',
					'badge'       => 'STAFF PICK',
					'coverage'    => 'model_360',
					'logo_cutout' => true,
					'layers'      => [
						'back'   => 'swarm',
						'camera' => 'matte-black',
					],
					'triggers'    => [ 'swarm' ],
				],
			];
		}
		return self::decode_entities( $presets );
	}

	public static function save_configurator_presets( array $presets ): bool {
		$sanitized = [];
		foreach ( $presets as $p ) {
			if ( ! is_array( $p ) ) {
				continue;
			}
			$id = sanitize_title( $p['id'] ?? $p['title'] ?? '' );
			if ( empty( $id ) ) {
				continue;
			}
			$clean_layers = [];
			if ( isset( $p['layers'] ) && is_array( $p['layers'] ) ) {
				foreach ( $p['layers'] as $k => $v ) {
					$clean_layers[ sanitize_key( $k ) ] = sanitize_title( (string) $v );
				}
			}
			$clean_triggers = [];
			if ( isset( $p['triggers'] ) && is_array( $p['triggers'] ) ) {
				$clean_triggers = array_values( array_filter( array_map( 'sanitize_title', $p['triggers'] ) ) );
			}
			$sanitized[] = [
				'id'          => $id,
				'title'       => sanitize_text_field( self::decode_entities( $p['title'] ?? '' ) ),
				'tagline'     => sanitize_text_field( self::decode_entities( $p['tagline'] ?? '' ) ),
				'badge'       => sanitize_text_field( self::decode_entities( $p['badge'] ?? '' ) ),
				'coverage'    => in_array( $p['coverage'] ?? '', [ 'model_360', 'model_cut' ], true ) ? $p['coverage'] : 'model_360',
				'logo_cutout' => ! empty( $p['logo_cutout'] ),
				'layers'      => $clean_layers,
				'triggers'    => $clean_triggers,
			];
		}
		update_option( self::PRESETS_OPTION_KEY, $sanitized );
		return true;
	}

	public static function get_default_surcharge_tiers(): array {
		return [
			[
				'id'        => 'tier_small',
				'label'     => 'Small Accents & Cutouts',
				'min_price' => 10000,
				'max_price' => 45000,
				'surcharge' => 5000,
			],
			[
				'id'        => 'tier_medium',
				'label'     => 'Medium Parts & Accents',
				'min_price' => 45001,
				'max_price' => 95000,
				'surcharge' => 15000,
			],
			[
				'id'        => 'tier_primary',
				'label'     => 'Full Skin & Main Body',
				'min_price' => 95001,
				'max_price' => 999999,
				'surcharge' => 30000,
			],
		];
	}

	public static function get_surcharge_tiers(): array {
		$tiers = get_option( self::SURCHARGE_TIERS_OPTION_KEY, null );
		if ( ! is_array( $tiers ) || empty( $tiers ) ) {
			return self::decode_entities( self::get_default_surcharge_tiers() );
		}
		return self::decode_entities( $tiers );
	}

	public static function save_surcharge_tiers( array $tiers ): bool {
		$sanitized = [];
		foreach ( $tiers as $idx => $t ) {
			if ( ! is_array( $t ) ) {
				continue;
			}
			$id = ! empty( $t['id'] ) ? sanitize_key( $t['id'] ) : 'tier_' . ( $idx + 1 );
			$sanitized[] = [
				'id'        => $id,
				'label'     => sanitize_text_field( self::decode_entities( $t['label'] ?? ( 'Tier ' . ( $idx + 1 ) ) ) ),
				'min_price' => max( 0, (float) ( $t['min_price'] ?? 0 ) ),
				'max_price' => max( 0, (float) ( $t['max_price'] ?? 0 ) ),
				'surcharge' => max( 0, (float) ( $t['surcharge'] ?? 0 ) ),
			];
		}
		update_option( self::SURCHARGE_TIERS_OPTION_KEY, $sanitized );
		return true;
	}

	public static function init(): void {
		add_action( 'rest_api_init', [ __CLASS__, 'register_rest_routes' ] );

		// Hook into post save for product cache revalidation
		add_action( 'save_post_product', [ __CLASS__, 'on_product_saved' ], 20, 2 );

		// Hook into WooCommerce product REST response and data loading
		add_filter( 'woocommerce_rest_prepare_product_object', [ __CLASS__, 'enrich_wc_product_configurator_meta' ], 10, 3 );

		// Hook into WooCommerce product editor: Device Configurator checkbox
		add_action( 'woocommerce_product_options_general_product_data', [ __CLASS__, 'add_configurator_product_checkbox' ] );
		add_action( 'woocommerce_process_product_meta', [ __CLASS__, 'save_configurator_product_checkbox' ] );

		// Hook into WooCommerce cart and order items for headless addons
		add_filter( 'woocommerce_add_cart_item_data', [ __CLASS__, 'add_addon_data_to_cart_item' ], 10, 3 );
		add_filter( 'woocommerce_get_cart_item_from_session', [ __CLASS__, 'get_cart_item_from_session' ], 10, 3 );
		add_action( 'woocommerce_before_calculate_totals', [ __CLASS__, 'calculate_custom_addon_totals' ], 20, 1 );
		add_filter( 'woocommerce_get_item_data', [ __CLASS__, 'display_custom_addons_in_cart' ], 10, 2 );
		add_filter( 'woocommerce_store_api_cart_line_item_data', [ __CLASS__, 'filter_store_api_cart_line_item_data' ], 10, 3 );
		add_filter( 'woocommerce_cart_item_thumbnail', [ __CLASS__, 'filter_cart_item_thumbnail' ], 10, 3 );
		add_action( 'woocommerce_checkout_create_order_line_item', [ __CLASS__, 'save_custom_addons_to_order_item' ], 10, 4 );
	}


	/**
	 * Default initial finish database
	 */
	public static function get_default_finishes(): array {
		return [
			// Signature skins
			[
				'id'          => 'swarm',
				'slug'        => 'swarm',
				'name'        => 'Swarm',
				'group'       => 'Signature skins',
				'class_name'  => 'cfg-swarm',
				'thumbnail'   => 'https://exacoat.com/wp-content/uploads/Swarm-Texture-Thumbnail.jpg',
				'extra_price' => 30000,
				'in_stock'    => true,
			],
			[
				'id'              => 'black-camo',
				'slug'            => 'black-camo',
				'name'            => 'Black Camo',
				'group'           => 'Signature skins',
				'class_name'      => 'cfg-black-camo',
				'thumbnail'       => 'https://media.exacoat.com/wp-content/uploads/Black-Camo-Texture-Thumbnail.jpg',
				'texture_big_url' => 'https://media.exacoat.com/wp-content/uploads/Exacoat-Texture-Big-Black-Camo.jpg',
				'extra_price'     => 30000,
				'in_stock'        => true,
			],
			[
				'id'          => 'patina',
				'slug'        => 'patina',
				'name'        => 'Patina',
				'group'       => 'Signature skins',
				'class_name'  => 'cfg-patina',
				'thumbnail'   => 'https://exacoat.com/wp-content/uploads/Patina-Texture-Thumbnail.jpg',
				'extra_price' => 30000,
				'in_stock'    => false,
			],
			[
				'id'          => 'slate',
				'slug'        => 'slate',
				'name'        => 'Slate',
				'group'       => 'Signature skins',
				'class_name'  => 'cfg-slate',
				'thumbnail'   => 'https://exacoat.com/wp-content/uploads/Slate-Texture-Thumbnail.jpg',
				'extra_price' => 30000,
				'in_stock'    => true,
			],
			[
				'id'          => 'dragon-black',
				'slug'        => 'dragon-black',
				'name'        => 'Dragon Black',
				'group'       => 'Signature skins',
				'class_name'  => 'cfg-dragon-black',
				'thumbnail'   => 'https://exacoat.com/wp-content/uploads/Dragon-Black-Texture-Thumbnail.jpg',
				'extra_price' => 0,
				'in_stock'    => true,
			],
			[
				'id'          => 'carbon-fiber-black',
				'slug'        => 'carbon-fiber-black',
				'name'        => 'Carbon Fiber Black',
				'group'       => 'Signature skins',
				'class_name'  => 'cfg-carbon-fiber-black',
				'thumbnail'   => 'https://exacoat.com/wp-content/uploads/Carbon-Fiber-Black-Texture-Thumbnail.jpg',
				'extra_price' => 0,
				'in_stock'    => true,
			],
			[
				'id'          => 'forged-carbon',
				'slug'        => 'forged-carbon',
				'name'        => 'Forged Carbon',
				'group'       => 'Signature skins',
				'class_name'  => 'cfg-forged-carbon',
				'thumbnail'   => 'https://exacoat.com/wp-content/uploads/Forged-Carbon-Texture-Thumbnail.jpg',
				'extra_price' => 30000,
				'in_stock'    => true,
			],
			[
				'id'          => 'woven',
				'slug'        => 'woven',
				'name'        => 'Woven',
				'group'       => 'Signature skins',
				'class_name'  => 'cfg-woven',
				'thumbnail'   => 'https://exacoat.com/wp-content/uploads/Woven-Texture-Thumbnail.jpg',
				'extra_price' => 30000,
				'in_stock'    => true,
			],

			// Colors
			[
				'id'          => 'matte-black',
				'slug'        => 'matte-black',
				'name'        => 'Matte Black',
				'group'       => 'Colors',
				'class_name'  => 'cfg-matte-black',
				'thumbnail'   => 'https://exacoat.com/wp-content/uploads/Matte-Black-Texture-Thumbnail.jpg',
				'extra_price' => 0,
				'in_stock'    => true,
			],
			[
				'id'          => 'matte-white',
				'slug'        => 'matte-white',
				'name'        => 'Matte White',
				'group'       => 'Colors',
				'class_name'  => 'cfg-matte-white',
				'thumbnail'   => 'https://exacoat.com/wp-content/uploads/Matte-White-Texture-Thumbnail.jpg',
				'extra_price' => 0,
				'in_stock'    => true,
				'surface_gradient_enabled' => true,
				'surface_gradient_opacity' => 0.22,
			],
			[
				'id'          => 'arctic-blue',
				'slug'        => 'arctic-blue',
				'name'        => 'Arctic Blue',
				'group'       => 'Colors',
				'class_name'  => 'cfg-arctic-blue',
				'thumbnail'   => 'https://exacoat.com/wp-content/uploads/Arctic-Blue-Texture-Thumbnail.jpg',
				'extra_price' => 0,
				'in_stock'    => true,
			],
			[
				'id'          => 'glacial-green',
				'slug'        => 'glacial-green',
				'name'        => 'Glacial Green',
				'group'       => 'Colors',
				'class_name'  => 'cfg-glacial-green',
				'thumbnail'   => 'https://exacoat.com/wp-content/uploads/Glacial-Green-Texture-Thumbnail.jpg',
				'extra_price' => 0,
				'in_stock'    => true,
			],
			[
				'id'          => 'mellow-yellow',
				'slug'        => 'mellow-yellow',
				'name'        => 'Mellow Yellow',
				'group'       => 'Colors',
				'class_name'  => 'cfg-mellow-yellow',
				'thumbnail'   => 'https://exacoat.com/wp-content/uploads/Mellow-Yellow-Texture-Thumbnail.jpg',
				'extra_price' => 0,
				'in_stock'    => true,
			],
			[
				'id'          => 'petal-pink',
				'slug'        => 'petal-pink',
				'name'        => 'Petal Pink',
				'group'       => 'Colors',
				'class_name'  => 'cfg-petal-pink',
				'thumbnail'   => 'https://exacoat.com/wp-content/uploads/Petal-Pink-Texture-Thumbnail.jpg',
				'extra_price' => 0,
				'in_stock'    => true,
			],
			[
				'id'          => 'blush-pink',
				'slug'        => 'blush-pink',
				'name'        => 'Blush Pink',
				'group'       => 'Colors',
				'class_name'  => 'cfg-blush-pink',
				'thumbnail'   => 'https://exacoat.com/wp-content/uploads/Blush-Pink-Texture-Thumbnail.jpg',
				'extra_price' => 0,
				'in_stock'    => true,
			],
			[
				'id'          => 'emerald-green',
				'slug'        => 'emerald-green',
				'name'        => 'Emerald Green',
				'group'       => 'Colors',
				'class_name'  => 'cfg-emerald-green',
				'thumbnail'   => 'https://exacoat.com/wp-content/uploads/Emerald-Green-Texture-Thumbnail.jpg',
				'extra_price' => 0,
				'in_stock'    => true,
			],
			[
				'id'          => 'lust-red',
				'slug'        => 'lust-red',
				'name'        => 'Lust Red',
				'group'       => 'Colors',
				'class_name'  => 'cfg-lust-red',
				'thumbnail'   => 'https://exacoat.com/wp-content/uploads/Lust-Red-Texture-Thumbnail.jpg',
				'extra_price' => 0,
				'in_stock'    => true,
			],
			[
				'id'          => 'lemon-yellow',
				'slug'        => 'lemon-yellow',
				'name'        => 'Lemon Yellow',
				'group'       => 'Colors',
				'class_name'  => 'cfg-lemon-yellow',
				'thumbnail'   => 'https://exacoat.com/wp-content/uploads/Lemon-Yellow-Texture-Thumbnail.jpg',
				'extra_price' => 0,
				'in_stock'    => true,
			],

			// Natural
			[
				'id'          => 'marble-white',
				'slug'        => 'marble-white',
				'name'        => 'Marble White',
				'group'       => 'Natural',
				'class_name'  => 'cfg-marble-white',
				'thumbnail'   => 'https://exacoat.com/wp-content/uploads/Marble-White-Texture-Thumbnail.jpg',
				'extra_price' => 0,
				'in_stock'    => true,
			],
			[
				'id'          => 'leather-black',
				'slug'        => 'leather-black',
				'name'        => 'Leather Black',
				'group'       => 'Natural',
				'class_name'  => 'cfg-leather-black',
				'thumbnail'   => 'https://exacoat.com/wp-content/uploads/Leather-Black-Texture-Thumbnail.jpg',
				'extra_price' => 0,
				'in_stock'    => true,
			],
			[
				'id'          => 'titanium-black',
				'slug'        => 'titanium-black',
				'name'        => 'Titanium Black',
				'group'       => 'Natural',
				'class_name'  => 'cfg-titanium-black',
				'thumbnail'   => 'https://exacoat.com/wp-content/uploads/Titanium-Black-Texture-Thumbnail.jpg',
				'extra_price' => 0,
				'in_stock'    => true,
			],
		];
	}

	/**
	 * Get all global finishes
	 */
	public static function get_finishes(): array {
		if ( self::$cached_finishes !== null ) {
			return self::$cached_finishes;
		}

		$finishes = get_option( self::OPTION_KEY, null );
		if ( $finishes === null ) {
			$finishes = get_option( self::LEGACY_OPTION_KEY, null );
		}

		if ( empty( $finishes ) || ! is_array( $finishes ) ) {
			$finishes = self::get_default_finishes();
			update_option( self::OPTION_KEY, $finishes );
			update_option( self::LEGACY_OPTION_KEY, $finishes );
		}

		// Ensure texture_url, order, and is_active fields exist on all returned finishes
		$idx = 0;
		foreach ( $finishes as &$f ) {
			if ( ! isset( $f['texture_url'] ) ) {
				$f['texture_url'] = $f['thumbnail'] ?? '';
			}
			if ( ! isset( $f['order'] ) ) {
				$f['order'] = $idx;
			}
			if ( ! isset( $f['is_active'] ) ) {
				$f['is_active'] = true;
			}
			$idx++;
		}

		self::$cached_finishes = self::decode_entities( $finishes );
		return self::$cached_finishes;
	}

	/**
	 * Save global finishes list
	 */
	public static function save_finishes( array $finishes ): bool {
		$finishes = self::decode_entities( $finishes );
		self::$cached_finishes = $finishes;
		update_option( self::OPTION_KEY, $finishes );
		update_option( self::LEGACY_OPTION_KEY, $finishes );
		return true;
	}

	/**
	 * Map finishes by slug, id, and class_name for fast lookup
	 */
	public static function get_finish_lookup_map(): array {
		$finishes = self::get_finishes();
		$map = [];

		foreach ( $finishes as $f ) {
			$id = $f['id'] ?? '';
			$slug = $f['slug'] ?? $id;
			$cls = trim( $f['class_name'] ?? '' );
			$name = strtolower( trim( $f['name'] ?? '' ) );

			if ( $id ) {
				$map[ $id ] = $f;
			}
			if ( $slug ) {
				$map[ $slug ] = $f;
			}
			if ( $cls ) {
				$map[ $cls ] = $f;
				$unprefixed = preg_replace( '/^cfg-/', '', $cls );
				if ( $unprefixed ) {
					$map[ $unprefixed ] = $f;
				}
			}
			if ( $name ) {
				$map[ $name ] = $f;
			}
		}

		return $map;
	}

	/**
	 * Register REST routes
	 */
	public static function register_rest_routes(): void {
		$namespaces = [ 'exacoat-core/v1', 'artmatter-core/v1' ];

		$register = function( string $route, array $args ) use ( $namespaces ) {
			foreach ( $namespaces as $namespace ) {
				register_rest_route( $namespace, $route, $args );
			}
		};

		// 1. GET /finishes: Fetch all global finishes and stock statuses
		$register( '/finishes', [
			'methods'             => 'GET',
			'callback'            => [ __CLASS__, 'rest_get_finishes' ],
			'permission_callback' => '__return_true',
		] );

		// 2. POST /finishes/toggle-stock: Toggle in_stock status for a finish
		$register( '/finishes/toggle-stock', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_toggle_finish_stock' ],
			'permission_callback' => [ __CLASS__, 'verify_permission' ],
			'args'                => [
				'id' => [
					'required'          => true,
					'sanitize_callback' => 'sanitize_text_field',
				],
				'in_stock' => [
					'required' => true,
					'type'     => 'boolean',
				],
			],
		] );

		// POST /finishes/toggle-active: Toggle active/inactive status for a finish
		$register( '/finishes/toggle-active', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_toggle_finish_active' ],
			'permission_callback' => [ __CLASS__, 'verify_permission' ],
			'args'                => [
				'id' => [
					'required'          => true,
					'sanitize_callback' => 'sanitize_text_field',
				],
				'is_active' => [
					'required' => true,
					'type'     => 'boolean',
				],
			],
		] );

		// 3. POST /finishes/save: Add or update a finish
		$register( '/finishes/save', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_save_finish' ],
			'permission_callback' => [ __CLASS__, 'verify_permission' ],
		] );

		// POST /finishes/delete: Delete a finish
		$register( '/finishes/delete', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_delete_finish' ],
			'permission_callback' => [ __CLASS__, 'verify_permission' ],
		] );

		// POST /finishes/reorder-groups: Save finish groups order
		$register( '/finishes/reorder-groups', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_save_finish_groups' ],
			'permission_callback' => [ __CLASS__, 'verify_permission' ],
		] );

		// POST /finishes/rename-group: Rename a finish group and migrate all assigned finishes
		$register( '/finishes/rename-group', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_rename_finish_group' ],
			'permission_callback' => [ __CLASS__, 'verify_permission' ],
		] );

		// POST /finishes/save-all: Batch save finishes and groups
		$register( '/finishes/save-all', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_save_all_finishes' ],
			'permission_callback' => [ __CLASS__, 'verify_permission' ],
		] );

		// POST /finishes/group-settings: Save finish group presentation settings
		$register( '/finishes/group-settings', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_save_finish_group_settings' ],
			'permission_callback' => [ __CLASS__, 'verify_permission' ],
		] );

		// GET /configurator/presets: Fetch bespoke configurator presets
		$register( '/configurator/presets', [
			'methods'             => 'GET',
			'callback'            => [ __CLASS__, 'rest_get_configurator_presets' ],
			'permission_callback' => '__return_true',
		] );

		// POST /configurator/presets: Save bespoke configurator presets
		$register( '/configurator/presets', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_save_configurator_presets' ],
			'permission_callback' => [ __CLASS__, 'verify_permission' ],
		] );

		// GET /configurator/surcharge-tiers: Fetch finish surcharge price brackets
		$register( '/configurator/surcharge-tiers', [
			'methods'             => 'GET',
			'callback'            => [ __CLASS__, 'rest_get_surcharge_tiers' ],
			'permission_callback' => '__return_true',
		] );

		// POST /configurator/surcharge-tiers: Save finish surcharge price brackets
		$register( '/configurator/surcharge-tiers', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_save_surcharge_tiers' ],
			'permission_callback' => [ __CLASS__, 'verify_permission' ],
		] );

		// 4. GET /configurator/profiles: List all products and their configurator profiles
		$register( '/configurator/profiles', [
			'methods'             => 'GET',
			'callback'            => [ __CLASS__, 'rest_get_configurator_profiles' ],
			'permission_callback' => '__return_true',
		] );

		// 5. GET /configurator/(?P<id_or_slug>[a-zA-Z0-9_-]+): Fetch normalized product configurator profile
		$register( '/configurator/(?P<id_or_slug>[a-zA-Z0-9_-]+)', [
			'methods'             => 'GET',
			'callback'            => [ __CLASS__, 'rest_get_product_configurator' ],
			'permission_callback' => '__return_true',
		] );

		// 6. POST /configurator/save: Save/update a device profile
		$register( '/configurator/save', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_save_product_configurator' ],
			'permission_callback' => [ __CLASS__, 'verify_permission' ],
		] );

		// 6b. POST /configurator/save-marketplace-settings: Save per-device cover & variant image generator position settings
		$register( '/configurator/save-marketplace-settings', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_save_marketplace_settings' ],
			'permission_callback' => [ __CLASS__, 'verify_permission' ],
		] );

		// 7. POST /configurator/batch-migrate: Convert all MKL products to modern profile
		$register( '/configurator/batch-migrate', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_batch_migrate' ],
			'permission_callback' => [ __CLASS__, 'verify_permission' ],
		] );

		// 7b. POST /configurator/sync-device-families: Auto-detect and sync device families catalog-wide
		$register( '/configurator/sync-device-families', [
			'methods'             => [ 'GET', 'POST' ],
			'callback'            => [ __CLASS__, 'rest_sync_device_families' ],
			'permission_callback' => '__return_true',
		] );

		// 8. POST /configurator/set-price: Set WooCommerce product price and sync profile base_price
		$register( '/configurator/set-price', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_set_product_price' ],
			'permission_callback' => [ __CLASS__, 'verify_permission' ],
		] );

		// 9. POST /configurator/duplicate-product: Duplicate product and its configurator profile
		$register( '/configurator/duplicate-product', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_duplicate_product' ],
			'permission_callback' => [ __CLASS__, 'verify_permission' ],
		] );

		// 10. GET /addons/schemas: Fetch custom product addon schemas and device catalog
		$register( '/addons/schemas', [
			'methods'             => 'GET',
			'callback'            => [ __CLASS__, 'rest_get_addon_schemas' ],
			'permission_callback' => '__return_true',
		] );

		// 11. POST /addons/schema/save: Save/update custom product addon schemas and catalog
		$register( '/addons/schema/save', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_save_addon_schemas' ],
			'permission_callback' => [ __CLASS__, 'verify_permission' ],
		] );

		// 12. POST /configurator/toggle-configurator: Enable or disable configurator for a product
		$register( '/configurator/toggle-configurator', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_toggle_configurator' ],
			'permission_callback' => [ __CLASS__, 'verify_permission' ],
		] );

		// 13. POST /configurator/mark-audited: Mark a single device as audited with timestamp & issues
		$register( '/configurator/mark-audited', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_mark_audited' ],
			'permission_callback' => [ __CLASS__, 'verify_permission' ],
		] );

		// 14. POST /configurator/batch-mark-audited: Batch mark multiple devices as audited
		$register( '/configurator/batch-mark-audited', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_batch_mark_audited' ],
			'permission_callback' => [ __CLASS__, 'verify_permission' ],
		] );

		// 15. POST /configurator/reset-audit: Reset audit records for a device or all devices
		$register( '/configurator/reset-audit', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_reset_audit' ],
			'permission_callback' => [ __CLASS__, 'verify_permission' ],
		] );

		// 16. GET /media/list: Search and browse WordPress media library for configurator assets
		$register( '/media/list', [
			'methods'             => 'GET',
			'callback'            => [ __CLASS__, 'rest_get_media_list' ],
			'permission_callback' => '__return_true',
		] );

		// 17. POST /configurator/extract-shading: Extract multiply shadow and screen highlight PNGs from a neutral render
		$register( '/configurator/extract-shading', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_extract_shading' ],
			'permission_callback' => [ __CLASS__, 'verify_permission' ],
		] );

		// 18. POST /configurator/revalidate-web: On-demand cache revalidation for web.exacoat.com and Cloudflare
		$register( '/configurator/revalidate-web', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_revalidate_web' ],
			'permission_callback' => [ __CLASS__, 'verify_permission' ],
		] );

		// 19. POST /configurator/composite/upload: Store rendered composite preview permanently in WordPress uploads
		$register( '/configurator/composite/upload', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_upload_composite' ],
			'permission_callback' => '__return_true',
		] );
		$register( '/composite/upload', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_upload_composite' ],
			'permission_callback' => '__return_true',
		] );

		// 20. POST /media/upload: Upload image file to WordPress Media Library
		$register( '/media/upload', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_upload_media' ],
			'permission_callback' => [ __CLASS__, 'verify_permission' ],
		] );

		// 21. POST /media/batch-optimize: Batch optimize master images and generate WebP
		$register( '/media/batch-optimize', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_batch_optimize_media' ],
			'permission_callback' => [ __CLASS__, 'verify_permission' ],
		] );

		// 22. POST /media/optimize-single: Optimize single attachment or texture file
		$register( '/media/optimize-single', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_optimize_single_media' ],
			'permission_callback' => [ __CLASS__, 'verify_permission' ],
		] );
	}


	public static function verify_permission( WP_REST_Request $request ): bool {
		if ( class_exists( 'Exacoat_Core' ) && method_exists( 'Exacoat_Core', 'verify_bridge_permission' ) ) {
			return Exacoat_Core::verify_bridge_permission( $request );
		}
		return current_user_can( 'manage_options' );
	}

	public static function rest_get_finishes( WP_REST_Request $request ): WP_REST_Response {
		$finishes        = self::get_finishes();
		$groups          = self::get_finish_groups();
		$group_settings  = self::get_finish_group_settings();
		$presets         = self::get_configurator_presets();
		$surcharge_tiers = self::get_surcharge_tiers();
		$response = rest_ensure_response( [
			'success'         => true,
			'finishes'        => $finishes,
			'groups'          => $groups,
			'group_settings'  => $group_settings,
			'presets'         => $presets,
			'surcharge_tiers' => $surcharge_tiers,
			'total'           => count( $finishes ),
		] );
		$response->header( 'Cache-Control', 'public, max-age=60, s-maxage=60, stale-while-revalidate=300' );
		return $response;
	}

	public static function rest_toggle_finish_stock( WP_REST_Request $request ): WP_REST_Response {
		$id = sanitize_text_field( (string) $request->get_param( 'id' ) );
		$in_stock = (bool) $request->get_param( 'in_stock' );

		$finishes = self::get_finishes();
		$found = false;

		foreach ( $finishes as &$f ) {
			if ( ( $f['id'] ?? '' ) === $id || ( $f['slug'] ?? '' ) === $id ) {
				$f['in_stock'] = $in_stock;
				$found = true;
				break;
			}
		}

		if ( ! $found ) {
			return new WP_REST_Response( [
				'success' => false,
				'message' => "Finish '{$id}' not found.",
			], 404 );
		}

		self::save_finishes( $finishes );

		if ( class_exists( 'Exacoat_Logger' ) ) {
			Exacoat_Logger::log( 'info', 'materials', "Finish '{$id}' stock toggled to " . ( $in_stock ? 'IN STOCK' : 'OUT OF STOCK' ) );
		}

		return rest_ensure_response( [
			'success'  => true,
			'id'       => $id,
			'in_stock' => $in_stock,
			'message'  => "Stock status updated for '{$id}'.",
			'finishes' => $finishes,
			'groups'   => self::get_finish_groups(),
		] );
	}

	public static function rest_toggle_finish_active( WP_REST_Request $request ): WP_REST_Response {
		$id = sanitize_text_field( (string) $request->get_param( 'id' ) );
		$is_active = (bool) $request->get_param( 'is_active' );

		$finishes = self::get_finishes();
		$found = false;

		foreach ( $finishes as &$f ) {
			if ( ( $f['id'] ?? '' ) === $id || ( $f['slug'] ?? '' ) === $id ) {
				$f['is_active'] = $is_active;
				$found = true;
				break;
			}
		}

		if ( ! $found ) {
			return new WP_REST_Response( [
				'success' => false,
				'message' => "Finish '{$id}' not found.",
			], 404 );
		}

		self::save_finishes( $finishes );

		if ( class_exists( 'Exacoat_Logger' ) ) {
			Exacoat_Logger::log( 'info', 'materials', "Finish '{$id}' status toggled to " . ( $is_active ? 'ACTIVE' : 'INACTIVE' ) );
		}

		return rest_ensure_response( [
			'success'   => true,
			'id'        => $id,
			'is_active' => $is_active,
			'message'   => "Active status updated for '{$id}'.",
			'finishes'  => $finishes,
			'groups'    => self::get_finish_groups(),
		] );
	}

	public static function rest_save_finish( WP_REST_Request $request ): WP_REST_Response {
		$params = $request->get_json_params() ?: $request->get_params();

		$name = sanitize_text_field( $params['name'] ?? '' );
		if ( empty( $name ) ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => 'Finish name is required' ], 400 );
		}

		$id = sanitize_title( $params['id'] ?? $params['slug'] ?? $name );
		$slug = sanitize_title( $params['slug'] ?? $id );
		$group = sanitize_text_field( $params['group'] ?? 'Signature skins' );
		$class_name = sanitize_html_class( $params['class_name'] ?? ( 'cfg-' . $slug ) );
		$thumbnail = esc_url_raw( $params['thumbnail'] ?? '' );
		$texture_url = esc_url_raw( $params['texture_url'] ?? '' );
		$texture_big_url = esc_url_raw( $params['texture_big_url'] ?? '' );
		$extra_price = isset( $params['extra_price'] ) ? (float) $params['extra_price'] : 0.0;
		$accent_extra_price = isset( $params['accent_extra_price'] ) ? (float) $params['accent_extra_price'] : 0.0;
		$in_stock = isset( $params['in_stock'] ) ? (bool) $params['in_stock'] : true;
		$is_active = isset( $params['is_active'] ) ? (bool) $params['is_active'] : true;
		$is_custom_per_device = ! empty( $params['is_custom_per_device'] );
		$order = isset( $params['order'] ) ? (int) $params['order'] : 0;
		$badge_text = sanitize_text_field( $params['badge_text'] ?? '' );
		$badge_color = sanitize_text_field( $params['badge_color'] ?? '' );
		$shadow_opacity = isset( $params['shadow_opacity'] ) ? (float) $params['shadow_opacity'] : null;
		$highlight_opacity = isset( $params['highlight_opacity'] ) ? (float) $params['highlight_opacity'] : null;
		$surface_gradient_enabled = isset( $params['surface_gradient_enabled'] ) ? (bool) $params['surface_gradient_enabled'] : null;
		$surface_gradient_opacity = isset( $params['surface_gradient_opacity'] ) ? (float) $params['surface_gradient_opacity'] : null;

		$finishes = self::get_finishes();
		$updated = false;

		foreach ( $finishes as &$f ) {
			if ( ( $f['id'] ?? '' ) === $id || ( $f['slug'] ?? '' ) === $slug ) {
				$f['name']                 = $name;
				$f['group']                = $group;
				$f['class_name']           = $class_name;
				if ( ! empty( $thumbnail ) || isset( $params['thumbnail'] ) ) {
					$f['thumbnail'] = $thumbnail;
				}
				if ( ! empty( $texture_url ) || isset( $params['texture_url'] ) ) {
					$f['texture_url'] = $texture_url;
				}
				if ( ! empty( $texture_big_url ) || isset( $params['texture_big_url'] ) ) {
					$f['texture_big_url'] = $texture_big_url;
				}
				$f['extra_price']          = $extra_price;
				$f['accent_extra_price']   = $accent_extra_price;
				$f['in_stock']             = $in_stock;
				$f['is_active']            = $is_active;
				$f['is_custom_per_device'] = $is_custom_per_device;
				$f['badge_text']           = $badge_text;
				$f['badge_color']          = $badge_color;
				if ( isset( $params['shadow_opacity'] ) ) {
					$f['shadow_opacity']   = (float) $params['shadow_opacity'];
				}
				if ( isset( $params['highlight_opacity'] ) ) {
					$f['highlight_opacity'] = (float) $params['highlight_opacity'];
				}
				if ( isset( $params['surface_gradient_enabled'] ) ) {
					$f['surface_gradient_enabled'] = (bool) $params['surface_gradient_enabled'];
				}
				if ( isset( $params['surface_gradient_opacity'] ) ) {
					$f['surface_gradient_opacity'] = (float) $params['surface_gradient_opacity'];
				}
				if ( isset( $params['order'] ) ) {
					$f['order'] = $order;
				}
				$updated = true;
				break;
			}
		}

		if ( ! $updated ) {
			$new_finish = [
				'id'                   => $id,
				'slug'                 => $slug,
				'name'                 => $name,
				'group'                => $group,
				'class_name'           => $class_name,
				'thumbnail'            => $thumbnail,
				'texture_url'          => $texture_url ?: $thumbnail,
				'texture_big_url'      => $texture_big_url,
				'extra_price'          => $extra_price,
				'accent_extra_price'   => $accent_extra_price,
				'in_stock'             => $in_stock,
				'is_active'            => $is_active,
				'is_custom_per_device' => $is_custom_per_device,
				'badge_text'           => $badge_text,
				'badge_color'          => $badge_color,
				'order'                => $order,
			];
			if ( $shadow_opacity !== null ) {
				$new_finish['shadow_opacity'] = $shadow_opacity;
			}
			if ( $highlight_opacity !== null ) {
				$new_finish['highlight_opacity'] = $highlight_opacity;
			}
			if ( $surface_gradient_enabled !== null ) {
				$new_finish['surface_gradient_enabled'] = $surface_gradient_enabled;
			}
			if ( $surface_gradient_opacity !== null ) {
				$new_finish['surface_gradient_opacity'] = $surface_gradient_opacity;
			}
			$finishes[] = $new_finish;
		}

		self::save_finishes( $finishes );

		// Auto-register new group if not present
		$groups = self::get_finish_groups();
		if ( ! empty( $group ) && ! in_array( $group, $groups, true ) ) {
			$groups[] = $group;
			self::save_finish_groups( $groups );
		}

		return rest_ensure_response( [
			'success'  => true,
			'message'  => $updated ? "Finish '{$name}' updated." : "Finish '{$name}' created.",
			'finish'   => [
				'id'                   => $id,
				'slug'                 => $slug,
				'name'                 => $name,
				'group'                => $group,
				'class_name'           => $class_name,
				'thumbnail'            => $thumbnail,
				'texture_url'          => $texture_url,
				'texture_big_url'      => $texture_big_url,
				'extra_price'          => $extra_price,
				'accent_extra_price'   => $accent_extra_price,
				'in_stock'             => $in_stock,
				'is_active'            => $is_active,
				'is_custom_per_device' => $is_custom_per_device,
				'shadow_opacity'       => $shadow_opacity,
				'highlight_opacity'    => $highlight_opacity,
				'order'                => $order,
			],
			'finishes' => $finishes,
			'groups'   => self::get_finish_groups(),
		] );

		// Automatically trigger storefront cache revalidation
		self::trigger_storefront_revalidation( [
			'tag'       => 'finishes',
			'path'      => '/api/configurator/finishes',
			'purge_all' => false,
		] );

		return $response;
	}

	public static function rest_delete_finish( WP_REST_Request $request ): WP_REST_Response {
		$params = $request->get_json_params() ?: $request->get_params();
		$id = sanitize_text_field( (string) ( $params['id'] ?? $params['slug'] ?? '' ) );

		if ( empty( $id ) ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => 'Finish id is required.' ], 400 );
		}

		$finishes = self::get_finishes();
		$initial_count = count( $finishes );
		$finishes = array_values( array_filter( $finishes, function( $f ) use ( $id ) {
			return ( $f['id'] ?? '' ) !== $id && ( $f['slug'] ?? '' ) !== $id;
		} ) );

		if ( count( $finishes ) === $initial_count ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => "Finish '{$id}' not found." ], 404 );
		}

		self::save_finishes( $finishes );

		return rest_ensure_response( [
			'success'  => true,
			'message'  => "Finish '{$id}' deleted.",
			'finishes' => $finishes,
			'groups'   => self::get_finish_groups(),
		] );
	}

	public static function rest_save_finish_groups( WP_REST_Request $request ): WP_REST_Response {
		$params = $request->get_json_params() ?: $request->get_params();
		$groups = $params['groups'] ?? null;

		if ( ! is_array( $groups ) ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => 'Groups must be an array.' ], 400 );
		}

		self::save_finish_groups( $groups );

		return rest_ensure_response( [
			'success' => true,
			'message' => 'Finish groups reordered.',
			'groups'  => self::get_finish_groups(),
		] );
	}

	public static function rest_rename_finish_group( WP_REST_Request $request ): WP_REST_Response {
		$params   = $request->get_json_params() ?: $request->get_params();
		$old_name = sanitize_text_field( trim( $params['old_name'] ?? '' ) );
		$new_name = sanitize_text_field( trim( $params['new_name'] ?? '' ) );

		if ( empty( $old_name ) || empty( $new_name ) ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => 'Both old_name and new_name are required.' ], 400 );
		}

		$groups = self::get_finish_groups();
		$idx    = array_search( $old_name, $groups, true );
		if ( false !== $idx ) {
			$groups[ $idx ] = $new_name;
		} else {
			$groups[] = $new_name;
		}
		self::save_finish_groups( array_values( array_unique( $groups ) ) );

		$finishes      = self::get_finishes();
		$updated_count = 0;
		foreach ( $finishes as &$f ) {
			if ( ( $f['group'] ?? '' ) === $old_name ) {
				$f['group'] = $new_name;
				$updated_count++;
			}
		}
		unset( $f );
		self::save_finishes( $finishes );

		// Automatically trigger storefront cache revalidation
		self::trigger_storefront_revalidation( [
			'tag'       => 'finishes',
			'path'      => '/api/configurator/finishes',
			'purge_all' => false,
		] );

		return rest_ensure_response( [
			'success'       => true,
			'message'       => "Renamed group '{$old_name}' to '{$new_name}'.",
			'updated_count' => $updated_count,
			'groups'        => self::get_finish_groups(),
			'finishes'      => self::get_finishes(),
		] );
	}

	public static function rest_save_all_finishes( WP_REST_Request $request ): WP_REST_Response {
		$params = $request->get_json_params() ?: $request->get_params();
		$finishes = $params['finishes'] ?? null;
		$groups = $params['groups'] ?? null;
		$group_settings = $params['group_settings'] ?? null;

		if ( is_array( $groups ) ) {
			self::save_finish_groups( $groups );
		}
		if ( is_array( $group_settings ) ) {
			self::save_finish_group_settings( $group_settings );
		}
		if ( is_array( $finishes ) ) {
			foreach ( $finishes as &$item ) {
				if ( isset( $item['badge_text'] ) ) {
					$item['badge_text'] = sanitize_text_field( $item['badge_text'] );
				}
				if ( isset( $item['badge_color'] ) ) {
					$item['badge_color'] = sanitize_text_field( $item['badge_color'] );
				}
				if ( isset( $item['is_active'] ) ) {
					$item['is_active'] = (bool) $item['is_active'];
				}
				if ( isset( $item['order'] ) ) {
					$item['order'] = (int) $item['order'];
				}
			}
			unset( $item );
			self::save_finishes( $finishes );
		}

		$response = rest_ensure_response( [
			'success'        => true,
			'message'        => 'All finishes and groups updated.',
			'finishes'       => self::get_finishes(),
			'groups'         => self::get_finish_groups(),
			'group_settings' => self::get_finish_group_settings(),
		] );

		// Automatically trigger storefront cache revalidation
		self::trigger_storefront_revalidation( [
			'tag'       => 'finishes',
			'path'      => '/api/configurator/finishes',
			'purge_all' => false,
		] );

		return $response;
	}

	public static function rest_save_finish_group_settings( WP_REST_Request $request ): WP_REST_Response {
		$params   = $request->get_json_params() ?: $request->get_params();
		$settings = $params['settings'] ?? $params['group_settings'] ?? $params;

		if ( ! is_array( $settings ) ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => 'Group settings must be an object.' ], 400 );
		}

		self::save_finish_group_settings( $settings );

		// Automatically trigger storefront cache revalidation
		self::trigger_storefront_revalidation( [
			'tag'       => 'finishes',
			'path'      => '/api/configurator/finishes',
			'purge_all' => false,
		] );

		return rest_ensure_response( [
			'success'        => true,
			'message'        => 'Group settings saved.',
			'group_settings' => self::get_finish_group_settings(),
		] );
	}

	public static function rest_get_configurator_presets( WP_REST_Request $request ): WP_REST_Response {
		$presets = self::get_configurator_presets();
		return rest_ensure_response( [
			'success' => true,
			'presets' => $presets,
			'total'   => count( $presets ),
		] );
	}

	public static function rest_save_configurator_presets( WP_REST_Request $request ): WP_REST_Response {
		$params  = $request->get_json_params() ?: $request->get_params();
		$presets = $params['presets'] ?? $params;

		if ( ! is_array( $presets ) ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => 'Presets must be an array.' ], 400 );
		}

		self::save_configurator_presets( $presets );

		// Automatically trigger storefront cache revalidation
		self::trigger_storefront_revalidation( [
			'tag'       => 'configurator',
			'path'      => '/api/configurator/finishes',
			'purge_all' => false,
		] );

		return rest_ensure_response( [
			'success' => true,
			'message' => 'Configurator presets saved.',
			'presets' => self::get_configurator_presets(),
		] );
	}

	public static function rest_get_surcharge_tiers( WP_REST_Request $request ): WP_REST_Response {
		$tiers = self::get_surcharge_tiers();
		return rest_ensure_response( [
			'success' => true,
			'tiers'   => $tiers,
			'total'   => count( $tiers ),
		] );
	}

	public static function rest_save_surcharge_tiers( WP_REST_Request $request ): WP_REST_Response {
		$params = $request->get_json_params() ?: $request->get_params();
		$tiers  = $params['tiers'] ?? $params;

		if ( ! is_array( $tiers ) ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => 'Tiers must be an array.' ], 400 );
		}

		self::save_surcharge_tiers( $tiers );

		// Automatically trigger storefront cache revalidation
		self::trigger_storefront_revalidation( [
			'tag'       => 'configurator',
			'path'      => '/api/configurator/finishes',
			'purge_all' => false,
		] );

		return rest_ensure_response( [
			'success' => true,
			'message' => 'Finish surcharge tiers saved.',
			'tiers'   => self::get_surcharge_tiers(),
		] );
	}

	/**
	 * Render device configurator checkbox in WooCommerce product edit screen (General tab)
	 */
	public static function add_configurator_product_checkbox() {
		global $post;
		if ( ! $post || ! $post->ID ) return;
		$val = get_post_meta( $post->ID, self::CONFIGURATOR_FLAG_META_KEY, true );
		if ( '' === $val ) {
			$val = self::is_product_configurator( $post->ID ) ? 'yes' : 'no';
		}
		echo '<div class="options_group show_if_simple show_if_variable">';
		woocommerce_wp_checkbox( [
			'id'            => self::CONFIGURATOR_FLAG_META_KEY,
			'label'         => __( 'Device Configurator', 'exacoat-core' ),
			'description'   => __( 'Check this if this product is an interactive 2D device skin configurator (uncheck for merchandise, limited drops, standalone kits, cases).', 'exacoat-core' ),
			'value'         => $val,
			'desc_tip'      => true,
		] );
		echo '</div>';
	}

	/**
	 * Save device configurator checkbox on WooCommerce product save
	 */
	public static function save_configurator_product_checkbox( $post_id ) {
		$is_configurator = isset( $_POST[ self::CONFIGURATOR_FLAG_META_KEY ] ) ? 'yes' : 'no';
		update_post_meta( $post_id, self::CONFIGURATOR_FLAG_META_KEY, $is_configurator );
	}

	/**
	 * Determine if a product is an active device configurator
	 */
	public static function is_product_configurator( int $pid, ?array $profile_data = null ): bool {
		$flag = get_post_meta( $pid, self::CONFIGURATOR_FLAG_META_KEY, true );
		if ( 'yes' === $flag ) {
			return true;
		}
		if ( 'no' === $flag ) {
			return false;
		}

		// When flag is not explicitly saved yet, evaluate intelligently based on configurator layers
		if ( $profile_data !== null && isset( $profile_data['layers'] ) ) {
			return ! empty( $profile_data['layers'] );
		}

		$modern_profile = get_post_meta( $pid, self::PROFILE_META_KEY, true );
		if ( ! empty( $modern_profile ) ) {
			$decoded = is_array( $modern_profile ) ? $modern_profile : json_decode( $modern_profile, true );
			if ( ! empty( $decoded['layers'] ) ) {
				return true;
			}
		}

		// Check MKL configurable flag
		$mkl_configurable = get_post_meta( $pid, '_mkl_pc__is_configurable', true );
		if ( 'yes' === $mkl_configurable ) {
			return true;
		}

		// Check MKL layers post meta
		$layers_meta = get_post_meta( $pid, '_mkl_product_configurator_layers', true );
		if ( ! empty( $layers_meta ) ) {
			$parsed = self::parse_meta_json( $layers_meta );
			if ( ! empty( $parsed ) && is_array( $parsed ) ) {
				foreach ( $parsed as $l ) {
					$l_name = strtolower( trim( $l['name'] ?? '' ) );
					if ( ! empty( $l_name ) && $l_name !== 'device' ) {
						return true;
					}
				}
			}
		}

		return false;
	}

	/**
	 * REST Endpoint: Toggle configurator status for a product directly from Exacoat Manager
	 */
	public static function rest_toggle_configurator( WP_REST_Request $request ): WP_REST_Response {
		$params = $request->get_json_params() ?: $request->get_params();
		$pid = (int) ( $params['product_id'] ?? 0 );
		$is_cfg = ! empty( $params['is_configurator'] );

		if ( ! $pid || ! get_post( $pid ) ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => 'Invalid product ID' ], 400 );
		}

		update_post_meta( $pid, self::CONFIGURATOR_FLAG_META_KEY, $is_cfg ? 'yes' : 'no' );

		$post = get_post( $pid );
		self::trigger_storefront_revalidation( [
			'slug' => $post ? $post->post_name : '',
		] );

		return rest_ensure_response( [
			'success'         => true,
			'product_id'      => $pid,
			'is_configurator' => $is_cfg,
			'message'         => $is_cfg ? 'Product enabled as configurator device.' : 'Product excluded from configurator devices.',
		] );
	}

	/**
	 * REST Endpoint: Mark a single device profile as audited
	 */
	public static function rest_mark_audited( WP_REST_Request $request ): WP_REST_Response {
		$params = $request->get_json_params() ?: $request->get_params();
		$pid = (int) ( $params['product_id'] ?? 0 );
		$status = sanitize_text_field( $params['audit_status'] ?? 'clean' );
		$issues = (int) ( $params['audit_issues'] ?? 0 );
		$timestamp = sanitize_text_field( $params['last_audited_at'] ?? current_time( 'mysql' ) );
		$details = $params['audit_details'] ?? [];

		if ( ! $pid || ! get_post( $pid ) ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => 'Invalid product ID' ], 400 );
		}

		update_post_meta( $pid, self::AUDIT_TIME_META_KEY, $timestamp );
		update_post_meta( $pid, self::AUDIT_STATUS_META_KEY, $status );
		update_post_meta( $pid, self::AUDIT_ISSUES_META_KEY, $issues );
		if ( ! empty( $details ) && is_array( $details ) ) {
			update_post_meta( $pid, self::AUDIT_DETAILS_META_KEY, wp_slash( wp_json_encode( array_values( $details ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) );
		} else {
			delete_post_meta( $pid, self::AUDIT_DETAILS_META_KEY );
		}

		return rest_ensure_response( [
			'success'         => true,
			'product_id'      => $pid,
			'last_audited_at' => $timestamp,
			'audit_status'    => $status,
			'audit_issues'    => $issues,
			'audit_details'   => is_array( $details ) ? array_values( $details ) : [],
		] );
	}

	/**
	 * REST Endpoint: Batch mark multiple devices as audited
	 */
	public static function rest_batch_mark_audited( WP_REST_Request $request ): WP_REST_Response {
		$params = $request->get_json_params() ?: $request->get_params();
		$results = $params['results'] ?? [];
		if ( ! is_array( $results ) ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => 'Results must be an array' ], 400 );
		}

		$updated = 0;
		$now = current_time( 'mysql' );
		foreach ( $results as $row ) {
			$pid = (int) ( $row['product_id'] ?? 0 );
			if ( ! $pid || ! get_post( $pid ) ) continue;

			$status = sanitize_text_field( $row['audit_status'] ?? 'clean' );
			$issues = (int) ( $row['audit_issues'] ?? 0 );
			$ts = sanitize_text_field( $row['last_audited_at'] ?? $now );
			$details = $row['audit_details'] ?? [];

			update_post_meta( $pid, self::AUDIT_TIME_META_KEY, $ts );
			update_post_meta( $pid, self::AUDIT_STATUS_META_KEY, $status );
			update_post_meta( $pid, self::AUDIT_ISSUES_META_KEY, $issues );
			if ( ! empty( $details ) && is_array( $details ) ) {
				update_post_meta( $pid, self::AUDIT_DETAILS_META_KEY, wp_slash( wp_json_encode( array_values( $details ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) );
			} else {
				delete_post_meta( $pid, self::AUDIT_DETAILS_META_KEY );
			}
			$updated++;
		}

		return rest_ensure_response( [
			'success' => true,
			'updated' => $updated,
			'message' => "Successfully marked {$updated} devices as audited.",
		] );
	}

	/**
	 * REST Endpoint: Reset audit status for a device or all devices
	 */
	public static function rest_reset_audit( WP_REST_Request $request ): WP_REST_Response {
		$params = $request->get_json_params() ?: $request->get_params();
		$pid = (int) ( $params['product_id'] ?? 0 );
		$all = ! empty( $params['all'] );

		if ( $all ) {
			delete_post_meta_by_key( self::AUDIT_TIME_META_KEY );
			delete_post_meta_by_key( self::AUDIT_STATUS_META_KEY );
			delete_post_meta_by_key( self::AUDIT_ISSUES_META_KEY );
			delete_post_meta_by_key( self::AUDIT_DETAILS_META_KEY );
			return rest_ensure_response( [ 'success' => true, 'message' => 'Cleared all device audit records.' ] );
		}

		if ( ! $pid || ! get_post( $pid ) ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => 'Invalid product ID' ], 400 );
		}

		delete_post_meta( $pid, self::AUDIT_TIME_META_KEY );
		delete_post_meta( $pid, self::AUDIT_STATUS_META_KEY );
		delete_post_meta( $pid, self::AUDIT_ISSUES_META_KEY );
		delete_post_meta( $pid, self::AUDIT_DETAILS_META_KEY );

		return rest_ensure_response( [
			'success'    => true,
			'product_id' => $pid,
			'message'    => 'Audit status reset for device.',
		] );
	}

	/**
	 * Search and browse WordPress media library attachments for configurator studio
	 */
	public static function rest_get_media_list( WP_REST_Request $request ): WP_REST_Response {
		$search   = sanitize_text_field( (string) $request->get_param( 'search' ) );
		$page     = max( 1, (int) $request->get_param( 'page' ) );
		$per_page = min( 100, max( 1, (int) ( $request->get_param( 'per_page' ) ?: 24 ) ) );

		$args = [
			'post_type'      => 'attachment',
			'post_mime_type' => 'image',
			'post_status'    => 'inherit',
			'posts_per_page' => $per_page,
			'paged'          => $page,
			'orderby'        => 'date',
			'order'          => 'DESC',
		];

		if ( ! empty( $search ) ) {
			$args['s'] = $search;
		}

		$query = new WP_Query( $args );
		$items = [];

		foreach ( $query->posts as $post ) {
			$id = $post->ID;
			$url = wp_get_attachment_url( $id );
			if ( ! $url ) {
				continue;
			}

			$meta = wp_get_attachment_metadata( $id );
			$thumb = wp_get_attachment_image_src( $id, 'medium' );
			$thumb_url = $thumb ? $thumb[0] : $url;

			$width  = isset( $meta['width'] ) ? (int) $meta['width'] : ( $thumb ? (int) $thumb[1] : 0 );
			$height = isset( $meta['height'] ) ? (int) $meta['height'] : ( $thumb ? (int) $thumb[2] : 0 );

			$items[] = [
				'id'            => $id,
				'title'         => get_the_title( $id ) ?: wp_basename( $url ),
				'filename'      => wp_basename( $url ),
				'url'           => $url,
				'thumbnail_url' => $thumb_url,
				'width'         => $width,
				'height'        => $height,
				'mime'          => get_post_mime_type( $id ) ?: 'image/png',
				'date'          => get_the_date( 'c', $id ),
			];
		}

		$response = new WP_REST_Response( [
			'success'     => true,
			'items'       => $items,
			'total'       => (int) $query->found_posts,
			'total_pages' => (int) $query->max_num_pages,
			'page'        => $page,
			'per_page'    => $per_page,
		] );

		$response->header( 'Access-Control-Allow-Origin', '*' );
		$response->header( 'Access-Control-Allow-Methods', 'GET, OPTIONS' );
		return $response;
	}

	/**
	 * REST Endpoint: Extract smooth multiply shadow and screen highlight PNG overlays from a neutral white render
	 */
	public static function rest_extract_shading( WP_REST_Request $request ): WP_REST_Response {
		$params = $request->get_json_params() ?: $request->get_params();
		$source_url = esc_url_raw( trim( $params['source_image_url'] ?? '' ) );
		$shadow_contrast = isset( $params['shadow_contrast'] ) ? max( 0.5, min( 2.5, (float) $params['shadow_contrast'] ) ) : 1.2;
		$highlight_contrast = isset( $params['highlight_contrast'] ) ? max( 0.5, min( 2.5, (float) $params['highlight_contrast'] ) ) : 1.0;

		if ( empty( $source_url ) ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => 'Source image URL is required' ], 400 );
		}

		if ( ! extension_loaded( 'gd' ) ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => 'PHP GD extension is required on server for image extraction' ], 500 );
		}

		// Download or fetch source image
		$response = wp_remote_get( $source_url, [
			'timeout' => 30,
			'sslverify' => false,
			'headers' => [ 'User-Agent' => 'Exacoat-Manager/1.0' ],
		] );

		if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => 'Unable to fetch source image: ' . ( is_wp_error( $response ) ? $response->get_error_message() : 'HTTP ' . wp_remote_retrieve_response_code( $response ) ) ], 400 );
		}

		$image_data = wp_remote_retrieve_body( $response );
		$src_img = @imagecreatefromstring( $image_data );
		if ( ! $src_img ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => 'Invalid image format. PNG with transparency is recommended.' ], 400 );
		}

		$width = imagesx( $src_img );
		$height = imagesy( $src_img );

		// Target directory in wp-content/uploads/configurator-shading/
		$upload_dir = wp_upload_dir();
		$shading_dir = trailingslashit( $upload_dir['basedir'] ) . 'configurator-shading';
		$shading_url = trailingslashit( $upload_dir['baseurl'] ) . 'configurator-shading';

		if ( ! file_exists( $shading_dir ) ) {
			wp_mkdir_p( $shading_dir );
		}

		// Find base luminance by sampling non-transparent pixels
		$lum_samples = [];
		for ( $y = 0; $y < $height; $y += 5 ) {
			for ( $x = 0; $x < $width; $x += 5 ) {
				$rgba = imagecolorat( $src_img, $x, $y );
				$a = ( $rgba >> 24 ) & 0x7F; // GD alpha: 0 = opaque, 127 = transparent
				if ( $a < 64 ) {
					$r = ( $rgba >> 16 ) & 0xFF;
					$g = ( $rgba >> 8 ) & 0xFF;
					$b = $rgba & 0xFF;
					$lum = 0.299 * $r + 0.587 * $g + 0.114 * $b;
					$lum_samples[] = $lum;
				}
			}
		}

		if ( empty( $lum_samples ) ) {
			imagedestroy( $src_img );
			return new WP_REST_Response( [ 'success' => false, 'message' => 'No visible skin pixels detected in source image' ], 400 );
		}

		sort( $lum_samples );
		// Median luminance is the flat neutral vinyl surface
		$base_lum = $lum_samples[ intval( count( $lum_samples ) * 0.5 ) ];
		if ( $base_lum < 180 ) {
			$base_lum = 240.0;
		}

		// Create TrueColor images with alpha channel
		$shadow_img = imagecreatetruecolor( $width, $height );
		imagealphablending( $shadow_img, false );
		imagesavealpha( $shadow_img, true );
		$transparent_black = imagecolorallocatealpha( $shadow_img, 0, 0, 0, 127 );
		imagefill( $shadow_img, 0, 0, $transparent_black );

		$highlight_img = imagecreatetruecolor( $width, $height );
		imagealphablending( $highlight_img, false );
		imagesavealpha( $highlight_img, true );
		$transparent_white = imagecolorallocatealpha( $highlight_img, 255, 255, 255, 127 );
		imagefill( $highlight_img, 0, 0, $transparent_white );

		for ( $y = 0; $y < $height; $y++ ) {
			for ( $x = 0; $x < $width; $x++ ) {
				$rgba = imagecolorat( $src_img, $x, $y );
				$gd_alpha = ( $rgba >> 24 ) & 0x7F; // 0 (opaque) to 127 (transparent)
				if ( $gd_alpha >= 120 ) {
					continue;
				}

				$r = ( $rgba >> 16 ) & 0xFF;
				$g = ( $rgba >> 8 ) & 0xFF;
				$b = $rgba & 0xFF;
				$lum = 0.299 * $r + 0.587 * $g + 0.114 * $b;
				$norm_alpha = ( 127 - $gd_alpha ) / 127.0; // 0.0 to 1.0

				// Shadow: where lum < base_lum
				if ( $lum < $base_lum ) {
					$shadow_factor = ( $base_lum - $lum ) / max( 1.0, $base_lum );
					$shadow_strength = min( 1.0, $shadow_factor * $shadow_contrast ) * $norm_alpha;
					if ( $shadow_strength > 0.01 ) {
						// In GD: 0 = opaque, 127 = transparent
						$gd_sh_alpha = intval( 127 - ( $shadow_strength * 127.0 ) );
						$col = imagecolorallocatealpha( $shadow_img, 0, 0, 0, max( 0, min( 127, $gd_sh_alpha ) ) );
						imagesetpixel( $shadow_img, $x, $y, $col );
					}
				}

				// Highlight: where lum > base_lum
				if ( $lum > $base_lum ) {
					$hl_factor = ( $lum - $base_lum ) / max( 1.0, 255.0 - $base_lum );
					$hl_strength = min( 1.0, $hl_factor * $highlight_contrast ) * $norm_alpha;
					if ( $hl_strength > 0.01 ) {
						$gd_hl_alpha = intval( 127 - ( $hl_strength * 127.0 ) );
						$col = imagecolorallocatealpha( $highlight_img, 255, 255, 255, max( 0, min( 127, $gd_hl_alpha ) ) );
						imagesetpixel( $highlight_img, $x, $y, $col );
					}
				}
			}
		}

		// Generate file names based on source hash
		$hash = substr( md5( $source_url ), 0, 10 );
		$filename_base = sanitize_title( pathinfo( parse_url( $source_url, PHP_URL_PATH ), PATHINFO_FILENAME ) );
		if ( empty( $filename_base ) ) $filename_base = 'shading';

		$shadow_filename = "{$filename_base}-shadow-{$hash}.png";
		$highlight_filename = "{$filename_base}-highlight-{$hash}.png";

		$shadow_path = $shading_dir . '/' . $shadow_filename;
		$highlight_path = $shading_dir . '/' . $highlight_filename;

		imagepng( $shadow_img, $shadow_path, 8 );
		imagepng( $highlight_img, $highlight_path, 8 );

		imagedestroy( $src_img );
		imagedestroy( $shadow_img );
		imagedestroy( $highlight_img );

		$res = new WP_REST_Response( [
			'success'       => true,
			'message'       => 'Shadow and highlight overlays extracted successfully.',
			'shadow_url'    => $shading_url . '/' . $shadow_filename,
			'highlight_url' => $shading_url . '/' . $highlight_filename,
			'base_lum'      => round( $base_lum, 1 ),
		] );
		$res->header( 'Access-Control-Allow-Origin', '*' );
		return $res;
	}

	/**
	 * Safe JSON parser for string or array meta values with unescaping support
	 */
	public static function parse_meta_json( $raw ) {
		if ( empty( $raw ) ) return [];
		if ( is_array( $raw ) ) return $raw;
		if ( is_string( $raw ) ) {
			$cur = trim( $raw );
			for ( $i = 0; $i < 4; $i++ ) {
				$decoded = json_decode( $cur, true );
				if ( is_array( $decoded ) ) return $decoded;
				if ( is_string( $decoded ) ) {
					$cur = trim( $decoded );
					continue;
				}
				$cur = stripslashes( $cur );
				$decoded2 = json_decode( $cur, true );
				if ( is_array( $decoded2 ) ) return $decoded2;
			}
		}
		return [];
	}

	/**
	 * Permanently persist rendered configurator composite preview image into WordPress uploads/composites.
	 */
	public static function rest_upload_composite( WP_REST_Request $request ): WP_REST_Response {
		$params = $request->get_json_params() ?: $request->get_params();
		$raw_key = sanitize_text_field( $params['key'] ?? '' );
		$data_url = $params['dataUrl'] ?? ( $params['data_url'] ?? '' );

		if ( empty( $raw_key ) || empty( $data_url ) || ! is_string( $data_url ) ) {
			return new WP_REST_Response( [
				'success' => false,
				'message' => 'Missing required key or dataUrl parameters.',
			], 400 );
		}

		$clean_key = preg_replace( '/[^a-zA-Z0-9_-]/', '_', $raw_key );
		$clean_key = substr( $clean_key, 0, 120 );

		if ( ! preg_match( '/^data:image\/(png|jpeg|jpg|webp);base64,(.+)$/', $data_url, $matches ) ) {
			return new WP_REST_Response( [
				'success' => false,
				'message' => 'Invalid image data URL format.',
			], 400 );
		}

		$ext = $matches[1] === 'jpeg' ? 'jpg' : $matches[1];
		$image_binary = base64_decode( $matches[2] );
		if ( ! $image_binary ) {
			return new WP_REST_Response( [
				'success' => false,
				'message' => 'Failed to decode base64 image data.',
			], 400 );
		}

		$upload_dir = wp_upload_dir();
		$composites_dir = trailingslashit( $upload_dir['basedir'] ) . 'composites';
		$composites_url = trailingslashit( $upload_dir['baseurl'] ) . 'composites';

		if ( ! file_exists( $composites_dir ) ) {
			wp_mkdir_p( $composites_dir );
		}

		$filename = $clean_key . '.' . $ext;
		$filepath = trailingslashit( $composites_dir ) . $filename;
		$file_saved = @file_put_contents( $filepath, $image_binary );

		if ( false === $file_saved ) {
			return new WP_REST_Response( [
				'success' => false,
				'message' => 'Could not write composite image file to disk.',
			], 500 );
		}

		$public_url = trailingslashit( $composites_url ) . $filename;

		$response = new WP_REST_Response( [
			'success' => true,
			'key'     => $clean_key,
			'url'     => $public_url,
		], 200 );

		$response->header( 'Access-Control-Allow-Origin', '*' );
		$response->header( 'Access-Control-Allow-Methods', 'POST, GET, OPTIONS' );

		return $response;
	}

	/**
	 * REST Endpoint: Upload image file to WordPress Media Library
	 * Enforces lossless/near-lossless optimization:
	 * - PNG: 128-color palette quantization with alpha preservation + compression level 9
	 * - JPEG: Quality 85
	 * - WebP: Generates 85-quality WebP companion (preserving alpha for PNGs)
	 */
	public static function rest_upload_media( WP_REST_Request $request ): WP_REST_Response {
		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';

		$png_colors   = max( 16, min( 256, (int) ( $request->get_param( 'png_colors' ) ?: 128 ) ) );
		$jpeg_quality = max( 50, min( 100, (int) ( $request->get_param( 'jpeg_quality' ) ?: 85 ) ) );

		$quality_cb = static function () use ( $jpeg_quality ) {
			return $jpeg_quality;
		};
		add_filter( 'jpeg_quality', $quality_cb, 999 );
		add_filter( 'wp_editor_set_quality', $quality_cb, 999 );

		$attachment_id = 0;
		if ( ! empty( $_FILES['file'] ) ) {
			$attachment_id = media_handle_upload( 'file', 0 );
		} elseif ( ! empty( $_FILES['image'] ) ) {
			$attachment_id = media_handle_upload( 'image', 0 );
		}

		remove_filter( 'jpeg_quality', $quality_cb, 999 );
		remove_filter( 'wp_editor_set_quality', $quality_cb, 999 );

		if ( is_wp_error( $attachment_id ) ) {
			return new WP_REST_Response( [
				'success' => false,
				'error'   => $attachment_id->get_error_message(),
			], 400 );
		}

		if ( ! $attachment_id ) {
			return new WP_REST_Response( [
				'success' => false,
				'error'   => 'No image file uploaded.',
			], 400 );
		}

		$file_path = get_attached_file( $attachment_id );
		$mime_type = (string) get_post_mime_type( $attachment_id );
		$webp_url  = '';

		if ( $file_path && file_exists( $file_path ) && function_exists( 'imagecreatetruecolor' ) ) {
			$orig_size = @filesize( $file_path );
			$im        = null;

			if ( 'image/png' === $mime_type && function_exists( 'imagecreatefrompng' ) ) {
				$im = @imagecreatefrompng( $file_path );
				if ( $im ) {
					imageAlphaBlending( $im, false );
					imagesavealpha( $im, true );
					if ( imageistruecolor( $im ) && function_exists( 'imagetruecolortopalette' ) ) {
						$w = imagesx( $im );
						$h = imagesy( $im );
						// Preserve full alpha channel while quantizing RGB colors to 128
						$palette_im = imagecreatetruecolor( $w, $h );
						imagealphablending( $palette_im, false );
						imagesavealpha( $palette_im, true );
						imagecopy( $palette_im, $im, 0, 0, 0, 0, $w, $h );
						imagetruecolortopalette( $palette_im, true, $png_colors );
						$tmp_png = $file_path . '.opt.png';
						if ( @imagepng( $palette_im, $tmp_png, 9 ) ) {
							$opt_size = @filesize( $tmp_png );
							if ( $opt_size && $orig_size && $opt_size < $orig_size ) {
								@rename( $tmp_png, $file_path );
							} else {
								@unlink( $tmp_png );
							}
						}
						imagedestroy( $palette_im );
					}
				}
			} elseif ( in_array( $mime_type, [ 'image/jpeg', 'image/jpg' ], true ) && function_exists( 'imagecreatefromjpeg' ) ) {
				$im = @imagecreatefromjpeg( $file_path );
				if ( $im ) {
					$tmp_jpg = $file_path . '.opt.jpg';
					if ( @imagejpeg( $im, $tmp_jpg, $jpeg_quality ) ) {
						$opt_size = @filesize( $tmp_jpg );
						if ( $opt_size && $orig_size && $opt_size < $orig_size ) {
							@rename( $tmp_jpg, $file_path );
						} else {
							@unlink( $tmp_jpg );
						}
					}
				}
			}

			// Generate WebP companion file (with full alpha transparency)
			if ( $im && function_exists( 'imagewebp' ) ) {
				if ( ! imageistruecolor( $im ) && function_exists( 'imagepalettetotruecolor' ) ) {
					@imagepalettetotruecolor( $im );
				}
				imagealphablending( $im, true );
				imagesavealpha( $im, true );
				$webp_path = preg_replace( '/\.(png|jpe?g)$/i', '.webp', $file_path );
				if ( $webp_path && $webp_path !== $file_path && @imagewebp( $im, $webp_path, $jpeg_quality ) ) {
					$att_url  = (string) wp_get_attachment_url( $attachment_id );
					$webp_url = (string) preg_replace( '/\.(png|jpe?g)$/i', '.webp', $att_url );
				}
			}

			if ( $im ) {
				imagedestroy( $im );
			}
		}

		$url      = (string) wp_get_attachment_url( $attachment_id );
		$metadata = wp_get_attachment_metadata( $attachment_id );
		$thumb    = wp_get_attachment_image_url( $attachment_id, 'exacoat_thumb_sm' )
			?: wp_get_attachment_image_url( $attachment_id, 'thumbnail' )
			?: $url;
		$post     = get_post( $attachment_id );

		return new WP_REST_Response( [
			'success'       => true,
			'id'            => (int) $attachment_id,
			'url'           => $url,
			'webp_url'      => $webp_url ?: ( str_ends_with( strtolower( $url ), '.webp' ) ? $url : '' ),
			'thumbnail_url' => (string) $thumb,
			'title'         => $post ? (string) $post->post_title : basename( $url ),
			'filename'      => $file_path ? basename( $file_path ) : basename( $url ),
			'width'         => isset( $metadata['width'] ) ? (int) $metadata['width'] : 0,
			'height'        => isset( $metadata['height'] ) ? (int) $metadata['height'] : 0,
			'mime_type'     => $mime_type,
			'date'          => $post ? (string) $post->post_date : current_time( 'mysql' ),
			'file_size'     => ( $file_path && file_exists( $file_path ) ) ? (int) @filesize( $file_path ) : 0,
		], 200 );
	}

	public static function rest_batch_optimize_media( WP_REST_Request $request ): WP_REST_Response {
		if ( ! class_exists( 'Exacoat_Image_Sizes' ) ) {
			return new WP_REST_Response( [ 'success' => false, 'error' => 'Image sizes module not loaded' ], 500 );
		}

		global $wpdb;

		@set_time_limit( 180 );
		if ( function_exists( 'ini_set' ) ) {
			@ini_set( 'memory_limit', '1024M' );
		}

		$params          = $request->get_json_params() ?: $request->get_params();
		$offset          = max( 0, (int) ( $params['offset'] ?? 0 ) );
		$batch_size      = max( 1, min( 50, (int) ( $params['batch_size'] ?? 15 ) ) );
		$only_over_500kb = ! isset( $params['only_over_500kb'] ) || ! empty( $params['only_over_500kb'] );
		$generate_webp   = ! isset( $params['generate_webp'] ) || ! empty( $params['generate_webp'] );
		$products_only   = ! empty( $params['products_only'] );

		$where_clause = "WHERE post_type = 'attachment' AND post_mime_type IN ('image/jpeg', 'image/jpg', 'image/png')";
		if ( $products_only ) {
			$where_clause .= " AND (
				post_parent IN (SELECT ID FROM {$wpdb->posts} WHERE post_type IN ('product', 'product_variation'))
				OR ID IN (SELECT CAST(meta_value AS UNSIGNED) FROM {$wpdb->postmeta} WHERE meta_key IN ('_thumbnail_id'))
				OR post_title LIKE '%Skin%' OR post_title LIKE '%Body%' OR post_title LIKE '%Case%' OR post_title LIKE '%Gallery%' OR post_title LIKE '%Texture%'
			)";
		}

		$total_attachments = (int) $wpdb->get_var(
			"SELECT COUNT(ID) FROM {$wpdb->posts} {$where_clause}"
		);

		$attachment_ids = $wpdb->get_col( $wpdb->prepare(
			"SELECT ID FROM {$wpdb->posts} {$where_clause} ORDER BY ID DESC LIMIT %d OFFSET %d",
			$batch_size,
			$offset
		) );

		$compressed_count = 0;
		$webp_count       = 0;
		$saved_bytes      = 0;
		$skipped_count    = 0;
		$threshold_bytes  = $only_over_500kb ? Exacoat_Image_Sizes::LARGE_FILE_THRESHOLD : 0;

		foreach ( $attachment_ids as $att_id ) {
			$att_id      = (int) $att_id;
			$source_file = get_attached_file( $att_id );

			if ( ! $source_file || ! file_exists( $source_file ) ) {
				$skipped_count++;
				continue;
			}

			$current_size = (int) @filesize( $source_file );
			$webp_file    = preg_replace( '/\.(jpe?g|png)$/i', '.webp', $source_file );
			$has_webp     = $webp_file && file_exists( $webp_file );

			if ( $current_size < $threshold_bytes && ( ! $generate_webp || $has_webp ) ) {
				$skipped_count++;
				continue;
			}

			$res = Exacoat_Image_Sizes::optimize_master_file(
				$source_file,
				! $only_over_500kb,
				Exacoat_Image_Sizes::LARGE_FILE_THRESHOLD,
				$generate_webp
			);

			if ( ! empty( $res['master_compressed'] ) ) {
				$compressed_count++;
				$saved_bytes += (int) ( $res['saved_bytes'] ?? 0 );
			}

			if ( ! empty( $res['webp_generated'] ) ) {
				$webp_count++;
			}
		}

		$processed_in_batch = count( $attachment_ids );
		$next_offset        = $offset + $processed_in_batch;
		$is_complete        = $next_offset >= $total_attachments || 0 === $processed_in_batch;

		return rest_ensure_response( [
			'success'            => true,
			'total_attachments'  => $total_attachments,
			'processed_in_batch' => $processed_in_batch,
			'compressed_count'   => $compressed_count,
			'webp_count'         => $webp_count,
			'saved_bytes'        => $saved_bytes,
			'formatted_saved'    => size_format( $saved_bytes, 1 ),
			'skipped_count'      => $skipped_count,
			'next_offset'        => $next_offset,
			'is_complete'        => $is_complete,
		] );
	}

	public static function rest_optimize_single_media( WP_REST_Request $request ): WP_REST_Response {
		if ( ! class_exists( 'Exacoat_Image_Sizes' ) ) {
			return new WP_REST_Response( [ 'success' => false, 'error' => 'Image sizes module not loaded' ], 500 );
		}

		$params = $request->get_json_params() ?: $request->get_params();
		$id     = isset( $params['id'] ) ? (int) $params['id'] : 0;
		$url    = isset( $params['url'] ) ? sanitize_text_field( $params['url'] ) : '';

		$source_file = '';
		if ( $id > 0 ) {
			$source_file = (string) get_attached_file( $id );
		}

		if ( empty( $source_file ) && ! empty( $url ) ) {
			$upload_dir = wp_upload_dir();
			$basedir    = wp_normalize_path( $upload_dir['basedir'] );
			$parsed     = parse_url( $url, PHP_URL_PATH );
			if ( $parsed && strpos( $parsed, '/wp-content/uploads/' ) !== false ) {
				$rel  = ltrim( substr( $parsed, strpos( $parsed, '/wp-content/uploads/' ) + 20 ), '/' );
				$cand = $basedir . '/' . $rel;
				if ( file_exists( $cand ) ) {
					$source_file = $cand;
				}
			}
			if ( empty( $source_file ) && class_exists( 'Exacoat_Store_Enhancements' ) ) {
				$fn = wp_basename( $url );
				$source_file = Exacoat_Store_Enhancements::locate_physical_upload( $fn, '', $basedir );
			}
		}

		if ( empty( $source_file ) || ! file_exists( $source_file ) ) {
			return new WP_REST_Response( [ 'success' => false, 'error' => 'Image file not found on disk' ], 404 );
		}

		$res = Exacoat_Image_Sizes::optimize_master_file( $source_file, true, 0, true );

		if ( $id > 0 && ! empty( $res['master_compressed'] ) ) {
			$metadata = wp_get_attachment_metadata( $id );
			if ( is_array( $metadata ) ) {
				$metadata['filesize'] = $res['current_size'];
				wp_update_attachment_metadata( $id, $metadata );
			}
			clean_post_cache( $id );
		}

		return rest_ensure_response( array_merge( [ 'success' => true, 'file_path' => $source_file ], $res ) );
	}

	/**
	 * Intelligent Device Family & Size Multiplier Inferrer
	 * Analyzes product title, slug, and category taxonomies across all device brands.
	 *
	 * @param string       $name       Product title/name.
	 * @param string       $slug       Product slug.
	 * @param array|string $categories Category names or string.
	 * @return array Array with 'family' and 'size_multiplier'.
	 */
	public static function infer_device_family( $name, $slug = '', $categories = [] ): array {
		$cat_str = is_array( $categories ) ? implode( ' ', $categories ) : (string) $categories;
		$haystack = strtolower( "{$name} {$slug} {$cat_str}" );

		// 1. Keyboards / Folios / Book Covers
		if ( preg_match( '/\b(keyboard|folio|book cover)\b/i', $haystack ) ) {
			return [ 'family' => 'keyboard', 'size_multiplier' => 2.0 ];
		}

		// 2. Laptops / Notebooks
		if ( preg_match( '/\b(macbook|xps|laptop|notebook|zenbook|thinkpad|blade|surface laptop|surface book|realme book|galaxy book|redmibook)\b/i', $haystack ) ) {
			return [ 'family' => 'laptop', 'size_multiplier' => 2.0 ];
		}

		// 3. Tablets (Galaxy Tab, Mi Pad, Xiaomi Pad, iPad, Surface Pro, Surface Go, etc.)
		if ( preg_match( '/\b(tab|pad|surface pro|surface go|tablet|ipad)\b/i', $haystack ) ) {
			return [ 'family' => 'tablet', 'size_multiplier' => 2.0 ];
		}

		// 4. Foldables
		if ( preg_match( '/\b(fold|flip|razr)\b/i', $haystack ) ) {
			return [ 'family' => 'foldable', 'size_multiplier' => 1.3 ];
		}

		// 5. Gaming Consoles
		if ( preg_match( '/\b(deck|rog ally|legion go|switch|playstation|ps5|ps4|xbox|console)\b/i', $haystack ) ) {
			return [ 'family' => 'console', 'size_multiplier' => 2.0 ];
		}

		// 6. Protective Cases
		if ( preg_match( '/\b(case|cases|dusk)\b/i', $haystack ) ) {
			return [ 'family' => 'case', 'size_multiplier' => 1.0 ];
		}

		// 7. Default: Phone
		return [ 'family' => 'phone', 'size_multiplier' => 1.0 ];
	}

	/**
	 * Helper to reliably resolve a product's base price across simple and variable products
	 */
	public static function get_product_base_price( $product ): float {
		if ( ! $product || ! is_object( $product ) ) {
			return 0.0;
		}

		$price = (float) ( $product->get_price() ?: $product->get_regular_price() ?: 0 );

		if ( $price <= 0 && method_exists( $product, 'is_type' ) && $product->is_type( 'variable' ) ) {
			if ( method_exists( $product, 'get_variation_price' ) ) {
				$min_price = (float) $product->get_variation_price( 'min', true );
				if ( $min_price > 0 ) {
					return $min_price;
				}
			}
			if ( method_exists( $product, 'get_variation_regular_price' ) ) {
				$min_reg_price = (float) $product->get_variation_regular_price( 'min', true );
				if ( $min_reg_price > 0 ) {
					return $min_reg_price;
				}
			}
		}

		return $price;
	}

	/**
	 * Convert legacy MKL product meta into modern Composable Device Profile
	 */
	public static function convert_mkl_to_profile( int $product_id ): array {
		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return [];
		}

		$angles_raw = get_post_meta( $product_id, '_mkl_product_configurator_angles', true );
		$layers_raw = get_post_meta( $product_id, '_mkl_product_configurator_layers', true );
		$content_raw = get_post_meta( $product_id, '_mkl_product_configurator_content', true );

		$angles = self::parse_meta_json( $angles_raw );
		$layers = self::parse_meta_json( $layers_raw );
		$content = self::parse_meta_json( $content_raw );

		$cat_names = wp_get_post_terms( $product_id, 'product_cat', [ 'fields' => 'names' ] );
		$main_cat = ! empty( $cat_names ) && is_array( $cat_names ) ? $cat_names[0] : 'General';

		// Determine device family and size multiplier using multi-attribute inference
		$inferred = self::infer_device_family( $product->get_name(), $product->get_slug(), $cat_names );
		$family = $inferred['family'];
		$size_multiplier = $inferred['size_multiplier'];

		// Convert Views
		$views = [];
		if ( ! empty( $angles ) && is_array( $angles ) ) {
			$order_idx = 0;
			foreach ( $angles as $a ) {
				$name = trim( self::decode_entities( $a['name'] ?? '' ) );
				if ( empty( $name ) ) continue;
				$slug = strtolower( preg_replace( '/[^a-z0-9]+/i', '_', $name ) );
				$slug = trim( $slug, '_' );
				$views[] = [
					'id'                => $slug ?: ( 'view_' . ( $a['_id'] ?? $order_idx ) ),
					'legacy_id'         => $a['_id'] ?? null,
					'name'              => $name,
					'is_default'        => $order_idx === 0,
					'aspect_ratio'      => '1:1',
					'canvas_dimensions' => [ 'width' => 1000, 'height' => 1000 ],
					'background_url'    => '',
					'texture_scale'     => 0.75,
				];
				$order_idx++;
			}
		}

		if ( empty( $views ) ) {
			$views[] = [
				'id'                => 'main_view',
				'name'              => 'Main View',
				'is_default'        => true,
				'aspect_ratio'      => '1:1',
				'canvas_dimensions' => [ 'width' => 1000, 'height' => 1000 ],
				'background_url'    => '',
				'texture_scale'     => 0.75,
			];
		}

		// Group content by layerId
		$content_by_layer = [];
		if ( is_array( $content ) ) {
			foreach ( $content as $item ) {
				if ( isset( $item['layerId'] ) ) {
					$content_by_layer[ $item['layerId'] ] = $item['choices'] ?? [];
				}
			}
		}

		// Find "Device" layer in MKL to extract base hardware body render
		$device_body_by_view = [];
		if ( is_array( $layers ) ) {
			foreach ( $layers as $l ) {
				$l_name = strtolower( trim( $l['name'] ?? '' ) );
				if ( $l_name === 'device' || strpos( (string) ( $l['class_name'] ?? '' ), 'device-body' ) !== false ) {
					$dev_choices = $content_by_layer[ $l['_id'] ?? 0 ] ?? [];
					foreach ( $dev_choices as $ch ) {
						if ( ! empty( $ch['images'] ) && is_array( $ch['images'] ) ) {
							foreach ( $ch['images'] as $img_obj ) {
								$url = $img_obj['image']['url'] ?? '';
								if ( empty( $url ) ) continue;
								$angle_id = $img_obj['angleId'] ?? null;
								$angle_name = $img_obj['angle_name'] ?? '';

								$matched = false;
								foreach ( $views as $v ) {
									if ( ( $angle_id && (int) ( $v['legacy_id'] ?? 0 ) === (int) $angle_id ) || ( $angle_name && strcasecmp( $v['name'], $angle_name ) === 0 ) ) {
										$device_body_by_view[ $v['id'] ] = $url;
										$matched = true;
									}
								}
								if ( ! $matched ) {
									foreach ( $views as $v ) {
										if ( empty( $device_body_by_view[ $v['id'] ] ) ) {
											$device_body_by_view[ $v['id'] ] = $url;
										}
									}
								}
							}
						}
					}
				}
			}
		}

		// Assign device body URL to views background_url
		foreach ( $views as &$v ) {
			if ( ! empty( $device_body_by_view[ $v['id'] ] ) ) {
				$v['background_url'] = $device_body_by_view[ $v['id'] ];
			}
		}
		unset( $v );

		// Convert Layers
		$normalized_layers = [];
		$variants = [];
		$logo_cutout_by_view = [];
		$has_logo_layer = false;
		$has_coverage_layer = false;
		$model_cut_image = '';
		$model_360_price = 40000;

		if ( is_array( $layers ) ) {
			foreach ( $layers as $idx => $l ) {
				$layer_name = trim( self::decode_entities( $l['name'] ?? '' ) );
				if ( empty( $layer_name ) ) continue;
				$layer_name_lower = strtolower( $layer_name );

				// Device layer is the hardware chassis render (Layer 1 base image), not a configurable skin layer
				if ( $layer_name_lower === 'device' || strpos( (string) ( $l['class_name'] ?? '' ), 'device-body' ) !== false ) {
					continue;
				}

				$layer_id_num = $l['_id'] ?? $idx;
				$layer_slug = sanitize_title( $layer_name );
				$is_required = ( ( $l['required'] ?? '' ) === '1' || ( $l['required'] ?? false ) === true );
				$is_optional = ( ( $l['can_deselect'] ?? '' ) === '1' || strpos( (string) ( $l['class_name'] ?? '' ), 'optional' ) !== false );
				
				$raw_choices = $content_by_layer[ $layer_id_num ] ?? [];

				// Detect if this layer represents Model Coverage (Model Cut vs Model 360)
				$is_coverage = ( strpos( $layer_name_lower, 'coverage' ) !== false || strpos( $layer_name_lower, 'model cut' ) !== false || strpos( $layer_name_lower, 'model 360' ) !== false );
				if ( ! $is_coverage && ( $layer_name_lower === 'model' || strpos( $layer_name_lower, 'cut' ) !== false ) ) {
					foreach ( $raw_choices as $ch ) {
						$ch_name_l = strtolower( self::decode_entities( $ch['name'] ?? '' ) );
						if ( strpos( $ch_name_l, 'model cut' ) !== false || strpos( $ch_name_l, 'model 360' ) !== false || strpos( $ch_name_l, '360' ) !== false ) {
							$is_coverage = true;
							break;
						}
					}
				}

				if ( $is_coverage ) {
					$has_coverage_layer = true;
					foreach ( $raw_choices as $ch ) {
						$ch_name_l = strtolower( self::decode_entities( $ch['name'] ?? '' ) );
						if ( strpos( $ch_name_l, 'model cut' ) !== false && ! empty( $ch['images'] ) && is_array( $ch['images'] ) ) {
							foreach ( $ch['images'] as $img_obj ) {
								$url = $img_obj['image']['url'] ?? '';
								if ( ! empty( $url ) ) {
									$model_cut_image = $url;
									break;
								}
							}
						}
						if ( ( strpos( $ch_name_l, 'model 360' ) !== false || strpos( $ch_name_l, '360' ) !== false ) && isset( $ch['extra_price'] ) && (float) $ch['extra_price'] > 0 ) {
							$model_360_price = (float) $ch['extra_price'];
						}
					}
					// Model coverage is managed by coverage_and_cutouts, strictly not a production variant
					continue;
				}

				// Exacoat catalog rule: iPhones and smartphones are strictly separate standalone products (never combined with model variants)
				$is_phone_device = ( $family === 'phone' || preg_match( '/\b(iphone|galaxy|pixel|xiaomi|redmi|poco|oppo|vivo|realme|infinix|oneplus|phone)\b/i', "{$product->get_name()} {$product->get_slug()}" ) );
				if ( $is_phone_device && ( in_array( $layer_name_lower, [ 'model', 'series', 'iphone model', 'phone model', 'device model', 'connectivity' ], true ) || strpos( $layer_name_lower, 'iphone' ) !== false || strpos( $layer_name_lower, 'model' ) !== false ) ) {
					// Discard legacy hardware model selector layers on phones
					continue;
				}

				// Only tablets (e.g. iPad Wi-Fi vs Cellular, iPad versions) or explicit hardware where physical templates differ may have selector variants
				$is_selector = strpos( (string) ( $l['class_name'] ?? '' ), 'none-hover' ) !== false
					|| in_array( $layer_name_lower, [ 'series', 'ipad series', 'version', 'ipad version', 'connectivity' ], true )
					|| preg_match( '/\b(series|connectivity|version)\b/i', $layer_name_lower );
				$is_logo = ( strpos( $layer_name_lower, 'logo' ) !== false || strpos( $layer_name_lower, 'cutout' ) !== false );

				if ( $is_selector ) {
					$options = [];
					foreach ( $raw_choices as $ch ) {
						if ( empty( $ch['is_group'] ) && ! empty( $ch['name'] ) ) {
							$ch_name = self::decode_entities( $ch['name'] );
							$opt_img = '';
							if ( ! empty( $ch['images'] ) && is_array( $ch['images'] ) ) {
								foreach ( $ch['images'] as $img_obj ) {
									if ( ! empty( $img_obj['image']['url'] ) ) {
										$opt_img = $img_obj['image']['url'];
										break;
									}
								}
							}
							$price_val = isset( $ch['price'] ) ? (float) $ch['price'] : ( isset( $ch['extra_price'] ) ? (float) $ch['extra_price'] : 0 );
							$options[] = [
								'id'         => sanitize_title( $ch_name ),
								'name'       => $ch_name,
								'price_diff' => $price_val,
								'image_url'  => $opt_img,
							];
						}
					}
					if ( ! empty( $options ) ) {
						$variants[] = [
							'id'      => $layer_slug,
							'name'    => $layer_name,
							'options' => $options,
						];
					}
					continue;
				}

				// Build texture map for this layer across all views
				$assets_by_view = [];
				foreach ( $views as $v ) {
					$assets_by_view[ $v['id'] ] = [
						'render_texture_map'     => [],
						'base_hardware_body_url' => $device_body_by_view[ $v['id'] ] ?? '',
					];
				}
				$assets_by_view['main_view'] = [
					'render_texture_map'     => [],
					'base_hardware_body_url' => reset( $device_body_by_view ) ?: '',
				];

				$layer_extra_price = 0;

				foreach ( $raw_choices as $ch ) {
					if ( ! empty( $ch['is_group'] ) ) continue;
					$ch_name = self::decode_entities( $ch['name'] ?? '' );
					$ch_slug = sanitize_title( $ch_name );
					$ch_price = isset( $ch['price'] ) ? (float) $ch['price'] : ( isset( $ch['extra_price'] ) ? (float) $ch['extra_price'] : 0 );
					if ( $ch_price > 0 && $layer_extra_price === 0 ) {
						$layer_extra_price = $ch_price;
					}

					if ( ! empty( $ch['images'] ) && is_array( $ch['images'] ) ) {
						foreach ( $ch['images'] as $img_obj ) {
							$url = $img_obj['image']['url'] ?? '';
							if ( empty( $url ) ) continue;

							$angle_id = $img_obj['angleId'] ?? null;
							$angle_name = $img_obj['angle_name'] ?? '';

							$matched = false;
							foreach ( $views as $v ) {
								if ( ( $angle_id && (int) ( $v['legacy_id'] ?? 0 ) === (int) $angle_id ) || ( $angle_name && strcasecmp( $v['name'], $angle_name ) === 0 ) ) {
									$assets_by_view[ $v['id'] ]['render_texture_map'][ $ch_slug ] = $url;
									$matched = true;
								}
							}

							if ( ! $matched || count( $views ) === 1 ) {
								foreach ( $views as $v ) {
									$assets_by_view[ $v['id'] ]['render_texture_map'][ $ch_slug ] = $url;
								}
							}

							$assets_by_view['main_view']['render_texture_map'][ $ch_slug ] = $url;
						}
					}
				}

				$layer_finish_slugs = [];
				foreach ( $raw_choices as $ch ) {
					if ( empty( $ch['is_group'] ) && ! empty( $ch['name'] ) ) {
						$layer_finish_slugs[] = sanitize_title( self::decode_entities( $ch['name'] ) );
					}
				}
				$layer_finish_slugs = array_values( array_unique( $layer_finish_slugs ) );

				$is_primary_layer = in_array( strtolower( trim( $layer_name ) ), [ 'back', 'back skin', 'top', 'top lid', 'device', 'body', 'main', 'base', 'full' ], true )
					|| in_array( $layer_slug, [ 'back', 'back-skin', 'top', 'top-lid', 'main', 'device' ], true )
					|| ( $idx === 0 && ! in_array( $layer_slug, [ 'series', 'version', 'connectivity', 'model' ], true ) && ! preg_match( '/\b(series|version|connectivity|model)\b/i', $layer_name ) );

				$normalized_layers[] = [
					'id'                    => $layer_slug,
					'legacy_id'             => $layer_id_num,
					'name'                  => $layer_name,
					'group'                 => $is_primary_layer ? 'primary' : 'accent',
					'is_required'           => $is_required,
					'is_optional'           => $is_optional,
					'default_selected'      => $is_required || ! $is_optional,
					'extra_price'           => $is_primary_layer ? 0 : $layer_extra_price,
					'z_index'               => $idx + 1,
					'allowed_finish_groups' => [ 'Signature skins', 'Colors', 'Natural' ],
					'allowed_finish_slugs'  => ( count( $layer_finish_slugs ) > 0 && count( $layer_finish_slugs ) < 15 ) ? $layer_finish_slugs : [],
					'assets_by_view'        => $assets_by_view,
				];
			}
		}

		// Assign logo cutout mask to views if discovered
		foreach ( $views as &$v ) {
			if ( ! empty( $logo_cutout_by_view[ $v['id'] ] ) ) {
				$v['logo_cutout_mask_url'] = $logo_cutout_by_view[ $v['id'] ];
				$v['logo_image_url'] = $logo_cutout_by_view[ $v['id'] ];
			}
		}
		unset( $v );

		$primary_logo_url = reset( $logo_cutout_by_view ) ?: '';
		$is_phone = ( $family === 'phone' || preg_match( '/\b(iphone|galaxy|pixel|xiaomi|redmi|poco|oppo|vivo|realme|infinix|oneplus|phone)\b/i', "{$product->get_name()} {$product->get_slug()}" ) );
		$is_foldable = ( $family === 'foldable' || preg_match( '/\b(fold|flip)\b/i', "{$product->get_name()} {$product->get_slug()}" ) );

		$cov_type = 'none';
		$has_cut = false;
		if ( $has_coverage_layer ) {
			$cov_type = 'model_cut_and_360';
			$has_cut = true;
		} elseif ( $is_foldable ) {
			$cov_type = 'model_cut_only';
			$has_cut = true;
		} elseif ( $is_phone ) {
			$cov_type = 'model_cut_and_360';
			$has_cut = true;
		}

		$coverage_and_cutouts = [
			'has_logo_cutout'       => $has_logo_layer || ! empty( $primary_logo_url ) || ( $family === 'laptop' ) || strpos( $cat_lower, 'macbook' ) !== false || strpos( $cat_lower, 'iphone' ) !== false,
			'logo_cutout_mask_url'  => $primary_logo_url,
			'has_pencil_cutout'     => false,
			'has_model_cut'         => $has_cut,
			'coverage_type'         => $cov_type,
			'model_cutout_url'      => $model_cut_image ?: '',
			'model_cut_mask_url'    => $model_cut_image ?: '',
			'model_360_extra_price' => ( $cov_type === 'model_cut_and_360' || $cov_type === 'both' ) ? ( $model_360_price ?: 40000 ) : 0,
		];

		$base_price = self::get_product_base_price( $product );

		return self::decode_entities( [
			'product_id'           => $product_id,
			'device_slug'          => $product->get_slug(),
			'device_name'          => $product->get_name(),
			'category'             => $main_cat,
			'family'               => $family,
			'base_price'           => $base_price,
			'currency'             => get_woocommerce_currency(),
			'size_multiplier'      => $size_multiplier,
			'texture_scale'        => isset( $views[0]['texture_scale'] ) ? (float) $views[0]['texture_scale'] : 0.75,
			'is_configurable'      => ! empty( $normalized_layers ),
			'configurator_version' => 'v1',
			'device_colors'        => [],
			'views'                => $views,
			'layers'               => $normalized_layers,
			'variants'             => self::sanitize_variants( $variants, $family, $product->get_name(), $product->get_slug() ),
			'coverage_and_cutouts' => $coverage_and_cutouts,
			'presets'              => [],
			'updated_at'           => current_time( 'mysql' ),
		] );
	}

	/**
	 * Sanitize production variants array: strip out logo cutout, coverage, and invalid phone model selectors
	 */
	public static function sanitize_variants( $variants, $family = '', $device_name = '', $device_slug = '' ): array {
		if ( ! is_array( $variants ) ) {
			return [];
		}

		$is_phone = ( $family === 'phone' || preg_match( '/\b(iphone|galaxy|pixel|xiaomi|redmi|poco|oppo|vivo|realme|infinix|oneplus|phone)\b/i', "{$device_name} {$device_slug}" ) );

		$clean = [];
		foreach ( $variants as $v ) {
			if ( ! is_array( $v ) ) continue;
			$v_id = strtolower( (string) ( $v['id'] ?? '' ) );
			$v_name = strtolower( (string) ( $v['name'] ?? '' ) );

			// Check if this variant represents coverage / model selection
			$has_coverage_options = false;
			$has_phone_model_options = false;
			if ( ! empty( $v['options'] ) && is_array( $v['options'] ) ) {
				foreach ( $v['options'] as &$opt ) {
					if ( ! is_array( $opt ) ) continue;
					$opt_id = strtolower( (string) ( $opt['id'] ?? '' ) );
					$opt_name = strtolower( (string) ( $opt['name'] ?? '' ) );
					if ( strpos( $opt_id, '360' ) !== false || strpos( $opt_name, '360' ) !== false || strpos( $opt_id, 'model-cut' ) !== false || strpos( $opt_name, 'model cut' ) !== false ) {
						$has_coverage_options = true;
					}
					// Detect phone model options (e.g. 17 Pro, 17 Pro Max, iPhone 17, Pro Max, Plus, Ultra)
					if ( preg_match( '/\b(iphone|17 pro|pro max|promax|16 pro|15 pro|14 pro|ultra|plus|mini)\b/i', "{$opt_name} {$opt_id}" ) ) {
						$has_phone_model_options = true;
					}
					if ( isset( $opt['name'] ) && is_string( $opt['name'] ) ) {
						$opt['name'] = str_replace( [ '360u00b0', '360\\u00b0', 'u00b0' ], '360°', $opt['name'] );
					}
				}
				unset( $opt );
			}

			// Reject coverage, logo, cutout
			if ( $has_coverage_options || strpos( $v_id, 'logo' ) !== false || strpos( $v_name, 'logo' ) !== false || strpos( $v_id, 'cutout' ) !== false || strpos( $v_id, 'coverage' ) !== false || strpos( $v_name, 'coverage' ) !== false || strpos( $v_name, 'model cut' ) !== false || strpos( $v_id, '360' ) !== false || strpos( $v_name, '360' ) !== false ) {
				continue;
			}

			// Reject any phone model variant (iPhones & phones are always separated individual products)
			if ( $has_phone_model_options || strpos( $v_id, 'iphone' ) !== false || strpos( $v_name, 'iphone' ) !== false || ( $is_phone && ( $v_id === 'model' || $v_name === 'model' || strpos( $v_id, 'model' ) !== false || strpos( $v_name, 'model' ) !== false || strpos( $v_id, 'series' ) !== false || strpos( $v_name, 'series' ) !== false || strpos( $v_id, 'device' ) !== false || strpos( $v_name, 'device' ) !== false ) ) ) {
				continue;
			}

			$clean[] = $v;
		}
		return array_values( $clean );
	}

	/**
	 * Sanitize presets array for a device configurator profile
	 */
	public static function sanitize_presets( $presets ): array {
		if ( ! is_array( $presets ) ) {
			return [];
		}
		$clean = [];
		foreach ( $presets as $p ) {
			if ( ! is_array( $p ) ) continue;
			$id = sanitize_title( $p['id'] ?? $p['title'] ?? '' );
			if ( empty( $id ) ) continue;
			$clean_layers = [];
			if ( isset( $p['layers'] ) && is_array( $p['layers'] ) ) {
				foreach ( $p['layers'] as $k => $v ) {
					$clean_layers[ sanitize_key( $k ) ] = sanitize_title( (string) $v );
				}
			}
			$clean_triggers = [];
			if ( isset( $p['triggers'] ) && is_array( $p['triggers'] ) ) {
				$clean_triggers = array_values( array_filter( array_map( 'sanitize_title', $p['triggers'] ) ) );
			}
			$badge = sanitize_text_field( $p['badge'] ?? '' );
			if ( ! in_array( $badge, [ 'POPULAR', 'STAFF PICK' ], true ) ) {
				$badge = '';
			}
			$clean[] = [
				'id'          => $id,
				'title'       => sanitize_text_field( $p['title'] ?? '' ),
				'tagline'     => sanitize_text_field( $p['tagline'] ?? '' ),
				'badge'       => $badge,
				'coverage'    => in_array( $p['coverage'] ?? '', [ 'model_360', 'model_cut' ], true ) ? $p['coverage'] : 'model_360',
				'logo_cutout' => ! empty( $p['logo_cutout'] ),
				'layers'      => $clean_layers,
				'triggers'    => $clean_triggers,
				'image_url'   => esc_url_raw( $p['image_url'] ?? '' ),
			];
		}
		return $clean;
	}

	/**
	 * REST Endpoint: Fetch list of all product profiles summary
	 */
	public static function rest_get_configurator_profiles( WP_REST_Request $request ): WP_REST_Response {
		$page = max( 1, (int) $request->get_param( 'page' ) ?: 1 );
		$per_page_param = $request->get_param( 'per_page' );
		if ( $per_page_param === '-1' || (int) $per_page_param === -1 ) {
			$per_page = 500;
		} else {
			$per_page = max( 10, min( 500, (int) $per_page_param ?: 100 ) );
		}
		$search = sanitize_text_field( $request->get_param( 'search' ) ?: '' );
		$category = sanitize_text_field( $request->get_param( 'category' ) ?: '' );
		$only_configurable = $request->get_param( 'only_configurable' );
		$filter_configurable = ( $only_configurable === null || $only_configurable === 'true' || $only_configurable === '1' || $only_configurable === true );

		$args = [
			'post_type'      => 'product',
			'post_status'    => [ 'publish', 'draft' ],
			'posts_per_page' => $per_page,
			'paged'          => $page,
			'orderby'        => 'ID',
			'order'          => 'DESC',
		];

		if ( $search ) {
			$args['s'] = $search;
		}

		if ( $category && $category !== 'all' ) {
			$args['tax_query'] = [
				[
					'taxonomy' => 'product_cat',
					'field'    => 'slug',
					'terms'    => $category,
				],
			];
		}

		$query = new WP_Query( $args );
		$profiles = [];

		foreach ( $query->posts as $p ) {
			$pid = $p->ID;
			$modern_profile = get_post_meta( $pid, self::PROFILE_META_KEY, true );

			if ( ! empty( $modern_profile ) && is_string( $modern_profile ) ) {
				$profile_data = json_decode( $modern_profile, true );
			} elseif ( is_array( $modern_profile ) ) {
				$profile_data = $modern_profile;
			} else {
				$profile_data = null;
			}

			// If profile is missing or is a stub without layers, auto-convert from MKL
			if ( empty( $profile_data ) || ! is_array( $profile_data ) || empty( $profile_data['layers'] ) ) {
				$mkl_profile = self::convert_mkl_to_profile( $pid );
				if ( ! empty( $mkl_profile['layers'] ) ) {
					if ( is_array( $profile_data ) ) {
						if ( ! empty( $profile_data['family'] ) ) $mkl_profile['family'] = $profile_data['family'];
						if ( ! empty( $profile_data['size_multiplier'] ) ) $mkl_profile['size_multiplier'] = $profile_data['size_multiplier'];
					}
					$profile_data = $mkl_profile;
					update_post_meta( $pid, self::PROFILE_META_KEY, wp_slash( wp_json_encode( $profile_data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) );
				}
			}

			$is_migrated = ! empty( $profile_data['layers'] );
			$is_cfg = self::is_product_configurator( $pid, $profile_data );

			// If only_configurable is requested, exclude non-configurator items (merch, cases, drops)
			if ( $filter_configurable && ! $is_cfg ) {
				continue;
			}

			$product = wc_get_product( $pid );
			$cats = wp_get_post_terms( $pid, 'product_cat', [ 'fields' => 'names' ] );

			$last_audited = get_post_meta( $pid, self::AUDIT_TIME_META_KEY, true );
			$audit_status = get_post_meta( $pid, self::AUDIT_STATUS_META_KEY, true );
			$audit_issues = (int) get_post_meta( $pid, self::AUDIT_ISSUES_META_KEY, true );
			$raw_audit_details = get_post_meta( $pid, self::AUDIT_DETAILS_META_KEY, true );
			$audit_details = [];
			if ( ! empty( $raw_audit_details ) ) {
				$audit_details = is_array( $raw_audit_details ) ? $raw_audit_details : json_decode( $raw_audit_details, true );
			}

			$p_name = self::decode_entities( $product ? $product->get_name() : $p->post_title );
			$p_slug = $product ? $product->get_slug() : $p->post_name;

			// Auto-infer and heal device family and size multiplier
			$fam = $profile_data['family'] ?? '';
			$mult = isset( $profile_data['size_multiplier'] ) ? (float) $profile_data['size_multiplier'] : 0;
			$inferred = self::infer_device_family( $p_name, $p_slug, $cats );

			$needs_save = false;
			if ( empty( $fam ) || ( $fam === 'phone' && $inferred['family'] !== 'phone' ) ) {
				$fam = $inferred['family'];
				$mult = $inferred['size_multiplier'];
				$profile_data['family'] = $fam;
				$profile_data['size_multiplier'] = $mult;
				$needs_save = true;
			} elseif ( in_array( $fam, [ 'laptop', 'tablet', 'keyboard', 'console' ], true ) && ( $mult <= 1.0 || in_array( $mult, [ 2.5, 1.8 ], true ) ) ) {
				$mult = 2.0;
				$profile_data['size_multiplier'] = 2.0;
				$needs_save = true;
			} elseif ( $fam === 'foldable' && $mult <= 1.0 ) {
				$mult = 1.3;
				$profile_data['size_multiplier'] = 1.3;
				$needs_save = true;
			}

			if ( $needs_save && ! empty( $modern_profile ) ) {
				update_post_meta( $pid, self::PROFILE_META_KEY, wp_slash( wp_json_encode( $profile_data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) );
				update_post_meta( $pid, '_device_family', $fam );
				update_post_meta( $pid, '_size_multiplier', $mult );
			}

			$profiles[] = [
				'product_id'           => $pid,
				'name'                 => $p_name,
				'slug'                 => $p_slug,
				'status'               => $product ? $product->get_status() : $p->post_status,
				'price'                => self::get_product_base_price( $product ),
				'categories'           => $cats,
				'is_migrated'          => $is_migrated,
				'configurator_version' => $profile_data['configurator_version'] ?? 'v1',
				'is_configurable'      => ! empty( $profile_data['layers'] ),
				'is_configurator'      => $is_cfg,
				'layers_count'         => count( $profile_data['layers'] ?? [] ),
				'views_count'          => count( $profile_data['views'] ?? [] ),
				'presets_count'        => count( $profile_data['presets'] ?? [] ),
				'family'               => $fam ?: 'phone',
				'size_multiplier'      => $mult > 0 ? $mult : 1.0,
				'texture_scale'        => isset( $profile_data['views'][0]['texture_scale'] ) ? (float) $profile_data['views'][0]['texture_scale'] : ( isset( $profile_data['texture_scale'] ) ? (float) $profile_data['texture_scale'] : 0.75 ),
				'last_audited_at'      => ! empty( $last_audited ) ? $last_audited : null,
				'audit_status'         => ! empty( $audit_status ) ? $audit_status : 'unaudited',
				'audit_issues'         => $audit_issues,
				'audit_details'        => is_array( $audit_details ) ? array_values( $audit_details ) : [],
			];
		}

		return rest_ensure_response( [
			'success'     => true,
			'profiles'    => self::decode_entities( $profiles ),
			'total'       => count( $profiles ),
			'total_pages' => (int) $query->max_num_pages,
			'page'        => $page,
		] );
	}

	/**
	 * REST Endpoint to get fully processed configurator data for a product
	 */
	public static function rest_get_product_configurator( WP_REST_Request $request ): WP_REST_Response {
		$id_or_slug = sanitize_text_field( $request->get_param( 'id_or_slug' ) );

		if ( is_numeric( $id_or_slug ) ) {
			$product_id = (int) $id_or_slug;
		} else {
			$product_id = wc_get_product_id_by_slug( $id_or_slug );
		}

		if ( ! $product_id ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => 'Product not found' ], 404 );
		}

		// 1. Check if Modern Composable Profile exists
		$modern_profile = get_post_meta( $product_id, self::PROFILE_META_KEY, true );
		$profile = null;
		if ( ! empty( $modern_profile ) ) {
			if ( is_array( $modern_profile ) ) {
				$profile = $modern_profile;
			} elseif ( is_string( $modern_profile ) ) {
				$profile = json_decode( $modern_profile, true );
				if ( ! is_array( $profile ) ) {
					$profile = json_decode( wp_unslash( $modern_profile ), true );
				}
			}
		}
		
		if ( empty( $profile ) || ! is_array( $profile ) || empty( $profile['layers'] ) ) {
			// Auto-convert legacy MKL on-the-fly if empty or stub profile without layers
			$mkl_profile = self::convert_mkl_to_profile( $product_id );
			if ( ! empty( $mkl_profile['layers'] ) ) {
				if ( is_array( $profile ) ) {
					if ( ! empty( $profile['family'] ) ) $mkl_profile['family'] = $profile['family'];
					if ( ! empty( $profile['size_multiplier'] ) ) $mkl_profile['size_multiplier'] = $profile['size_multiplier'];
				}
				$profile = $mkl_profile;
				update_post_meta( $product_id, self::PROFILE_META_KEY, wp_slash( wp_json_encode( $profile, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) );
			}
		}

		$product = wc_get_product( $product_id );
		if ( $profile && is_array( $profile ) ) {
			$p_name = $product ? $product->get_name() : ( $profile['device_name'] ?? "Device #{$product_id}" );
			$p_slug = $product ? $product->get_slug() : ( $profile['device_slug'] ?? '' );
			$cats = $product ? wp_get_post_terms( $product_id, 'product_cat', [ 'fields' => 'names' ] ) : [];

			// Guarantee essential product identity and price fields are always populated
			$profile['product_id'] = $product_id;
			if ( empty( $profile['device_name'] ) ) {
				$profile['device_name'] = $p_name;
			}
			if ( empty( $profile['device_slug'] ) ) {
				$profile['device_slug'] = $p_slug;
			}
			if ( empty( $profile['category'] ) ) {
				$profile['category'] = ! empty( $cats[0] ) ? $cats[0] : 'General';
			}
			if ( empty( $profile['currency'] ) ) {
				$profile['currency'] = get_woocommerce_currency();
			}
			if ( ! isset( $profile['base_price'] ) || (float) $profile['base_price'] <= 0 ) {
				$profile['base_price'] = self::get_product_base_price( $product );
			}

			if ( $product ) {
				$profile['status'] = $product->get_status();

				$fam = $profile['family'] ?? '';
				$mult = isset( $profile['size_multiplier'] ) ? (float) $profile['size_multiplier'] : 0;
				$inferred = self::infer_device_family( $p_name, $p_slug, $cats );

				$needs_save = false;
				if ( empty( $fam ) || ( $fam === 'phone' && $inferred['family'] !== 'phone' ) ) {
					$fam = $inferred['family'];
					$mult = $inferred['size_multiplier'];
					$profile['family'] = $fam;
					$profile['size_multiplier'] = $mult;
					$needs_save = true;
				} elseif ( in_array( $fam, [ 'laptop', 'tablet', 'keyboard', 'console' ], true ) && ( $mult <= 1.0 || in_array( $mult, [ 2.5, 1.8 ], true ) ) ) {
					$mult = 2.0;
					$profile['size_multiplier'] = 2.0;
					$needs_save = true;
				} elseif ( $fam === 'foldable' && $mult <= 1.0 ) {
					$mult = 1.3;
					$profile['size_multiplier'] = 1.3;
					$needs_save = true;
				}

				// Auto-heal missing identity or base_price in persistent metadata
				if ( is_array( $modern_profile ) && ( empty( $modern_profile['product_id'] ) || empty( $modern_profile['device_name'] ) || empty( $modern_profile['base_price'] ) ) ) {
					$needs_save = true;
				}

				if ( $needs_save && ! empty( $modern_profile ) ) {
					update_post_meta( $product_id, self::PROFILE_META_KEY, wp_slash( wp_json_encode( $profile, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) );
					update_post_meta( $product_id, '_device_family', $fam );
					update_post_meta( $product_id, '_size_multiplier', $mult );
				}
				$cleaned_variants = self::sanitize_variants( $profile['variants'] ?? [], $fam, $p_name ?? '', $p_slug ?? '' );
				if ( count( $profile['variants'] ?? [] ) !== count( $cleaned_variants ) ) {
					$profile['variants'] = $cleaned_variants;
					if ( ! empty( $modern_profile ) ) {
						update_post_meta( $product_id, self::PROFILE_META_KEY, wp_slash( wp_json_encode( $profile, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) );
					}
				} else {
					$profile['variants'] = $cleaned_variants;
				}
			}
			$profile['presets']  = isset( $profile['presets'] ) && is_array( $profile['presets'] ) ? $profile['presets'] : [];
			if ( ! empty( $profile['coverage_and_cutouts'] ) && is_array( $profile['coverage_and_cutouts'] ) ) {
				$dev_fam = $profile['family'] ?? '';
				$cur_cov = $profile['coverage_and_cutouts']['coverage_type'] ?? '';

				if ( in_array( $dev_fam, [ 'laptop', 'macbook', 'tablet', 'ipad', 'console', 'audio', 'charger', 'keyboard' ], true ) ) {
					$profile['coverage_and_cutouts']['coverage_type'] = 'none';
					$profile['coverage_and_cutouts']['has_model_cut'] = false;
					$profile['coverage_and_cutouts']['model_360_extra_price'] = 0;
				} elseif ( $dev_fam === 'foldable' ) {
					if ( $cur_cov !== 'none' && $cur_cov !== 'model_cut_only' ) {
						$profile['coverage_and_cutouts']['coverage_type'] = 'model_cut_only';
						$profile['coverage_and_cutouts']['has_model_cut'] = true;
						$needs_save = true;
					}
					if ( ! empty( $profile['coverage_and_cutouts']['model_360_extra_price'] ) ) {
						$profile['coverage_and_cutouts']['model_360_extra_price'] = 0;
						$needs_save = true;
					}
					if ( $needs_save && ! empty( $modern_profile ) ) {
						update_post_meta( $product_id, self::PROFILE_META_KEY, wp_slash( wp_json_encode( $profile, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) );
					}
				} else {
					if ( $cur_cov === 'none' || $cur_cov === 'model_cut_only' ) {
						$profile['coverage_and_cutouts']['model_360_extra_price'] = 0;
					} elseif ( ! isset( $profile['coverage_and_cutouts']['model_360_extra_price'] ) || ! is_numeric( $profile['coverage_and_cutouts']['model_360_extra_price'] ) ) {
						$profile['coverage_and_cutouts']['model_360_extra_price'] = 40000;
					}

					// Default phone coverage only if coverage_type is missing/unset entirely (honor explicit 'none')
					if ( $dev_fam === 'phone' && ! isset( $profile['coverage_and_cutouts']['coverage_type'] ) ) {
						$profile['coverage_and_cutouts']['coverage_type'] = 'model_cut_and_360';
						$profile['coverage_and_cutouts']['has_model_cut'] = true;
						$profile['coverage_and_cutouts']['model_360_extra_price'] = 40000;
						if ( ! empty( $modern_profile ) ) {
							update_post_meta( $product_id, self::PROFILE_META_KEY, wp_slash( wp_json_encode( $profile, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) );
						}
					}
				}
			}

			// Ensure foldables and laptops default to directional shading disabled
			if ( in_array( $profile['family'] ?? '', [ 'foldable', 'laptop' ], true ) && ! empty( $profile['views'] ) && is_array( $profile['views'] ) ) {
				$views_updated = false;
				foreach ( $profile['views'] as &$v ) {
					if ( is_array( $v ) && ( ! isset( $v['generated_shadow']['enabled'] ) || $v['generated_shadow']['enabled'] !== false ) ) {
						$v['generated_shadow'] = [ 'enabled' => false ];
						$views_updated = true;
					}
				}
				unset( $v );
				if ( $views_updated && ! empty( $modern_profile ) ) {
					update_post_meta( $product_id, self::PROFILE_META_KEY, wp_slash( wp_json_encode( $profile, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) );
				}
			}

			// Ensure selector layers (Series, Connectivity, Version) are strictly variants, never skin layers
			if ( ! empty( $profile['layers'] ) && is_array( $profile['layers'] ) ) {
				$layers_modified = false;
				$pruned_layers = [];
				foreach ( $profile['layers'] as $l ) {
					$l_id = strtolower( $l['id'] ?? '' );
					$l_name = strtolower( $l['name'] ?? '' );
					$is_selector_layer = in_array( $l_id, [ 'series', 'connectivity', 'version' ], true )
						|| preg_match( '/\b(series|connectivity|version)\b/i', $l_name );

					if ( $is_selector_layer ) {
						$layers_modified = true;
						$already_in_variants = false;
						if ( ! empty( $profile['variants'] ) && is_array( $profile['variants'] ) ) {
							foreach ( $profile['variants'] as $v ) {
								if ( strtolower( $v['id'] ?? '' ) === $l_id || strtolower( $v['name'] ?? '' ) === $l_name ) {
									$already_in_variants = true;
									break;
								}
							}
						}
						if ( ! $already_in_variants ) {
							if ( ! isset( $profile['variants'] ) || ! is_array( $profile['variants'] ) ) {
								$profile['variants'] = [];
							}
							$opts = [];
							if ( ! empty( $l['allowed_finishes'] ) && is_array( $l['allowed_finishes'] ) ) {
								foreach ( $l['allowed_finishes'] as $f_name ) {
									$opts[] = [
										'id'         => sanitize_title( $f_name ),
										'name'       => $f_name,
										'price_diff' => 0,
									];
								}
							}
							$profile['variants'][] = [
								'id'      => $l['id'] ?? sanitize_title( $l['name'] ?? 'variant' ),
								'name'    => $l['name'] ?? 'Variant',
								'options' => $opts,
							];
						}
					} else {
						$pruned_layers[] = $l;
					}
				}
				$profile['layers'] = $pruned_layers;

				// Ensure primary layers never carry extra_price (the base skin is already covered by base_price)
				foreach ( $profile['layers'] as $idx => &$l ) {
					$is_primary = ( isset( $l['group'] ) && $l['group'] === 'primary' )
						|| ( isset( $l['id'] ) && in_array( $l['id'], [ 'back', 'back-skin', 'device', 'main' ], true ) )
						|| ( isset( $l['name'] ) && preg_match( '/\b(back|top lid|body|base|full)\b/i', $l['name'] ) )
						|| ( $idx === 0 && ! in_array( $l['id'] ?? '', [ 'series', 'version', 'connectivity', 'model' ], true ) && ! preg_match( '/\b(series|version|connectivity|model)\b/i', $l['name'] ?? '' ) );
					if ( $is_primary ) {
						if ( empty( $l['group'] ) || $l['group'] !== 'primary' ) {
							$l['group'] = 'primary';
							$layers_modified = true;
						}
						if ( ! empty( $l['extra_price'] ) ) {
							$l['extra_price'] = 0;
							$layers_modified = true;
						}
					}
				}
				unset( $l );

				// Auto-heal phone accents from legacy 40000 to 35000
				$dev_fam = $profile['family'] ?? '';
				if ( $dev_fam === 'phone' || $dev_fam === 'foldable' ) {
					foreach ( $profile['layers'] as &$l ) {
						$l_id = strtolower( $l['id'] ?? '' );
						$l_name = strtolower( $l['name'] ?? '' );
						if ( ( $l_id === 'accents' || strpos( $l_name, 'accent' ) !== false ) && (float) ( $l['extra_price'] ?? 0 ) == 40000 ) {
							$l['extra_price'] = 35000;
							$layers_modified = true;
						}
					}
					unset( $l );
				}

				// Auto-heal tablet / iPad sides and accents from 0 to 50000
				if ( $dev_fam === 'tablet' || stripos( $profile['category'] ?? '', 'ipad' ) !== false || stripos( $profile['device_name'] ?? '', 'ipad' ) !== false ) {
					foreach ( $profile['layers'] as &$l ) {
						$l_id = strtolower( $l['id'] ?? '' );
						$l_name = strtolower( $l['name'] ?? '' );
						if ( ( $l_id === 'sides' || $l_id === 'side' || strpos( $l_name, 'side' ) !== false ) && (float) ( $l['extra_price'] ?? 0 ) == 0 ) {
							$l['extra_price'] = 50000;
							$layers_modified = true;
						}
						if ( ( $l_id === 'accents' || strpos( $l_name, 'accent' ) !== false ) && (float) ( $l['extra_price'] ?? 0 ) == 0 ) {
							$l['extra_price'] = 50000;
							$layers_modified = true;
						}
					}
					unset( $l );
				}

				if ( $layers_modified && ! empty( $modern_profile ) ) {
					update_post_meta( $product_id, self::PROFILE_META_KEY, wp_slash( wp_json_encode( $profile, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) );
				}
			}
		}

		if ( is_array( $profile ) ) {
			$profile['product_id'] = (int) ( $profile['product_id'] ?? $product_id );
			$profile['base_price'] = (float) ( $profile['base_price'] ?? self::get_product_base_price( $product ) );
			if ( empty( $profile['device_name'] ) && $product ) {
				$profile['device_name'] = $product->get_name();
			}
			if ( empty( $profile['device_slug'] ) && $product ) {
				$profile['device_slug'] = $product->get_slug();
			}
			if ( empty( $profile['currency'] ) ) {
				$profile['currency'] = get_woocommerce_currency();
			}
			if ( empty( $profile['marketplace_image_settings'] ) ) {
				$saved_mp_settings = get_post_meta( $product_id, '_exacoat_marketplace_image_settings', true );
				if ( is_string( $saved_mp_settings ) && ! empty( $saved_mp_settings ) ) {
					$decoded_mp = json_decode( $saved_mp_settings, true );
					if ( is_array( $decoded_mp ) ) {
						$profile['marketplace_image_settings'] = $decoded_mp;
					}
				} elseif ( is_array( $saved_mp_settings ) ) {
					$profile['marketplace_image_settings'] = $saved_mp_settings;
				}
			}
		}

		return rest_ensure_response( [
			'success'        => true,
			'profile'        => self::decode_entities( $profile ),
			'finishes'       => self::get_finishes(),
			'groups'         => self::get_finish_groups(),
			'group_settings' => self::get_finish_group_settings(),
			'presets'        => self::get_configurator_presets(),
			'surcharge_tiers'=> self::get_surcharge_tiers(),
		] );
	}

	/**
	 * REST Endpoint to save per-device marketplace image generator position & settings
	 */
	public static function rest_save_marketplace_settings( WP_REST_Request $request ): WP_REST_Response {
		$params = $request->get_json_params() ?: $request->get_params();
		$product_id = (int) ( $params['product_id'] ?? $params['id'] ?? $request->get_param( 'product_id' ) ?? 0 );

		if ( ! $product_id && ! empty( $params['device_slug'] ) ) {
			$slug = sanitize_title( (string) $params['device_slug'] );
			$post = get_page_by_path( $slug, OBJECT, 'product' );
			if ( $post ) {
				$product_id = (int) $post->ID;
			}
		}

		if ( ! $product_id || ! get_post( $product_id ) ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => 'Valid product_id is required' ], 400 );
		}

		$raw_settings = is_array( $params['settings'] ?? null ) ? $params['settings'] : ( is_array( $params['marketplace_image_settings'] ?? null ) ? $params['marketplace_image_settings'] : [] );

		$clean_settings = [
			'cover_scale'            => isset( $raw_settings['cover_scale'] ) ? (float) $raw_settings['cover_scale'] : 1.0,
			'cover_offset_x'         => isset( $raw_settings['cover_offset_x'] ) ? (int) $raw_settings['cover_offset_x'] : 0,
			'cover_offset_y'         => isset( $raw_settings['cover_offset_y'] ) ? (int) $raw_settings['cover_offset_y'] : 110,
			'variant_scale'          => isset( $raw_settings['variant_scale'] ) ? (float) $raw_settings['variant_scale'] : 0.75,
			'variant_offset_x'       => isset( $raw_settings['variant_offset_x'] ) ? (int) $raw_settings['variant_offset_x'] : 0,
			'variant_offset_y'       => isset( $raw_settings['variant_offset_y'] ) ? (int) $raw_settings['variant_offset_y'] : 80,
			'headline_text'          => isset( $raw_settings['headline_text'] ) ? sanitize_textarea_field( (string) $raw_settings['headline_text'] ) : '',
			'primary_skin_id'        => isset( $raw_settings['primary_skin_id'] ) ? sanitize_text_field( (string) $raw_settings['primary_skin_id'] ) : '',
			'primary_top_right_text' => isset( $raw_settings['primary_top_right_text'] ) ? sanitize_text_field( (string) $raw_settings['primary_top_right_text'] ) : '20+ SKINS SELECTION',
			'selected_view_id'       => isset( $raw_settings['selected_view_id'] ) ? sanitize_text_field( (string) $raw_settings['selected_view_id'] ) : '',
			'active_color_id'        => isset( $raw_settings['active_color_id'] ) ? sanitize_text_field( (string) $raw_settings['active_color_id'] ) : '',
			'active_layer_ids'       => is_array( $raw_settings['active_layer_ids'] ?? null ) ? array_values( array_map( 'sanitize_text_field', $raw_settings['active_layer_ids'] ) ) : [],
			'logo_cutout'            => isset( $raw_settings['logo_cutout'] ) ? (bool) $raw_settings['logo_cutout'] : true,
			'pencil_cutout'          => isset( $raw_settings['pencil_cutout'] ) ? (bool) $raw_settings['pencil_cutout'] : true,
			'updated_at'             => current_time( 'mysql' ),
		];

		update_post_meta( $product_id, '_exacoat_marketplace_image_settings', wp_slash( wp_json_encode( $clean_settings, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) );

		$existing_raw = get_post_meta( $product_id, self::PROFILE_META_KEY, true );
		$existing_profile = self::parse_meta_json( $existing_raw );
		if ( is_array( $existing_profile ) && ! empty( $existing_profile ) ) {
			$existing_profile['marketplace_image_settings'] = $clean_settings;
			update_post_meta( $product_id, self::PROFILE_META_KEY, wp_slash( wp_json_encode( $existing_profile, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) );
		}

		return rest_ensure_response( [
			'success'                    => true,
			'product_id'                 => $product_id,
			'marketplace_image_settings' => $clean_settings,
		] );
	}

	/**
	 * REST Endpoint to save/update a product configurator profile
	 */
	public static function rest_save_product_configurator( WP_REST_Request $request ): WP_REST_Response {
		$params = $request->get_json_params() ?: $request->get_params();
		$product_id = (int) ( $params['product_id'] ?? $params['id'] ?? $request->get_param( 'product_id' ) ?? $request->get_param( 'id' ) ?? 0 );

		if ( ! $product_id || ! get_post( $product_id ) ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => 'Valid product_id is required' ], 400 );
		}

		$raw_coverage = is_array( $params['coverage_and_cutouts'] ?? null ) ? $params['coverage_and_cutouts'] : null;
		if ( is_array( $raw_coverage ) ) {
			if ( ( $params['family'] ?? '' ) === 'foldable' ) {
				$raw_coverage['coverage_type'] = ( ( $raw_coverage['coverage_type'] ?? '' ) === 'none' ) ? 'none' : 'model_cut_only';
				$raw_coverage['has_model_cut'] = ( $raw_coverage['coverage_type'] !== 'none' );
				$raw_coverage['model_360_extra_price'] = 0;
			} else {
				if ( ! isset( $raw_coverage['model_360_extra_price'] ) || ! is_numeric( $raw_coverage['model_360_extra_price'] ) ) {
					$raw_coverage['model_360_extra_price'] = 40000;
				} else {
					$raw_coverage['model_360_extra_price'] = (float) $raw_coverage['model_360_extra_price'];
				}
			}
			if ( ! empty( $raw_coverage['model_cut_mask_url'] ) && empty( $raw_coverage['model_cutout_url'] ) ) {
				$raw_coverage['model_cutout_url'] = $raw_coverage['model_cut_mask_url'];
			} elseif ( ! empty( $raw_coverage['model_cutout_url'] ) && empty( $raw_coverage['model_cut_mask_url'] ) ) {
				$raw_coverage['model_cut_mask_url'] = $raw_coverage['model_cutout_url'];
			} elseif ( isset( $raw_coverage['model_cut_mask_url'] ) && empty( $raw_coverage['model_cut_mask_url'] ) ) {
				$raw_coverage['model_cutout_url'] = '';
				$raw_coverage['model_cut_mask_url'] = '';
				$raw_coverage['has_model_cut'] = false;
			}
			if ( isset( $raw_coverage['coverage_type'] ) && $raw_coverage['coverage_type'] === 'none' ) {
				$raw_coverage['has_model_cut'] = false;
			}
		}

		$post_obj = get_post( $product_id );
		$wc_product = wc_get_product( $product_id );
		$dev_slug = ! empty( $params['device_slug'] ) ? sanitize_title( $params['device_slug'] ) : ( $post_obj ? $post_obj->post_name : '' );
		$dev_name = ! empty( $params['device_name'] ) ? sanitize_text_field( self::decode_entities( $params['device_name'] ) ) : ( $post_obj ? self::decode_entities( $post_obj->post_title ) : '' );

		$raw_price = isset( $params['base_price'] ) ? (float) $params['base_price'] : 0;
		if ( $raw_price <= 0 && $wc_product ) {
			$raw_price = self::get_product_base_price( $wc_product );
		}

		$raw_views = is_array( $params['views'] ?? null ) ? $params['views'] : [];
		if ( in_array( $params['family'] ?? '', [ 'foldable', 'laptop' ], true ) ) {
			foreach ( $raw_views as &$v ) {
				if ( is_array( $v ) ) {
					$v['generated_shadow'] = [ 'enabled' => false ];
				}
			}
			unset( $v );
		}

		$raw_presets = is_array( $params['presets'] ?? null ) ? self::sanitize_presets( $params['presets'] ) : [];
		if ( in_array( $params['family'] ?? '', [ 'foldable', 'laptop' ], true ) ) {
			foreach ( $raw_presets as &$p ) {
				if ( is_array( $p ) && isset( $p['coverage'] ) && $p['coverage'] === 'model_360' ) {
					$p['coverage'] = 'model_cut';
				}
			}
			unset( $p );
		}

		$existing_mp_settings = null;
		if ( ! empty( $params['marketplace_image_settings'] ) && is_array( $params['marketplace_image_settings'] ) ) {
			$existing_mp_settings = $params['marketplace_image_settings'];
		} else {
			$saved_mp_raw = get_post_meta( $product_id, '_exacoat_marketplace_image_settings', true );
			if ( is_string( $saved_mp_raw ) && ! empty( $saved_mp_raw ) ) {
				$decoded = json_decode( $saved_mp_raw, true );
				if ( is_array( $decoded ) ) {
					$existing_mp_settings = $decoded;
				}
			} elseif ( is_array( $saved_mp_raw ) ) {
				$existing_mp_settings = $saved_mp_raw;
			}
		}

		$profile = [
			'product_id'           => $product_id,
			'device_slug'          => $dev_slug,
			'device_name'          => $dev_name,
			'category'             => sanitize_text_field( $params['category'] ?? '' ),
			'family'               => sanitize_text_field( $params['family'] ?? 'phone' ),
			'base_price'           => $raw_price,
			'currency'             => sanitize_text_field( $params['currency'] ?? 'IDR' ),
			'size_multiplier'      => (float) ( $params['size_multiplier'] ?? 1.0 ),
			'texture_scale'        => isset( $params['texture_scale'] ) ? (float) $params['texture_scale'] : 1.0,
			'configurator_version' => in_array( $params['configurator_version'] ?? '', [ 'v1', 'v2' ], true ) ? $params['configurator_version'] : 'v2',
			'device_colors'        => is_array( $params['device_colors'] ?? null ) ? $params['device_colors'] : [],
			'views'                => $raw_views,
			'layers'               => is_array( $params['layers'] ?? null ) ? $params['layers'] : [],
			'variants'             => self::sanitize_variants( $params['variants'] ?? [], $params['family'] ?? 'phone', $dev_name, $dev_slug ),
			'coverage_and_cutouts' => $raw_coverage,
			'presets'              => $raw_presets,
			'marketplace_image_settings' => $existing_mp_settings,
			'updated_at'           => current_time( 'mysql' ),
		];

		// Ensure selector layers (Series, Connectivity, Version) are strictly variants, never skin layers
		if ( ! empty( $profile['layers'] ) && is_array( $profile['layers'] ) ) {
			$pruned_layers = [];
			foreach ( $profile['layers'] as $l ) {
				$l_id = strtolower( $l['id'] ?? '' );
				$l_name = strtolower( $l['name'] ?? '' );
				$is_selector_layer = in_array( $l_id, [ 'series', 'connectivity', 'version' ], true )
					|| preg_match( '/\b(series|connectivity|version)\b/i', $l_name );

				if ( $is_selector_layer ) {
					$already_in_variants = false;
					if ( ! empty( $profile['variants'] ) && is_array( $profile['variants'] ) ) {
						foreach ( $profile['variants'] as $v ) {
							if ( strtolower( $v['id'] ?? '' ) === $l_id || strtolower( $v['name'] ?? '' ) === $l_name ) {
								$already_in_variants = true;
								break;
							}
						}
					}
					if ( ! $already_in_variants ) {
						if ( ! isset( $profile['variants'] ) || ! is_array( $profile['variants'] ) ) {
							$profile['variants'] = [];
						}
						$opts = [];
						if ( ! empty( $l['allowed_finishes'] ) && is_array( $l['allowed_finishes'] ) ) {
							foreach ( $l['allowed_finishes'] as $f_name ) {
								$opts[] = [
									'id'         => sanitize_title( $f_name ),
									'name'       => $f_name,
									'price_diff' => 0,
								];
							}
						}
						$profile['variants'][] = [
							'id'      => $l['id'] ?? sanitize_title( $l['name'] ?? 'variant' ),
							'name'    => $l['name'] ?? 'Variant',
							'options' => $opts,
						];
					}
				} else {
					$pruned_layers[] = $l;
				}
			}
			$profile['layers'] = $pruned_layers;

			// Ensure primary layers never carry extra_price on the layer itself (covered by base_price)
			foreach ( $profile['layers'] as $idx => &$layer ) {
				$is_primary = ( isset( $layer['group'] ) && $layer['group'] === 'primary' )
					|| ( isset( $layer['id'] ) && in_array( $layer['id'], [ 'back', 'back-skin', 'device', 'main' ], true ) )
					|| ( isset( $layer['name'] ) && preg_match( '/\b(back|top lid|body|base|full)\b/i', $layer['name'] ) )
					|| ( $idx === 0 && ! in_array( $layer['id'] ?? '', [ 'series', 'version', 'connectivity', 'model' ], true ) && ! preg_match( '/\b(series|version|connectivity|model)\b/i', $layer['name'] ?? '' ) );
				if ( $is_primary ) {
					$layer['group'] = 'primary';
					$layer['extra_price'] = 0;
				}
			}
			unset( $layer );

			// Auto-heal phone accents from legacy 40000 to 35000
			$dev_fam = $profile['family'] ?? '';
			if ( $dev_fam === 'phone' || $dev_fam === 'foldable' ) {
				foreach ( $profile['layers'] as &$layer ) {
					$l_id = strtolower( $layer['id'] ?? '' );
					$l_name = strtolower( $layer['name'] ?? '' );
					if ( ( $l_id === 'accents' || strpos( $l_name, 'accent' ) !== false ) && (float) ( $layer['extra_price'] ?? 0 ) == 40000 ) {
						$layer['extra_price'] = 35000;
					}
				}
				unset( $layer );
			}

			// Auto-heal tablet / iPad sides and accents from 0 to 50000
			if ( $dev_fam === 'tablet' || stripos( $profile['category'] ?? '', 'ipad' ) !== false || stripos( $profile['device_name'] ?? '', 'ipad' ) !== false ) {
				foreach ( $profile['layers'] as &$layer ) {
					$l_id = strtolower( $layer['id'] ?? '' );
					$l_name = strtolower( $layer['name'] ?? '' );
					if ( ( $l_id === 'sides' || $l_id === 'side' || strpos( $l_name, 'side' ) !== false ) && (float) ( $layer['extra_price'] ?? 0 ) == 0 ) {
						$layer['extra_price'] = 50000;
					}
					if ( ( $l_id === 'accents' || strpos( $l_name, 'accent' ) !== false ) && (float) ( $layer['extra_price'] ?? 0 ) == 0 ) {
						$layer['extra_price'] = 50000;
					}
				}
				unset( $layer );
			}
		}

		// For v2 profiles, prune legacy per-layer shading/shadow properties so universal view-level shading takes precedence
		if ( $profile['configurator_version'] === 'v2' && ! empty( $profile['layers'] ) ) {
			foreach ( $profile['layers'] as &$layer ) {
				if ( ! empty( $layer['assets_by_view'] ) && is_array( $layer['assets_by_view'] ) ) {
					foreach ( $layer['assets_by_view'] as &$view_asset ) {
						unset( $view_asset['shadow_png_url'], $view_asset['highlight_png_url'], $view_asset['shading_image_url'] );
					}
				}
			}
			unset( $layer );
		}

		// Recursively sanitize corrupted unicode degree sequences (e.g. 360u00b0 -> 360°)
		array_walk_recursive( $profile, function( &$val ) {
			if ( is_string( $val ) ) {
				$val = str_replace( [ '360u00b0', '360\\u00b0' ], '360°', $val );
			}
		} );

		// Recursively decode entities to prevent saving raw entities (&amp;, &#038;, etc.) into database
		$profile = self::decode_entities( $profile );

		// Use wp_slash and JSON_UNESCAPED_UNICODE so WordPress update_metadata does not strip quotes or slashes, and degree signs (°) are preserved directly
		$json_str = wp_json_encode( $profile, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		update_post_meta( $product_id, self::PROFILE_META_KEY, wp_slash( $json_str ) );
		update_post_meta( $product_id, self::CONFIGURATOR_FLAG_META_KEY, 'yes' );
		update_post_meta( $product_id, '_configurator_version', $profile['configurator_version'] );
		update_post_meta( $product_id, '_device_family', $profile['family'] );
		update_post_meta( $product_id, '_size_multiplier', $profile['size_multiplier'] );

		// When saving a modern v2 profile, clean up conflicting obsolete MKL layers and content
		// so legacy fallback on duplicated products never shadows the v2 profile
		if ( $profile['configurator_version'] === 'v2' ) {
			delete_post_meta( $product_id, '_mkl_product_configurator_layers' );
			delete_post_meta( $product_id, '_mkl_product_configurator_content' );
		}

		// Sync WooCommerce product price with configurator base_price
		// Require base_price > 0 to prevent accidental zero wipes
		if ( isset( $params['base_price'] ) && (float) $params['base_price'] > 0 ) {
			$product = wc_get_product( $product_id );
			if ( $product ) {
				$new_price = (float) $params['base_price'];
				$product->set_regular_price( $new_price );
				$product->set_price( $new_price );
				$product->save();
				update_post_meta( $product_id, '_regular_price', $new_price );
				update_post_meta( $product_id, '_price', $new_price );
			}
		}

		// Sync product status (publish / draft) if provided
		if ( ! empty( $params['status'] ) && in_array( $params['status'], [ 'publish', 'draft' ], true ) ) {
			$product = wc_get_product( $product_id );
			if ( $product ) {
				$product->set_status( $params['status'] );
				$product->save();
			}
			wp_update_post( [
				'ID'          => $product_id,
				'post_status' => $params['status'],
			] );
			$profile['status'] = $params['status'];
		}

		if ( class_exists( 'Exacoat_Logger' ) ) {
			Exacoat_Logger::log( 'info', 'configurator', "Configurator profile updated for Product #{$product_id} ({$profile['device_name']})" );
		}

		// Trigger storefront Next.js ISR revalidation and Cloudflare cache purge
		$reval_results = self::trigger_storefront_revalidation( [
			'slug'     => $profile['device_slug'] ?? '',
			'category' => $profile['category'] ?? '',
		] );

		return rest_ensure_response( [
			'success'      => true,
			'message'      => "Configurator profile saved successfully.",
			'profile'      => $profile,
			'revalidation' => $reval_results,
		] );
	}

	/**
	 * REST Endpoint to batch migrate all products from MKL to Modern Profile
	 */
	public static function rest_batch_migrate( WP_REST_Request $request ): WP_REST_Response {
		$args = [
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'fields'         => 'ids',
		];

		$product_ids = get_posts( $args );
		$migrated_count = 0;
		$skipped_count = 0;

		foreach ( $product_ids as $pid ) {
			$layers_raw = get_post_meta( $pid, '_mkl_product_configurator_layers', true );
			$is_mkl = get_post_meta( $pid, '_mkl_pc__is_configurable', true ) === 'yes';

			if ( $is_mkl || ! empty( $layers_raw ) ) {
				$profile = self::convert_mkl_to_profile( $pid );
				if ( ! empty( $profile['layers'] ) ) {
					update_post_meta( $pid, self::PROFILE_META_KEY, wp_slash( wp_json_encode( $profile, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) );
					$migrated_count++;
					continue;
				}
			}
			$skipped_count++;
		}

		return rest_ensure_response( [
			'success'        => true,
			'message'        => "Batch migration completed: {$migrated_count} products converted to modern configurator profiles.",
			'migrated_count' => $migrated_count,
			'skipped_count'  => $skipped_count,
			'total_scanned'  => count( $product_ids ),
		] );
	}

	/**
	 * REST Endpoint: Auto-detect and sync device families and size multipliers catalog-wide
	 */
	public static function rest_sync_device_families( WP_REST_Request $request ): WP_REST_Response {
		$args = [
			'post_type'      => 'product',
			'post_status'    => [ 'publish', 'draft' ],
			'posts_per_page' => -1,
			'fields'         => 'ids',
		];

		$product_ids = get_posts( $args );
		$updated_devices = [];
		$total_scanned = 0;

		foreach ( $product_ids as $pid ) {
			$product = wc_get_product( $pid );
			if ( ! $product ) {
				continue;
			}

			$p_name = $product->get_name();
			$p_slug = $product->get_slug();
			$cats = wp_get_post_terms( $pid, 'product_cat', [ 'fields' => 'names' ] );

			$modern_profile = get_post_meta( $pid, self::PROFILE_META_KEY, true );
			if ( empty( $modern_profile ) ) {
				continue;
			}

			$total_scanned++;
			$profile_data = is_array( $modern_profile ) ? $modern_profile : json_decode( $modern_profile, true );
			if ( ! is_array( $profile_data ) ) {
				$profile_data = json_decode( wp_unslash( $modern_profile ), true );
			}
			if ( ! is_array( $profile_data ) ) {
				continue;
			}

			$current_fam = $profile_data['family'] ?? '';
			$current_mult = isset( $profile_data['size_multiplier'] ) ? (float) $profile_data['size_multiplier'] : 0;
			$inferred = self::infer_device_family( $p_name, $p_slug, $cats );

			$needs_save = false;
			$next_fam = $current_fam;
			$next_mult = $current_mult;

			if ( empty( $current_fam ) || ( $current_fam === 'phone' && $inferred['family'] !== 'phone' ) ) {
				$next_fam = $inferred['family'];
				$next_mult = $inferred['size_multiplier'];
				$needs_save = true;
			} elseif ( in_array( $current_fam, [ 'laptop', 'tablet', 'keyboard', 'console' ], true ) && ( $current_mult <= 1.0 || in_array( $current_mult, [ 2.5, 1.8 ], true ) ) ) {
				$next_mult = 2.0;
				$needs_save = true;
			} elseif ( $current_fam === 'foldable' && $current_mult <= 1.0 ) {
				$next_mult = 1.3;
				$needs_save = true;
			}

			// Prune invalid phone model variants catalog-wide
			$existing_variants = $profile_data['variants'] ?? [];
			$cleaned_variants = self::sanitize_variants( $existing_variants, $next_fam, $p_name, $p_slug );
			if ( count( $existing_variants ) !== count( $cleaned_variants ) ) {
				$profile_data['variants'] = $cleaned_variants;
				$needs_save = true;
			}

			// Foldable coverage: strictly model_cut_only, no 360 wrap, no 360 price
			if ( $next_fam === 'foldable' ) {
				if ( ! isset( $profile_data['coverage_and_cutouts'] ) || ! is_array( $profile_data['coverage_and_cutouts'] ) ) {
					$profile_data['coverage_and_cutouts'] = [];
				}
				$cur_cov = $profile_data['coverage_and_cutouts']['coverage_type'] ?? '';
				if ( $cur_cov !== 'none' && $cur_cov !== 'model_cut_only' ) {
					$profile_data['coverage_and_cutouts']['coverage_type'] = 'model_cut_only';
					$profile_data['coverage_and_cutouts']['has_model_cut'] = true;
					$needs_save = true;
				}
				if ( ! empty( $profile_data['coverage_and_cutouts']['model_360_extra_price'] ) ) {
					$profile_data['coverage_and_cutouts']['model_360_extra_price'] = 0;
					$needs_save = true;
				}
			}

			// Foldables and laptops: disable directional shading
			if ( in_array( $next_fam, [ 'foldable', 'laptop' ], true ) && ! empty( $profile_data['views'] ) && is_array( $profile_data['views'] ) ) {
				foreach ( $profile_data['views'] as &$v ) {
					if ( is_array( $v ) && ( ! isset( $v['generated_shadow']['enabled'] ) || $v['generated_shadow']['enabled'] !== false ) ) {
						$v['generated_shadow'] = [ 'enabled' => false ];
						$needs_save = true;
					}
				}
				unset( $v );
			}

			if ( $needs_save ) {
				$profile_data['family'] = $next_fam;
				$profile_data['size_multiplier'] = $next_mult;
				$json_str = wp_json_encode( $profile_data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
				update_post_meta( $pid, self::PROFILE_META_KEY, wp_slash( $json_str ) );
				update_post_meta( $pid, '_device_family', $next_fam );
				update_post_meta( $pid, '_size_multiplier', $next_mult );

				$updated_devices[] = [
					'product_id'   => $pid,
					'name'         => $p_name,
					'old_family'   => $current_fam ?: 'phone',
					'new_family'   => $next_fam,
					'old_mult'     => $current_mult ?: 1.0,
					'new_mult'     => $next_mult,
				];
			}
		}

		return rest_ensure_response( [
			'success'         => true,
			'total_scanned'   => $total_scanned,
			'updated_count'   => count( $updated_devices ),
			'updated_devices' => $updated_devices,
			'message'         => 'Device families and size multipliers successfully synchronized catalog-wide.',
		] );
	}

	/**
	 * Enriches WooCommerce Product REST responses with configurator data
	 */
	/**
	 * REST Endpoint: Set WooCommerce product price and sync configurator profile base_price
	 */
	public static function rest_set_product_price( WP_REST_Request $request ): WP_REST_Response {
		$params = $request->get_json_params() ?: $request->get_params();
		$product_id = (int) ( $params['product_id'] ?? $params['id'] ?? $request->get_param( 'product_id' ) ?? $request->get_param( 'id' ) ?? 0 );
		$price = isset( $params['price'] ) ? (float) $params['price'] : null;

		if ( ! $product_id || $price === null || $price < 0 ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => 'Valid product_id and non-negative price are required' ], 400 );
		}

		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => 'Product not found' ], 404 );
		}

		$product->set_regular_price( $price );
		$product->set_price( $price );
		$product->save();

		update_post_meta( $product_id, '_regular_price', $price );
		update_post_meta( $product_id, '_price', $price );

		// Update base_price in profile metadata if present
		$meta = get_post_meta( $product_id, self::PROFILE_META_KEY, true );
		if ( ! empty( $meta ) ) {
			$profile = is_string( $meta ) ? json_decode( $meta, true ) : $meta;
			if ( is_array( $profile ) ) {
				$profile['base_price'] = $price;
				update_post_meta( $product_id, self::PROFILE_META_KEY, wp_slash( wp_json_encode( $profile, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) );
			}
		}

		if ( class_exists( 'Exacoat_Logger' ) ) {
			Exacoat_Logger::log( 'info', 'configurator', "Price updated to IDR {$price} for Product #{$product_id} ({$product->get_name()})" );
		}

		// Trigger storefront Next.js ISR revalidation and Cloudflare cache purge
		$reval_results = self::trigger_storefront_revalidation( [
			'slug' => $product->get_slug(),
		] );

		return rest_ensure_response( [
			'success'      => true,
			'product_id'   => $product_id,
			'price'        => $price,
			'message'      => "Price updated successfully to IDR " . number_format( $price, 0, ',', '.' ),
			'revalidation' => $reval_results,
		] );
	}

	/**
	 * REST Endpoint: Duplicate WooCommerce product and its configurator profile
	 */
	public static function rest_duplicate_product( WP_REST_Request $request ): WP_REST_Response {
		$params = $request->get_json_params() ?: $request->get_params();
		$source_id = (int) ( $params['source_product_id'] ?? 0 );
		$new_name = sanitize_text_field( $params['new_name'] ?? '' );
		$new_slug = sanitize_title( $params['new_slug'] ?? '' );
		$new_price = isset( $params['new_price'] ) ? (float) $params['new_price'] : null;
		$copy_configurator = ! empty( $params['copy_configurator'] );

		if ( ! $source_id ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => 'Valid source_product_id is required' ], 400 );
		}

		$source_product = wc_get_product( $source_id );
		if ( ! $source_product ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => 'Source product not found' ], 404 );
		}

		if ( empty( $new_name ) ) {
			$new_name = $source_product->get_name() . ' (Copy)';
		}

		if ( empty( $new_slug ) ) {
			$new_slug = sanitize_title( $new_name );
		}

		$short_desc = $source_product->get_short_description();
		$long_desc  = $source_product->get_description();
		$menu_order = (int) $source_product->get_menu_order();

		$new_product = null;
		if ( function_exists( 'wc_duplicate_product' ) ) {
			$new_product = wc_duplicate_product( $source_product );
		}

		if ( ! $new_product ) {
			// Fallback product creation
			$new_pid = wp_insert_post( [
				'post_title'   => $new_name,
				'post_name'    => $new_slug,
				'post_type'    => 'product',
				'post_status'  => 'draft',
				'post_content' => $long_desc,
				'post_excerpt' => $short_desc,
				'menu_order'   => $menu_order,
			] );

			if ( is_wp_error( $new_pid ) ) {
				return new WP_REST_Response( [ 'success' => false, 'message' => $new_pid->get_error_message() ], 500 );
			}

			$new_product = wc_get_product( $new_pid );
		}

		if ( ! $new_product ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => 'Failed creating duplicate product' ], 500 );
		}

		$new_pid = $new_product->get_id();
		$new_product->set_name( $new_name );
		$new_product->set_slug( $new_slug );
		// Status must strictly be draft
		$new_product->set_status( 'draft' );

		// Set descriptions and menu order
		if ( ! empty( $short_desc ) ) {
			$new_product->set_short_description( $short_desc );
		}
		if ( ! empty( $long_desc ) ) {
			$new_product->set_description( $long_desc );
		}
		$new_product->set_menu_order( $menu_order );

		// Duplicate Featured Image (_thumbnail_id)
		$source_thumb_id = (int) $source_product->get_image_id();
		if ( $source_thumb_id > 0 ) {
			$new_product->set_image_id( $source_thumb_id );
			update_post_meta( $new_pid, '_thumbnail_id', $source_thumb_id );
		}

		// Duplicate Product Gallery (_product_image_gallery)
		$source_gallery = $source_product->get_gallery_image_ids();
		if ( ! empty( $source_gallery ) ) {
			$new_product->set_gallery_image_ids( $source_gallery );
			update_post_meta( $new_pid, '_product_image_gallery', implode( ',', $source_gallery ) );
		}

		// Set price
		$price_to_set = ( $new_price !== null && $new_price > 0 ) ? $new_price : (float) $source_product->get_price();
		if ( $price_to_set > 0 ) {
			$new_product->set_regular_price( $price_to_set );
			$new_product->set_price( $price_to_set );
		}

		// Set catalog visibility
		$new_product->set_catalog_visibility( $source_product->get_catalog_visibility() );

		$new_product->save();

		// Explicitly ensure post status is draft in wp_posts
		wp_update_post( [
			'ID'           => $new_pid,
			'post_status'  => 'draft',
			'post_excerpt' => $short_desc,
			'post_content' => $long_desc,
			'menu_order'   => $menu_order,
		] );

		update_post_meta( $new_pid, '_regular_price', $price_to_set );
		update_post_meta( $new_pid, '_price', $price_to_set );

		// Copy Categories
		$source_cats = wp_get_post_terms( $source_id, 'product_cat', [ 'fields' => 'ids' ] );
		if ( ! empty( $source_cats ) && ! is_wp_error( $source_cats ) ) {
			wp_set_post_terms( $new_pid, $source_cats, 'product_cat' );
		}

		// Copy Tags
		$source_tags = wp_get_post_terms( $source_id, 'product_tag', [ 'fields' => 'ids' ] );
		if ( ! empty( $source_tags ) && ! is_wp_error( $source_tags ) ) {
			wp_set_post_terms( $new_pid, $source_tags, 'product_tag' );
		}

		// Copy Configurator Post Meta Flags & Family
		$is_cfg = get_post_meta( $source_id, self::CONFIGURATOR_FLAG_META_KEY, true );
		update_post_meta( $new_pid, self::CONFIGURATOR_FLAG_META_KEY, ! empty( $is_cfg ) ? $is_cfg : 'yes' );

		$family = get_post_meta( $source_id, '_device_family', true );
		if ( $family ) {
			update_post_meta( $new_pid, '_device_family', $family );
		}
		$size_mult = get_post_meta( $source_id, '_size_multiplier', true );
		if ( $size_mult ) {
			update_post_meta( $new_pid, '_size_multiplier', $size_mult );
		}
		$cfg_ver = get_post_meta( $source_id, '_configurator_version', true );
		if ( $cfg_ver ) {
			update_post_meta( $new_pid, '_configurator_version', $cfg_ver );
		}

		// Clean audit stamps so duplicate product starts fresh as unaudited
		delete_post_meta( $new_pid, self::AUDIT_TIME_META_KEY );
		delete_post_meta( $new_pid, self::AUDIT_STATUS_META_KEY );
		delete_post_meta( $new_pid, self::AUDIT_ISSUES_META_KEY );

		// Copy Configurator Profile if requested
		if ( $copy_configurator ) {
			$source_profile_raw = get_post_meta( $source_id, self::PROFILE_META_KEY, true );
			if ( ! empty( $source_profile_raw ) ) {
				$profile = is_string( $source_profile_raw ) ? json_decode( $source_profile_raw, true ) : $source_profile_raw;
			} else {
				$profile = self::convert_mkl_to_profile( $source_id );
			}

			if ( is_array( $profile ) ) {
				$profile['product_id'] = $new_pid;
				$profile['device_name'] = $new_name;
				$profile['device_slug'] = $new_slug;
				$profile['status'] = 'draft';
				if ( $price_to_set > 0 ) {
					$profile['base_price'] = $price_to_set;
				}
				// Note: Always use wp_slash(wp_json_encode()) to prevent unslashing corruption
				update_post_meta( $new_pid, self::PROFILE_META_KEY, wp_slash( wp_json_encode( $profile, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) );
			}

			// Copy legacy MKL metadata for backward compatibility
			foreach ( [ '_mkl_product_configurator_angles', '_mkl_product_configurator_layers', '_mkl_product_configurator_content', '_mkl_pc__is_configurable' ] as $mkl_key ) {
				$mkl_val = get_post_meta( $source_id, $mkl_key, true );
				if ( ! empty( $mkl_val ) ) {
					update_post_meta( $new_pid, $mkl_key, $mkl_val );
				}
			}
		}

		if ( class_exists( 'Exacoat_Logger' ) ) {
			Exacoat_Logger::log( 'info', 'configurator', "Product duplicated: #{$source_id} to #{$new_pid} ({$new_name}) in draft status" );
		}

		// Trigger storefront Next.js ISR revalidation and Cloudflare cache purge
		$reval_results = self::trigger_storefront_revalidation( [
			'slug' => $new_slug,
		] );

		return rest_ensure_response( [
			'success'      => true,
			'product_id'   => $new_pid,
			'name'         => $new_name,
			'slug'         => $new_slug,
			'price'        => $price_to_set,
			'status'       => 'draft',
			'message'      => "Product duplicated successfully as draft #{$new_pid} ({$new_name})",
			'revalidation' => $reval_results,
		] );
	}

	/**
	 * Enriches WooCommerce Product REST responses with configurator data
	 */
	public static function enrich_wc_product_configurator_meta( WP_REST_Response $response, $product, WP_REST_Request $request ): WP_REST_Response {
		$data = $response->get_data();
		if ( ! is_array( $data ) || empty( $data['id'] ) ) {
			return $response;
		}

		$profile_raw = get_post_meta( $data['id'], self::PROFILE_META_KEY, true );
		if ( ! empty( $profile_raw ) ) {
			$profile = is_string( $profile_raw ) ? json_decode( $profile_raw, true ) : $profile_raw;
			$data['configurator_profile'] = self::decode_entities( $profile );
		}

		if ( ! empty( $data['name'] ) && is_string( $data['name'] ) ) {
			$data['name'] = self::decode_entities( $data['name'] );
		}

		$response->set_data( $data );
		return $response;
	}

	const ADDON_SCHEMAS_OPTION_KEY = 'exacoat_addon_schemas';

	public static function rest_get_addon_schemas( WP_REST_Request $request ): WP_REST_Response {
		$schemas = get_option( self::ADDON_SCHEMAS_OPTION_KEY, null );
		return new WP_REST_Response( [
			'success' => true,
			'schemas' => $schemas,
		], 200 );
	}

	public static function rest_save_addon_schemas( WP_REST_Request $request ): WP_REST_Response {
		$schemas = $request->get_param( 'schemas' );
		if ( empty( $schemas ) ) {
			return new WP_REST_Response( [
				'success' => false,
				'message' => 'Schema payload is required.',
			], 400 );
		}
		update_option( self::ADDON_SCHEMAS_OPTION_KEY, $schemas );
		return new WP_REST_Response( [
			'success' => true,
			'message' => 'Addon schemas updated successfully.',
		], 200 );
	}

	/**
	 * Sorts configurator addon layers so Back Skin / primary base layer appears on top.
	 */
	public static function sort_addon_layers( array $addons ): array {
		if ( count( $addons ) <= 1 ) {
			return $addons;
		}
		usort( $addons, function( $a, $b ) {
			$label_a = strtolower( trim( $a['label'] ?? ( $a['key'] ?? ( $a['name'] ?? '' ) ) ) );
			$label_b = strtolower( trim( $b['label'] ?? ( $b['key'] ?? ( $b['name'] ?? '' ) ) ) );

			$is_back_a = ( false !== strpos( $label_a, 'back' ) ) && ( false === strpos( $label_a, 'camera' ) ) && ( false === strpos( $label_a, 'glass' ) );
			$is_back_b = ( false !== strpos( $label_b, 'back' ) ) && ( false === strpos( $label_b, 'camera' ) ) && ( false === strpos( $label_b, 'glass' ) );
			if ( $is_back_a && ! $is_back_b ) return -1;
			if ( ! $is_back_a && $is_back_b ) return 1;

			$is_primary_a = ( false !== strpos( $label_a, 'top lid' ) ) || ( false !== strpos( $label_a, 'main body' ) ) || 'skin' === $label_a || 'body' === $label_a;
			$is_primary_b = ( false !== strpos( $label_b, 'top lid' ) ) || ( false !== strpos( $label_b, 'main body' ) ) || 'skin' === $label_b || 'body' === $label_b;
			if ( $is_primary_a && ! $is_primary_b ) return -1;
			if ( ! $is_primary_a && $is_primary_b ) return 1;

			$is_cov_a = false !== strpos( $label_a, 'coverage' );
			$is_cov_b = false !== strpos( $label_b, 'coverage' );
			$is_logo_a = false !== strpos( $label_a, 'logo' );
			$is_logo_b = false !== strpos( $label_b, 'logo' );
			$is_pen_a = ( false !== strpos( $label_a, 'pencil' ) ) || ( false !== strpos( $label_a, 'stylus' ) ) || ( false !== strpos( $label_a, 's-pen' ) );
			$is_pen_b = ( false !== strpos( $label_b, 'pencil' ) ) || ( false !== strpos( $label_b, 'stylus' ) ) || ( false !== strpos( $label_b, 's-pen' ) );

			$rank_a = $is_cov_a ? 100 : ( $is_logo_a ? 101 : ( $is_pen_a ? 102 : 10 ) );
			$rank_b = $is_cov_b ? 100 : ( $is_logo_b ? 101 : ( $is_pen_b ? 102 : 10 ) );

			if ( $rank_a !== $rank_b ) {
				return $rank_a - $rank_b;
			}
			return 0;
		} );
		return $addons;
	}

	public static function add_addon_data_to_cart_item( $cart_item_data, $product_id, $variation_id ) {
		if ( ! empty( $_POST['exacoat_addon_data'] ) ) {
			$raw = wp_unslash( $_POST['exacoat_addon_data'] );
			$parsed = json_decode( $raw, true );
			if ( is_array( $parsed ) ) {
				$cart_item_data['exacoat_addons'] = self::sort_addon_layers( $parsed );
				$cart_item_data['unique_key'] = md5( microtime() . rand() );
			}
		}
		if ( ! empty( $_POST['exacoat_custom_price'] ) ) {
			$custom_price = floatval( $_POST['exacoat_custom_price'] );
			if ( $custom_price > 0 ) {
				$cart_item_data['exacoat_custom_price'] = $custom_price;
			}
		}
		if ( ! empty( $_POST['exacoat_custom_image'] ) ) {
			$cart_item_data['exacoat_custom_image'] = esc_url_raw( wp_unslash( $_POST['exacoat_custom_image'] ) );
		}
		return $cart_item_data;
	}

	public static function get_cart_item_from_session( $cart_item, $values, $key ) {
		if ( ! empty( $values['exacoat_addons'] ) ) {
			$cart_item['exacoat_addons'] = $values['exacoat_addons'];
		}
		if ( ! empty( $values['exacoat_custom_image'] ) ) {
			$cart_item['exacoat_custom_image'] = $values['exacoat_custom_image'];
		}
		if ( ! empty( $values['exacoat_custom_price'] ) ) {
			$cart_item['exacoat_custom_price'] = $values['exacoat_custom_price'];
		}
		return $cart_item;
	}

	public static function calculate_custom_addon_totals( $cart ) {
		if ( is_admin() && ! defined( 'DOING_AJAX' ) ) return;
		if ( did_action( 'woocommerce_before_calculate_totals' ) >= 2 ) return;

		$active_currency = class_exists( 'Exacoat_Checkout_Engine' )
			? Exacoat_Checkout_Engine::get_active_currency()
			: ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'IDR' );

		foreach ( $cart->get_cart() as $cart_item_key => $cart_item ) {
			if ( isset( $cart_item['exacoat_custom_price'] ) && floatval( $cart_item['exacoat_custom_price'] ) > 0 ) {
				$base_idr_price = floatval( $cart_item['exacoat_custom_price'] );
				if ( ! empty( $active_currency ) && 'IDR' !== $active_currency ) {
					if ( class_exists( 'Exacoat_Store_Enhancements' ) ) {
						$final_price = Exacoat_Store_Enhancements::calculate_price_for_currency( $base_idr_price, $active_currency );
					} else {
						$converted = apply_filters( 'wc_aelia_cs_convert', $base_idr_price, 'IDR', $active_currency );
						if ( $converted > 0 && (float) $converted !== (float) $base_idr_price ) {
							$final_price = round( (float) $converted, 2 );
						} else {
							$final_price = $base_idr_price;
						}
					}
				} else {
					$final_price = $base_idr_price;
				}
				$cart_item['data']->set_price( $final_price );
			}
		}
	}

	public static function display_custom_addons_in_cart( $item_data, $cart_item ) {
		if ( ! empty( $cart_item['exacoat_addons'] ) && is_array( $cart_item['exacoat_addons'] ) ) {
			$sorted = self::sort_addon_layers( $cart_item['exacoat_addons'] );
			foreach ( $sorted as $addon ) {
				if ( ! empty( $addon['label'] ) && ! empty( $addon['value'] ) ) {
					$item_data[] = [
						'key'   => sanitize_text_field( $addon['label'] ),
						'value' => sanitize_text_field( $addon['value'] ),
					];
				}
			}
		}
		return $item_data;
	}

	public static function filter_store_api_cart_line_item_data( $data, $cart_item, $cart ) {
		if ( ! empty( $cart_item['exacoat_custom_image'] ) ) {
			$custom_img = esc_url_raw( $cart_item['exacoat_custom_image'] );
			$custom_img_obj = [
				'id'        => 0,
				'src'       => $custom_img,
				'thumbnail' => $custom_img,
				'srcset'    => '',
				'sizes'     => '',
				'name'      => $data['name'] ?? '',
				'alt'       => $data['name'] ?? '',
			];
			$data['images'] = array_merge( [ $custom_img_obj ], $data['images'] ?? [] );
		}
		return $data;
	}

	public static function filter_cart_item_thumbnail( $thumbnail, $cart_item, $cart_item_key ) {
		if ( ! empty( $cart_item['exacoat_custom_image'] ) ) {
			return sprintf(
				'<img src="%s" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" />',
				esc_url( $cart_item['exacoat_custom_image'] )
			);
		}
		return $thumbnail;
	}

	public static function save_custom_addons_to_order_item( $item, $cart_item_key, $values, $order ) {
		if ( ! empty( $values['exacoat_addons'] ) && is_array( $values['exacoat_addons'] ) ) {
			$sorted = self::sort_addon_layers( $values['exacoat_addons'] );
			foreach ( $sorted as $addon ) {
				if ( ! empty( $addon['label'] ) && ! empty( $addon['value'] ) ) {
					$item->add_meta_data( sanitize_text_field( $addon['label'] ), sanitize_text_field( $addon['value'] ), true );
				}
			}
		}
		if ( ! empty( $values['exacoat_custom_image'] ) ) {
			$img_url = esc_url_raw( $values['exacoat_custom_image'] );
			$item->add_meta_data( '_configured_image_url', $img_url, true );
			$item->add_meta_data( '_configurator_image', $img_url, true );
			$item->add_meta_data( '_thumbnail_url', $img_url, true );
			$item->add_meta_data( 'image_url', $img_url, true );
		}
	}

	/**
	 * Hook triggered when any product post is saved/updated in WordPress.
	 */
	public static function on_product_saved( $post_id, $post ): void {
		if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}
		if ( ! $post || 'product' !== $post->post_type ) {
			return;
		}
		$slug = $post->post_name;
		self::trigger_storefront_revalidation( [ 'slug' => $slug ] );
	}

	/**
	 * Dual Revalidation: triggers Next.js storefront on-demand ISR revalidation and Cloudflare Edge Cache purge.
	 */
	public static function trigger_storefront_revalidation( array $params = [] ): array {
		$slug      = sanitize_title( $params['slug'] ?? '' );
		$category  = sanitize_title( $params['category'] ?? '' );
		$tag       = sanitize_text_field( $params['tag'] ?? 'products' );
		$path      = sanitize_text_field( $params['path'] ?? '' );
		$purge_all = ! empty( $params['purge_everything'] );

		$results = [
			'nextjs'     => null,
			'cloudflare' => null,
		];

		// 1. Next.js storefront revalidation (web.exacoat.com)
		$storefront_base = defined( 'EXACOAT_STOREFRONT_URL' ) ? EXACOAT_STOREFRONT_URL : 'https://web.exacoat.com';
		$secret = defined( 'EXACOAT_REVALIDATE_SECRET' ) ? EXACOAT_REVALIDATE_SECRET : 'exacoat_revalidate_secret_2026';
		$revalidate_url = trailingslashit( $storefront_base ) . 'api/revalidate?secret=' . rawurlencode( $secret );

		$payload = [
			'tag'      => $tag,
			'slug'     => $slug,
			'category' => $category,
			'path'     => $path,
		];

		$response = wp_remote_post( $revalidate_url, [
			'headers' => [ 'Content-Type' => 'application/json' ],
			'body'    => wp_json_encode( $payload ),
			'timeout' => 8,
		] );

		if ( is_wp_error( $response ) ) {
			$results['nextjs'] = [
				'success' => false,
				'error'   => $response->get_error_message(),
			];
		} else {
			$status_code = wp_remote_retrieve_response_code( $response );
			$body = json_decode( wp_remote_retrieve_body( $response ), true );
			$results['nextjs'] = [
				'success'     => ( 200 === $status_code && ! empty( $body['success'] ) ),
				'status_code' => $status_code,
				'details'     => $body,
			];
		}

		// 2. Cloudflare Edge Cache Purge (if credentials configured)
		$zone_id = defined( 'EXA_CLOUDFLARE_ZONE_ID' ) ? EXA_CLOUDFLARE_ZONE_ID : ( defined( 'EXACOAT_CLOUDFLARE_ZONE_ID' ) ? EXACOAT_CLOUDFLARE_ZONE_ID : ( defined( 'CLOUDFLARE_ZONE_ID' ) ? CLOUDFLARE_ZONE_ID : ( defined( 'AM_CLOUDFLARE_ZONE_ID' ) ? AM_CLOUDFLARE_ZONE_ID : ( getenv( 'EXA_CLOUDFLARE_ZONE_ID' ) ?: ( class_exists( 'Exacoat_Core' ) ? Exacoat_Core::get_setting( 'cloudflare_zone_id', '' ) : '' ) ) ) ) );
		$api_token = defined( 'EXA_CLOUDFLARE_API_TOKEN' ) ? EXA_CLOUDFLARE_API_TOKEN : ( defined( 'EXACOAT_CLOUDFLARE_API_TOKEN' ) ? EXACOAT_CLOUDFLARE_API_TOKEN : ( defined( 'CLOUDFLARE_API_TOKEN' ) ? CLOUDFLARE_API_TOKEN : ( defined( 'AM_CLOUDFLARE_API_TOKEN' ) ? AM_CLOUDFLARE_API_TOKEN : ( getenv( 'EXA_CLOUDFLARE_API_TOKEN' ) ?: ( class_exists( 'Exacoat_Core' ) ? Exacoat_Core::get_setting( 'cloudflare_api_token', '' ) : '' ) ) ) ) );

		if ( ! empty( $zone_id ) && ! empty( $api_token ) ) {
			if ( $purge_all ) {
				$cf_payload = [ 'purge_everything' => true ];
			} else {
				$files = [
					'https://web.exacoat.com/',
					'https://web.exacoat.com/shop',
					'https://exacoat.com/',
					'https://exacoat.com/shop/',
				];
				if ( ! empty( $slug ) ) {
					$files[] = "https://web.exacoat.com/product/{$slug}";
					$files[] = "https://exacoat.com/product/{$slug}";
				}
				if ( ! empty( $category ) ) {
					$files[] = "https://web.exacoat.com/shop/{$category}";
				}
				$cf_payload = [ 'files' => array_values( array_unique( $files ) ) ];
			}

			$cf_res = wp_remote_post( 'https://api.cloudflare.com/client/v4/zones/' . rawurlencode( trim( $zone_id ) ) . '/purge_cache', [
				'headers' => [
					'Authorization' => 'Bearer ' . trim( $api_token ),
					'Content-Type'  => 'application/json',
				],
				'body'    => wp_json_encode( $cf_payload ),
				'timeout' => 12,
			] );

			if ( is_wp_error( $cf_res ) ) {
				$results['cloudflare'] = [
					'success' => false,
					'error'   => $cf_res->get_error_message(),
				];
			} else {
				$cf_code = wp_remote_retrieve_response_code( $cf_res );
				$cf_body = json_decode( wp_remote_retrieve_body( $cf_res ), true );
				$results['cloudflare'] = [
					'success'     => ( 200 === $cf_code && ! empty( $cf_body['success'] ) ),
					'status_code' => $cf_code,
					'details'     => $cf_body,
				];
			}
		} else {
			$results['cloudflare'] = [
				'configured' => false,
				'message'    => 'Cloudflare credentials not configured in wp-config.php or settings.',
			];
		}

		if ( class_exists( 'Exacoat_Logger' ) ) {
			Exacoat_Logger::log( 'info', 'configurator', "Storefront revalidation triggered for slug: '{$slug}', category: '{$category}'" );
		}

		return $results;
	}

	/**
	 * REST Endpoint: On-demand cache revalidation for web.exacoat.com and Cloudflare
	 */
	public static function rest_revalidate_web( WP_REST_Request $request ): WP_REST_Response {
		$params = $request->get_json_params() ?: $request->get_params();
		$results = self::trigger_storefront_revalidation( $params );

		return rest_ensure_response( [
			'success' => ( ! empty( $results['nextjs']['success'] ) || ! empty( $results['cloudflare']['success'] ) ),
			'results' => $results,
			'message' => 'Storefront web cache revalidation completed.',
		] );
	}
}

}

