<?php
/**
 * Exacoat Store & Frontend Enhancements Module
 * Consolidates store-wide UX, currency handling, and checkout enhancements.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Exacoat_Store_Enhancements' ) ) {

class Exacoat_Store_Enhancements {

	public static function init() {
		// 1. Store Tweaks & Cleanups
		add_filter( 'woocommerce_countries_ex_tax_or_vat', '__return_empty_string' );
		add_filter( 'woocommerce_bacs_process_payment_order_status', fn() => 'pending', 10, 2 );
		add_filter( 'big_image_size_threshold', '__return_false' );
		add_filter( 'cfw_promo_code_toggle_link_text', fn() => __( 'Have a promo code?', 'exacoat-core' ) );
		add_filter( 'cfw_disable_email_domain_validation', '__return_true' );

		// Cart to checkout redirect, disabled by default to preserve standard WooCommerce cart behavior
		if ( Exacoat_Core::get_setting( 'redirect_cart_checkout', 0 ) ) {
			add_action( 'template_redirect', [ __CLASS__, 'redirect_cart_to_checkout' ] );
		}

		// Optional login page redirect
		if ( Exacoat_Core::get_setting( 'redirect_wp_login', 0 ) ) {
			add_action( 'init', [ __CLASS__, 'redirect_wp_login_page' ] );
		}

		// Logout redirect to homepage
		add_action( 'wp_logout', fn() => wp_safe_redirect( home_url( '/' ) ) );

		// Product Tags Meta Sync
		add_action( 'updated_post_meta', [ __CLASS__, 'sync_meta_to_tag_taxonomy' ], 10, 4 );
		add_action( 'added_post_meta', [ __CLASS__, 'sync_meta_to_tag_taxonomy' ], 10, 4 );
		add_action( 'set_object_terms', [ __CLASS__, 'sync_tag_taxonomy_to_meta' ], 10, 6 );

		// Custom Product Statuses: 'Rejected' & 'Scheduled for removal'
		add_action( 'init', [ __CLASS__, 'register_custom_product_statuses' ] );
		add_filter( 'display_post_states', [ __CLASS__, 'display_custom_product_post_states' ], 10, 2 );
		add_filter( 'woocommerce_product_query_post_status', [ __CLASS__, 'include_rejected_in_product_query' ] );

		// Lockdown /wp/v2/users Endpoint
		add_filter( 'rest_authentication_errors', [ __CLASS__, 'lockdown_users_rest_api' ], 10, 1 );

		// Aelia Multi-Currency auto-price generator with Configurable FX Rates & Markup
		add_action( 'woocommerce_process_product_meta', [ __CLASS__, 'auto_set_aelia_currency_prices' ], 20 );
		add_action( 'woocommerce_after_product_object_save', [ __CLASS__, 'auto_set_aelia_currency_prices_after_save' ], 20, 2 );
		add_filter( 'woocommerce_price_num_decimals', [ __CLASS__, 'get_active_currency_decimals' ], 999 );

		// 15. Checkout Shipping Rules (#14577) - Multi-Zone Tiered Free Shipping Discount & Legacy Sanitization
		add_filter( 'woocommerce_package_rates', [ __CLASS__, 'filter_legacy_shipping_rates' ], 5, 2 );
		add_filter( 'woocommerce_package_rates', [ __CLASS__, 'apply_currency_markup_to_shipping_rates' ], 90, 2 );
		add_filter( 'woocommerce_package_rates', [ __CLASS__, 'apply_zone_tiered_shipping_discount' ], 100, 2 );
		add_filter( 'woocommerce_package_rates', [ __CLASS__, 'apply_shipping_promo_coupon_rate_discount' ], 110, 2 );
		add_filter( 'woocommerce_order_item_shipping_get_method_title', [ __CLASS__, 'clean_shipping_method_title' ], 20, 2 );
		add_filter( 'woocommerce_shipping_rate_label', [ __CLASS__, 'clean_shipping_method_title' ], 20, 2 );

		// 18. Virtual Upload Folder Path Resolver & 404 Prevention
		add_action( 'init', [ __CLASS__, 'resolve_virtual_upload' ], 1 );
		add_filter( 'redirect_canonical', [ __CLASS__, 'prevent_upload_404_redirect_loop' ], 10, 2 );
		add_filter( 'wp_get_attachment_url', [ __CLASS__, 'filter_virtual_attachment_url' ], 10, 2 );

		// 19. Custom Print Finish (FeelForm 3D vs Flat) Cart & Order Handling
		add_filter( 'woocommerce_add_cart_item_data', [ __CLASS__, 'add_print_finish_to_cart_item' ], 10, 3 );
		add_filter( 'woocommerce_get_item_data', [ __CLASS__, 'display_print_finish_in_cart' ], 10, 2 );
		add_action( 'woocommerce_checkout_create_order_line_item', [ __CLASS__, 'save_print_finish_to_order_item' ], 10, 4 );

		// 20. WebP Image Integration for Products in WooCommerce Cart & Checkout
		add_filter( 'woocommerce_cart_item_thumbnail', [ __CLASS__, 'filter_cart_item_thumbnail_webp' ], 20, 3 );
		add_filter( 'woocommerce_admin_order_item_thumbnail', [ __CLASS__, 'filter_order_item_thumbnail_webp' ], 20, 3 );

		// 21. Selective WooCommerce Asset Decoupling on Non-Shop Pages
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'maybe_unload_wc_assets_on_non_shop' ], 99 );

		// 22. Shortlink Redirects (/cs, /wa, /whatsapp -> WhatsApp Customer Support)
		add_action( 'template_redirect', [ __CLASS__, 'handle_shortlink_redirects' ], 1 );

		// 23. Headless CMS Frontend to Storefront Redirect (Redirect cms.exacoat.com to exacoat.com except wp-admin & APIs)
		add_action( 'template_redirect', [ __CLASS__, 'redirect_cms_frontend_to_storefront' ], 6 );

		// 24. Refine REST API product search to match post_title & SKU instead of broad post_content
		add_filter( 'posts_search', [ __CLASS__, 'refine_rest_product_search' ], 20, 2 );
		add_filter( 'posts_clauses', [ __CLASS__, 'refine_rest_product_search_orderby' ], 20, 2 );

		// 25. PHP 8.4 Strict Type Safety for Email Preview (Prevents "Unsupported operand types: string * int" in EmailPreview.php)
		add_filter( 'woocommerce_product_get_price', [ __CLASS__, 'sanitize_product_price_for_php8' ], 9999, 2 );
		add_filter( 'woocommerce_product_variation_get_price', [ __CLASS__, 'sanitize_product_price_for_php8' ], 9999, 2 );
		add_filter( 'woocommerce_email_preview_dummy_product', [ __CLASS__, 'harden_email_preview_dummy_product' ], 9999, 2 );
	}

	/**
	 * Shortlink redirect handler: dynamically checks registered redirections with fallback
	 */
	public static function handle_shortlink_redirects() {
		if ( is_admin() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}

		$request_uri = untrailingslashit( strtolower( parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ) ?: '' ) );
		if ( empty( $request_uri ) ) {
			return;
		}

		$rules = class_exists( 'Exacoat_Core' ) ? Exacoat_Core::get_redirections() : [];
		foreach ( $rules as $rule ) {
			if ( empty( $rule['enabled'] ) ) continue;
			$source = untrailingslashit( strtolower( $rule['source'] ?? '' ) );
			if ( $source === $request_uri && ! empty( $rule['target'] ) ) {
				$status = in_array( (int) ( $rule['status_code'] ?? 307 ), [ 301, 302, 307, 308 ], true ) ? (int) $rule['status_code'] : 307;
				$target = (string) $rule['target'];
				if ( str_starts_with( $target, '/' ) ) {
					$target = function_exists( 'exacoat_storefront_url' ) ? exacoat_storefront_url( $target ) : ( 'https://exacoat.com' . $target );
				}
				wp_redirect( $target, $status );
				exit;
			}
		}

		if ( in_array( $request_uri, [ '/cs', '/care', '/wa', '/whatsapp' ], true ) ) {
			$wa_url = 'https://api.whatsapp.com/send?phone=628975556000';
			wp_redirect( $wa_url, 307 );
			exit;
		}
	}

	/**
	 * Headless CMS Frontend Redirection
	 *
	 * Automatically redirects all frontend page visits on cms.exacoat.com to the authoritative
	 * storefront on exacoat.com, preserving paths and query strings, while strictly safeguarding:
	 * - /wp-admin & /wp-login.php (Admin dashboard and authentication)
	 * - /wp-json/* (WooCommerce REST API, Store API, Exacoat Core REST routes)
	 * - /wc-api/* & ?wc-ajax=* (Payment callbacks, IPNs, webhooks)
	 * - /wp-content/* & /wp-includes/* (Static uploads, scripts, stylesheets)
	 * - /wp-cron.php & /xmlrpc.php
	 * - Active Bricks builder sessions (?bricks=run / ?brickspreview) for logged-in editors
	 */
	public static function redirect_cms_frontend_to_storefront(): void {
		// 1. Skip admin screens, AJAX, Cron, or REST API requests
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}

		// 2. Allow disabling via setting or constant if ever needed
		if ( defined( 'EXACOAT_DISABLE_CMS_REDIRECT' ) && EXACOAT_DISABLE_CMS_REDIRECT ) {
			return;
		}
		if ( class_exists( 'Exacoat_Core' ) && ! Exacoat_Core::get_setting( 'redirect_cms_frontend', 1 ) ) {
			return;
		}

		$raw_uri = $_SERVER['REQUEST_URI'] ?? '/';
		$path    = parse_url( $raw_uri, PHP_URL_PATH ) ?: '/';

		// 3. Strictly safeguard core backend endpoints from redirection
		if ( preg_match( '#^/(wp-admin|wp-login\.php|wp-json|wc-api|wc-ajax|wp-content|wp-includes|xmlrpc\.php|wp-cron\.php)#i', $path ) ) {
			return;
		}

		if ( isset( $_GET['wc-ajax'] ) || isset( $_GET['wc-api'] ) ) {
			return;
		}

		// 4. Allow logged-in staff to use Bricks visual editor or preview unpublished posts
		if ( function_exists( 'is_user_logged_in' ) && is_user_logged_in() && current_user_can( 'edit_posts' ) ) {
			if ( isset( $_GET['bricks'] ) || isset( $_GET['brickspreview'] ) || ( function_exists( 'is_preview' ) && is_preview() ) ) {
				return;
			}
		}

		// 5. Canonical resolution for plain post queries (e.g. ?p=123 or ?page_id=456)
		$target_path = $raw_uri;
		if ( ( isset( $_GET['p'] ) || isset( $_GET['page_id'] ) ) && function_exists( 'is_singular' ) && is_singular() ) {
			$canonical = get_permalink();
			if ( $canonical ) {
				$parsed_path = parse_url( $canonical, PHP_URL_PATH );
				if ( $parsed_path ) {
					$query = $_GET;
					unset( $query['p'], $query['page_id'], $query['post_type'] );
					$target_path = $parsed_path . ( ! empty( $query ) ? ( '?' . http_build_query( $query ) ) : '' );
				}
			}
		}

		// 6. Resolve destination URL on exacoat.com
		$storefront_base = function_exists( 'exacoat_storefront_url' )
			? exacoat_storefront_url( '/' )
			: ( defined( 'EXACOAT_WEB_URL' ) ? EXACOAT_WEB_URL : 'https://exacoat.com' );
		$storefront_base = untrailingslashit( $storefront_base );

		$destination = $storefront_base . ( str_starts_with( $target_path, '/' ) ? $target_path : ( '/' . $target_path ) );

		// 7. Prevent infinite redirect loop if host matches destination
		$target_host  = parse_url( $destination, PHP_URL_HOST );
		$current_host = parse_url( home_url(), PHP_URL_HOST ) ?: ( $_SERVER['HTTP_HOST'] ?? '' );
		if ( strcasecmp( (string) $target_host, (string) $current_host ) === 0 ) {
			return;
		}

		// 8. Execute 301 Permanent Redirect
		wp_redirect( $destination, 301, 'Exacoat-Headless-CMS' );
		exit;
	}

	public static function redirect_cart_to_checkout() {
		if ( ! Exacoat_Core::get_setting( 'redirect_cart_checkout', 1 ) ) return;

		if ( function_exists( 'is_cart' ) && is_cart() ) {
			wp_safe_redirect( wc_get_checkout_url() );
			exit;
		}
	}

	public static function journal_rewrite_rules() {
		add_rewrite_rule( '^journal/([^/]+)/?$', 'index.php?name=$matches[1]', 'top' );
	}

	public static function custom_order_rewrite_rules() {
		add_rewrite_rule( '^posters/(custom-order-[^/]+)/?$', 'index.php?product=$matches[1]', 'top' );
	}

	public static function handle_custom_order_redirect() {
		if ( empty( $_SERVER['REQUEST_URI'] ) ) return;
		$uri = trim( parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH ), '/' );

		if ( preg_match( '#^posters/(custom-order-[a-z0-9\-_]+)$#i', $uri, $matches ) ) {
			$slug = strtolower( $matches[1] );
			$posts = get_posts( [
				'name'        => $slug,
				'post_type'   => 'product',
				'post_status' => 'publish',
				'numberposts' => 1,
			] );

			if ( ! empty( $posts ) ) {
				$target = get_permalink( $posts[0]->ID );
				if ( $target && strcasecmp( home_url( $_SERVER['REQUEST_URI'] ), $target ) !== 0 ) {
					wp_safe_redirect( $target, 302 );
					exit;
				}
			}
		}
	}

	public static function redirect_wp_login_page() {
		if ( empty( $_SERVER['REQUEST_URI'] ) || ( $_SERVER['REQUEST_METHOD'] ?? '' ) !== 'GET' ) {
			return;
		}

		$path = trim( (string) parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH ), '/' );
		if ( 'wp-login.php' !== basename( $path ) ) {
			return;
		}

		// Allow WordPress logout, password recovery, postpass, and Nextend Social Login
		$action = isset( $_GET['action'] ) ? sanitize_key( $_GET['action'] ) : '';
		if ( in_array( $action, [ 'logout', 'postpass', 'lostpassword', 'rp', 'resetpass' ], true ) || isset( $_GET['loginSocial'] ) ) {
			return;
		}

		$login_page = home_url( '/login/' );
		if ( ! empty( $_GET['redirect_to'] ) ) {
			$login_page = add_query_arg( 'redirect_to', rawurlencode( wp_unslash( $_GET['redirect_to'] ) ), $login_page );
		}

		wp_safe_redirect( $login_page );
		exit;
	}

	public static function sync_art_fandom_meta( $term_id, $tt_id, $taxonomy, $update = false ) {
		if ( $taxonomy !== 'art_fandom' ) return;
		clean_term_cache( $term_id, $taxonomy );
		$term = get_term( $term_id, $taxonomy );
		if ( ! $term || is_wp_error( $term ) ) return;

		$acf_id = 'art_fandom_' . $term_id;
		if ( function_exists( 'update_field' ) ) {
			update_field( 'fandom_title', $term->name, $acf_id );
			update_field( 'fandom_slug', $term->slug, $acf_id );
			$link = get_term_link( $term );
			if ( ! is_wp_error( $link ) ) {
				update_field( 'fandom_public_url', $link, $acf_id );
			}
		}

		if ( ! $update ) {
			Artmatter_Webhook_Dispatcher::dispatch( 'fandom_created', get_option( 'admin_email' ), 'Admin', [
				'term_id'     => $term_id,
				'name'        => $term->name,
				'slug'        => $term->slug,
				'description' => $term->description,
			] );
		}
	}

	public static function sync_collection_term_meta( $term_id ) {
		$term = get_term( $term_id, 'artist_collection' );
		if ( ! $term || is_wp_error( $term ) ) return;
		update_term_meta( $term_id, 'collection_term_id', (int) $term_id );
		update_term_meta( $term_id, 'collection_term_name', $term->name );
		update_term_meta( $term_id, 'collection_term_slug', $term->slug );
	}

	public static function sync_artwork_collection_meta( $value, $post_id, $field ) {
		if ( get_post_type( $post_id ) !== 'product' ) return $value;
		$term_id = is_array( $value ) ? reset( $value ) : $value;
		if ( $term_id ) {
			$term = get_term( (int) $term_id, 'artist_collection' );
			if ( $term && ! is_wp_error( $term ) ) {
				update_post_meta( $post_id, 'artwork_artist_collection_name', $term->name );
				update_post_meta( $post_id, 'artwork_artist_collection_slug', $term->slug );
			}
		} else {
			delete_post_meta( $post_id, 'artwork_artist_collection_name' );
			delete_post_meta( $post_id, 'artwork_artist_collection_slug' );
		}
		return $value;
	}

	public static function sync_artwork_fandom_meta( $value, $post_id, $field ) {
		if ( get_post_type( $post_id ) !== 'product' ) return $value;
		$term_id = is_array( $value ) ? reset( $value ) : $value;
		if ( $term_id ) {
			$term = get_term( (int) $term_id, 'art_fandom' );
			if ( $term && ! is_wp_error( $term ) ) {
				update_post_meta( $post_id, 'artwork_fandom_name', $term->name );
				update_post_meta( $post_id, 'artwork_fandom_slug', $term->slug );
			}
		} else {
			delete_post_meta( $post_id, 'artwork_fandom_name' );
			delete_post_meta( $post_id, 'artwork_fandom_slug' );
		}
		return $value;
	}

	public static function sync_author_and_artist_field( $post_id ) {
		if ( get_post_type( $post_id ) !== 'product' ) return;

		// Decoupled architecture: all products are owned by Master Admin (ID 1)
		$current_author = (int) get_post_field( 'post_author', $post_id );
		if ( $current_author !== 1 ) {
			global $wpdb;
			$wpdb->update( $wpdb->posts, [ 'post_author' => 1 ], [ 'ID' => $post_id ] );
			clean_post_cache( $post_id );
		}

		// Ensure the featured image has post_parent and post_author set to 1
		$thumb_id = get_post_thumbnail_id( $post_id );
		if ( $thumb_id ) {
			$thumb_parent = (int) get_post_field( 'post_parent', $thumb_id );
			$thumb_author = (int) get_post_field( 'post_author', $thumb_id );
			$needs_update = false;
			$thumb_update = [ 'ID' => $thumb_id ];
			if ( $thumb_parent !== (int) $post_id ) {
				$thumb_update['post_parent'] = $post_id;
				$needs_update = true;
			}
			if ( $thumb_author !== 1 ) {
				$thumb_update['post_author'] = 1;
				$needs_update = true;
			}
			if ( $needs_update ) {
				wp_update_post( $thumb_update );
				clean_post_cache( $thumb_id );
			}
		}
	}

	public static function sync_product_artist_display_name( $post_id, $post = null ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
		if ( wp_is_post_revision( $post_id ) ) return;
		if ( get_post_type( $post_id ) !== 'product' ) return;

		$artist_id = (int) get_post_meta( $post_id, 'artwork_artist', true );
		if ( ! $artist_id && $post ) {
			$artist_id = (int) $post->post_author;
		}

		if ( $artist_id ) {
			$custom_name = get_user_meta( $artist_id, 'artist_display_name', true );
			if ( is_array( $custom_name ) ) $custom_name = $custom_name[0];
			$final_name = ! empty( $custom_name ) ? $custom_name : get_the_author_meta( 'display_name', $artist_id );
			update_post_meta( $post_id, 'artwork_artist_display_name', $final_name );
			update_post_meta( $post_id, 'product_artist_display_name', $final_name );
		}
	}

	private static $tag_syncing = false;

	public static function sync_meta_to_tag_taxonomy( $meta_id, $object_id, $meta_key, $meta_value ) {
		if ( self::$tag_syncing || $meta_key !== 'product_tags' || get_post_type( $object_id ) !== 'product' ) return;
		self::$tag_syncing = true;
		$tags = array_filter( array_map( 'trim', explode( ',', strtolower( (string) $meta_value ) ) ) );
		if ( ! empty( $tags ) ) {
			wp_set_post_terms( $object_id, $tags, 'product_tag', false );
		}
		self::$tag_syncing = false;
	}

	public static function sync_tag_taxonomy_to_meta( $object_id, $terms, $tt_ids, $taxonomy, $append, $old_tt_ids ) {
		if ( self::$tag_syncing || $taxonomy !== 'product_tag' || get_post_type( $object_id ) !== 'product' ) return;
		self::$tag_syncing = true;
		$term_names = wp_get_post_terms( $object_id, 'product_tag', [ 'fields' => 'names' ] );
		if ( ! is_wp_error( $term_names ) ) {
			$normalized = implode( ', ', array_unique( array_map( 'strtolower', $term_names ) ) );
			update_post_meta( $object_id, 'product_tags', $normalized );
		}
		self::$tag_syncing = false;
	}

	/**
	 * Fast SQL search query extension covering product_tag and device taxonomies (#12532)
	 */

	public static function register_custom_product_statuses() {
		register_post_status( 'rejected', [
			'label'                     => _x( 'Rejected', 'post status', 'exacoat-core' ),
			'public'                    => false,
			'private'                   => true,
			'protected'                 => false,
			'exclude_from_search'       => true,
			'show_in_admin_all_list'    => true,
			'show_in_admin_status_list' => true,
			'label_count'               => _n_noop( 'Rejected <span class="count">(%s)</span>', 'Rejected <span class="count">(%s)</span>', 'exacoat-core' ),
		] );

		register_post_status( 'sched_removal', [
			'label'                     => _x( 'Delisting Wind-Down (7 Days)', 'post status', 'exacoat-core' ),
			'public'                    => false,
			'private'                   => true,
			'protected'                 => false,
			'exclude_from_search'       => true,
			'show_in_admin_all_list'    => true,
			'show_in_admin_status_list' => true,
			'label_count'               => _n_noop( 'Delisting Wind-Down <span class="count">(%s)</span>', 'Delisting Wind-Down <span class="count">(%s)</span>', 'exacoat-core' ),
		] );

		register_post_status( 'scheduled_removal', [
			'label'                     => _x( 'Scheduled for Removal', 'post status', 'exacoat-core' ),
			'public'                    => false,
			'private'                   => true,
			'protected'                 => false,
			'exclude_from_search'       => true,
			'show_in_admin_all_list'    => true,
			'show_in_admin_status_list' => true,
			'label_count'               => _n_noop( 'Scheduled for Removal <span class="count">(%s)</span>', 'Scheduled for Removal <span class="count">(%s)</span>', 'exacoat-core' ),
		] );

		register_post_status( 'delisted', [
			'label'                     => _x( 'Delisted', 'post status', 'exacoat-core' ),
			'public'                    => false,
			'private'                   => true,
			'protected'                 => false,
			'exclude_from_search'       => true,
			'show_in_admin_all_list'    => true,
			'show_in_admin_status_list' => true,
			'label_count'               => _n_noop( 'Delisted <span class="count">(%s)</span>', 'Delisted <span class="count">(%s)</span>', 'exacoat-core' ),
		] );
	}

	public static function display_custom_product_post_states( $states, $post ) {
		if ( $post->post_type === 'product' ) {
			if ( $post->post_status === 'rejected' ) {
				$states['rejected'] = __( 'Rejected', 'exacoat-core' );
			} elseif ( $post->post_status === 'sched_removal' || $post->post_status === 'scheduled_removal' ) {
				$states['sched_removal'] = __( 'Delisting Wind-Down (7 Days)', 'exacoat-core' );
			} elseif ( $post->post_status === 'delisted' ) {
				$states['delisted'] = __( 'Delisted (Archived)', 'exacoat-core' );
			}
		}
		return $states;
	}

	public static function include_rejected_in_product_query( $statuses ) {
		$statuses[] = 'rejected';
		$statuses[] = 'sched_removal';
		$statuses[] = 'scheduled_removal';
		$statuses[] = 'delisted';
		return $statuses;
	}

	/**
	 * Force Product Slug with ID: {slug}-{id} (#10117)
	 */
	public static function force_product_slug_with_id( $slug, $post_ID, $post_status, $post_type, $post_parent, $original_slug ) {
		if ( $post_type !== 'product' || empty( $post_ID ) ) {
			return $slug;
		}

		if ( ! Exacoat_Core::get_setting( 'enable_product_id_slugs', 1 ) ) return $slug;

		if ( get_post_meta( $post_ID, '_artmatter_custom_product', true ) ) {
			return $slug;
		}

		$excluded_category_slugs = [ 'misc', 'accessories' ];
		$product_terms = wp_get_post_terms( $post_ID, 'product_cat', [ 'fields' => 'slugs' ] );
		if ( ! is_wp_error( $product_terms ) && array_intersect( $excluded_category_slugs, $product_terms ) ) {
			return $slug;
		}

		$base_slug = empty( $slug ) ? 'product' : $slug;
		$id_suffix = '-' . $post_ID;

		if ( substr( $base_slug, -strlen( $id_suffix ) ) === $id_suffix ) {
			return $base_slug;
		}

		return $base_slug . $id_suffix;
	}

	public static function lockdown_users_rest_api( $result ) {
		if ( ! Exacoat_Core::get_setting( 'lockdown_users_api', 1 ) ) return $result;

		if ( ! empty( $result ) ) return $result;
		$route = $GLOBALS['wp']->query_vars['rest_route'] ?? '';
		if ( strpos( $route, '/wp/v2/users' ) !== false && ! is_user_logged_in() ) {
			return new WP_Error( 'rest_forbidden', __( 'Authentication required to view users.', 'exacoat-core' ), [ 'status' => 401 ] );
		}
		return $result;
	}

	public static function display_singles_collection_name( $term, $taxonomy ) {
		return $term;
	}

	/**
	 * Extract exchange rates directly from Aelia Currency Switcher
	 *
	 * Returns an associative array of currency codes to their rate vs 1 IDR (or shop base currency):
	 * e.g. [ 'USD' => 0.000062, 'EUR' => 0.000058, ... ]
	 */
	public static function get_aelia_exchange_rates(): array {
		$shop_base_currency = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'IDR';
		$rates = [];

		$aelia_settings = get_option( 'woocommerce_aelia_currencyswitcher', [] );
		if ( empty( $aelia_settings ) || ! is_array( $aelia_settings ) ) {
			$aelia_settings = get_option( 'wc_aelia_currency_switcher', [] );
		}

		$aelia_raw_rates = [];
		if ( ! empty( $aelia_settings['exchange_rates'] ) && is_array( $aelia_settings['exchange_rates'] ) ) {
			$aelia_raw_rates = $aelia_settings['exchange_rates'];
		} elseif ( class_exists( 'WC_Aelia_CurrencyPrices_Manager' ) && method_exists( 'WC_Aelia_CurrencyPrices_Manager', 'get_exchange_rates' ) ) {
			$aelia_raw_rates = (array) \WC_Aelia_CurrencyPrices_Manager::get_exchange_rates();
		}

		$enabled_currencies = apply_filters( 'wc_aelia_cs_enabled_currencies', [] );
		if ( empty( $enabled_currencies ) && ! empty( $aelia_settings['enabled_currencies'] ) && is_array( $aelia_settings['enabled_currencies'] ) ) {
			$enabled_currencies = $aelia_settings['enabled_currencies'];
		}
		if ( empty( $enabled_currencies ) ) {
			$enabled_currencies = [ 'USD', 'EUR', 'AUD', 'SGD', 'JPY', 'GBP', 'CAD', 'CHF', 'HKD', 'THB', 'KRW', 'MYR' ];
		}

		foreach ( $enabled_currencies as $currency_code ) {
			$curr = strtoupper( trim( (string) $currency_code ) );
			if ( empty( $curr ) || $curr === $shop_base_currency ) {
				continue;
			}

			$rate = 0.0;

			// Method A: Check Aelia convert filter with 1,000,000 base units for high decimal accuracy
			$test_base = 1000000.0;
			$converted = (float) apply_filters( 'wc_aelia_cs_convert', $test_base, $shop_base_currency, $curr );
			if ( $converted > 0 && abs( $converted - $test_base ) > 0.0001 ) {
				$rate = $converted / $test_base;
			}

			// Method B: Parse raw exchange rate matrix from Aelia settings
			if ( $rate <= 0 && ! empty( $aelia_raw_rates[ $curr ] ) ) {
				$entry = $aelia_raw_rates[ $curr ];
				$raw_val = floatval( is_array( $entry ) ? ( $entry['rate'] ?? 0 ) : $entry );
				if ( $raw_val > 0 ) {
					if ( $raw_val < 1.0 ) {
						$rate = $raw_val;
					} else {
						// 1 USD = 16,129.03 IDR => 1 IDR = 1 / 16129.03 = 0.000062 USD
						$rate = 1.0 / $raw_val;
					}
				}
			}

			if ( $rate > 0 ) {
				$rates[ $curr ] = $rate;
			}
		}

		return $rates;
	}

	/**
	 * Synchronize Exacoat Core currency registry with active Aelia Currency Switcher rates.
	 * Preserves custom symbols and rounding engines, updating only the numeric FX rates.
	 */
	public static function sync_rates_from_aelia(): array {
		$aelia_rates = self::get_aelia_exchange_rates();
		if ( empty( $aelia_rates ) ) {
			return [
				'success' => false,
				'message' => 'No active exchange rates could be retrieved from Aelia Currency Switcher.',
				'rates'   => self::get_currency_rates(),
			];
		}

		$current_rates = self::get_currency_rates();
		$synced_count  = 0;
		$synced_codes  = [];

		$default_symbols = [
			'USD' => '$',   'EUR' => '€',   'AUD' => 'A$',  'SGD' => 'S$',
			'JPY' => '¥',   'GBP' => '£',   'CAD' => 'CA$', 'CHF' => 'CHF',
			'HKD' => 'HK$', 'THB' => '฿',   'KRW' => '₩',   'MYR' => 'RM',
			'NZD' => 'NZ$', 'PHP' => '₱',   'INR' => '₹',   'TWD' => 'NT$',
		];

		$default_roundings = [
			'JPY' => '50_step',
			'KRW' => '500_step',
			'THB' => '90_end',
		];

		foreach ( $aelia_rates as $code => $rate ) {
			$rate = (float) $rate;
			if ( $rate <= 0 ) continue;

			if ( isset( $current_rates[ $code ] ) ) {
				$current_rates[ $code ]['rate'] = $rate;
			} else {
				$current_rates[ $code ] = [
					'code'     => $code,
					'symbol'   => $default_symbols[ $code ] ?? $code,
					'rate'     => $rate,
					'rounding' => $default_roundings[ $code ] ?? '90_decimal',
				];
			}
			$synced_count++;
			$synced_codes[] = $code;
		}

		$settings = Exacoat_Core::get_settings();
		$settings['currency_rates'] = $current_rates;
		$settings['currency_last_synced_aelia'] = current_time( 'mysql' );

		update_option( 'exacoat_core_settings', $settings );
		Exacoat_Core::clear_settings_cache();

		return [
			'success'        => true,
			'message'        => sprintf( 'Successfully synchronized %d currency rates from Aelia (%s).', $synced_count, implode( ', ', $synced_codes ) ),
			'synced_count'   => $synced_count,
			'synced_codes'   => $synced_codes,
			'synced_at'      => $settings['currency_last_synced_aelia'],
			'currency_rates' => $current_rates,
		];
	}

	/**
	 * Dynamic Currency Registry (#11889)
	 */
	public static function get_currency_rates(): array {
		$settings = Exacoat_Core::get_settings();
		$default_currencies = [
			'USD' => [ 'symbol' => '$',   'rate' => 0.000100, 'rounding' => '90_decimal' ],
			'EUR' => [ 'symbol' => '€',   'rate' => 0.000092, 'rounding' => '90_decimal' ],
			'AUD' => [ 'symbol' => 'A$',  'rate' => 0.000150, 'rounding' => '90_decimal' ],
			'SGD' => [ 'symbol' => 'S$',  'rate' => 0.000130, 'rounding' => '90_decimal' ],
			'JPY' => [ 'symbol' => '¥',   'rate' => 0.015000, 'rounding' => '50_step' ],
			'GBP' => [ 'symbol' => '£',   'rate' => 0.000078, 'rounding' => '90_decimal' ],
			'CAD' => [ 'symbol' => 'CA$', 'rate' => 0.000140, 'rounding' => '90_decimal' ],
			'CHF' => [ 'symbol' => 'CHF', 'rate' => 0.000088, 'rounding' => '90_decimal' ],
			'HKD' => [ 'symbol' => 'HK$', 'rate' => 0.000780, 'rounding' => '90_decimal' ],
			'THB' => [ 'symbol' => '฿',   'rate' => 0.003300, 'rounding' => '90_end' ],
			'KRW' => [ 'symbol' => '₩',   'rate' => 0.140000, 'rounding' => '500_step' ],
		];

		$currencies = $settings['currency_rates'] ?? $default_currencies;
		if ( ! is_array( $currencies ) || empty( $currencies ) ) {
			$currencies = $default_currencies;
		} else {
			// Upgrade legacy integer USD/EUR rates if detected
			if ( isset( $currencies['USD']['rounding'] ) && '9_end' === $currencies['USD']['rounding'] && (float) ( $currencies['USD']['rate'] ?? 0 ) < 0.00008 ) {
				foreach ( [ 'USD', 'EUR', 'AUD', 'SGD', 'GBP', 'CAD', 'CHF', 'HKD' ] as $c ) {
					if ( isset( $default_currencies[ $c ] ) ) {
						$currencies[ $c ] = $default_currencies[ $c ];
					}
				}
			}
		}

		// Optional: Apply real-time Aelia exchange rates if auto-sync is enabled
		if ( ! empty( $settings['currency_auto_sync_aelia'] ) ) {
			$aelia_rates = self::get_aelia_exchange_rates();
			if ( ! empty( $aelia_rates ) ) {
				foreach ( $aelia_rates as $code => $rate ) {
					if ( isset( $currencies[ $code ] ) && $rate > 0 ) {
						$currencies[ $code ]['rate'] = (float) $rate;
					}
				}
			}
		}

		return $currencies;
	}

	public static function auto_set_aelia_currency_prices_after_save( $product, $data_store = null ) {
		if ( ! $product instanceof WC_Product ) return;
		self::auto_set_aelia_currency_prices( $product->get_id() );
	}

	/**
	 * Calculate rounded price for a given IDR base amount in any target currency using decimal or psychological rounding
	 */
	public static function calculate_price_for_currency( $amount_idr, $currency_code = 'IDR', $is_addon = false ): float {
		$currency_code = strtoupper( trim( (string) $currency_code ) );
		if ( empty( $currency_code ) || 'IDR' === $currency_code ) {
			return (float) $amount_idr;
		}

		$settings   = Exacoat_Core::get_settings();
		$markup     = floatval( $settings['currency_global_markup'] ?? 1.8 );
		$currencies = self::get_currency_rates();

		if ( ! isset( $currencies[ $currency_code ] ) ) {
			return (float) round( $amount_idr * 0.000100 * $markup, 2 );
		}

		$data          = $currencies[ $currency_code ];
		$rate          = floatval( is_array( $data ) ? ( $data['rate'] ?? 0 ) : $data );
		$rounding_type = is_array( $data ) ? ( $data['rounding'] ?? '90_decimal' ) : '90_decimal';

		if ( $rate <= 0 ) {
			return (float) $amount_idr;
		}

		$raw = $amount_idr * $rate * $markup;

		if ( $is_addon ) {
			if ( '500_step' === $rounding_type || 'KRW' === $currency_code ) {
				return (float) max( 0, ceil( $raw / 500 ) * 500 );
			}
			if ( '50_step' === $rounding_type || 'JPY' === $currency_code ) {
				return (float) max( 0, ceil( $raw / 50 ) * 50 );
			}
			if ( '90_end' === $rounding_type || 'THB' === $currency_code ) {
				return (float) max( 0, round( $raw / 10 ) * 10 );
			}
			return (float) max( 0, round( $raw ) );
		}

		switch ( $rounding_type ) {
			case '90_decimal':
				// End in .90 (e.g. 14.90, 19.90, 8.90)
				$val = ceil( $raw ) - 0.10;
				if ( $val < $raw ) {
					$val += 1.0;
				}
				$val = round( $val, 2 );
				break;

			case '99_decimal':
				// End in .99 (e.g. 14.99, 19.99)
				$val = ceil( $raw ) - 0.01;
				if ( $val < $raw ) {
					$val += 1.0;
				}
				$val = round( $val, 2 );
				break;

			case '50_decimal':
				// Step 0.50 (e.g. 14.50, 15.00)
				$val = round( ceil( $raw * 2 ) / 2, 2 );
				break;

			case '90_end':
				// Integer End in 90 (e.g. 2,790, 390)
				$val = ( ceil( $raw / 100 ) * 100 ) - 10;
				if ( $val < $raw ) {
					$val += 100;
				}
				break;

			case '500_step':
				// Integer Step 500 (e.g. 19,500, 128,500)
				$val = ceil( $raw / 500 ) * 500;
				break;

			case '50_step':
				// Integer Step 50 (e.g. 1,950, 13,900)
				$val = ceil( $raw / 50 ) * 50;
				break;

			case '9_end':
				// Integer End in 9 (e.g. 19, 89)
				$val = ( ceil( $raw / 10 ) * 10 ) - 1;
				if ( $val < $raw ) {
					$val += 10;
				}
				break;

			case 'none':
			default:
				$val = round( $raw, 2 );
				break;
		}

		return (float) max( 0, $val );
	}

	public static function get_currency_decimals( string $currency_code ): int {
		$currency_code = strtoupper( trim( $currency_code ) );
		if ( in_array( $currency_code, [ 'IDR', 'JPY', 'KRW', 'THB', 'VND' ], true ) ) {
			return 0;
		}

		$currencies = self::get_currency_rates();
		$rounding   = $currencies[ $currency_code ]['rounding'] ?? '90_decimal';

		// Integer-only regimes return 0 decimals
		if ( in_array( $rounding, [ '9_end', '90_end', '50_step', '500_step' ], true ) ) {
			return 0;
		}

		// Decimal regimes (90_decimal, 99_decimal, 50_decimal, none) return 2 decimals
		return 2;
	}

	public static function get_active_currency_decimals( $decimals ): int {
		$currency = class_exists( 'Exacoat_Checkout_Engine' )
			? Exacoat_Checkout_Engine::get_active_currency()
			: ( class_exists( 'Artmatter_Checkout_Engine' )
				? Artmatter_Checkout_Engine::get_active_currency()
				: ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'IDR' ) );
		return self::get_currency_decimals( $currency );
	}

	public static function auto_set_aelia_currency_prices( $post_id ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
		if ( wp_is_post_revision( $post_id ) ) return;

		$product = wc_get_product( $post_id );
		if ( ! $product ) return;

		$base_regular = get_post_meta( $post_id, '_regular_price', true );
		$base_sale    = get_post_meta( $post_id, '_sale_price', true );
		if ( ! is_numeric( $base_regular ) || $base_regular <= 0 ) return;

		$currencies = self::get_currency_rates();
		$regular_prices = [];
		$sale_prices    = [];

		foreach ( $currencies as $code => $data ) {
			$decimals = self::get_currency_decimals( $code );
			$regular_prices[ $code ] = number_format( self::calculate_price_for_currency( $base_regular, $code ), $decimals, '.', '' );
			if ( is_numeric( $base_sale ) && $base_sale > 0 ) {
				$sale_prices[ $code ] = number_format( self::calculate_price_for_currency( $base_sale, $code ), $decimals, '.', '' );
			}
		}

		update_post_meta( $post_id, '_regular_currency_prices', wp_json_encode( $regular_prices ) );

		if ( ! empty( $sale_prices ) ) {
			update_post_meta( $post_id, '_sale_currency_prices', wp_json_encode( $sale_prices ) );
		} else {
			delete_post_meta( $post_id, '_sale_currency_prices' );
		}
	}


	/**
	 * Handle Preview & Maintenance Bypass Cookie & Safe URL Parameters
	 * Allows testing live product pages and museum views without being redirected to coming soon or blocked by maintenance mode.
	 * Trigger params: ?preview=1, ?preview=true, ?bypass=artmatter, ?bypass=1, ?artmatter_preview=1, ?preview_mode=1
	 * Exit params: ?preview=0, ?bypass=0, ?exit_preview=1
	 */
	public static function handle_preview_bypass_cookies_and_redirects() {
		// Exit bypass mode
		if ( isset( $_GET['exit_preview'] ) || ( isset( $_GET['preview'] ) && ( $_GET['preview'] === '0' || $_GET['preview'] === 'false' ) ) || ( isset( $_GET['bypass'] ) && $_GET['bypass'] === '0' ) ) {
			if ( ! headers_sent() ) {
				setcookie( 'exacoat_preview_bypass', '', time() - 3600, '/' );
				setcookie( 'artmatter_preview_bypass', '', time() - 3600, '/' );
			}
			unset( $_COOKIE['exacoat_preview_bypass'] );
			unset( $_COOKIE['artmatter_preview_bypass'] );
			if ( ! is_admin() && ! ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
				wp_safe_redirect( home_url( '/template/coming-soon' ), 302 );
				exit;
			}
			return;
		}

		// Activate bypass mode
		$has_bypass_param = false;
		if ( isset( $_GET['bypass'] ) && ( $_GET['bypass'] === 'exacoat' || $_GET['bypass'] === 'artmatter' || $_GET['bypass'] === 'true' || $_GET['bypass'] === '1' ) ) {
			$has_bypass_param = true;
		} elseif ( isset( $_GET['preview'] ) && ( $_GET['preview'] === '1' || $_GET['preview'] === 'true' ) ) {
			$has_bypass_param = true;
		} elseif ( isset( $_GET['exacoat_preview'] ) || isset( $_GET['artmatter_preview'] ) || isset( $_GET['preview_mode'] ) || isset( $_GET['preview_auth'] ) ) {
			$has_bypass_param = true;
		}

		if ( $has_bypass_param ) {
			if ( ! headers_sent() ) {
				setcookie( 'exacoat_preview_bypass', '1', time() + ( 86400 * 7 ), '/' );
				setcookie( 'artmatter_preview_bypass', '1', time() + ( 86400 * 7 ), '/' );
			}
			$_COOKIE['exacoat_preview_bypass']   = '1';
			$_COOKIE['artmatter_preview_bypass'] = '1';
		}
	}

	public static function is_preview_bypass_active(): bool {
		if ( ( ! empty( $_COOKIE['exacoat_preview_bypass'] ) && $_COOKIE['exacoat_preview_bypass'] === '1' ) ||
		     ( ! empty( $_COOKIE['artmatter_preview_bypass'] ) && $_COOKIE['artmatter_preview_bypass'] === '1' ) ) {
			return true;
		}
		if ( isset( $_GET['bypass'] ) && ( $_GET['bypass'] === 'exacoat' || $_GET['bypass'] === 'artmatter' || $_GET['bypass'] === 'true' || $_GET['bypass'] === '1' ) ) {
			return true;
		}
		if ( isset( $_GET['preview'] ) && ( $_GET['preview'] === '1' || $_GET['preview'] === 'true' ) ) {
			return true;
		}
		if ( isset( $_GET['exacoat_preview'] ) || isset( $_GET['artmatter_preview'] ) || isset( $_GET['preview_mode'] ) || isset( $_GET['preview_auth'] ) ) {
			return true;
		}
		return false;
	}


	/**
	 * Get Shipping Zones Configuration (#14577)
	 */
	public static function get_shipping_config(): array {
		$settings = Exacoat_Core::get_settings();

		$default_zones = [
			'indonesia' => [
				'name'        => 'Domestic Indonesia',
				'countries'   => 'ID',
				'currency'    => 'IDR',
				'free'        => 300000,
				'filter_text' => 'reg',
			],
			'united_states' => [
				'name'        => 'United States',
				'countries'   => 'US',
				'currency'    => 'USD',
				'free'        => 30,
				'filter_text' => 'goorita',
			],
			'default' => [
				'name'        => 'Default (Rest of World)',
				'countries'   => '*',
				'currency'    => 'USD',
				'free'        => 50,
				'filter_text' => 'pos',
			],
		];

		$target_methods_raw = $settings['shipping_target_method_ids'] ?? 'flat_rate, biteship_shipping';
		$target_methods     = array_values( array_filter( array_map( 'trim', explode( ',', $target_methods_raw ) ) ) );
		if ( ! in_array( 'biteship_shipping', $target_methods, true ) ) {
			$target_methods[] = 'biteship_shipping';
		}

		$zones = $settings['shipping_zones'] ?? $default_zones;
		if ( ! is_array( $zones ) || empty( $zones ) ) {
			$zones = $default_zones;
		} else {
			// Migrate legacy IDR-scaled zone amounts or missing currency keys
			foreach ( $zones as $k => &$z ) {
				$z_curr = strtoupper( trim( $z['currency'] ?? '' ) );
				if ( empty( $z_curr ) ) {
					$c_raw = strtoupper( $z['countries'] ?? '' );
					if ( strpos( $c_raw, 'US' ) !== false ) $z_curr = 'USD';
					elseif ( strpos( $c_raw, 'ID' ) !== false ) $z_curr = 'IDR';
					elseif ( strpos( $c_raw, 'SG' ) !== false || strpos( $c_raw, 'MY' ) !== false ) $z_curr = 'SGD';
					elseif ( strpos( $c_raw, 'AU' ) !== false ) $z_curr = 'AUD';
					elseif ( strpos( $c_raw, 'GB' ) !== false ) $z_curr = 'GBP';
					elseif ( strpos( $c_raw, 'DE' ) !== false || strpos( $c_raw, 'FR' ) !== false || strpos( $c_raw, 'IT' ) !== false ) $z_curr = 'EUR';
					else $z_curr = ( (float)( $z['free'] ?? 0 ) > 50000 ) ? 'IDR' : 'USD';
					$z['currency'] = $z_curr;
				}
				$free_val = (float) ( $z['free'] ?? 0 );
				// If legacy threshold is in IDR (> 10,000) for a non-IDR zone, migrate to default native or converted amount
				if ( 'IDR' !== $z_curr && $free_val > 10000 ) {
					if ( isset( $default_zones[ $k ]['free'] ) && $default_zones[ $k ]['currency'] === $z_curr ) {
						$z['free'] = $default_zones[ $k ]['free'];
					} else {
						$converted = (float) apply_filters( 'wc_aelia_cs_convert', $free_val, 'IDR', $z_curr );
						$z['free'] = $converted > 0 ? round( $converted, 2 ) : 30;
					}
				}
				// If legacy Artmatter threshold (>= 1,500,000 IDR or >= 180 USD/EUR) is found, migrate to Exacoat skin defaults
				if ( 'IDR' === $z_curr && $free_val >= 1500000 ) {
					$z['free'] = 300000;
				} elseif ( in_array( $z_curr, [ 'USD', 'EUR', 'GBP', 'AUD', 'SGD' ], true ) && $free_val >= 180 ) {
					if ( isset( $default_zones[ $k ]['free'] ) ) {
						$z['free'] = $default_zones[ $k ]['free'];
					} else {
						$z['free'] = ( 'united_states' === $k ) ? 30 : 50;
					}
				}
			}
			unset( $z );
		}

		return [
			'target_method_ids' => $target_methods,
			'zones'             => $zones,
		];
	}

	/**
	 * Get Shipping Promo / Coupon Configuration
	 */
	public static function get_shipping_promo_config(): array {
		$settings = Exacoat_Core::get_settings();
		return [
			'enabled'      => isset( $settings['shipping_promo_enabled'] ) ? (bool) $settings['shipping_promo_enabled'] : true,
			'code'         => strtoupper( trim( (string) ( $settings['shipping_promo_code'] ?? 'ONGKIR15' ) ) ),
			'max_discount' => floatval( $settings['shipping_promo_max_discount'] ?? 15000 ),
			'filter_text'  => strtolower( trim( (string) ( $settings['shipping_promo_filter_text'] ?? 'reg' ) ) ),
			'currency'     => strtoupper( trim( (string) ( $settings['shipping_promo_currency'] ?? 'IDR' ) ) ),
		];
	}

	/**
	 * Apply adaptive shipping discount for shipping promo coupon in classic/REST WC checkout
	 */
	public static function apply_shipping_promo_coupon_rate_discount( $rates, $package ) {
		if ( is_admin() && ! defined( 'DOING_AJAX' ) ) return $rates;
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) return $rates;

		$promo = self::get_shipping_promo_config();
		if ( empty( $promo['enabled'] ) || empty( $promo['code'] ) ) return $rates;

		$applied = (array) WC()->cart->get_applied_coupons();
		$has_coupon = in_array( strtoupper( $promo['code'] ), array_map( 'strtoupper', $applied ), true );
		if ( ! $has_coupon ) return $rates;

		$filter_text  = strtolower( trim( $promo['filter_text'] ?: 'reg' ) );
		$max_discount = floatval( $promo['max_discount'] ?: 15000 );

		foreach ( $rates as $rate_id => $rate ) {
			if ( ! is_object( $rate ) || ! isset( $rate->cost ) ) continue;

			$label = strtolower( (string) ( $rate->label ?? '' ) );
			$id    = strtolower( (string) ( $rate->id ?? '' ) );

			if ( strpos( $label, $filter_text ) !== false || strpos( $id, $filter_text ) !== false ) {
				$orig_cost = floatval( $rate->cost );
				if ( $orig_cost > 0 ) {
					$discount   = min( $orig_cost, $max_discount );
					$rate->cost = max( 0, $orig_cost - $discount );
					$rate->add_meta_data( '_shipping_promo_discount', $discount, true );
					$rate->add_meta_data( '_shipping_promo_code', $promo['code'], true );
				}
			}
		}

		return $rates;
	}

	/**
	 * Filter out legacy or internal WooCommerce shipping methods (e.g. Stock Adjustment, Redeem, Endorsement, Penyesuaian Stok, Klaim Garansi).
	 * These must never be displayed in the storefront, cart, or Store API packages.
	 */
	public static function filter_legacy_shipping_rates( $rates, $package ) {
		if ( ! is_array( $rates ) ) return $rates;

		foreach ( $rates as $rate_id => $rate ) {
			$label     = strtolower( (string) ( $rate->label ?? '' ) );
			$id        = strtolower( (string) ( $rate->id ?? '' ) );
			$method_id = strtolower( (string) ( $rate->method_id ?? '' ) );

			$is_legacy = (
				preg_match( '/stock\s*adjustment|penyesuaian\s*stok|penyesuaian|redeem|endorsement|klaim/i', $label ) ||
				preg_match( '/stock|redeem|endorse/i', $id ) ||
				preg_match( '/stock|redeem|endorse/i', $method_id )
			);

			if ( $is_legacy ) {
				unset( $rates[ $rate_id ] );
			}
		}

		return $rates;
	}

	/**
	 * Sanitize shipping method title to strip messy applied promo tags (e.g. "(FREE SHIPPING Applied)", "(ONGKIR10 Applied)"),
	 * preserving clean courier service names like "SICEPAT - REG" or "JNE - REG".
	 */
	public static function clean_shipping_method_title( $title, $item = null ) {
		if ( empty( $title ) || ! is_string( $title ) ) {
			return $title;
		}

		$clean = preg_replace( '/\s*[\(\[]\s*[^)\]]*applied[^)\]]*[\)\]]/i', '', $title );
		$clean = preg_replace( '/\s*\[[^\]]*applied[^\]]*\]/i', '', $clean );
		$clean = preg_replace( '/\s*[\(\[]\s*free\s*shipping\s*[\)\]]/i', '', $clean );
		$clean = preg_replace( '/\s*[-–—:]\s*free\s*shipping\b/i', '', $clean );

		return trim( preg_replace( '/\s{2,}/', ' ', $clean ) );
	}

	/**
	 * Apply global currency markup buffer to shipping costs for non-base currencies (#14577).
	 * Ensures shipping rates in foreign currencies (USD, SGD, EUR, AUD, etc.) apply the configured
	 * safety markup buffer, protecting against payment gateway FX volatility and spreads.
	 */
	public static function apply_currency_markup_to_shipping_rates( $rates, $package ) {
		if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
			return $rates;
		}
		if ( ! is_array( $rates ) || empty( $rates ) ) {
			return $rates;
		}

		$active_currency = class_exists( 'Exacoat_Checkout_Engine' )
			? Exacoat_Checkout_Engine::get_active_currency()
			: ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'IDR' );

		// IDR is the shop base currency; raw carrier rates apply without FX markup
		if ( 'IDR' === $active_currency ) {
			return $rates;
		}

		$settings = class_exists( 'Exacoat_Core' ) ? Exacoat_Core::get_settings() : [];
		$markup   = floatval( $settings['currency_global_markup'] ?? 1.15 );
		if ( $markup <= 1.0 ) {
			return $rates;
		}

		foreach ( $rates as $rate_id => $rate ) {
			if ( ! $rate instanceof WC_Shipping_Rate ) {
				continue;
			}

			// Prevent duplicate markup application across cart recalculation loops
			$meta = $rate->get_meta_data();
			if ( ! empty( $meta['_shipping_markup_applied'] ) ) {
				continue;
			}

			$cost = floatval( $rate->get_cost() );
			if ( $cost <= 0 ) {
				continue;
			}

			// If rate was not converted to active currency by Aelia (e.g. still in IDR units >= 500)
			if ( $cost >= 500 && ! in_array( $active_currency, [ 'IDR', 'JPY', 'KRW', 'VND' ], true ) ) {
				$currencies = self::get_currency_rates();
				$rate_val   = floatval( $currencies[ $active_currency ]['rate'] ?? 0 );
				$marked_up_cost = $rate_val > 0 ? round( $cost * $rate_val * $markup, 2 ) : round( $cost * $markup, 2 );
			} else {
				$marked_up_cost = round( $cost * $markup, 2 );
			}

			$rate->set_cost( $marked_up_cost );

			// Re-scale tax amounts proportionally if present
			$taxes = $rate->get_taxes();
			if ( ! empty( $taxes ) && is_array( $taxes ) ) {
				$new_taxes = [];
				foreach ( $taxes as $tax_id => $tax_val ) {
					$new_taxes[ $tax_id ] = round( floatval( $tax_val ) * $markup, 2 );
				}
				$rate->set_taxes( $new_taxes );
			}

			$rate->add_meta_data( '_shipping_markup_applied', (string) $markup, true );
			$rate->add_meta_data( '_shipping_raw_cost_before_markup', (string) $cost, true );
		}

		return $rates;
	}

	/**
	 * Apply Multi-Zone Tiered Free Shipping Discount (#14577)
	 */
	public static function apply_zone_tiered_shipping_discount( $rates, $package ) {
		if ( is_admin() && ! defined( 'DOING_AJAX' ) ) return $rates;

		$config     = self::get_shipping_config();
		$target_ids = $config['target_method_ids'];
		$zones      = $config['zones'];

		$country    = strtoupper( trim( $package['destination']['country'] ?? 'ID' ) );
		$cart_total = ( function_exists( 'WC' ) && WC()->cart ) ? (float) WC()->cart->get_displayed_subtotal() : 0.0;

		$active_currency = class_exists( 'Exacoat_Checkout_Engine' )
			? Exacoat_Checkout_Engine::get_active_currency()
			: ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'IDR' );

		// Normalize cart total to IDR base currency for comparison against IDR-configured zone thresholds
		$cart_total_idr = $cart_total;
		if ( 'IDR' !== $active_currency ) {
			$currencies = self::get_currency_rates();
			$rate_val   = floatval( $currencies[ $active_currency ]['rate'] ?? 0 );
			if ( $rate_val > 0 ) {
				$cart_total_idr = $cart_total / $rate_val;
			}
		}

		// Match destination country (supports specific ISO codes, comma-separated lists, and wildcard * / ALL)
		$matched_zone  = null;
		$fallback_zone = null;
		foreach ( $zones as $z_key => $zone ) {
			if ( empty( $zone['countries'] ) ) continue;
			$c_list = array_map( 'trim', explode( ',', strtoupper( $zone['countries'] ) ) );
			if ( in_array( $country, $c_list, true ) ) {
				$matched_zone = $zone;
				break;
			}
			if ( ! $fallback_zone && ( in_array( '*', $c_list, true ) || in_array( 'ALL', $c_list, true ) || 'default' === $z_key ) ) {
				$fallback_zone = $zone;
			}
		}

		// Fallback to wildcard or default zone if country did not match a specific zone
		if ( ! $matched_zone ) {
			$matched_zone = $fallback_zone ?: ( $zones['default'] ?? null );
		}

		if ( ! $matched_zone ) {
			return $rates;
		}
		$free_thresh = floatval( $matched_zone['free'] ?? 0 );
		$zone_curr   = strtoupper( trim( $matched_zone['currency'] ?? '' ) );
		if ( empty( $zone_curr ) ) {
			$zone_curr = ( $free_thresh > 50000 ) ? 'IDR' : 'USD';
		}

		$effective_threshold = $free_thresh;
		if ( $zone_curr !== $active_currency ) {
			if ( 'IDR' === $zone_curr ) {
				$converted = apply_filters( 'wc_aelia_cs_convert', $free_thresh, 'IDR', $active_currency );
				if ( (float) $converted === (float) $free_thresh && $active_currency !== 'IDR' ) {
					$currencies = self::get_currency_rates();
					$rate_val   = floatval( $currencies[ $active_currency ]['rate'] ?? 0 );
					$effective_threshold = $rate_val > 0 ? ( $free_thresh * $rate_val ) : $free_thresh;
				} else {
					$effective_threshold = (float) $converted;
				}
			} else {
				$thresh_idr = (float) apply_filters( 'wc_aelia_cs_convert', $free_thresh, $zone_curr, 'IDR' );
				if ( (float) $thresh_idr === (float) $free_thresh && $zone_curr !== 'IDR' ) {
					$currencies = self::get_currency_rates();
					$rate_val   = floatval( $currencies[ $zone_curr ]['rate'] ?? 0 );
					$thresh_idr = $rate_val > 0 ? ( $free_thresh / $rate_val ) : $free_thresh;
				}
				$converted = apply_filters( 'wc_aelia_cs_convert', $thresh_idr, 'IDR', $active_currency );
				if ( (float) $converted === (float) $thresh_idr && $active_currency !== 'IDR' ) {
					$currencies = self::get_currency_rates();
					$rate_val   = floatval( $currencies[ $active_currency ]['rate'] ?? 0 );
					$effective_threshold = $rate_val > 0 ? ( $thresh_idr * $rate_val ) : $thresh_idr;
				} else {
					$effective_threshold = (float) $converted;
				}
			}
		}

		$is_free_qualified = ( $effective_threshold > 0 && $cart_total >= $effective_threshold );
		$filter_text       = trim( strtolower( (string) ( $matched_zone['filter_text'] ?? '' ) ) );

		// Defensive fallback for filter_text if left blank in zone settings
		if ( empty( $filter_text ) ) {
			if ( 'ID' === $country ) {
				$filter_text = 'reg';
			} elseif ( 'US' === $country ) {
				$filter_text = 'goorita';
			} else {
				$filter_text = 'pos';
			}
		}

		foreach ( $rates as $rate_id => $rate ) {
			$rate_label = strtolower( (string) $rate->label );
			$rate_id_s  = strtolower( (string) $rate->id );

			// Legacy methods must NEVER receive free shipping discounts or be modified
			$is_legacy = (
				preg_match( '/stock\s*adjustment|penyesuaian\s*stok|penyesuaian|redeem|endorsement|klaim/i', $rate_label ) ||
				preg_match( '/stock|redeem|endorse/i', $rate_id_s )
			);
			if ( $is_legacy ) {
				unset( $rates[ $rate_id ] );
				continue;
			}

			$is_biteship = ( strpos( $rate->id, 'biteship_shipping' ) !== false || ( isset( $rate->method_id ) && 'biteship_shipping' === $rate->method_id ) );

			// Target method ID verification
			if ( ! empty( $target_ids ) ) {
				$matched_method = false;
				foreach ( $target_ids as $tid ) {
					if ( strpos( $rate->id, $tid ) !== false || ( isset( $rate->method_id ) && $rate->method_id === $tid ) ) {
						$matched_method = true;
						break;
					}
				}
				// Biteship rates always pass method ID verification so filter_text applies cleanly
				if ( ! $matched_method && $is_biteship ) {
					$matched_method = true;
				}
				if ( ! $matched_method ) continue;
			}

			$is_flat_rate = ( isset( $rate->method_id ) && 'flat_rate' === $rate->method_id ) || ( strpos( $rate_id_s, 'flat_rate' ) !== false );

			// Guard against expensive express/freight carriers (DHL, FedEx, UPS, Cargo, Trucking, Same Day, Instant)
			// These must NEVER receive free shipping unless filter_text explicitly targets them
			$is_premium_express = (
				strpos( $rate_label, 'dhl' ) !== false ||
				strpos( $rate_label, 'fedex' ) !== false ||
				strpos( $rate_label, 'ups' ) !== false ||
				strpos( $rate_label, 'cargo' ) !== false ||
				strpos( $rate_label, 'trucking' ) !== false ||
				strpos( $rate_label, 'same day' ) !== false ||
				strpos( $rate_label, 'instant' ) !== false ||
				strpos( $rate_id_s, 'dhl' ) !== false ||
				strpos( $rate_id_s, 'fedex' ) !== false ||
				strpos( $rate_id_s, 'cargo' ) !== false
			);

			$filter_specifically_wants_premium = (
				( strpos( $filter_text, 'dhl' ) !== false && ( strpos( $rate_label, 'dhl' ) !== false || strpos( $rate_id_s, 'dhl' ) !== false ) ) ||
				( strpos( $filter_text, 'fedex' ) !== false && ( strpos( $rate_label, 'fedex' ) !== false || strpos( $rate_id_s, 'fedex' ) !== false ) ) ||
				( strpos( $filter_text, 'ups' ) !== false && ( strpos( $rate_label, 'ups' ) !== false || strpos( $rate_id_s, 'ups' ) !== false ) )
			);

			if ( $is_premium_express && ! $filter_specifically_wants_premium ) {
				// Premium carrier can never be discounted to free unless explicitly configured
				continue;
			}

			// Filter text check (e.g. 'pos', 'goorita', 'reg')
			$matches_text = false;
			if ( ! empty( $filter_text ) ) {
				$matches_text = ( strpos( $rate_label, $filter_text ) !== false || strpos( $rate_id_s, $filter_text ) !== false );
			}

			if ( ! $matches_text ) {
				continue;
			}

			// 100% Free Shipping Rule
			$existing_meta = method_exists( $rate, 'get_meta_data' ) ? $rate->get_meta_data() : [];
			$orig_cost     = null;
			if ( ! empty( $existing_meta ) && is_array( $existing_meta ) ) {
				foreach ( $existing_meta as $mk => $mv ) {
					if ( 'original_cost' === $mk || ( is_object( $mv ) && isset( $mv->key ) && 'original_cost' === $mv->key ) ) {
						$orig_cost = is_object( $mv ) ? $mv->value : $mv;
						break;
					}
				}
			}
			if ( null === $orig_cost && floatval( $rate->cost ) > 0 ) {
				$orig_cost = floatval( $rate->cost );
			}

			if ( $is_free_qualified ) {
				if ( $orig_cost > 0 && method_exists( $rate, 'add_meta_data' ) ) {
					$rate->add_meta_data( 'original_cost', (string) $orig_cost, true );
					$rate->add_meta_data( 'is_free_shipping', '1', true );
				}
				$rate->cost = 0;
			}
		}

		return $rates;
	}

	/**
	 * 18. Prevent infinite 301 redirect loops when static uploads (images, PDFs) 404.
	 */
	public static function prevent_upload_404_redirect_loop( $redirect_url, $requested_url ) {
		if ( strpos( $requested_url, '/wp-content/uploads/' ) !== false ) {
			return false;
		}
		return $redirect_url;
	}

	/**
	 * Virtual Upload Folder Path Resolver.
	 *
	 * Intercepts requests to virtual upload paths (e.g. /wp-content/uploads/Assets/Image/Skin Textures/<file>)
	 * where folders are virtual only and not physically present on disk.
	 * Resolves to the physical file in the root uploads directory or media library,
	 * and serves the asset with full browser/edge caching and CORS headers.
	 */
	public static function resolve_virtual_upload() {
		if ( empty( $_SERVER['REQUEST_URI'] ) ) {
			return;
		}

		$request_uri = (string) $_SERVER['REQUEST_URI'];
		if ( strpos( $request_uri, '/wp-content/uploads/' ) === false ) {
			return;
		}

		$parsed_path = parse_url( $request_uri, PHP_URL_PATH );
		if ( empty( $parsed_path ) ) {
			return;
		}

		$decoded_path  = rawurldecode( $parsed_path );
		$upload_marker = '/wp-content/uploads/';
		$pos           = strpos( $decoded_path, $upload_marker );
		if ( false === $pos ) {
			return;
		}

		$rel_path = ltrim( substr( $decoded_path, $pos + strlen( $upload_marker ) ), '/' );
		if ( empty( $rel_path ) ) {
			return;
		}

		$upload_dir = wp_upload_dir();
		$basedir    = wp_normalize_path( $upload_dir['basedir'] );

		// If physical file exists at exact relative path, serve directly
		$exact_physical = $basedir . '/' . $rel_path;
		if ( file_exists( $exact_physical ) && is_file( $exact_physical ) ) {
			self::serve_virtual_file( $exact_physical );
			exit;
		}

		// Virtual folder path: resolve physical file location
		$filename = wp_basename( $rel_path );
		if ( empty( $filename ) ) {
			return;
		}

		$resolved_file = self::locate_physical_upload( $filename, $rel_path, $basedir );
		if ( empty( $resolved_file ) || ! file_exists( $resolved_file ) || ! is_file( $resolved_file ) ) {
			return;
		}

		$clean_rel_found = ltrim( str_replace( $basedir, '', wp_normalize_path( $resolved_file ) ), '/' );
		$canonical_url   = trailingslashit( $upload_dir['baseurl'] ) . $clean_rel_found;

		$force_redirect = ! empty( $_GET['redirect'] ) || apply_filters( 'exacoat_virtual_upload_redirect', false );
		if ( $force_redirect ) {
			wp_safe_redirect( $canonical_url, 301 );
			exit;
		}

		self::serve_virtual_file( $resolved_file, $canonical_url );
		exit;
	}

	/**
	 * Revert any nested Assets/ uploads back to root /wp-content/uploads/.
	 * Moves nested files to root, removes empty folders, and cleans attachment meta in database.
	 */
	public static function revert_assets_to_flat_uploads(): array {
		$upload_dir = wp_upload_dir();
		$basedir    = wp_normalize_path( $upload_dir['basedir'] );
		$assets_dir = $basedir . '/Assets';

		$files_moved        = 0;
		$files_deduplicated = 0;
		$dirs_removed       = 0;
		$meta_updated       = 0;
		$errors             = [];

		if ( is_dir( $assets_dir ) ) {
			try {
				$iterator = new RecursiveIteratorIterator(
					new RecursiveDirectoryIterator( $assets_dir, RecursiveDirectoryIterator::SKIP_DOTS ),
					RecursiveIteratorIterator::CHILD_FIRST
				);

				foreach ( $iterator as $item ) {
					$item_path = wp_normalize_path( $item->getPathname() );

					if ( $item->isFile() ) {
						$filename    = $item->getFilename();
						$target_path = $basedir . '/' . $filename;

						if ( file_exists( $target_path ) ) {
							// Root file already exists; safely remove nested duplicate
							@unlink( $item_path );
							$files_deduplicated++;
						} else {
							// Move nested file to root uploads
							$moved = @rename( $item_path, $target_path );
							if ( ! $moved ) {
								$moved = @copy( $item_path, $target_path );
								if ( $moved ) {
									@unlink( $item_path );
								}
							}
							if ( $moved ) {
								$files_moved++;
							} else {
								$errors[] = 'Failed to move: ' . $filename;
							}
						}
					} elseif ( $item->isDir() ) {
						if ( @rmdir( $item_path ) ) {
							$dirs_removed++;
						}
					}
				}

				if ( is_dir( $assets_dir ) ) {
					@rmdir( $assets_dir );
				}
			} catch ( \Throwable $e ) {
				$errors[] = $e->getMessage();
			}
		}

		// Update database postmeta references
		global $wpdb;
		if ( isset( $wpdb->postmeta ) ) {
			$meta_rows = $wpdb->get_results(
				"SELECT meta_id, post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_wp_attached_file' AND meta_value LIKE 'Assets/%'"
			);

			if ( ! empty( $meta_rows ) ) {
				foreach ( $meta_rows as $row ) {
					$old_val = (string) $row->meta_value;
					$new_val = wp_basename( $old_val );
					if ( $new_val !== $old_val ) {
						$updated = $wpdb->update(
							$wpdb->postmeta,
							[ 'meta_value' => $new_val ],
							[ 'meta_id' => $row->meta_id ]
						);
						if ( false !== $updated ) {
							$meta_updated++;
						}
					}
				}
			}

			if ( isset( $wpdb->posts ) ) {
				$wpdb->query(
					"UPDATE {$wpdb->posts} SET guid = REPLACE(guid, '/wp-content/uploads/Assets/Image/Skin Textures/', '/wp-content/uploads/') WHERE post_type = 'attachment' AND guid LIKE '%/wp-content/uploads/Assets/%'"
				);
				$wpdb->query(
					"UPDATE {$wpdb->posts} SET guid = REPLACE(guid, '/wp-content/uploads/Assets/', '/wp-content/uploads/') WHERE post_type = 'attachment' AND guid LIKE '%/wp-content/uploads/Assets/%'"
				);
			}
		}

		return [
			'status'             => empty( $errors ) ? 'success' : 'partial',
			'files_moved'        => $files_moved,
			'files_deduplicated' => $files_deduplicated,
			'dirs_removed'       => $dirs_removed,
			'meta_updated'       => $meta_updated,
			'errors'             => $errors,
			'message'            => sprintf(
				'Media consolidation complete: %d file(s) moved to root /uploads, %d duplicate(s) cleaned, %d database record(s) updated.',
				$files_moved,
				$files_deduplicated,
				$meta_updated
			),
		];
	}

	/**
	 * Locate physical file on disk for a virtual upload filename.
	 */
	public static function locate_physical_upload( $filename, $rel_path = '', $basedir = '' ) {
		if ( empty( $basedir ) ) {
			$upload_dir = wp_upload_dir();
			$basedir    = wp_normalize_path( $upload_dir['basedir'] );
		}

		// 1. Check flat in root uploads directory
		$flat_path = $basedir . '/' . $filename;
		if ( file_exists( $flat_path ) && is_file( $flat_path ) ) {
			return $flat_path;
		}

		// 2. Variations in spaces, hyphens, and underscores
		$variations = [
			str_replace( ' ', '-', $filename ),
			str_replace( '-', ' ', $filename ),
			str_replace( [ ' ', '-' ], '_', $filename ),
			str_replace( '_', '-', $filename ),
		];
		foreach ( array_unique( $variations ) as $var_name ) {
			if ( $var_name !== $filename ) {
				$test_path = $basedir . '/' . $var_name;
				if ( file_exists( $test_path ) && is_file( $test_path ) ) {
					return $test_path;
				}
			}
		}

		// 3. Strip 'Assets/' or 'Assets/Image/' prefix if intermediate folders physically exist
		if ( ! empty( $rel_path ) ) {
			$stripped = preg_replace( '#^Assets/(?:Image/)?#i', '', $rel_path );
			if ( ! empty( $stripped ) && $stripped !== $rel_path ) {
				$test_path = $basedir . '/' . $stripped;
				if ( file_exists( $test_path ) && is_file( $test_path ) ) {
					return $test_path;
				}
			}
		}

		// 4. WebP / original extension cross-lookup
		$ext         = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );
		$name_no_ext = pathinfo( $filename, PATHINFO_FILENAME );
		if ( in_array( $ext, [ 'jpg', 'jpeg', 'png' ], true ) ) {
			$webp_test = $basedir . '/' . $name_no_ext . '.webp';
			if ( file_exists( $webp_test ) && is_file( $webp_test ) ) {
				return $webp_test;
			}
		} elseif ( 'webp' === $ext ) {
			foreach ( [ 'jpg', 'jpeg', 'png' ] as $fallback_ext ) {
				$img_test = $basedir . '/' . $name_no_ext . '.' . $fallback_ext;
				if ( file_exists( $img_test ) && is_file( $img_test ) ) {
					return $img_test;
				}
			}
		}

		// 5. Query WordPress attachment database meta (_wp_attached_file)
		global $wpdb;
		if ( $wpdb instanceof wpdb || ( is_object( $wpdb ) && method_exists( $wpdb, 'get_var' ) ) ) {
			$attached = $wpdb->get_var( $wpdb->prepare(
				"SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_wp_attached_file' AND ( meta_value = %s OR meta_value LIKE %s ) LIMIT 1",
				$filename,
				'%' . $wpdb->esc_like( '/' . $filename )
			) );
			if ( ! empty( $attached ) ) {
				$db_path = $basedir . '/' . ltrim( $attached, '/' );
				if ( file_exists( $db_path ) && is_file( $db_path ) ) {
					return $db_path;
				}
			}
		}

		return null;
	}

	/**
	 * Output physical file stream with headers for client/edge caching and CORS.
	 */
	public static function serve_virtual_file( $filepath, $canonical_url = '' ) {
		if ( ! file_exists( $filepath ) || ! is_readable( $filepath ) ) {
			return;
		}

		$filesize   = (int) filesize( $filepath );
		$filemtime  = (int) filemtime( $filepath );
		$filetype   = function_exists( 'wp_check_filetype' ) ? wp_check_filetype( $filepath ) : [];
		$mime_type  = ! empty( $filetype['type'] ) ? $filetype['type'] : ( function_exists( 'mime_content_type' ) ? mime_content_type( $filepath ) : 'image/jpeg' );
		$etag       = '"' . md5( $filemtime . '_' . $filesize ) . '"';
		$last_mod   = gmdate( 'D, d M Y H:i:s', $filemtime ) . ' GMT';

		if ( isset( $_SERVER['HTTP_IF_NONE_MATCH'] ) && trim( (string) $_SERVER['HTTP_IF_NONE_MATCH'] ) === $etag ) {
			if ( function_exists( 'status_header' ) ) {
				status_header( 304 );
			} else {
				header( 'HTTP/1.1 304 Not Modified' );
			}
			exit;
		}
		if ( isset( $_SERVER['HTTP_IF_MODIFIED_SINCE'] ) && strtotime( (string) $_SERVER['HTTP_IF_MODIFIED_SINCE'] ) >= $filemtime ) {
			if ( function_exists( 'status_header' ) ) {
				status_header( 304 );
			} else {
				header( 'HTTP/1.1 304 Not Modified' );
			}
			exit;
		}

		if ( function_exists( 'status_header' ) ) {
			status_header( 200 );
		} else {
			header( 'HTTP/1.1 200 OK' );
		}

		header( 'Content-Type: ' . $mime_type );
		header( 'Content-Length: ' . $filesize );
		header( 'ETag: ' . $etag );
		header( 'Last-Modified: ' . $last_mod );
		header( 'Cache-Control: public, max-age=31536000, immutable' );
		header( 'Access-Control-Allow-Origin: *' );
		header( 'Access-Control-Allow-Methods: GET, HEAD, OPTIONS' );
		header( 'Access-Control-Allow-Headers: *' );
		header( 'X-Virtual-Upload: resolved' );

		if ( ! empty( $canonical_url ) ) {
			header( 'Link: <' . esc_url( $canonical_url ) . '>; rel="canonical"' );
		}

		$request_method = strtoupper( (string) ( $_SERVER['REQUEST_METHOD'] ?? 'GET' ) );
		if ( in_array( $request_method, [ 'HEAD', 'OPTIONS' ], true ) ) {
			exit;
		}

		while ( ob_get_level() ) {
			ob_end_clean();
		}

		readfile( $filepath );
		exit;
	}

	/**
	 * Normalize attachment URLs that reference virtual folders.
	 */
	public static function filter_virtual_attachment_url( $url, $post_id = 0 ) {
		if ( empty( $url ) || strpos( $url, '/wp-content/uploads/' ) === false ) {
			return $url;
		}

		if ( preg_match( '#/wp-content/uploads/Assets/(.+)$#i', $url, $matches ) ) {
			$clean_rel  = ltrim( parse_url( $matches[1], PHP_URL_PATH ) ?: $matches[1], '/' );
			$upload_dir = wp_upload_dir();
			$basedir    = wp_normalize_path( $upload_dir['basedir'] );

			if ( ! file_exists( $basedir . '/Assets/' . $clean_rel ) ) {
				$filename = wp_basename( $clean_rel );
				if ( file_exists( $basedir . '/' . $filename ) ) {
					return trailingslashit( $upload_dir['baseurl'] ) . $filename;
				}
			}
		}

		return $url;
	}

	/**
	 * 19. Add Print Finish (FeelForm 3D vs Flat) to WooCommerce Cart Item
	 */
	public static function add_print_finish_to_cart_item( $cart_item_data, $product_id, $variation_id ) {
		$finish = '';
		if ( ! empty( $_POST['print_finish'] ) ) {
			$finish = sanitize_text_field( wp_unslash( $_POST['print_finish'] ) );
		} elseif ( ! empty( $_POST['finish'] ) ) {
			$finish = sanitize_text_field( wp_unslash( $_POST['finish'] ) );
		} elseif ( ! empty( $_POST['feelform_mode'] ) ) {
			$finish = sanitize_text_field( wp_unslash( $_POST['feelform_mode'] ) );
		} elseif ( ! empty( $_GET['print_finish'] ) ) {
			$finish = sanitize_text_field( wp_unslash( $_GET['print_finish'] ) );
		}

		if ( ! empty( $finish ) ) {
			$is_flat = ( stripos( $finish, 'flat' ) !== false || $finish === '2d' || $finish === 'classic' || $finish === 'standard' );
			$cart_item_data['print_finish'] = $is_flat ? 'flat' : 'feelform';
			$cart_item_data['print_finish_label'] = $is_flat ? 'Flat (Classic)' : 'FeelForm™';
			$cart_item_data['unique_key'] = md5( microtime() . rand() );
		}

		return $cart_item_data;
	}

	/**
	 * Display Print Finish in Cart & Checkout
	 */
	public static function display_print_finish_in_cart( $item_data, $cart_item ) {
		if ( ! empty( $cart_item['print_finish_label'] ) ) {
			$item_data[] = [
				'key'   => __( 'Print Finish', 'exacoat-core' ),
				'value' => esc_html( $cart_item['print_finish_label'] ),
			];
		}
		return $item_data;
	}

	/**
	 * Save Print Finish to WooCommerce Order Line Item Meta
	 */
	public static function save_print_finish_to_order_item( $item, $cart_item_key, $values, $order ) {
		if ( ! empty( $values['print_finish'] ) ) {
			$item->add_meta_data( 'print_finish', $values['print_finish'], true );
			$item->add_meta_data( 'Print Finish', $values['print_finish_label'] ?? ucfirst( $values['print_finish'] ), true );
			$item->add_meta_data( 'feelform_mode', $values['print_finish'], true );
		}
	}

	/**
	 * Filter WooCommerce Cart & Checkout Item Thumbnail to use WebP for Products
	 */
	public static function filter_cart_item_thumbnail_webp( $thumbnail, $cart_item, $cart_item_key ) {
		$product_id = (int) ( $cart_item['product_id'] ?? 0 );
		if ( ! $product_id ) {
			return $thumbnail;
		}

		$webp_url = class_exists( 'Artmatter_Feelform_3D' ) ? Artmatter_Feelform_3D::get_tactile_flat_preview_url( $product_id ) : '';

		if ( ! empty( $webp_url ) ) {
			$product = $cart_item['data'] ?? ( function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : null );
			$title = $product ? $product->get_name() : get_the_title( $product_id );
			return sprintf(
				'<img src="%s" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail artmatter-cart-webp-thumb" alt="%s" loading="lazy" style="aspect-ratio:32/45;object-fit:cover;border-radius:0;" />',
				esc_url( $webp_url ),
				esc_attr( $title )
			);
		}

		return $thumbnail;
	}

	/**
	 * Filter Admin/Email Order Item Thumbnail to use WebP for Products
	 */
	public static function filter_order_item_thumbnail_webp( $thumbnail, $item_id, $item ) {
		if ( ! is_object( $item ) || ! method_exists( $item, 'get_product_id' ) ) {
			return $thumbnail;
		}

		$product_id = (int) $item->get_product_id();
		if ( ! $product_id ) {
			return $thumbnail;
		}

		$is_metal_poster = class_exists( 'Artmatter_Artwork_Vault' )
			? Artmatter_Artwork_Vault::is_metal_poster( $product_id )
			: true;

		if ( ! $is_metal_poster ) {
			return $thumbnail;
		}

		$webp_url = class_exists( 'Artmatter_Feelform_3D' ) ? Artmatter_Feelform_3D::get_tactile_flat_preview_url( $product_id ) : '';

		if ( ! empty( $webp_url ) ) {
			$product = $item->get_product();
			$title = $product ? $product->get_name() : get_the_title( $product_id );
			return sprintf(
				'<img src="%s" width="60" height="84" class="attachment-60x84 size-60x84 artmatter-order-webp-thumb" alt="%s" style="aspect-ratio:32/45;object-fit:cover;border-radius:0;" />',
				esc_url( $webp_url ),
				esc_attr( $title )
			);
		}

		return $thumbnail;
	}

	/**
	 * Selective WooCommerce Asset Decoupling
	 * Prevents heavy WooCommerce CSS/JS from loading on non-eCommerce pages (e.g. /journal/, about, homepage)
	 */
	public static function maybe_unload_wc_assets_on_non_shop() {
		if ( ! function_exists( 'is_woocommerce' ) ) {
			return;
		}

		$speed = class_exists( 'Exacoat_Performance_Auditor' ) 
			? Exacoat_Performance_Auditor::get_speed_settings() 
			: [ 'selective_wc_assets' => 1 ];

		if ( empty( $speed['selective_wc_assets'] ) ) {
			return;
		}

		// Keep assets on WooCommerce store pages, cart, checkout, account, product, or shop taxonomy
		if ( is_woocommerce() || is_cart() || is_checkout() || is_account_page() ) {
			return;
		}

		// Also check specific page slugs or endpoints
		if ( is_page( [ 'cart', 'checkout', 'my-account', 'order-pay', 'order-received' ] ) ) {
			return;
		}

		// Check if singular post is a product
		if ( is_singular( [ 'product', 'product_variation' ] ) ) {
			return;
		}

		// Dequeue WooCommerce default stylesheets
		wp_dequeue_style( 'woocommerce-layout' );
		wp_dequeue_style( 'woocommerce-smallscreen' );
		wp_dequeue_style( 'woocommerce-general' );
		wp_dequeue_style( 'woocommerce_frontend_styles' );
		wp_dequeue_style( 'woocommerce_fancybox_styles' );
		wp_dequeue_style( 'woocommerce_chosen_styles' );
		wp_dequeue_style( 'woocommerce_prettyPhoto_css' );

		// Dequeue WooCommerce default scripts
		wp_dequeue_script( 'wc-single-product' );
		wp_dequeue_script( 'woocommerce' );
		wp_dequeue_script( 'prettyPhoto' );
		wp_dequeue_script( 'prettyPhoto-init' );
		wp_dequeue_script( 'fancybox' );
		wp_dequeue_script( 'enable-lightbox' );
	}

	/**
	 * Refine WooCommerce REST API product search to match post_title, ID, or SKU.
	 * Prevents broad boiler-plate description text (e.g. "pro", "skin", "3M") from
	 * matching unrelated catalog items when operators perform targeted model searches.
	 */
	public static function refine_rest_product_search( $search, $wp_query ) {
		if ( empty( $search ) ) {
			return $search;
		}

		$post_type = $wp_query->get( 'post_type' );
		$is_product_query = ( $post_type === 'product' || ( is_array( $post_type ) && in_array( 'product', $post_type, true ) ) );

		if ( ! $is_product_query ) {
			return $search;
		}

		$search_query = trim( (string) $wp_query->get( 's' ) );
		if ( empty( $search_query ) ) {
			return $search;
		}

		$is_rest = ( defined( 'REST_REQUEST' ) && REST_REQUEST );
		if ( ! $is_rest && ! isset( $_SERVER['HTTP_X_EXACOAT_CLIENT'] ) ) {
			return $search;
		}

		global $wpdb;

		// Numeric search: allow exact post ID match or title match
		if ( is_numeric( $search_query ) ) {
			$numeric_id = (int) $search_query;
			return " AND ({$wpdb->posts}.ID = {$numeric_id} OR {$wpdb->posts}.post_title LIKE '%" . $wpdb->esc_like( $search_query ) . "%') ";
		}

		// Tokenize search string by whitespace
		$tokens = preg_split( '/\s+/', $search_query, -1, PREG_SPLIT_NO_EMPTY );
		if ( empty( $tokens ) ) {
			return $search;
		}

		$title_conditions = [];
		foreach ( $tokens as $token ) {
			$escaped_token = $wpdb->esc_like( $token );
			$title_conditions[] = "{$wpdb->posts}.post_title LIKE '%{$escaped_token}%'";
		}

		// All tokens must be present in post_title (e.g. '17' AND 'pro')
		$all_tokens_sql = implode( ' AND ', $title_conditions );
		$exact_phrase = $wpdb->esc_like( $search_query );

		return " AND (({$all_tokens_sql}) OR ({$wpdb->posts}.post_title LIKE '%{$exact_phrase}%')) ";
	}

	/**
	 * Rank exact phrase matches and start-of-title matches higher during product search
	 */
	public static function refine_rest_product_search_orderby( $clauses, $wp_query ) {
		$search_query = trim( (string) $wp_query->get( 's' ) );
		$post_type = $wp_query->get( 'post_type' );
		$is_product_query = ( $post_type === 'product' || ( is_array( $post_type ) && in_array( 'product', $post_type, true ) ) );

		if ( empty( $search_query ) || ! $is_product_query ) {
			return $clauses;
		}

		$is_rest = ( defined( 'REST_REQUEST' ) && REST_REQUEST );
		if ( ! $is_rest && ! isset( $_SERVER['HTTP_X_EXACOAT_CLIENT'] ) ) {
			return $clauses;
		}

		global $wpdb;
		$escaped = $wpdb->esc_like( $search_query );
		$order_case = "CASE 
			WHEN {$wpdb->posts}.post_title LIKE '{$escaped}%' THEN 1 
			WHEN {$wpdb->posts}.post_title LIKE '%{$escaped}%' THEN 2 
			ELSE 3 
		END ASC";

		if ( ! empty( $clauses['orderby'] ) ) {
			$clauses['orderby'] = "{$order_case}, " . $clauses['orderby'];
		} else {
			$clauses['orderby'] = "{$order_case}, {$wpdb->posts}.post_date DESC";
		}

		return $clauses;
	}

	/**
	 * Sanitize product price values to guarantee numeric float/int return types under PHP 8.4+.
	 * Prevents fatal TypeError: Unsupported operand types: string * int in WooCommerce EmailPreview.php line 400.
	 */
	public static function sanitize_product_price_for_php8( $price, $product = null ) {
		if ( is_float( $price ) || is_int( $price ) ) {
			return $price;
		}

		if ( is_string( $price ) ) {
			$trimmed = trim( $price );
			if ( '' === $trimmed ) {
				// If dummy product has empty price in preview context, ensure standard numeric fallback
				if ( is_object( $product ) && method_exists( $product, 'get_id' ) && $product->get_id() === 0 ) {
					return 25.0;
				}
				return 0.0;
			}
			if ( is_numeric( $trimmed ) ) {
				return (float) $trimmed;
			}
			// Clean localized decimal separators (e.g. "25,00" -> "25.00")
			$cleaned = preg_replace( '/[^\d,.]/', '', $trimmed );
			if ( strpos( $cleaned, ',' ) !== false && strpos( $cleaned, '.' ) === false ) {
				$cleaned = str_replace( ',', '.', $cleaned );
			}
			if ( is_numeric( $cleaned ) ) {
				return (float) $cleaned;
			}
		}

		if ( is_object( $product ) && method_exists( $product, 'get_id' ) && $product->get_id() === 0 ) {
			return 25.0;
		}

		return is_numeric( $price ) ? (float) $price : 0.0;
	}

	/**
	 * Ensure WooCommerce Email Preview dummy product always has a numeric price assigned.
	 */
	public static function harden_email_preview_dummy_product( $product, $email_type = '' ) {
		if ( is_object( $product ) && method_exists( $product, 'set_price' ) ) {
			$product->set_price( 25.0 );
			if ( method_exists( $product, 'set_regular_price' ) ) {
				$product->set_regular_price( 25.0 );
			}
		}
		return $product;
	}
}

}
