<?php
/**
 * Main Exacoat Core Class & REST API Bridge
 *
 * @package Exacoat_Core
 * @version 0.0.8
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Exacoat_Core' ) ) {

class Exacoat_Core {

	private static $instance = null;
	private static $cached_settings = null;
	public $settings = [];

	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Memoized Settings Accessors
	 */
	public static function get_settings(): array {
		if ( self::$cached_settings === null ) {
			$options = get_option( 'exacoat_core_settings', [] );
			if ( empty( $options ) || ! is_array( $options ) ) {
				$options = get_option( 'artmatter_core_settings', [] );
			}
			if ( ! is_array( $options ) ) {
				$options = [];
			}
			// Environment constant fallbacks for AI credentials from wp-config.php
			$env_gemini = defined( 'EXA_GEMINI_API_KEY' ) ? EXA_GEMINI_API_KEY : ( defined( 'AM_GEMINI_API_KEY' ) ? AM_GEMINI_API_KEY : ( defined( 'GEMINI_API_KEY' ) ? GEMINI_API_KEY : getenv( 'EXA_GEMINI_API_KEY' ) ) );
			if ( empty( $options['gemini_api_key'] ) && ! empty( $env_gemini ) ) {
				$options['gemini_api_key'] = trim( (string) $env_gemini );
			}
			$env_openai = defined( 'EXA_OPENAI_API_KEY' ) ? EXA_OPENAI_API_KEY : ( defined( 'AM_OPENAI_API_KEY' ) ? AM_OPENAI_API_KEY : ( defined( 'OPENAI_API_KEY' ) ? OPENAI_API_KEY : getenv( 'EXA_OPENAI_API_KEY' ) ) );
			if ( empty( $options['openai_api_key'] ) && ! empty( $env_openai ) ) {
				$options['openai_api_key'] = trim( (string) $env_openai );
			}
			$env_trackingmore = defined( 'EXA_TRACKINGMORE_API_KEY' ) ? EXA_TRACKINGMORE_API_KEY : ( defined( 'TRACKINGMORE_API_KEY' ) ? TRACKINGMORE_API_KEY : getenv( 'EXA_TRACKINGMORE_API_KEY' ) );
			if ( empty( $options['trackingmore_api_key'] ) && ! empty( $env_trackingmore ) ) {
				$options['trackingmore_api_key'] = trim( (string) $env_trackingmore );
			}
			$env_trackingmore_secret = defined( 'EXA_TRACKINGMORE_WEBHOOK_SECRET' ) ? EXA_TRACKINGMORE_WEBHOOK_SECRET : ( defined( 'TRACKINGMORE_WEBHOOK_SECRET' ) ? TRACKINGMORE_WEBHOOK_SECRET : getenv( 'EXA_TRACKINGMORE_WEBHOOK_SECRET' ) );
			if ( empty( $options['trackingmore_webhook_secret'] ) && ! empty( $env_trackingmore_secret ) ) {
				$options['trackingmore_webhook_secret'] = trim( (string) $env_trackingmore_secret );
			}
			$env_rayspeed = defined( 'EXA_RAYSPEED_API_KEY' ) ? EXA_RAYSPEED_API_KEY : ( defined( 'RAYSPEED_API_KEY' ) ? RAYSPEED_API_KEY : getenv( 'EXA_RAYSPEED_API_KEY' ) );
			if ( empty( $options['rayspeed_api_key'] ) && ! empty( $env_rayspeed ) ) {
				$options['rayspeed_api_key'] = trim( (string) $env_rayspeed );
			}
			$env_goorita = defined( 'EXA_GOORITA_PROD_API_KEY' ) ? EXA_GOORITA_PROD_API_KEY : ( defined( 'EXA_GOORITA_API_KEY' ) ? EXA_GOORITA_API_KEY : ( defined( 'GOORITA_API_KEY' ) ? GOORITA_API_KEY : getenv( 'EXA_GOORITA_API_KEY' ) ) );
			if ( empty( $options['goorita_api_key'] ) && ! empty( $env_goorita ) ) {
				$options['goorita_api_key'] = trim( (string) $env_goorita );
			}
			$env_goorita_dev = defined( 'EXA_GOORITA_DEV_API_KEY' ) ? EXA_GOORITA_DEV_API_KEY : ( defined( 'GOORITA_DEV_API_KEY' ) ? GOORITA_DEV_API_KEY : getenv( 'EXA_GOORITA_DEV_API_KEY' ) );
			if ( empty( $options['goorita_dev_api_key'] ) && ! empty( $env_goorita_dev ) ) {
				$options['goorita_dev_api_key'] = trim( (string) $env_goorita_dev );
			}
			$env_goorita_env = defined( 'EXA_GOORITA_ENVIRONMENT' ) ? EXA_GOORITA_ENVIRONMENT : ( defined( 'GOORITA_ENVIRONMENT' ) ? GOORITA_ENVIRONMENT : getenv( 'EXA_GOORITA_ENVIRONMENT' ) );
			if ( empty( $options['goorita_environment'] ) && ! empty( $env_goorita_env ) ) {
				$options['goorita_environment'] = trim( strtolower( (string) $env_goorita_env ) );
			}
			self::$cached_settings = $options;
		}
		return self::$cached_settings;
	}

	public static function get_setting( string $key, $default = null ) {
		$settings = self::get_settings();
		return $settings[ $key ] ?? $default;
	}

	public static function clear_settings_cache(): void {
		self::$cached_settings = null;
	}

	private function __construct() {
		$this->settings = self::get_settings();
		$this->init_modules();

		// Invalidate settings cache when updated
		add_action( 'update_option_exacoat_core_settings', [ __CLASS__, 'clear_settings_cache' ] );
		add_action( 'update_option_artmatter_core_settings', [ __CLASS__, 'clear_settings_cache' ] );

		// Register REST API Bridge for Exacoat Manager ERP communication
		add_action( 'rest_api_init', [ $this, 'register_bridge_routes' ] );

		// Preflight OPTIONS handler early in request lifecycle
		add_action( 'init', function() {
			$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
			if ( ! empty( $origin ) && self::is_cors_origin_allowed( $origin ) ) {
				self::send_cors_headers( $origin );
				if ( ( $_SERVER['REQUEST_METHOD'] ?? '' ) === 'OPTIONS' ) {
					status_header( 200 );
					exit;
				}
			}
		}, 1 );

		add_filter( 'allowed_http_origins', function( $origins ) {
			$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
			if ( ! empty( $origin ) && self::is_cors_origin_allowed( $origin ) ) {
				$origins[] = $origin;
			}
			return array_values( array_unique( (array) $origins ) );
		} );

		remove_filter( 'rest_pre_serve_request', 'rest_send_cors_headers' );
		add_filter( 'rest_pre_serve_request', function( $value ) {
			$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
			if ( ! empty( $origin ) && self::is_cors_origin_allowed( $origin ) ) {
				self::send_cors_headers( $origin );
				if ( ( $_SERVER['REQUEST_METHOD'] ?? '' ) === 'OPTIONS' ) {
					status_header( 200 );
					exit;
				}
			}
			return $value;
		}, 999 );

		add_filter( 'rest_allowed_cors_headers', function( $headers ) {
			$custom = [ 'Authorization', 'Content-Type', 'X-WP-Nonce', 'Cache-Control', 'Pragma', 'X-Requested-With', 'sent_from', 'x-api-key', 'X-Api-Key', 'apikey', 'Accept', 'Origin', 'Cart-Token', 'Nonce', 'X-Exacoat-Currency', 'X-Artmatter-Currency', 'X-Exacoat-Client-IP', 'X-Artmatter-Client-IP', 'x-secret-key', 'X-Secret-Key', 'X-Exacoat-Secret', 'x_exacoat_secret', 'X-Goorita-Token', 'x-goorita-token', 'X-Goorita-Event', 'x-goorita-event' ];
			return array_unique( array_merge( (array) $headers, $custom ) );
		} );
	}

	/**
	 * Check if an origin is permitted for cross-origin resource sharing
	 */
	public static function is_cors_origin_allowed( ?string $origin ): bool {
		if ( empty( $origin ) ) {
			return false;
		}

		$parsed = wp_parse_url( $origin );
		$host   = strtolower( (string) ( $parsed['host'] ?? '' ) );
		if ( empty( $host ) ) {
			return false;
		}

		if ( $host === 'localhost' || $host === '127.0.0.1' ) {
			return true;
		}

		if ( preg_match( '/(^|\.)(exacoat\.com|artmatter\.co)$/i', $host ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Send unified CORS response headers
	 */
	public static function send_cors_headers( ?string $origin = null ): void {
		$origin = $origin ?: ( $_SERVER['HTTP_ORIGIN'] ?? '' );
		if ( empty( $origin ) || ! self::is_cors_origin_allowed( $origin ) ) {
			return;
		}

		header_remove( 'Access-Control-Allow-Origin' );
		header_remove( 'Access-Control-Allow-Credentials' );
		header( "Access-Control-Allow-Origin: {$origin}" );
		header( 'Access-Control-Allow-Credentials: true' );
		header( 'Vary: Origin', false );
		header( 'Access-Control-Allow-Methods: OPTIONS, GET, POST, PUT, PATCH, DELETE, HEAD' );
		header( 'Access-Control-Allow-Headers: Authorization, Content-Type, X-WP-Nonce, Cache-Control, Pragma, X-Requested-With, sent_from, x-api-key, X-Api-Key, apikey, Accept, Origin, Cart-Token, Nonce, X-Exacoat-Currency, X-Artmatter-Currency, X-Exacoat-Client-IP, X-Artmatter-Client-IP, x-secret-key, X-Secret-Key, X-Exacoat-Secret, x_exacoat_secret, X-WC-Consumer-Key, X-WC-Consumer-Secret, X-SliceWP-Key, X-SliceWP-Secret, X-Goorita-Token, x-goorita-token, X-Goorita-Event, x-goorita-event' );
		header( 'Access-Control-Expose-Headers: Cart-Token, Nonce, X-WP-Total, X-WP-TotalPages, X-Exacoat-Currency, X-Artmatter-Currency' );
		header( 'Cache-Control: no-cache, no-store, must-revalidate, max-age=0' );
		header( 'Pragma: no-cache' );
		header( 'Expires: 0' );
		header( 'X-LiteSpeed-Cache-Control: no-cache' );
	}

	private function init_modules() {
		try {
			// 0. High-Performance Logging & Telemetry Engine (7-Day Retention)
			if ( class_exists( 'Exacoat_Logger' ) ) {
				Exacoat_Logger::init();
			} elseif ( class_exists( 'Artmatter_Logger' ) ) {
				Artmatter_Logger::init();
			}
		} catch ( \Throwable $e ) {
			error_log( 'Exacoat Logger init error: ' . $e->getMessage() );
		}

		try {
			// 1. Shipping & Biteship Tracker
			if ( self::get_setting( 'enable_shipping_tracker', 1 ) ) {
				if ( class_exists( 'Exacoat_Shipping_Tracker' ) ) {
					Exacoat_Shipping_Tracker::init();
				} elseif ( class_exists( 'Artmatter_Shipping_Tracker' ) ) {
					Artmatter_Shipping_Tracker::init();
				}
			}
			if ( class_exists( 'Exacoat_Biteship_Engine' ) ) {
				Exacoat_Biteship_Engine::init();
			} elseif ( class_exists( 'Artmatter_Biteship_Engine' ) ) {
				Artmatter_Biteship_Engine::init();
			}
			if ( class_exists( 'Exacoat_Rayspeed_Service' ) ) {
				Exacoat_Rayspeed_Service::init();
			}
		} catch ( \Throwable $e ) {
			error_log( 'Exacoat Shipping Tracker init error: ' . $e->getMessage() );
		}

		try {
			// 2. Store Enhancements & Frontend Cleanups
			if ( class_exists( 'Exacoat_Store_Enhancements' ) ) {
				Exacoat_Store_Enhancements::init();
			} elseif ( class_exists( 'Artmatter_Store_Enhancements' ) ) {
				Artmatter_Store_Enhancements::init();
			}
		} catch ( \Throwable $e ) {
			error_log( 'Exacoat Store Enhancements init error: ' . $e->getMessage() );
		}

		try {
			// 3. Comprehensive Diagnostics & Safe Testing Suite
			if ( class_exists( 'Exacoat_Diagnostics' ) ) {
				Exacoat_Diagnostics::init();
			} elseif ( class_exists( 'Artmatter_Diagnostics' ) ) {
				Artmatter_Diagnostics::init();
			}
			if ( class_exists( 'Exacoat_Performance_Auditor' ) ) {
				Exacoat_Performance_Auditor::init();
			} elseif ( class_exists( 'Artmatter_Performance_Auditor' ) ) {
				Artmatter_Performance_Auditor::init();
			}
		} catch ( \Throwable $e ) {
			error_log( 'Exacoat Diagnostics init error: ' . $e->getMessage() );
		}

		try {
			// 4. Native Responsive HTML Email Engine
			if ( class_exists( 'Exacoat_Email_Engine' ) ) {
				Exacoat_Email_Engine::init();
			} elseif ( class_exists( 'Artmatter_Email_Engine' ) ) {
				Artmatter_Email_Engine::init();
			}
			self::maybe_sync_email_senders();
		} catch ( \Throwable $e ) {
			error_log( 'Exacoat Email Engine init error: ' . $e->getMessage() );
		}

		try {
			// 5. Order Manager & Production Hub
			if ( class_exists( 'Exacoat_Order_Manager' ) ) {
				Exacoat_Order_Manager::init();
			} elseif ( class_exists( 'Artmatter_Order_Manager' ) ) {
				Artmatter_Order_Manager::init();
			}
		} catch ( \Throwable $e ) {
			error_log( 'Exacoat Order Manager init error: ' . $e->getMessage() );
		}

		try {
			// 6. Checkout, Thank You & Repayment Engine
			if ( class_exists( 'Exacoat_Checkout_Engine' ) ) {
				Exacoat_Checkout_Engine::init();
			} elseif ( class_exists( 'Artmatter_Checkout_Engine' ) ) {
				Artmatter_Checkout_Engine::init();
			}
		} catch ( \Throwable $e ) {
			error_log( 'Exacoat Checkout Engine init error: ' . $e->getMessage() );
		}

		try {
			// 7. Headless customer sessions, registration, recovery, and auth bridge
			if ( class_exists( 'Exacoat_Customer_Auth' ) ) {
				Exacoat_Customer_Auth::init();
			} elseif ( class_exists( 'Artmatter_Customer_Auth' ) ) {
				Artmatter_Customer_Auth::init();
			}
		} catch ( \Throwable $e ) {
			error_log( 'Exacoat Customer Auth init error: ' . $e->getMessage() );
		}

		try {
			// Admin Settings Panel
			if ( is_admin() ) {
				if ( class_exists( 'Exacoat_Admin_Settings' ) ) {
					Exacoat_Admin_Settings::init();
				} elseif ( class_exists( 'Artmatter_Admin_Settings' ) ) {
					Artmatter_Admin_Settings::init();
				}
			}
		} catch ( \Throwable $e ) {
			error_log( 'Exacoat Admin Settings init error: ' . $e->getMessage() );
		}

		try {
			// 8. Dynamic Configurator Engine & Global Finishes Inventory
			if ( class_exists( 'Exacoat_Configurator_Engine' ) ) {
				Exacoat_Configurator_Engine::init();
			}
		} catch ( \Throwable $e ) {
			error_log( 'Exacoat Configurator Engine init error: ' . $e->getMessage() );
		}

		try {
			// 9. Review & Customer Feedback Manager
			if ( self::get_setting( 'enable_review_manager', 1 ) ) {
				if ( class_exists( 'Exacoat_Review_Manager' ) ) {
					Exacoat_Review_Manager::init();
				} elseif ( class_exists( 'Artmatter_Review_Manager' ) ) {
					Artmatter_Review_Manager::init();
				}
			}
		} catch ( \Throwable $e ) {
			error_log( 'Exacoat Review Manager init error: ' . $e->getMessage() );
		}
	}

	/**
	 * Unified Order Payload Generator for Supabase & Webhook sync
	 */
	public static function build_order_payload( int $order_id ): ?array {
		$order = wc_get_order( $order_id );
		if ( ! $order ) return null;

		$meta_data = [];
		foreach ( $order->get_meta_data() as $meta ) {
			$meta_data[ $meta->key ] = $meta->value;
		}

		$items = [];
		foreach ( $order->get_items() as $item_id => $item ) {
			$item_meta = [];
			foreach ( $item->get_meta_data() as $im ) {
				$item_meta[ $im->key ] = $im->value;
			}
			$product = $item->get_product();
			$items[] = [
				'order_item_id' => (int) $item_id,
				'product_id'    => (int) $item->get_product_id(),
				'variation_id'  => (int) $item->get_variation_id(),
				'name'          => $item->get_name(),
				'quantity'      => (int) $item->get_quantity(),
				'subtotal'      => (float) $item->get_subtotal(),
				'total'         => (float) $item->get_total(),
				'sku'           => $product ? $product->get_sku() : '',
				'meta'          => $item_meta,
			];
		}

		$fees = [];
		$fees_total = 0.0;
		foreach ( $order->get_fees() as $fee_id => $fee ) {
			$amount = (float) $fee->get_total();
			$name   = $fee->get_name();
			$is_shipping_discount = stripos( $name, 'shipping' ) !== false;
			$fees[] = [
				'fee_id' => (int) $fee_id,
				'name'   => $name,
				'total'  => $amount,
				'tax'    => (float) $fee->get_total_tax(),
				'type'   => $is_shipping_discount ? 'shipping_discount' : 'fee',
			];
			$fees_total += $amount;
		}

		return [
			'order_id'     => $order_id,
			'order_number' => $order->get_order_number(),
			'status'       => $order->get_status(),
			'currency'     => $order->get_currency(),
			'created_at'   => $order->get_date_created() ? $order->get_date_created()->date( 'c' ) : null,
			'updated_at'   => $order->get_date_modified() ? $order->get_date_modified()->date( 'c' ) : null,
			'totals'       => [
				'subtotal'   => (float) $order->get_subtotal(),
				'shipping'   => (float) $order->get_shipping_total(),
				'discount'   => (float) $order->get_discount_total(),
				'fees_total' => (float) $fees_total,
				'total'      => (float) $order->get_total(),
			],
			'fees'         => $fees,
			'items'        => $items,
			'customer'     => [
				'id'    => (int) $order->get_customer_id(),
				'email' => $order->get_billing_email(),
				'phone' => $order->get_billing_phone(),
				'note'  => $order->get_customer_note(),
			],
			'billing'      => $order->get_address( 'billing' ),
			'shipping'     => $order->get_address( 'shipping' ),
			'meta'         => $meta_data,
		];
	}

	/**
	 * Secure Verification for Manager ERP & External Bridge API Requests
	 */
	public static function verify_bridge_permission( WP_REST_Request $request ): bool {
		// 1. Native WordPress admin session cookie (wp-admin or authenticated AJAX)
		if ( current_user_can( 'manage_options' ) || current_user_can( 'manage_woocommerce' ) ) {
			return true;
		}

		// 2. WooCommerce REST API Keys (Consumer Key & Consumer Secret via Basic auth or params)
		if ( self::verify_wc_api_credentials( $request ) ) {
			return true;
		}

		// 3. WordPress Application Passwords (HTTP Basic Auth username:app_password)
		if ( self::verify_application_password( $request ) ) {
			return true;
		}

		// 4. Plugin Master Webhook Secret Header
		if ( self::verify_secret_key( $request ) ) {
			return true;
		}

		// 5. Customer / Staff Auth Bearer Session Token (from Exacoat_Customer_Auth)
		if ( self::verify_customer_auth_session( $request ) ) {
			return true;
		}

		// 6. Supabase User Session (if configured)
		if ( self::verify_manager_session( $request ) ) {
			return true;
		}

		// 7. Local development loopback (requests originating from localhost / local Vite dev server)
		if ( self::is_local_dev_request( $request ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Verify WooCommerce Consumer Key & Secret against wp_woocommerce_api_keys
	 */
	public static function verify_wc_api_credentials( WP_REST_Request $request ): bool {
		global $wpdb;

		$consumer_key = '';
		$consumer_secret = '';

		// A. Check HTTP Basic Auth header
		$auth_header = (string) $request->get_header( 'Authorization' );
		if ( ! empty( $auth_header ) && preg_match( '/^Basic\s+(.+)$/i', $auth_header, $matches ) ) {
			$decoded = base64_decode( trim( $matches[1] ) );
			if ( strpos( $decoded, ':' ) !== false ) {
				list( $consumer_key, $consumer_secret ) = explode( ':', $decoded, 2 );
			}
		}

		// B. Check URL query parameters or request body
		if ( empty( $consumer_key ) ) {
			$consumer_key = (string) ( $request->get_param( 'consumer_key' ) ?: $request->get_header( 'X-WC-Consumer-Key' ) );
			$consumer_secret = (string) ( $request->get_param( 'consumer_secret' ) ?: $request->get_header( 'X-WC-Consumer-Secret' ) );
		}

		if ( empty( $consumer_key ) || empty( $consumer_secret ) ) {
			return false;
		}

		$table_name = $wpdb->prefix . 'woocommerce_api_keys';
		if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table_name ) ) !== $table_name ) {
			return false;
		}

		$key_hash = function_exists( 'wc_api_hash' ) ? wc_api_hash( $consumer_key ) : hash( 'sha256', $consumer_key );
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT key_id, user_id, permissions, consumer_secret FROM {$table_name} WHERE consumer_key = %s LIMIT 1",
			$key_hash
		) );

		if ( ! $row ) {
			return false;
		}

		if ( ! hash_equals( (string) $row->consumer_secret, (string) $consumer_secret ) ) {
			return false;
		}

		if ( ! in_array( $row->permissions, [ 'write', 'read_write' ], true ) ) {
			return false;
		}

		$user = get_user_by( 'id', (int) $row->user_id );
		if ( ! $user || ( ! $user->has_cap( 'manage_woocommerce' ) && ! $user->has_cap( 'manage_options' ) && ! in_array( 'shop_manager', (array) $user->roles, true ) ) ) {
			return false;
		}

		wp_set_current_user( (int) $row->user_id );
		return true;
	}

	/**
	 * Verify WordPress Application Password
	 */
	public static function verify_application_password( WP_REST_Request $request ): bool {
		$auth_header = (string) $request->get_header( 'Authorization' );
		if ( empty( $auth_header ) || ! preg_match( '/^Basic\s+(.+)$/i', $auth_header, $matches ) ) {
			return false;
		}

		$decoded = base64_decode( trim( $matches[1] ) );
		if ( strpos( $decoded, ':' ) === false ) {
			return false;
		}

		list( $username, $password ) = explode( ':', $decoded, 2 );
		if ( ! function_exists( 'wp_authenticate_application_password' ) ) {
			return false;
		}

		$user = wp_authenticate_application_password( null, $username, $password );
		if ( is_wp_error( $user ) || ! $user instanceof \WP_User ) {
			return false;
		}

		if ( $user->has_cap( 'manage_woocommerce' ) || $user->has_cap( 'manage_options' ) || in_array( 'shop_manager', (array) $user->roles, true ) ) {
			wp_set_current_user( $user->ID );
			return true;
		}

		return false;
	}

	/**
	 * Verify Plugin Master Secret Header
	 */
	public static function verify_secret_key( WP_REST_Request $request ): bool {
		$settings = self::get_settings();
		$expected = trim( (string) ( $settings['webhook_secret'] ?? '' ) );
		if ( empty( $expected ) ) {
			return false;
		}

		$secret = (string) ( $request->get_header( 'X-Exacoat-Secret' )
			?: $request->get_header( 'X-Manager-Secret' )
			?: $request->get_header( 'X-Artmatter-Secret' )
			?: $request->get_param( 'secret' ) );

		return ! empty( $secret ) && hash_equals( $expected, trim( $secret ) );
	}

	/**
	 * Verify Customer / Staff Bearer Session Token
	 */
	public static function verify_customer_auth_session( WP_REST_Request $request ): bool {
		$auth_header = (string) $request->get_header( 'Authorization' );
		if ( ! preg_match( '/^Bearer\s+(\d+)\.([A-Za-z0-9_-]+)$/i', $auth_header, $matches ) ) {
			return false;
		}

		$user_id  = (int) $matches[1];
		$verifier = $matches[2];

		if ( ! class_exists( 'WP_Session_Tokens' ) || ! \WP_Session_Tokens::get_instance( $user_id )->verify( $verifier ) ) {
			return false;
		}

		$user = get_user_by( 'id', $user_id );
		if ( ! $user ) {
			return false;
		}

		if ( $user->has_cap( 'manage_woocommerce' ) || $user->has_cap( 'manage_options' ) || in_array( 'shop_manager', (array) $user->roles, true ) ) {
			wp_set_current_user( $user_id );
			return true;
		}

		return false;
	}

	/**
	 * Check if request originates from localhost development environment
	 */
	private static function is_local_dev_request( WP_REST_Request $request ): bool {
		$origin  = (string) $request->get_header( 'Origin' );
		$referer = (string) $request->get_header( 'Referer' );
		$host    = (string) $request->get_header( 'Host' );

		$is_local_origin = false;
		foreach ( [ $origin, $referer ] as $url ) {
			if ( ! empty( $url ) && preg_match( '#^https?://(localhost|127\.0\.0\.1)(:\d+)?#i', $url ) ) {
				$is_local_origin = true;
				break;
			}
		}

		if ( ! $is_local_origin ) {
			return false;
		}

		if ( ( defined( 'WP_DEBUG' ) && WP_DEBUG )
			|| ( defined( 'EXACOAT_LOCAL_DEV' ) && EXACOAT_LOCAL_DEV )
			|| in_array( $host, [ 'localhost', '127.0.0.1', 'localhost:8080', 'localhost:8000', 'localhost:3005' ], true ) ) {
			return true;
		}

		return false;
	}

	public static function verify_manager_session( WP_REST_Request $request ): bool {
		$user = self::get_verified_supabase_user( $request );
		if ( empty( $user ) ) {
			return false;
		}

		$role = $user['app_metadata']['role'] ?? '';
		$email = strtolower( (string) ( $user['email'] ?? '' ) );
		return in_array( $role, [ 'manager', 'super_admin', 'shop_manager' ], true )
			|| in_array( $email, [ 'admin@exacoat.com', 'shandy@exacoat.com', 'admin@artmatter.co', 'shandy@artmatter.co' ], true );
	}

	public static function verify_authenticated_session( WP_REST_Request $request ): bool {
		return current_user_can( 'manage_options' ) || ! empty( self::get_verified_supabase_user( $request ) );
	}

	private static function get_verified_supabase_user( WP_REST_Request $request ): array {
		$auth_header = (string) $request->get_header( 'Authorization' );
		if ( ! preg_match( '/^Bearer\s+(.+)$/i', $auth_header, $matches ) ) {
			return [];
		}

		$config = class_exists( 'Artmatter_Supabase_Sync' ) ? Artmatter_Supabase_Sync::get_config() : [];
		if ( empty( $config['url'] ) || empty( $config['service_key'] ) ) {
			return [];
		}

		$response = wp_remote_get( untrailingslashit( $config['url'] ) . '/auth/v1/user', [
			'headers' => [
				'apikey'        => $config['service_key'],
				'Authorization' => 'Bearer ' . trim( $matches[1] ),
			],
			'timeout' => 10,
		] );
		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return [];
		}

		$user = json_decode( wp_remote_retrieve_body( $response ), true );
		return is_array( $user ) ? $user : [];
	}

	public function rest_purge_cloudflare_cache( WP_REST_Request $request ): WP_REST_Response {
		$params = $request->get_json_params() ?: $request->get_params();

		// Detect target with defensive handling for legacy parameter order
		$target = sanitize_text_field( $params['target'] ?? '' );
		if ( empty( $target ) || 'all' === $target ) {
			if ( ! empty( $params['zone_id'] ) && in_array( $params['zone_id'], [ 'manager', 'storefront', 'all' ], true ) ) {
				$target = $params['zone_id'];
			} else {
				$target = 'all';
			}
		}

		$zone_id_param = ! empty( $params['zone_id'] ) && ! in_array( $params['zone_id'], [ 'manager', 'storefront', 'all' ], true )
			? sanitize_text_field( $params['zone_id'] )
			: '';

		$zone_id = ! empty( $zone_id_param )
			? $zone_id_param
			: ( defined( 'EXA_CLOUDFLARE_ZONE_ID' ) ? EXA_CLOUDFLARE_ZONE_ID : ( defined( 'EXACOAT_CLOUDFLARE_ZONE_ID' ) ? EXACOAT_CLOUDFLARE_ZONE_ID : ( defined( 'AM_CLOUDFLARE_ZONE_ID' ) ? AM_CLOUDFLARE_ZONE_ID : ( defined( 'CLOUDFLARE_ZONE_ID' ) ? CLOUDFLARE_ZONE_ID : ( getenv( 'EXA_CLOUDFLARE_ZONE_ID' ) ?: ( getenv( 'EXACOAT_CLOUDFLARE_ZONE_ID' ) ?: ( getenv( 'AM_CLOUDFLARE_ZONE_ID' ) ?: self::get_setting( 'cloudflare_zone_id', '' ) ) ) ) ) ) ) );

		$api_token_param = sanitize_text_field( $params['cloudflare_api_token'] ?? $params['api_token'] ?? '' );
		$api_token = ! empty( $api_token_param )
			? $api_token_param
			: ( defined( 'EXA_CLOUDFLARE_API_TOKEN' ) ? EXA_CLOUDFLARE_API_TOKEN : ( defined( 'EXACOAT_CLOUDFLARE_API_TOKEN' ) ? EXACOAT_CLOUDFLARE_API_TOKEN : ( defined( 'AM_CLOUDFLARE_API_TOKEN' ) ? AM_CLOUDFLARE_API_TOKEN : ( defined( 'CLOUDFLARE_API_TOKEN' ) ? CLOUDFLARE_API_TOKEN : ( getenv( 'EXA_CLOUDFLARE_API_TOKEN' ) ?: ( getenv( 'EXACOAT_CLOUDFLARE_API_TOKEN' ) ?: ( getenv( 'AM_CLOUDFLARE_API_TOKEN' ) ?: self::get_setting( 'cloudflare_api_token', '' ) ) ) ) ) ) ) );

		if ( empty( $zone_id ) || empty( $api_token ) ) {
			return new WP_REST_Response( [ 'success' => false, 'error' => 'Cloudflare cache credentials are not configured.' ], 400 );
		}

		if ( 'manager' === $target ) {
			$purge_payload = [
				'files' => [
					'https://manager.exacoat.com/',
					'https://manager.exacoat.com/version.json',
					'https://manager.exacoat.com/exacoat-core.zip',
					'https://manager.exacoat.com/index.html',
					'https://manager.exacoat.com/env-config.js',
				],
			];
			$success_message = 'Manager workstation cache purged (manager.exacoat.com).';
		} elseif ( 'storefront' === $target ) {
			$purge_payload = [
				'files' => [
					'https://exacoat.com/',
					'https://exacoat.com/shop/',
					'https://exacoat.com/products/',
				],
			];
			$success_message = 'Storefront key pages cache purged (exacoat.com).';
		} else {
			$purge_payload = [ 'purge_everything' => true ];
			$success_message = 'Entire Exacoat network cache cleared (Storefront, Manager & CMS).';
		}

		$response = wp_remote_post( 'https://api.cloudflare.com/client/v4/zones/' . rawurlencode( trim( $zone_id ) ) . '/purge_cache', [
			'headers' => [
				'Authorization' => 'Bearer ' . trim( $api_token ),
				'Content-Type'  => 'application/json',
			],
			'body'    => wp_json_encode( $purge_payload ),
			'timeout' => 20,
		] );
		if ( is_wp_error( $response ) ) {
			return new WP_REST_Response( [ 'success' => false, 'error' => $response->get_error_message() ], 502 );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( 200 !== wp_remote_retrieve_response_code( $response ) || empty( $body['success'] ) ) {
			$message = $body['errors'][0]['message'] ?? 'Cloudflare did not clear the cache.';
			return new WP_REST_Response( [ 'success' => false, 'error' => $message ], 502 );
		}

		return new WP_REST_Response( [ 'success' => true, 'message' => $success_message, 'target' => $target ] );
	}

	public function rest_get_catalog_prices( WP_REST_Request $request ) {
		$currency = strtoupper( sanitize_text_field( (string) $request->get_param( 'currency' ) ) );
		$page      = min( 1000, max( 1, absint( $request->get_param( 'page' ) ) ) );
		$per_page  = min( 250, max( 1, absint( $request->get_param( 'per_page' ) ) ) );
		$cache_key = 'exacoat_catalog_prices_' . strtolower( $currency ) . "_{$page}_{$per_page}";
		$cached    = get_transient( $cache_key );

		if ( is_array( $cached ) ) {
			$response = new WP_REST_Response( $cached );
			$response->header( 'Cache-Control', 'public, max-age=60, stale-while-revalidate=300' );
			return $response;
		}

		$visibility_ids = function_exists( 'wc_get_product_visibility_term_ids' )
			? wc_get_product_visibility_term_ids()
			: [];
		$tax_query      = [];

		if ( ! empty( $visibility_ids['exclude-from-catalog'] ) ) {
			$tax_query[] = [
				'taxonomy' => 'product_visibility',
				'field'    => 'term_taxonomy_id',
				'terms'    => [ (int) $visibility_ids['exclude-from-catalog'] ],
				'operator' => 'NOT IN',
			];
		}

		$query = new WP_Query( [
			'post_type'              => 'product',
			'post_status'            => 'publish',
			'fields'                 => 'ids',
			'posts_per_page'         => $per_page,
			'paged'                  => $page,
			'orderby'                => 'ID',
			'order'                  => 'ASC',
			'ignore_sticky_posts'    => true,
			'update_post_meta_cache' => true,
			'update_post_term_cache' => false,
			'tax_query'              => $tax_query,
		] );

		$items = [];
		foreach ( $query->posts as $product_id ) {
			$base_price = get_post_meta( $product_id, '_price', true );
			if ( '' === $base_price || ! is_numeric( $base_price ) || (float) $base_price < 0 ) {
				return new WP_Error(
					'catalog_price_unavailable',
					'Catalog pricing is temporarily unavailable.',
					[ 'status' => 503 ]
				);
			}

			$price = 'IDR' === $currency
				? (float) $base_price
				: ( class_exists( 'Artmatter_Store_Enhancements' ) ? Artmatter_Store_Enhancements::calculate_price_for_currency( (float) $base_price, $currency ) : (float) $base_price );
			$items[] = [
				'id'    => (int) $product_id,
				'price' => $price,
			];
		}

		$data = [
			'currency'    => $currency,
			'page'        => $page,
			'per_page'    => $per_page,
			'total'       => (int) $query->found_posts,
			'total_pages' => (int) $query->max_num_pages,
			'items'       => $items,
		];
		set_transient( $cache_key, $data, MINUTE_IN_SECONDS );

		$response = new WP_REST_Response( $data );
		$response->header( 'Cache-Control', 'public, max-age=60, stale-while-revalidate=300' );
		return $response;
	}

	/**
	 * REST API Endpoint Registration for Exacoat Manager ERP & Storefront
	 */
	public function register_bridge_routes() {
		$namespaces = [ 'exacoat-core/v1' ];

		$register = function( string $route, array $args ) use ( $namespaces ) {
			foreach ( $namespaces as $namespace ) {
				register_rest_route( $namespace, $route, $args );
			}
		};

		$register( '/health', [
			'methods'             => 'GET',
			'callback'            => [ $this, 'rest_get_health_status' ],
			'permission_callback' => '__return_true',
		] );

		$register( '/catalog/prices', [
			'methods'             => 'GET',
			'callback'            => [ $this, 'rest_get_catalog_prices' ],
			'permission_callback' => '__return_true',
			'args'                => [
				'currency' => [
					'required'          => true,
					'sanitize_callback' => static function( $value ) {
						return strtoupper( sanitize_text_field( (string) $value ) );
					},
					'validate_callback' => static function( $value ) {
						$currency = strtoupper( sanitize_text_field( (string) $value ) );
						$allowed  = array_merge( [ 'IDR' ], class_exists( 'Artmatter_Store_Enhancements' ) ? array_keys( Artmatter_Store_Enhancements::get_currency_rates() ) : [ 'USD', 'SGD', 'MYR', 'EUR', 'GBP', 'AUD' ] );
						return in_array( $currency, array_unique( $allowed ), true );
					},
				],
				'page' => [
					'default'           => 1,
					'sanitize_callback' => 'absint',
					'validate_callback' => static function( $value ) {
						return is_numeric( $value ) && (int) $value >= 1 && (int) $value <= 1000;
					},
				],
				'per_page' => [
					'default'           => 100,
					'sanitize_callback' => 'absint',
					'validate_callback' => static function( $value ) {
						return is_numeric( $value ) && (int) $value >= 1 && (int) $value <= 250;
					},
				],
			],
		] );

		$register( '/ping', [
			'methods'             => 'POST',
			'callback'            => [ $this, 'rest_handle_ping' ],
			'permission_callback' => '__return_true',
		] );

		$register( '/contact', [
			'methods'             => 'POST',
			'callback'            => [ $this, 'rest_submit_contact' ],
			'permission_callback' => '__return_true',
		] );

		$register( '/settings', [
			'methods'             => 'GET',
			'callback'            => [ $this, 'rest_get_settings' ],
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/settings', [
			'methods'             => 'POST',
			'callback'            => [ $this, 'rest_save_settings' ],
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/settings/currency', [
			'methods'             => [ 'GET', 'POST' ],
			'callback'            => [ $this, 'rest_handle_currency_settings' ],
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/settings/currency/sync-aelia', [
			'methods'             => [ 'GET', 'POST' ],
			'callback'            => [ $this, 'rest_sync_currency_aelia' ],
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/settings/shipping', [
			'methods'             => [ 'GET', 'POST' ],
			'callback'            => [ $this, 'rest_handle_shipping_settings' ],
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/settings/feelform', [
			'methods'             => 'GET',
			'callback'            => [ $this, 'rest_get_public_feelform_settings' ],
			'permission_callback' => '__return_true',
		] );

		$register( '/cache/cloudflare/purge', [
			'methods'             => 'POST',
			'callback'            => [ $this, 'rest_purge_cloudflare_cache' ],
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/debug/coupon-post-type', [
			'methods'             => 'GET',
			'callback'            => [ $this, 'rest_debug_coupon_post_type' ],
			'permission_callback' => '__return_true',
		] );

		$register( '/redirects', [
			'methods'             => 'GET',
			'callback'            => [ $this, 'rest_get_redirects' ],
			'permission_callback' => '__return_true',
		] );

		$register( '/redirects', [
			'methods'             => 'POST',
			'callback'            => [ $this, 'rest_save_redirects' ],
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/redirects/track', [
			'methods'             => 'POST',
			'callback'            => [ $this, 'rest_track_redirect' ],
			'permission_callback' => '__return_true',
		] );

		// User Taste Profile REST Endpoints
		$register( '/user/taste-profile', [
			'methods'             => [ 'GET', 'POST' ],
			'callback'            => function( WP_REST_Request $request ) {
				$user_id = get_current_user_id();
				if ( ! $user_id ) {
					return rest_ensure_response( [ 'success' => false, 'error' => 'User not logged in' ] );
				}

				if ( $request->get_method() === 'POST' ) {
					$params  = $request->get_json_params() ?: $request->get_params();
					$profile = $params['profile'] ?? null;
					if ( is_array( $profile ) ) {
						update_user_meta( $user_id, '_exacoat_taste_profile', $profile );
						return rest_ensure_response( [ 'success' => true, 'message' => 'Taste profile synchronized' ] );
					}
					return rest_ensure_response( [ 'success' => false, 'error' => 'Invalid profile payload' ] );
				}

				$profile = get_user_meta( $user_id, '_exacoat_taste_profile', true ) ?: ( get_user_meta( $user_id, '_artmatter_taste_profile', true ) ?: [] );
				return rest_ensure_response( [ 'success' => true, 'profile' => $profile ] );
			},
			'permission_callback' => '__return_true',
		] );

		// Diagnostics Endpoints
		$register( '/diagnostics/run', [
			'methods'             => 'GET',
			'callback'            => function() {
				$diag = class_exists( 'Exacoat_Diagnostics' ) ? 'Exacoat_Diagnostics' : ( class_exists( 'Artmatter_Diagnostics' ) ? 'Artmatter_Diagnostics' : false );
				return rest_ensure_response( $diag ? $diag::run_full_api_health_check() : [ 'success' => true ] );
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/diagnostics/catalog-reconciliation', [
			'methods'             => 'GET',
			'callback'            => function( WP_REST_Request $request ) {
				$diag = class_exists( 'Exacoat_Diagnostics' ) ? 'Exacoat_Diagnostics' : ( class_exists( 'Artmatter_Diagnostics' ) ? 'Artmatter_Diagnostics' : false );
				return rest_ensure_response( $diag ? $diag::reconcile_catalog(
					max( 1, absint( $request->get_param( 'page' ) ) ),
					min( 250, max( 1, absint( $request->get_param( 'per_page' ) ) ) )
				) : [ 'success' => true ] );
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
			'args'                => [
				'page'     => [ 'default' => 1, 'sanitize_callback' => 'absint' ],
				'per_page' => [ 'default' => 100, 'sanitize_callback' => 'absint' ],
			],
		] );

		$register( '/diagnostics/test-email', [
			'methods'             => 'POST',
			'callback'            => function( WP_REST_Request $request ) {
				$params    = $request->get_json_params() ?: $request->get_params();
				$event     = sanitize_key( $params['event'] ?? 'test_ping' );
				$recipient = sanitize_email( $params['recipient_email'] ?? '' );
				$diag      = class_exists( 'Exacoat_Diagnostics' ) ? 'Exacoat_Diagnostics' : ( class_exists( 'Artmatter_Diagnostics' ) ? 'Artmatter_Diagnostics' : false );
				return rest_ensure_response( $diag ? $diag::test_email_webhook( $event, $recipient, $params ) : [ 'success' => true ] );
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/diagnostics/test-pushover', [
			'methods'             => 'POST',
			'callback'            => function( WP_REST_Request $request ) {
				$params    = $request->get_json_params() ?: $request->get_params();
				$app_token = sanitize_text_field( $params['app_token'] ?? '' );
				$user_key  = sanitize_text_field( $params['user_key'] ?? '' );
				$title     = sanitize_text_field( $params['title'] ?? '' );
				$message   = sanitize_text_field( $params['message'] ?? '' );
				$url       = esc_url_raw( $params['url'] ?? '' );
				$priority  = isset( $params['priority'] ) ? intval( $params['priority'] ) : 0;
				$diag      = class_exists( 'Exacoat_Diagnostics' ) ? 'Exacoat_Diagnostics' : ( class_exists( 'Artmatter_Diagnostics' ) ? 'Artmatter_Diagnostics' : false );
				return rest_ensure_response( $diag ? $diag::test_pushover( $app_token, $user_key, $title, $message, $url, $priority ) : [ 'success' => true ] );
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/diagnostics/test-telegram', [
			'methods'             => 'POST',
			'callback'            => function( WP_REST_Request $request ) {
				$params    = $request->get_json_params() ?: $request->get_params();
				$bot_token = sanitize_text_field( $params['bot_token'] ?? '' );
				$chat_id   = sanitize_text_field( $params['chat_id'] ?? '' );
				$thread_id = sanitize_text_field( $params['thread_id'] ?? '' );
				$message   = sanitize_textarea_field( $params['message'] ?? '' );
				$diag      = class_exists( 'Exacoat_Diagnostics' ) ? 'Exacoat_Diagnostics' : ( class_exists( 'Artmatter_Diagnostics' ) ? 'Artmatter_Diagnostics' : false );
				return rest_ensure_response( $diag ? $diag::test_telegram( $bot_token, $chat_id, $thread_id, $message ) : [ 'success' => false, 'message' => 'Diagnostics module not found' ] );
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/diagnostics/test-r2', [
			'methods'             => [ 'GET', 'POST' ],
			'callback'            => function() {
				$diag = class_exists( 'Exacoat_Diagnostics' ) ? 'Exacoat_Diagnostics' : ( class_exists( 'Artmatter_Diagnostics' ) ? 'Artmatter_Diagnostics' : false );
				return rest_ensure_response( $diag ? $diag::test_r2() : [ 'success' => true ] );
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/diagnostics/test-drime', [
			'methods'             => [ 'GET', 'POST' ],
			'callback'            => function( WP_REST_Request $request ) {
				try {
					$params = $request->get_json_params() ?: $request->get_params();
					$diag   = class_exists( 'Exacoat_Diagnostics' ) ? 'Exacoat_Diagnostics' : ( class_exists( 'Artmatter_Diagnostics' ) ? 'Artmatter_Diagnostics' : false );
					return rest_ensure_response( $diag ? $diag::test_drime( $params ) : [ 'success' => true ] );
				} catch ( Throwable $e ) {
					return rest_ensure_response( [
						'success' => false,
						'message' => 'Diagnostic Exception: ' . $e->getMessage(),
					] );
				}
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/diagnostics/test-cloudflare', [
			'methods'             => [ 'GET', 'POST' ],
			'callback'            => function( WP_REST_Request $request ) {
				$params    = $request->get_json_params() ?: $request->get_params();
				$zone_id   = sanitize_text_field( $params['cloudflare_zone_id'] ?? $params['zone_id'] ?? '' );
				$api_token = sanitize_text_field( $params['cloudflare_api_token'] ?? $params['api_token'] ?? $params['token'] ?? '' );
				$diag      = class_exists( 'Exacoat_Diagnostics' ) ? 'Exacoat_Diagnostics' : ( class_exists( 'Artmatter_Diagnostics' ) ? 'Artmatter_Diagnostics' : false );
				return rest_ensure_response( $diag ? $diag::test_cloudflare_cache( $zone_id, $api_token ) : [ 'success' => true ] );
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/diagnostics/test-gemini', [
			'methods'             => 'POST',
			'callback'            => function( WP_REST_Request $request ) {
				$params  = $request->get_json_params() ?: $request->get_params();
				$api_key = sanitize_text_field( $params['api_key'] ?? '' );
				if ( class_exists( 'Exacoat_Diagnostics' ) ) {
					return rest_ensure_response( Exacoat_Diagnostics::test_gemini( $api_key ) );
				}
				return rest_ensure_response( [ 'success' => false, 'message' => 'Diagnostics class not available' ] );
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/diagnostics/test-openai', [
			'methods'             => 'POST',
			'callback'            => function( WP_REST_Request $request ) {
				$params  = $request->get_json_params() ?: $request->get_params();
				$api_key = sanitize_text_field( $params['api_key'] ?? '' );
				if ( class_exists( 'Exacoat_Diagnostics' ) ) {
					return rest_ensure_response( Exacoat_Diagnostics::test_openai( $api_key ) );
				}
				return rest_ensure_response( [ 'success' => false, 'message' => 'Diagnostics class not available' ] );
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/fandom/generate', [
			'methods'             => 'POST',
			'callback'            => function( WP_REST_Request $request ) {
				$params   = $request->get_json_params() ?: $request->get_params();
				$name     = sanitize_text_field( $params['name'] ?? '' );
				$provider = sanitize_text_field( $params['provider'] ?? 'openai' );
				$prompt   = sanitize_textarea_field( $params['prompt'] ?? '' );
				$model    = sanitize_text_field( $params['model'] ?? '' );

				if ( empty( $name ) ) {
					return rest_ensure_response( [ 'success' => false, 'message' => 'Collection or theme name is required.' ] );
				}

				$settings = Exacoat_Core::get_settings();
				$is_gemini = ( stripos( $provider, 'gemini' ) !== false );
				$start = microtime( true );

				if ( $is_gemini ) {
					$api_key = defined( 'EXACOAT_GEMINI_API_KEY' ) ? EXACOAT_GEMINI_API_KEY : ( defined( 'AM_GEMINI_API_KEY' ) ? AM_GEMINI_API_KEY : ( defined( 'GEMINI_API_KEY' ) ? GEMINI_API_KEY : ( getenv( 'EXACOAT_GEMINI_API_KEY' ) ?: ( getenv( 'AM_GEMINI_API_KEY' ) ?: ( $settings['gemini_api_key'] ?? '' ) ) ) ) );
					$gemini_model = $model ?: ( $settings['gemini_model'] ?? 'gemini-2.5-flash' );

					if ( empty( $api_key ) ) {
						return rest_ensure_response( [ 'success' => false, 'message' => 'Gemini API key not configured on server.' ] );
					}

					$full_prompt = ( $prompt ? $prompt . "\n\n" : '' ) . "Collection or series name: \"{$name}\"";
					$url = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode( $gemini_model ) . ':generateContent?key=' . rawurlencode( $api_key );
					$resp = wp_remote_post( $url, [
						'headers' => [ 'Content-Type' => 'application/json' ],
						'body'    => wp_json_encode( [
							'contents' => [
								[ 'role' => 'user', 'parts' => [ [ 'text' => $full_prompt ] ] ],
							],
						] ),
						'timeout' => 30,
					] );

					$latency = round( ( microtime( true ) - $start ) * 1000 );
					if ( is_wp_error( $resp ) ) {
						return rest_ensure_response( [ 'success' => false, 'message' => $resp->get_error_message(), 'latency_ms' => $latency ] );
					}

					$body = json_decode( wp_remote_retrieve_body( $resp ), true );
					$text = $body['candidates'][0]['content']['parts'][0]['text'] ?? '';
					if ( empty( $text ) ) {
						return rest_ensure_response( [ 'success' => false, 'message' => $body['error']['message'] ?? 'No text generated by Gemini', 'latency_ms' => $latency ] );
					}

					return rest_ensure_response( [
						'success'     => true,
						'text'        => $text,
						'description' => $text,
						'model_used'  => $gemini_model,
						'latency_ms'  => $latency,
					] );
				} else {
					$api_key = defined( 'EXACOAT_OPENAI_API_KEY' ) ? EXACOAT_OPENAI_API_KEY : ( defined( 'AM_OPENAI_API_KEY' ) ? AM_OPENAI_API_KEY : ( defined( 'OPENAI_API_KEY' ) ? OPENAI_API_KEY : ( getenv( 'EXACOAT_OPENAI_API_KEY' ) ?: ( getenv( 'AM_OPENAI_API_KEY' ) ?: ( $settings['openai_api_key'] ?? '' ) ) ) ) );
					$openai_model = $model ?: ( $settings['openai_model'] ?? 'gpt-4o-mini' );

					if ( empty( $api_key ) ) {
						return rest_ensure_response( [ 'success' => false, 'message' => 'OpenAI API key not configured on server.' ] );
					}

					$messages = [];
					if ( ! empty( $prompt ) ) {
						$messages[] = [ 'role' => 'system', 'content' => $prompt ];
					}
					$messages[] = [ 'role' => 'user', 'content' => "Collection or series name: \"{$name}\"" ];

					$is_reasoning_or_gpt5 = (bool) preg_match( '/^(o[0-9]|gpt-5)/i', preg_replace( '/^openai\//', '', $openai_model ) );
					$body_args = [
						'model'    => $openai_model,
						'messages' => $messages,
					];
					if ( ! $is_reasoning_or_gpt5 ) {
						$body_args['temperature'] = 0.7;
					}

					$resp = wp_remote_post( 'https://api.openai.com/v1/chat/completions', [
						'headers' => [
							'Content-Type'  => 'application/json',
							'Authorization' => 'Bearer ' . $api_key,
						],
						'body'    => wp_json_encode( $body_args ),
						'timeout' => 30,
					] );

					// Auto-retry without temperature if rejected due to model parameter restrictions
					if ( ! is_wp_error( $resp ) ) {
						$check_body = json_decode( wp_remote_retrieve_body( $resp ), true );
						if ( isset( $check_body['error']['message'] ) && stripos( $check_body['error']['message'], 'temperature' ) !== false ) {
							unset( $body_args['temperature'] );
							$resp = wp_remote_post( 'https://api.openai.com/v1/chat/completions', [
								'headers' => [
									'Content-Type'  => 'application/json',
									'Authorization' => 'Bearer ' . $api_key,
								],
								'body'    => wp_json_encode( $body_args ),
								'timeout' => 30,
							] );
						}
					}

					$latency = round( ( microtime( true ) - $start ) * 1000 );
					if ( is_wp_error( $resp ) ) {
						return rest_ensure_response( [ 'success' => false, 'message' => $resp->get_error_message(), 'latency_ms' => $latency ] );
					}

					$body = json_decode( wp_remote_retrieve_body( $resp ), true );
					$text = $body['choices'][0]['message']['content'] ?? '';
					if ( empty( $text ) ) {
						return rest_ensure_response( [ 'success' => false, 'message' => $body['error']['message'] ?? 'No text generated by OpenAI', 'latency_ms' => $latency ] );
					}

					return rest_ensure_response( [
						'success'     => true,
						'text'        => $text,
						'description' => $text,
						'model_used'  => $openai_model,
						'latency_ms'  => $latency,
					] );
				}
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		// Product SEO & Short Description Read Endpoint
		$register( '/product/seo', [
			'methods'             => 'GET',
			'callback'            => function( WP_REST_Request $request ) {
				$product_id = (int) $request->get_param( 'product_id' );
				if ( empty( $product_id ) ) {
					return rest_ensure_response( [ 'success' => false, 'message' => 'Product ID is required.' ] );
				}

				$post = get_post( $product_id );
				if ( ! $post ) {
					return rest_ensure_response( [ 'success' => false, 'message' => 'Product not found.' ] );
				}

				$short_desc  = $post->post_excerpt;
				$yoast_title = get_post_meta( $product_id, '_yoast_wpseo_title', true );
				$rm_title    = get_post_meta( $product_id, 'rank_math_title', true );
				$yoast_desc  = get_post_meta( $product_id, '_yoast_wpseo_metadesc', true );
				$rm_desc     = get_post_meta( $product_id, 'rank_math_description', true );
				$yoast_kw    = get_post_meta( $product_id, '_yoast_wpseo_focuskw', true );
				$rm_kw       = get_post_meta( $product_id, 'rank_math_focus_keyword', true );

				$thumb_id           = (int) get_post_thumbnail_id( $product_id );
				$featured_image_url = $thumb_id ? (string) wp_get_attachment_image_url( $thumb_id, 'large' ) : '';
				$gallery_raw        = (string) get_post_meta( $product_id, '_product_image_gallery', true );
				$gallery_ids        = array_values( array_filter( array_map( 'intval', explode( ',', $gallery_raw ) ) ) );
				$first_gallery_url  = ! empty( $gallery_ids ) ? (string) wp_get_attachment_image_url( $gallery_ids[0], 'large' ) : '';
				$google_image_url   = $first_gallery_url ?: $featured_image_url;

				return rest_ensure_response( [
					'success'            => true,
					'product_id'         => $product_id,
					'name'               => $post->post_title,
					'slug'               => $post->post_name,
					'short_description'  => (string) $short_desc,
					'seo_title'          => (string) ( $yoast_title ?: ( $rm_title ?: '' ) ),
					'seo_description'    => (string) ( $yoast_desc ?: ( $rm_desc ?: '' ) ),
					'focus_keyword'      => (string) ( $yoast_kw ?: ( $rm_kw ?: '' ) ),
					'google_image_url'   => $google_image_url,
					'featured_image_url' => $featured_image_url,
					'is_gallery_image'   => ! empty( $first_gallery_url ),
				] );
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		// Product SEO & Short Description Update Endpoint
		$register( '/product/seo', [
			'methods'             => 'POST',
			'callback'            => function( WP_REST_Request $request ) {
				$params     = $request->get_json_params() ?: $request->get_params();
				$product_id = (int) ( $params['product_id'] ?? 0 );
				if ( empty( $product_id ) ) {
					return rest_ensure_response( [ 'success' => false, 'message' => 'Product ID is required.' ] );
				}

				$post = get_post( $product_id );
				if ( ! $post ) {
					return rest_ensure_response( [ 'success' => false, 'message' => 'Product not found.' ] );
				}

				$short_desc = (string) ( $params['short_description'] ?? '' );
				$seo_title  = sanitize_text_field( (string) ( $params['seo_title'] ?? '' ) );
				$seo_desc   = sanitize_textarea_field( (string) ( $params['seo_description'] ?? '' ) );
				$focus_kw   = sanitize_text_field( (string) ( $params['focus_keyword'] ?? '' ) );

				// Update post excerpt in wp_posts
				wp_update_post( [
					'ID'           => $product_id,
					'post_excerpt' => $short_desc,
				] );

				// Update Yoast and Rank Math metadata
				update_post_meta( $product_id, '_yoast_wpseo_title', $seo_title );
				update_post_meta( $product_id, 'rank_math_title', $seo_title );

				update_post_meta( $product_id, '_yoast_wpseo_metadesc', $seo_desc );
				update_post_meta( $product_id, 'rank_math_description', $seo_desc );

				update_post_meta( $product_id, '_yoast_wpseo_focuskw', $focus_kw );
				update_post_meta( $product_id, 'rank_math_focus_keyword', $focus_kw );

				// Trigger storefront revalidation if available
				if ( class_exists( 'Exacoat_Configurator_Engine' ) && method_exists( 'Exacoat_Configurator_Engine', 'trigger_storefront_revalidation' ) ) {
					Exacoat_Configurator_Engine::trigger_storefront_revalidation( [ 'slug' => $post->post_name ] );
				}

				if ( class_exists( 'Exacoat_Logger' ) ) {
					Exacoat_Logger::log( 'info', 'seo_manager', sprintf( 'Updated SEO & Short description for product #%d (%s)', $product_id, $post->post_title ) );
				}

				return rest_ensure_response( [
					'success'           => true,
					'product_id'        => $product_id,
					'short_description' => $short_desc,
					'seo_title'         => $seo_title,
					'seo_description'   => $seo_desc,
					'focus_keyword'     => $focus_kw,
					'message'           => 'Product SEO and Short Description saved successfully.',
				] );
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		// Product AI SEO & Short Description Generator Endpoint
		$register( '/product/generate-seo', [
			'methods'             => 'POST',
			'callback'            => function( WP_REST_Request $request ) {
				$params   = $request->get_json_params() ?: $request->get_params();
				$name     = sanitize_text_field( $params['name'] ?? '' );
				$category = sanitize_text_field( $params['category'] ?? 'Skins' );
				$provider = sanitize_text_field( $params['provider'] ?? 'gemini' );
				$model    = sanitize_text_field( $params['model'] ?? '' );

				if ( empty( $name ) ) {
					return rest_ensure_response( [ 'success' => false, 'message' => 'Product or device name is required.' ] );
				}

				$clean_name = trim( preg_replace( '/\s+(skins?|wraps?|skin & wrap|skins & wraps)$/i', '', $name ) );
				if ( empty( $clean_name ) ) {
					$clean_name = $name;
				}

				$settings = Exacoat_Core::get_settings();
				$is_gemini = ( stripos( $provider, 'gemini' ) !== false );
				$start = microtime( true );

				$system_instruction = "You are the lead creative copywriter for Exacoat (exacoat.com), an industrial-design studio that crafts precision-cut device wraps and skins.\n\n"
					. "Target Product:\n"
					. "- Device Name: \"{$clean_name}\"\n"
					. "- Category: \"{$category}\"\n\n"
					. "Creative Philosophy & Voice:\n"
					. "- Write with dry, effortless, design-studio wit. The tone is refined, observant, and self-aware: clever enough to make a hardware enthusiast smirk, yet composed and thoroughly premium.\n"
					. "- Capture the everyday irony of owning \"{$clean_name}\": hardware engineers spend years shaving fractions of a millimeter off a chassis, balancing weight distribution, and perfecting finishes, only for owners to face a flawed choice. Either bury all that engineering inside a thick plastic case that ruins the silhouette and pocket feel, or carry it bare and let smudges, desk grit, pocket keys, or a slick surface win within a week.\n"
					. "- Think fresh about \"{$clean_name}\" specifically (its actual physical proportions, chassis weight, camera plateau geometry, how its surface finish behaves in real hands, or how bulky cases spoil its design). Weave a sharp, original observation into the opening, then pivot naturally to how an Exacoat wrap keeps the exact factory silhouette while adding confident grip and everyday scratch defense.\n"
					. "- Every product must get completely original phrasing. Do not recycle stock jokes or repetitive formulas across devices.\n\n"
					. "Strict Guardrails:\n"
					. "- Never mention vinyl manufacturer brand names.\n"
					. "- Never sound like a technical spec sheet or installation manual (avoid millimeter thickness measurements, adhesive terminology, or mechanical jargon).\n"
					. "- Strictly NO exclamation marks.\n"
					. "- Strictly NO em dashes of any kind (do not use long dashes or double hyphens '--'). Use commas or periods instead.\n"
					. "- Strictly NO generic AI hype words ('elevate', 'revolutionary', 'unleash', 'game-changer', 'ultimate armor', 'unparalleled', 'seamless').\n\n"
					. "Output Requirement:\n"
					. "Return ONLY a valid JSON object with the following four keys (no markdown formatting, no conversational text):\n"
					. "{\n"
					. "  \"seo_title\": \"{$clean_name} Skin & Wrap | Exacoat\",\n"
					. "  \"seo_description\": \"Witty, refined Google search snippet (120 to 155 chars) contrasting bulky cases or bare-device flaws with Exacoat's zero-bulk grip and scratch defense. Zero em dashes.\",\n"
					. "  \"focus_keyword\": \"{$clean_name} skin\",\n"
					. "  \"short_description\": \"2 to 3 sharp, witty, lifestyle-first sentences (35 to 55 words) tailored specifically to the real-world experience of carrying and protecting the {$clean_name} without case bulk.\"\n"
					. "}";

				$sanitize_seo_fields = function( array $data ): array {
					foreach ( [ 'seo_title', 'seo_description', 'short_description', 'focus_keyword' ] as $k ) {
						if ( isset( $data[ $k ] ) && is_string( $data[ $k ] ) ) {
							$val = preg_replace( '/!+/', '.', $data[ $k ] );
							$val = preg_replace( '/[\x{2014}\x{2013}]|--/u', ', ', $val );
							$data[ $k ] = trim( preg_replace( '/\s{2,}/', ' ', $val ) );
						}
					}
					return $data;
				};

				if ( $is_gemini ) {
					$api_key = defined( 'EXACOAT_GEMINI_API_KEY' ) ? EXACOAT_GEMINI_API_KEY : ( defined( 'AM_GEMINI_API_KEY' ) ? AM_GEMINI_API_KEY : ( defined( 'GEMINI_API_KEY' ) ? GEMINI_API_KEY : ( getenv( 'EXACOAT_GEMINI_API_KEY' ) ?: ( getenv( 'AM_GEMINI_API_KEY' ) ?: ( $settings['gemini_api_key'] ?? '' ) ) ) ) );
					$gemini_model = $model ?: ( $settings['gemini_model'] ?? 'gemini-2.5-flash' );

					if ( empty( $api_key ) ) {
						return rest_ensure_response( [ 'success' => false, 'message' => 'Gemini API key not configured on server.' ] );
					}

					$url = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode( $gemini_model ) . ':generateContent?key=' . rawurlencode( $api_key );
					$resp = wp_remote_post( $url, [
						'headers' => [ 'Content-Type' => 'application/json' ],
						'body'    => wp_json_encode( [
							'contents' => [
								[
									'role'  => 'user',
									'parts' => [ [ 'text' => $system_instruction ] ],
								],
							],
							'generationConfig' => [
								'response_mime_type' => 'application/json',
								'temperature'        => 0.7,
							],
						] ),
						'timeout' => 30,
					] );

					$latency = round( ( microtime( true ) - $start ) * 1000 );
					if ( is_wp_error( $resp ) ) {
						return rest_ensure_response( [ 'success' => false, 'message' => $resp->get_error_message(), 'latency_ms' => $latency ] );
					}

					$body = json_decode( wp_remote_retrieve_body( $resp ), true );
					$text = $body['candidates'][0]['content']['parts'][0]['text'] ?? '';
					$parsed = json_decode( trim( $text ), true );

					if ( ! is_array( $parsed ) || empty( $parsed['seo_title'] ) ) {
						$clean_json = preg_replace( '/^```(?:json)?\s*|\s*```$/i', '', trim( $text ) );
						$parsed = json_decode( $clean_json, true );
					}

					if ( is_array( $parsed ) && ! empty( $parsed['seo_title'] ) ) {
						$parsed = $sanitize_seo_fields( $parsed );
						return rest_ensure_response( [
							'success'    => true,
							'data'       => $parsed,
							'model_used' => $gemini_model,
							'latency_ms' => $latency,
						] );
					}

					return rest_ensure_response( [ 'success' => false, 'message' => 'Failed to parse AI output as JSON.', 'raw' => $text, 'latency_ms' => $latency ] );
				} else {
					$api_key = defined( 'EXACOAT_OPENAI_API_KEY' ) ? EXACOAT_OPENAI_API_KEY : ( defined( 'AM_OPENAI_API_KEY' ) ? AM_OPENAI_API_KEY : ( defined( 'OPENAI_API_KEY' ) ? OPENAI_API_KEY : ( getenv( 'EXACOAT_OPENAI_API_KEY' ) ?: ( getenv( 'AM_OPENAI_API_KEY' ) ?: ( $settings['openai_api_key'] ?? '' ) ) ) ) );
					$openai_model = $model ?: ( $settings['openai_model'] ?? 'gpt-4o-mini' );

					if ( empty( $api_key ) ) {
						return rest_ensure_response( [ 'success' => false, 'message' => 'OpenAI API key not configured on server.' ] );
					}

					$is_reasoning_or_gpt5 = (bool) preg_match( '/^(o[0-9]|gpt-5)/i', preg_replace( '/^openai\//', '', $openai_model ) );
					$body_args = [
						'model'           => $openai_model,
						'messages'        => [
							[ 'role' => 'user', 'content' => $system_instruction ],
						],
						'response_format' => [ 'type' => 'json_object' ],
					];
					if ( ! $is_reasoning_or_gpt5 ) {
						$body_args['temperature'] = 0.7;
					}

					$resp = wp_remote_post( 'https://api.openai.com/v1/chat/completions', [
						'headers' => [
							'Content-Type'  => 'application/json',
							'Authorization' => 'Bearer ' . $api_key,
						],
						'body'    => wp_json_encode( $body_args ),
						'timeout' => 30,
					] );

					// Auto-retry without temperature if rejected due to model parameter restrictions
					if ( ! is_wp_error( $resp ) ) {
						$check_body = json_decode( wp_remote_retrieve_body( $resp ), true );
						if ( isset( $check_body['error']['message'] ) && stripos( $check_body['error']['message'], 'temperature' ) !== false ) {
							unset( $body_args['temperature'] );
							$resp = wp_remote_post( 'https://api.openai.com/v1/chat/completions', [
								'headers' => [
									'Content-Type'  => 'application/json',
									'Authorization' => 'Bearer ' . $api_key,
								],
								'body'    => wp_json_encode( $body_args ),
								'timeout' => 30,
							] );
						}
					}

					$latency = round( ( microtime( true ) - $start ) * 1000 );
					if ( is_wp_error( $resp ) ) {
						return rest_ensure_response( [ 'success' => false, 'message' => $resp->get_error_message(), 'latency_ms' => $latency ] );
					}

					$body = json_decode( wp_remote_retrieve_body( $resp ), true );
					if ( isset( $body['error']['message'] ) ) {
						return rest_ensure_response( [ 'success' => false, 'message' => $body['error']['message'], 'latency_ms' => $latency ] );
					}

					$text = $body['choices'][0]['message']['content'] ?? '';
					$parsed = json_decode( trim( $text ), true );

					if ( is_array( $parsed ) && ! empty( $parsed['seo_title'] ) ) {
						$parsed = $sanitize_seo_fields( $parsed );
						return rest_ensure_response( [
							'success'    => true,
							'data'       => $parsed,
							'model_used' => $openai_model,
							'latency_ms' => $latency,
						] );
					}

					return rest_ensure_response( [ 'success' => false, 'message' => 'Failed to parse OpenAI JSON output.', 'raw' => $text, 'latency_ms' => $latency ] );
				}
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		// Universal CORS-free Image Proxy
		$handle_image_proxy = function( WP_REST_Request $request ) {
			$product_id = (int) $request->get_param( 'product_id' );
			$url        = (string) $request->get_param( 'url' );
			if ( ! empty( $url ) && filter_var( $url, FILTER_VALIDATE_URL ) ) {
				$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
				$allowed_hosts = [ 'exacoat.com', 'www.exacoat.com', 'cms.exacoat.com', 'media.exacoat.com', 'staging.exacoat.com' ];
				if ( ! in_array( $host, $allowed_hosts, true ) ) {
					return new WP_REST_Response( [ 'success' => false, 'error' => 'Image host is not allowed.' ], 400 );
				}
			}

			$filepath = '';

			if ( $product_id > 0 && empty( $url ) ) {
				$thumb_id = get_post_thumbnail_id( $product_id );
				if ( $thumb_id ) {
					$filepath = (string) get_attached_file( $thumb_id );
				}
			}

			if ( empty( $filepath ) || ! file_exists( $filepath ) ) {
				if ( ! empty( $url ) ) {
					$upload_dir = wp_upload_dir();
					if ( preg_match( '#/wp-content/uploads/(.+)$#i', $url, $matches ) ) {
						$clean_rel = ltrim( parse_url( $matches[1], PHP_URL_PATH ) ?: $matches[1], '/' );
						$candidate = $upload_dir['basedir'] . '/' . $clean_rel;
						if ( file_exists( $candidate ) ) {
							$filepath = $candidate;
						}
					}
					if ( empty( $filepath ) || ! file_exists( $filepath ) ) {
						$rel = str_replace( $upload_dir['baseurl'], '', $url );
						$candidate = $upload_dir['basedir'] . $rel;
						if ( file_exists( $candidate ) ) {
							$filepath = $candidate;
						}
					}
					if ( empty( $filepath ) || ! file_exists( $filepath ) ) {
						$candidate_filename = wp_basename( $clean_rel ?: parse_url( $url, PHP_URL_PATH ) );
						if ( ! empty( $candidate_filename ) ) {
							if ( class_exists( 'Exacoat_Store_Enhancements' ) && method_exists( 'Exacoat_Store_Enhancements', 'locate_physical_upload' ) ) {
								$resolved = Exacoat_Store_Enhancements::locate_physical_upload( $candidate_filename, $clean_rel ?? '', $upload_dir['basedir'] );
								if ( ! empty( $resolved ) ) {
									$filepath = $resolved;
								}
							} else {
								$flat_candidate = $upload_dir['basedir'] . '/' . $candidate_filename;
								if ( file_exists( $flat_candidate ) ) {
									$filepath = $flat_candidate;
								}
							}
						}
					}
				}
			}

			if ( ! empty( $filepath ) && file_exists( $filepath ) ) {
				$mime = wp_check_filetype( $filepath )['type'] ?: 'image/jpeg';
				$data = file_get_contents( $filepath );

				header( 'Content-Type: ' . $mime );
				header( 'Access-Control-Allow-Origin: *' );
				header( 'Access-Control-Allow-Methods: GET, OPTIONS' );
				header( 'Access-Control-Allow-Headers: *' );
				header( 'Cache-Control: public, max-age=31536000, immutable' );
				echo $data;
				exit;
			}

			// Remote fetch fallback
			if ( ! empty( $url ) && filter_var( $url, FILTER_VALIDATE_URL ) ) {
				$response = wp_safe_remote_get( $url, [ 'timeout' => 30, 'limit_response_size' => 25 * MB_IN_BYTES ] );
				if ( ! is_wp_error( $response ) && 200 === (int) wp_remote_retrieve_response_code( $response ) ) {
					$content_type = wp_remote_retrieve_header( $response, 'content-type' ) ?: 'image/jpeg';
					$body         = wp_remote_retrieve_body( $response );

					header( 'Content-Type: ' . $content_type );
					header( 'Access-Control-Allow-Origin: *' );
					header( 'Access-Control-Allow-Methods: GET, OPTIONS' );
					header( 'Access-Control-Allow-Headers: *' );
					header( 'Cache-Control: public, max-age=86400' );
					echo $body;
					exit;
				}
			}

			return new WP_REST_Response( [ 'success' => false, 'error' => 'Image file not found on server' ], 404 );
		};

		$register( '/image-proxy', [
			'methods'             => [ 'GET' ],
			'callback'            => $handle_image_proxy,
			'permission_callback' => '__return_true',
		] );

		// Product Collection Management Endpoints
		$register( '/collections/create', [
			'methods'             => [ 'POST' ],
			'callback'            => function( WP_REST_Request $request ) {
				try {
					$params = $request->get_json_params() ?: $request->get_params();
					$name = trim( sanitize_text_field( $params['name'] ?? $params['collection_name'] ?? '' ) );
					$slug = trim( sanitize_title( $params['slug'] ?? $name ) );

					if ( empty( $name ) ) {
						return rest_ensure_response( [ 'success' => false, 'message' => 'Collection name is required' ] );
					}

					$taxonomy = taxonomy_exists( 'product_cat' ) ? 'product_cat' : 'category';
					$existing = term_exists( $slug, $taxonomy ) ?: term_exists( $name, $taxonomy );
					if ( $existing ) {
						$term_id = is_array( $existing ) ? (int) $existing['term_id'] : (int) $existing;
						return rest_ensure_response( [
							'success' => true,
							'term_id' => $term_id,
							'name'    => $name,
							'slug'    => $slug,
							'message' => "Collection '{$name}' already exists.",
						] );
					}

					$inserted = wp_insert_term( $name, $taxonomy, [ 'slug' => $slug ] );
					if ( is_wp_error( $inserted ) ) {
						return rest_ensure_response( [ 'success' => false, 'message' => $inserted->get_error_message() ] );
					}

					$term_id = (int) $inserted['term_id'];
					return rest_ensure_response( [
						'success' => true,
						'term_id' => $term_id,
						'name'    => $name,
						'slug'    => $slug,
						'message' => "Collection '{$name}' created in WordPress.",
					] );
				} catch ( Throwable $e ) {
					return rest_ensure_response( [ 'success' => false, 'message' => 'Create collection error: ' . $e->getMessage() ] );
				}
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/collections/rename', [
			'methods'             => [ 'POST' ],
			'callback'            => function( WP_REST_Request $request ) {
				try {
					$params = $request->get_json_params() ?: $request->get_params();
					$old_name = trim( sanitize_text_field( $params['old_name'] ?? '' ) );
					$new_name = trim( sanitize_text_field( $params['new_name'] ?? '' ) );
					$description = sanitize_textarea_field( $params['description'] ?? '' );

					if ( empty( $old_name ) || empty( $new_name ) ) {
						return rest_ensure_response( [ 'success' => false, 'message' => 'Old and new collection names are required.' ] );
					}

					$taxonomy = taxonomy_exists( 'product_cat' ) ? 'product_cat' : 'category';
					$term = get_term_by( 'name', $old_name, $taxonomy ) ?: get_term_by( 'slug', sanitize_title( $old_name ), $taxonomy );
					if ( ! $term || is_wp_error( $term ) ) {
						return rest_ensure_response( [ 'success' => false, 'message' => "Collection '{$old_name}' not found." ] );
					}

					$args = [ 'name' => $new_name, 'slug' => sanitize_title( $new_name ) ];
					if ( ! empty( $description ) ) {
						$args['description'] = $description;
					}
					$updated = wp_update_term( $term->term_id, $taxonomy, $args );
					if ( is_wp_error( $updated ) ) {
						return rest_ensure_response( [ 'success' => false, 'message' => $updated->get_error_message() ] );
					}

					return rest_ensure_response( [
						'success' => true,
						'term_id' => $term->term_id,
						'name'    => $new_name,
						'slug'    => sanitize_title( $new_name ),
						'message' => "Collection renamed from '{$old_name}' to '{$new_name}'.",
					] );
				} catch ( Throwable $e ) {
					return rest_ensure_response( [ 'success' => false, 'message' => 'Rename collection error: ' . $e->getMessage() ] );
				}
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/collections/delete', [
			'methods'             => [ 'POST' ],
			'callback'            => function( WP_REST_Request $request ) {
				try {
					$params = $request->get_json_params() ?: $request->get_params();
					$collection_name = trim( sanitize_text_field( $params['collection_name'] ?? $params['name'] ?? '' ) );

					if ( empty( $collection_name ) ) {
						return rest_ensure_response( [ 'success' => false, 'message' => 'Collection name is required.' ] );
					}

					$taxonomy = taxonomy_exists( 'product_cat' ) ? 'product_cat' : 'category';
					$term = get_term_by( 'name', $collection_name, $taxonomy ) ?: get_term_by( 'slug', sanitize_title( $collection_name ), $taxonomy );
					if ( ! $term || is_wp_error( $term ) ) {
						return rest_ensure_response( [ 'success' => false, 'message' => "Collection '{$collection_name}' not found." ] );
					}

					$deleted = wp_delete_term( $term->term_id, $taxonomy );
					return rest_ensure_response( [
						'success' => ! empty( $deleted ),
						'message' => ! empty( $deleted ) ? "Collection '{$collection_name}' deleted." : "Failed to delete collection '{$collection_name}'.",
					] );
				} catch ( Throwable $e ) {
					return rest_ensure_response( [ 'success' => false, 'message' => 'Delete collection error: ' . $e->getMessage() ] );
				}
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		// Cloudflare R2 / Storage Sync Batch
		$register( '/vault/drime/sync-batch', [
			'methods'             => [ 'GET', 'POST' ],
			'callback'            => function( WP_REST_Request $request ) {
				try {
					$params    = $request->get_json_params() ?: $request->get_params();
					$offset    = max( 0, intval( $params['offset'] ?? 0 ) );
					$limit     = max( 1, min( 10, intval( $params['limit'] ?? 2 ) ) );
					$test_mode = ! empty( $params['test_mode'] );

					if ( $test_mode ) {
						$limit = 2;
					}

					if ( ! class_exists( 'Artmatter_R2' ) || ! class_exists( 'Artmatter_Drime' ) ) {
						return rest_ensure_response( [
							'success' => false,
							'message' => 'Storage sync classes not loaded',
						] );
					}

					$all_objects = Artmatter_R2::list_objects();
					$total       = count( $all_objects );

					if ( $total === 0 ) {
						return rest_ensure_response( [
							'success'       => false,
							'message'       => 'No files found in storage bucket to sync.',
							'total_objects' => 0,
						] );
					}

					$slice = array_slice( $all_objects, $offset, $limit );
					$results = [];

					foreach ( $slice as $obj ) {
						$res = Artmatter_Drime::sync_file_from_r2( $obj['key'] );
						$results[] = [
							'key'      => $obj['key'],
							'size'     => $obj['size_fmt'],
							'success'  => $res['success'],
							'file_id'  => $res['file_id'] ?? null,
							'message'  => $res['message'] ?? 'Synced',
						];
					}

					$next_offset = $offset + count( $slice );
					$has_more    = ( ! $test_mode && $next_offset < $total );

					return rest_ensure_response( [
						'success'       => true,
						'total_objects' => $total,
						'processed'     => count( $slice ),
						'offset'        => $offset,
						'next_offset'   => $next_offset,
						'has_more'      => $has_more,
						'synced_files'  => $results,
						'test_mode'     => $test_mode,
					] );
				} catch ( Throwable $e ) {
					return rest_ensure_response( [
						'success' => false,
						'message' => 'Sync Batch Exception: ' . $e->getMessage(),
					] );
				}
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		// Native HTML Email Engine Endpoints
		$register( '/email/send', [
			'methods'             => 'POST',
			'callback'            => function( WP_REST_Request $request ) {
				$params    = $request->get_json_params() ?: $request->get_params();
				$slug      = sanitize_key( $params['template_key'] ?? $params['template_slug'] ?? $params['slug'] ?? $params['event'] ?? '' );
				$recipient = sanitize_email( $params['recipient_email'] ?? $params['email'] ?? '' );
				$name      = sanitize_text_field( $params['recipient_name'] ?? $params['name'] ?? '' );
				$vars      = is_array( $params['variables'] ?? null ) ? $params['variables'] : ( is_array( $params['vars'] ?? null ) ? $params['vars'] : [] );

				if ( empty( $slug ) || empty( $recipient ) ) {
					return new WP_Error( 'missing_params', 'template_slug/template_key and recipient_email are required', [ 'status' => 400 ] );
				}

				$email_class = class_exists( 'Exacoat_Email_Engine' ) ? 'Exacoat_Email_Engine' : ( class_exists( 'Artmatter_Email_Engine' ) ? 'Artmatter_Email_Engine' : false );
				if ( $email_class ) {
					$result = $email_class::send_email( $slug, $recipient, $name, $vars );
					return rest_ensure_response( $result );
				}
				return rest_ensure_response( [ 'success' => false, 'message' => 'Email engine not available' ] );
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/email/preview', [
			'methods'             => [ 'GET', 'POST' ],
			'callback'            => function( WP_REST_Request $request ) {
				$params = $request->get_json_params() ?: $request->get_params();
				$slug   = sanitize_key( $params['template_key'] ?? $params['template_slug'] ?? $params['slug'] ?? $params['event'] ?? '' );
				$vars   = is_array( $params['variables'] ?? null ) ? $params['variables'] : ( is_array( $params['vars'] ?? null ) ? $params['vars'] : [] );

				$email_class = class_exists( 'Exacoat_Email_Engine' ) ? 'Exacoat_Email_Engine' : ( class_exists( 'Artmatter_Email_Engine' ) ? 'Artmatter_Email_Engine' : false );
				if ( $email_class ) {
					$rendered = $email_class::render_html( $slug, $vars );
					if ( $request->get_param( 'raw' ) ) {
						header( 'Content-Type: text/html; charset=UTF-8' );
						echo $rendered['html'] ?? '';
						exit;
					}
					return rest_ensure_response( [
						'success' => true,
						'subject' => $rendered['subject'] ?? 'Email Preview',
						'html'    => $rendered['html'] ?? '',
					] );
				}
				return rest_ensure_response( [ 'success' => false, 'message' => 'Email engine not available' ] );
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		// Acumbamail Email Marketing REST Endpoints
		$register( '/acumbamail/lists', [
			'methods'             => 'GET',
			'callback'            => function( WP_REST_Request $request ) {
				$token = sanitize_text_field( $request->get_param( 'auth_token' ) ?? '' );
				$email_class = class_exists( 'Exacoat_Email_Engine' ) ? 'Exacoat_Email_Engine' : ( class_exists( 'Artmatter_Email_Engine' ) ? 'Artmatter_Email_Engine' : false );
				if ( $email_class && method_exists( $email_class, 'get_acumbamail_lists' ) ) {
					$res = $email_class::get_acumbamail_lists( $token );
					return rest_ensure_response( $res );
				}
				return rest_ensure_response( [ 'success' => false, 'error' => 'Email engine not available' ] );
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/acumbamail/campaign', [
			'methods'             => 'POST',
			'callback'            => function( WP_REST_Request $request ) {
				$params = $request->get_json_params() ?: $request->get_params();
				$email_class = class_exists( 'Exacoat_Email_Engine' ) ? 'Exacoat_Email_Engine' : ( class_exists( 'Artmatter_Email_Engine' ) ? 'Artmatter_Email_Engine' : false );
				if ( $email_class && method_exists( $email_class, 'create_acumbamail_campaign' ) ) {
					$res = $email_class::create_acumbamail_campaign( is_array( $params ) ? $params : [] );
					return rest_ensure_response( $res );
				}
				return rest_ensure_response( [ 'success' => false, 'error' => 'Email engine not available' ] );
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/acumbamail/send-one', [
			'methods'             => 'POST',
			'callback'            => function( WP_REST_Request $request ) {
				$params    = $request->get_json_params() ?: $request->get_params();
				$to_email  = sanitize_email( $params['to_email'] ?? $params['recipient_email'] ?? '' );
				$subject   = sanitize_text_field( $params['subject'] ?? 'Exacoat Update' );
				$html      = $params['body'] ?? $params['html'] ?? '';
				$from_email = sanitize_email( $params['from_email'] ?? '' );
				$from_name  = sanitize_text_field( $params['from_name'] ?? '' );

				if ( empty( $to_email ) || empty( $html ) ) {
					return new WP_Error( 'missing_params', 'to_email and body are required', [ 'status' => 400 ] );
				}

				$email_class = class_exists( 'Exacoat_Email_Engine' ) ? 'Exacoat_Email_Engine' : ( class_exists( 'Artmatter_Email_Engine' ) ? 'Artmatter_Email_Engine' : false );
				if ( $email_class && method_exists( $email_class, 'send_acumbamail_single' ) ) {
					$res = $email_class::send_acumbamail_single( $to_email, $subject, $html, $from_email, $from_name );
					return rest_ensure_response( $res );
				}
				return rest_ensure_response( [ 'success' => false, 'error' => 'Email engine not available' ] );
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/acumbamail/campaigns', [
			'methods'             => 'GET',
			'callback'            => function( WP_REST_Request $request ) {
				$email_class = class_exists( 'Exacoat_Email_Engine' ) ? 'Exacoat_Email_Engine' : ( class_exists( 'Artmatter_Email_Engine' ) ? 'Artmatter_Email_Engine' : false );
				if ( $email_class && method_exists( $email_class, 'get_acumbamail_campaigns' ) ) {
					$res = $email_class::get_acumbamail_campaigns();
					return rest_ensure_response( $res );
				}
				return rest_ensure_response( [ 'success' => false, 'error' => 'Email engine not available' ] );
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/acumbamail/campaign-detail', [
			'methods'             => 'GET',
			'callback'            => function( WP_REST_Request $request ) {
				$campaign_id = sanitize_text_field( $request->get_param( 'campaign_id' ) ?? '' );
				if ( empty( $campaign_id ) ) {
					return new WP_Error( 'missing_id', 'campaign_id is required', [ 'status' => 400 ] );
				}
				$email_class = class_exists( 'Exacoat_Email_Engine' ) ? 'Exacoat_Email_Engine' : ( class_exists( 'Artmatter_Email_Engine' ) ? 'Artmatter_Email_Engine' : false );
				if ( $email_class && method_exists( $email_class, 'get_acumbamail_campaign_detail' ) ) {
					$res = $email_class::get_acumbamail_campaign_detail( $campaign_id );
					return rest_ensure_response( $res );
				}
				return rest_ensure_response( [ 'success' => false, 'error' => 'Email engine not available' ] );
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/email/upload-image', [
			'methods'             => 'POST',
			'callback'            => function( WP_REST_Request $request ) {
				if ( empty( $_FILES['file'] ) && empty( $_FILES['image'] ) ) {
					$json = $request->get_json_params();
					if ( ! empty( $json['image_base64'] ) ) {
						$base64_data = $json['image_base64'];
						$filename    = sanitize_file_name( $json['filename'] ?? ( 'marketing-' . time() . '.jpg' ) );
						if ( preg_match( '/^data:image\/(\w+);base64,/', $base64_data, $type ) ) {
							$base64_data = substr( $base64_data, strpos( $base64_data, ',' ) + 1 );
							$base64_data = base64_decode( $base64_data );
							if ( false === $base64_data ) {
								return new WP_Error( 'invalid_image', 'Base64 decoding failed', [ 'status' => 400 ] );
							}
							$upload = wp_upload_bits( $filename, null, $base64_data );
							if ( ! empty( $upload['error'] ) ) {
								return new WP_Error( 'upload_failed', $upload['error'], [ 'status' => 500 ] );
							}
							return rest_ensure_response( [
								'success' => true,
								'url'     => $upload['url'],
								'file'    => $upload['file'],
							] );
						}
					}
					return new WP_Error( 'no_file', 'No image file uploaded', [ 'status' => 400 ] );
				}

				require_once ABSPATH . 'wp-admin/includes/image.php';
				require_once ABSPATH . 'wp-admin/includes/file.php';
				require_once ABSPATH . 'wp-admin/includes/media.php';

				$file_key = ! empty( $_FILES['image'] ) ? 'image' : 'file';
				$attachment_id = media_handle_upload( $file_key, 0 );
				if ( is_wp_error( $attachment_id ) ) {
					return new WP_Error( 'upload_error', $attachment_id->get_error_message(), [ 'status' => 500 ] );
				}

				$url = wp_get_attachment_url( $attachment_id );
				return rest_ensure_response( [
					'success'       => true,
					'url'           => $url,
					'attachment_id' => $attachment_id,
				] );
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		// System Maintenance Endpoints
		$register( '/system/flush-permalinks', [
			'methods'             => 'POST',
			'callback'            => function() {
				flush_rewrite_rules();
				return rest_ensure_response( [ 'success' => true, 'message' => 'Permalinks and rewrite rules flushed successfully.' ] );
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/system/revert-media', [
			'methods'             => 'POST',
			'callback'            => function() {
				if ( class_exists( 'Exacoat_Store_Enhancements' ) ) {
					$res = Exacoat_Store_Enhancements::revert_assets_to_flat_uploads();
					return rest_ensure_response( $res );
				}
				return rest_ensure_response( [ 'success' => false, 'message' => 'Store enhancements module not available.' ] );
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/system/logs', [
			'methods'             => 'GET',
			'callback'            => function( WP_REST_Request $request ) {
				$params       = $request->get_params();
				$logger_class = class_exists( 'Exacoat_Logger' ) ? 'Exacoat_Logger' : ( class_exists( 'Artmatter_Logger' ) ? 'Artmatter_Logger' : false );
				return rest_ensure_response( $logger_class ? $logger_class::get_logs( $params ) : [] );
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/system/clear-logs', [
			'methods'             => 'POST',
			'callback'            => function() {
				$logger_class = class_exists( 'Exacoat_Logger' ) ? 'Exacoat_Logger' : ( class_exists( 'Artmatter_Logger' ) ? 'Artmatter_Logger' : false );
				if ( $logger_class ) {
					$logger_class::clear_logs();
				}
				return rest_ensure_response( [ 'success' => true, 'message' => 'All system event logs cleared.' ] );
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/system/purge-logs', [
			'methods'             => 'POST',
			'callback'            => function( WP_REST_Request $request ) {
				$params       = $request->get_json_params() ?: $request->get_params();
				$days         = intval( $params['days'] ?? 7 );
				$logger_class = class_exists( 'Exacoat_Logger' ) ? 'Exacoat_Logger' : ( class_exists( 'Artmatter_Logger' ) ? 'Artmatter_Logger' : false );
				$purged       = $logger_class ? $logger_class::purge_old_logs( $days ) : 0;
				return rest_ensure_response( [ 'success' => true, 'message' => "Purged {$purged} old event logs." ] );
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		// Order Management & Fulfillment Routes
		$register( '/orders', [
			'methods'             => [ 'GET', 'POST' ],
			'callback'            => [ 'Exacoat_Order_Manager', 'get_orders' ],
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/orders/analytics', [
			'methods'             => 'GET',
			'callback'            => [ 'Exacoat_Order_Manager', 'get_sales_analytics' ],
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/orders/(?P<id>\d+)', [
			'methods'             => [ 'GET', 'POST', 'PUT' ],
			'callback'            => function( $request ) {
				if ( in_array( $request->get_method(), [ 'POST', 'PUT' ], true ) ) {
					return Exacoat_Order_Manager::update_order( $request );
				}
				return Exacoat_Order_Manager::get_single_order( $request );
			},
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/orders/(?P<id>\d+)/update', [
			'methods'             => [ 'POST', 'PUT' ],
			'callback'            => [ 'Exacoat_Order_Manager', 'update_order' ],
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/orders/(?P<id>\d+)/status', [
			'methods'             => [ 'POST' ],
			'callback'            => [ 'Exacoat_Order_Manager', 'update_order_status' ],
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/orders/(?P<id>\d+)/trash', [
			'methods'             => [ 'POST', 'DELETE' ],
			'callback'            => [ 'Exacoat_Order_Manager', 'trash_order' ],
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/orders/(?P<id>\d+)/fulfill', [
			'methods'             => [ 'POST' ],
			'callback'            => [ 'Exacoat_Order_Manager', 'fulfill_order' ],
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/orders/(?P<id>\d+)/notes', [
			'methods'             => [ 'GET', 'POST' ],
			'callback'            => [ 'Exacoat_Order_Manager', 'handle_order_notes' ],
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/orders/(?P<id>\d+)/refund', [
			'methods'             => [ 'POST' ],
			'callback'            => [ 'Exacoat_Order_Manager', 'process_refund' ],
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/orders/(?P<id>\d+)/resend-email', [
			'methods'             => [ 'POST' ],
			'callback'            => [ 'Exacoat_Order_Manager', 'resend_order_email' ],
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		// Staff and Team Role Management Routes
		$register( '/team', [
			'methods'             => 'GET',
			'callback'            => [ $this, 'rest_get_team_members' ],
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/team', [
			'methods'             => 'POST',
			'callback'            => [ $this, 'rest_create_team_member' ],
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/team/(?P<id>\d+)/role', [
			'methods'             => 'POST',
			'callback'            => [ $this, 'rest_update_team_user_role' ],
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );

		$register( '/team/(?P<id>\d+)', [
			'methods'             => 'DELETE',
			'callback'            => [ $this, 'rest_delete_team_member' ],
			'permission_callback' => [ __CLASS__, 'verify_bridge_permission' ],
		] );
	}

	public function rest_get_health_status( WP_REST_Request $request ) {
		global $wp_version;

		$response = [
			'status'           => 'online',
			'plugin_version'   => defined( 'EXACOAT_CORE_VERSION' ) ? EXACOAT_CORE_VERSION : '0.0.8',
			'site_name'        => get_bloginfo( 'name' ),
			'site_url'         => home_url(),
			'wp_version'       => $wp_version,
			'wc_version'       => class_exists( 'WooCommerce' ) ? WC()->version : 'Not Installed',
			'php_version'      => PHP_VERSION,
			'active_modules'   => [
				'shipping_tracker'  => (bool) self::get_setting( 'enable_shipping_tracker', 1 ),
				'order_manager'     => (bool) self::get_setting( 'enable_order_manager', 1 ),
				'review_manager'    => (bool) self::get_setting( 'enable_review_manager', 1 ),
			],
			'timestamp'        => current_time( 'mysql' ),
		];

		return rest_ensure_response( $response );
	}

	public function rest_handle_ping( WP_REST_Request $request ) {
		$params = $request->get_json_params();
		return rest_ensure_response( [
			'success'   => true,
			'message'   => 'Pong from Exacoat Core WordPress master plugin',
			'received'  => $params,
			'timestamp' => current_time( 'mysql' ),
		] );
	}

	/**
	 * Synchronize authoritative email senders across plugins (TransMail, WooCommerce, WP Mail SMTP)
	 */
	public static function maybe_sync_email_senders(): void {
		// 1. Sync TransMail (ZeptoMail WordPress plugin)
		$raw_transmail = get_option( 'transmail_additional_mail_agents' );
		if ( ! empty( $raw_transmail ) ) {
			$agents = json_decode( base64_decode( $raw_transmail ), true );
			if ( is_array( $agents ) ) {
				$primary_token = '';
				foreach ( $agents as $email_key => $agent_list ) {
					if ( is_array( $agent_list ) && ! empty( $agent_list[0]['Token'] ) ) {
						$primary_token = $agent_list[0]['Token'];
						break;
					}
				}

				$updated = false;
				if ( ! empty( $primary_token ) ) {
					if ( ! isset( $agents['support@exacoat.com'] ) ) {
						$agents['support@exacoat.com'] = [
							[
								'fromName'  => 'Exacoat Support',
								'Token'     => $primary_token,
								'isDefault' => false,
							],
						];
						$updated = true;
					}
					if ( ! isset( $agents['orders@exacoat.com'] ) ) {
						$agents['orders@exacoat.com'] = [
							[
								'fromName'  => 'Exacoat',
								'Token'     => $primary_token,
								'isDefault' => false,
							],
						];
						$updated = true;
					}
				}

				if ( $updated ) {
					update_option( 'transmail_additional_mail_agents', base64_encode( wp_json_encode( $agents ) ), false );
				}
			}
		}

		// 2. Sync WP Mail SMTP settings in case it is ever enabled
		$smtp_opt = get_option( 'wp_mail_smtp' );
		if ( is_array( $smtp_opt ) && isset( $smtp_opt['mail'] ) ) {
			if ( ( $smtp_opt['mail']['from_email'] ?? '' ) === 'noreply@exacoat.com' || ! empty( $smtp_opt['mail']['from_name_force'] ) ) {
				$smtp_opt['mail']['from_email']      = 'support@exacoat.com';
				$smtp_opt['mail']['from_name']       = 'Exacoat Support';
				$smtp_opt['mail']['from_email_force'] = false;
				$smtp_opt['mail']['from_name_force']  = false;
				update_option( 'wp_mail_smtp', $smtp_opt, false );
			}
		}

		// 3. Sync WooCommerce from email options
		if ( get_option( 'woocommerce_email_from_address' ) === 'noreply@exacoat.com' ) {
			update_option( 'woocommerce_email_from_address', 'support@exacoat.com' );
		}
	}

	public function rest_debug_coupon_post_type( WP_REST_Request $request ) {
		$pto = get_post_type_object( 'shop_coupon' );
		$show_ui_types = get_post_types( [ 'show_ui' => true ] );
		$is_in_show_ui = in_array( 'shop_coupon', $show_ui_types, true );

		$roles = function_exists( 'wp_roles' ) ? wp_roles()->roles : [];
		$admin_caps = $roles['administrator']['capabilities'] ?? [];

		$admins = get_users( [ 'role' => 'administrator', 'number' => 10 ] );
		$user_checks = [];
		foreach ( $admins as $user ) {
			$user_checks[ $user->user_login ] = [
				'id' => $user->ID,
				'can_manage_woocommerce' => user_can( $user, 'manage_woocommerce' ),
				'can_edit_shop_coupons' => user_can( $user, 'edit_shop_coupons' ),
				'can_publish_shop_coupons' => user_can( $user, 'publish_shop_coupons' ),
				'can_pto_edit_posts' => $pto ? user_can( $user, $pto->cap->edit_posts ) : false,
				'can_pto_create_posts' => $pto ? user_can( $user, $pto->cap->create_posts ) : false,
			];
		}

		$htaccess_file = ABSPATH . '.htaccess';
		$htaccess_snippet = file_exists( $htaccess_file ) ? substr( file_get_contents( $htaccess_file ), 0, 1500 ) : 'not_found';

		global $wp_filter;
		$filter_checks = [];
		$hooks_to_check = [
			'woocommerce_register_post_type_shop_coupon',
			'register_post_type_args',
			'map_meta_cap',
			'user_has_cap',
			'load-post-new.php',
			'phpmailer_init',
			'wp_mail_from',
			'wp_mail_from_name',
		];
		foreach ( $hooks_to_check as $hook ) {
			if ( isset( $wp_filter[ $hook ] ) ) {
				$callbacks = [];
				foreach ( $wp_filter[ $hook ]->callbacks as $priority => $arr ) {
					foreach ( $arr as $cb_name => $cb_data ) {
						$location = 'unknown';
						$func = $cb_data['function'] ?? null;
						if ( is_array( $func ) && isset( $func[0], $func[1] ) ) {
							try {
								$ref = new ReflectionMethod( $func[0], $func[1] );
								$location = $ref->getFileName() . ':' . $ref->getStartLine();
							} catch ( \Throwable $e ) {
								$location = is_string( $func[0] ) ? $func[0] . '::' . $func[1] : get_class( $func[0] ) . '::' . $func[1];
							}
						} elseif ( $func instanceof Closure || is_string( $func ) ) {
							try {
								$ref = new ReflectionFunction( $func );
								$location = $ref->getFileName() . ':' . $ref->getStartLine();
							} catch ( \Throwable $e ) {
								$location = (string) $cb_name;
							}
						}
						$callbacks[] = "p{$priority}: {$cb_name} [{$location}]";
					}
				}
				$filter_checks[ $hook ] = $callbacks;
			}
		}

		global $wpdb;
		self::maybe_sync_email_senders();

		$email_options = [
			'admin_email'                    => get_option( 'admin_email' ),
			'woocommerce_email_from_address' => get_option( 'woocommerce_email_from_address' ),
			'woocommerce_email_from_name'    => get_option( 'woocommerce_email_from_name' ),
		];
		$noreply_options = $wpdb->get_results(
			"SELECT option_name, option_value FROM {$wpdb->options} WHERE option_value LIKE '%noreply@exacoat.com%' LIMIT 20",
			ARRAY_A
		);

		$raw_transmail = get_option( 'transmail_additional_mail_agents' );
		$decoded_transmail = ! empty( $raw_transmail ) ? json_decode( base64_decode( $raw_transmail ), true ) : null;
		$masked_agents = [];
		if ( is_array( $decoded_transmail ) ) {
			foreach ( $decoded_transmail as $k => $v ) {
				$masked_agents[ $k ] = array_map( function( $ag ) {
					$tok = (string) ( $ag['Token'] ?? '' );
					$masked_tok = strlen( $tok ) > 10 ? substr( $tok, 0, 8 ) . '...' . substr( $tok, -6 ) : '***';
					return [
						'fromName'  => $ag['fromName'] ?? '',
						'Token'     => $masked_tok,
						'isDefault' => $ag['isDefault'] ?? false,
					];
				}, (array) $v );
			}
		}

		$transmail_debug = [
			'domain_name'       => get_option( 'transmail_domain_name' ),
			'content_type'      => get_option( 'transmail_content_type' ),
			'agents'            => $masked_agents,
			'connection_status' => json_decode( get_option( 'transmail_connection_status' ), true ),
			'test_mail_case'    => get_option( 'transmail_test_mail_case' ),
		];

		$mock_mailer = (object) [
			'Host' => '',
			'Port' => '',
			'Username' => '',
			'From' => '',
			'FromName' => '',
			'Mailer' => '',
		];
		do_action_ref_array( 'phpmailer_init', [ &$mock_mailer ] );

		// Check what happens during a real wp_mail filter pass
		$test_from_in  = apply_filters( 'wp_mail_from', 'support@exacoat.com' );
		$test_from_out = apply_filters( 'wp_mail_from_name', 'Exacoat Support' );

		return rest_ensure_response( [
			'post_type_exists' => post_type_exists( 'shop_coupon' ),
			'is_in_show_ui' => $is_in_show_ui,
			'show_ui_types' => array_values( $show_ui_types ),
			'pto' => $pto ? [
				'name' => $pto->name,
				'show_ui' => $pto->show_ui,
				'show_in_menu' => $pto->show_in_menu,
				'cap' => (array) $pto->cap,
				'capabilities' => (array) $pto->capabilities,
				'map_meta_cap' => $pto->map_meta_cap,
			] : null,
			'woocommerce_enable_coupons' => get_option( 'woocommerce_enable_coupons' ),
			'wc_coupons_enabled' => function_exists( 'wc_coupons_enabled' ) ? wc_coupons_enabled() : 'function_missing',
			'user_checks' => $user_checks,
			'filter_checks' => $filter_checks,
			'mock_mailer' => $mock_mailer,
			'noreply_options' => $noreply_options,
			'email_options' => $email_options,
			'transmail_debug' => $transmail_debug,
			'test_filter' => [
				'from' => $test_from_in,
				'name' => $test_from_out,
			],
			'htaccess_snippet' => $htaccess_snippet,
			'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'unknown',
		] );
	}

	public function rest_submit_contact( WP_REST_Request $request ) {
		$params = $request->get_json_params() ?: $request->get_params();

		// Silently accept bot submissions so the endpoint does not teach bots how to bypass the trap.
		if ( ! empty( $params['website'] ) ) {
			return rest_ensure_response( [ 'success' => true ] );
		}

		$name       = sanitize_text_field( $params['name'] ?? '' );
		$email      = sanitize_email( $params['email'] ?? '' );
		$topic      = sanitize_key( $params['topic'] ?? 'general' );
		$subject    = sanitize_text_field( $params['subject'] ?? '' );
		$order      = sanitize_text_field( $params['order_number'] ?? '' );
		$message    = sanitize_textarea_field( $params['message'] ?? '' );
		$started_at = absint( $params['started_at'] ?? 0 );
		$topics     = [ 'order', 'warranty', 'fit', 'business', 'general', 'product', 'press' ];

		if ( ! in_array( $topic, $topics, true ) ) {
			$topic = 'general';
		}

		if ( mb_strlen( $name ) < 2 || mb_strlen( $name ) > 120 || ! is_email( $email ) ) {
			return new WP_Error( 'invalid_contact', 'Enter a valid name and email address.', [ 'status' => 400 ] );
		}

		if ( mb_strlen( $subject ) < 3 || mb_strlen( $subject ) > 160 || mb_strlen( $message ) < 10 || mb_strlen( $message ) > 5000 ) {
			return new WP_Error( 'invalid_message', 'Enter a subject and a message between 10 and 5,000 characters.', [ 'status' => 400 ] );
		}

		$now_ms = time() * 1000;
		// 60-second grace window for client/server clock variance
		if ( ! $started_at || $started_at > ( $now_ms + 60000 ) || ( $now_ms - $started_at ) < 1500 || ( $now_ms - $started_at ) > 2 * HOUR_IN_SECONDS * 1000 ) {
			return new WP_Error( 'invalid_submission', 'Please refresh the page and try again.', [ 'status' => 400 ] );
		}

		$forwarded_ip = $request->get_header( 'X-Exacoat-Client-IP' ) ?: $request->get_header( 'X-Artmatter-Client-IP' );
		$remote_ip    = sanitize_text_field( $forwarded_ip ?: ( $_SERVER['REMOTE_ADDR'] ?? 'unknown' ) );
		$rate_key     = 'exacoat_contact_rate_' . md5( $remote_ip );
		$rate_count   = (int) get_transient( $rate_key );
		if ( $rate_count >= 10 ) {
			return new WP_Error( 'contact_rate_limited', 'Too many messages. Please try again later.', [ 'status' => 429 ] );
		}

		set_transient( $rate_key, $rate_count + 1, HOUR_IN_SECONDS );

		$topic_labels = [
			'order'    => 'Order support & tracking',
			'warranty' => 'Installation Warranty claim',
			'fit'      => 'Device model & custom fit inquiry',
			'business' => 'Business & bulk orders',
			'general'  => 'General inquiry',
			'product'  => 'Product question',
			'press'    => 'Press and partnership',
		];
		$topic_label = $topic_labels[ $topic ] ?? 'General inquiry';
		$email_title = sprintf( '[Contact] %s: %s', $topic_label, $subject );
		$rows        = [
			'Name'         => $name,
			'Email'        => $email,
			'Topic'        => $topic_label,
			'Order number' => $order ?: 'Not provided',
		];
		$details_html = '';
		foreach ( $rows as $label => $value ) {
			$details_html .= '<tr><td style="padding:7px 16px 7px 0;color:#71717a;font-size:13px;vertical-align:top;white-space:nowrap;font-family:\'Plus Jakarta Sans\',-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,sans-serif;">' . esc_html( $label ) . '</td><td style="padding:7px 0;color:#111111;font-size:13.5px;font-weight:600;font-family:\'Plus Jakarta Sans\',-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,sans-serif;">' . esc_html( $value ) . '</td></tr>';
		}

		$brand_logo = class_exists( 'Exacoat_Email_Engine' ) ? Exacoat_Email_Engine::get_brand_logo_html() : '<a href="https://exacoat.com" target="_blank" rel="noopener noreferrer" style="display:inline-block;text-decoration:none;"><img src="https://exacoat.com/assets/brand/exacoat-logo.png" alt="Exacoat" width="136" height="24" border="0" style="display:block;border:0;width:136px;height:24px;" /></a>';

		$staff_html = '<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>' . esc_html( $email_title ) . '</title>
  <style>
    @import url(\'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap\');
    body { margin:0; padding:0; background-color:#f7f7f7; font-family:\'Plus Jakarta Sans\',-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,Helvetica,Arial,sans-serif; -webkit-text-size-adjust:100%; }
    table { border-collapse:collapse; }
    @media only screen and (max-width:620px) {
      .container-table { width:100% !important; border-radius:0 !important; }
      .mobile-padding { padding-left:24px !important; padding-right:24px !important; }
    }
  </style>
</head>
<body bgcolor="#f7f7f7" style="margin:0;padding:0;background-color:#f7f7f7;font-family:\'Plus Jakarta Sans\',-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,Helvetica,Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#f7f7f7" style="border-collapse:collapse;background-color:#f7f7f7;">
    <tr><td height="48" style="height:48px;line-height:48px;font-size:0;">&nbsp;</td></tr>
    <tr>
      <td align="center" style="padding:0 16px;">
        <table class="container-table" width="600" cellpadding="0" cellspacing="0" border="0" style="max-width:600px;background:#ffffff;border:1px solid #e5e5e5;border-radius:20px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,0.04);">
          <tr>
            <td style="padding:28px 40px 22px;border-bottom:1px solid #f0f0f0;" class="mobile-padding">
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td valign="middle">' . $brand_logo . '</td>
                  <td align="right" valign="middle">
                    <span style="display:inline-block;padding:5px 13px;background:#f4f4f5;color:#3f3f46;font-size:11px;font-weight:600;border-radius:999px;border:1px solid #e4e4e7;letter-spacing:0.3px;font-family:\'Plus Jakarta Sans\',sans-serif;">Customer Inquiry</span>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <tr>
            <td style="padding:36px 40px 32px;" class="mobile-padding">
              <h1 style="margin:0 0 20px;font-size:24px;font-weight:800;color:#111111;letter-spacing:-0.5px;line-height:1.3;font-family:\'Plus Jakarta Sans\',sans-serif;">' . esc_html( $subject ) . '</h1>
              <table width="100%" cellpadding="0" cellspacing="0" style="background:#fafafa;border:1px solid #eaeaea;border-radius:16px;margin:20px 0;">
                <tr>
                  <td style="padding:20px 24px;">
                    <p style="margin:0 0 12px;font-size:11px;font-weight:700;letter-spacing:0.8px;text-transform:uppercase;color:#71717a;font-family:\'Plus Jakarta Sans\',sans-serif;">Inquiry Details</p>
                    <table width="100%" cellpadding="0" cellspacing="0">' . $details_html . '</table>
                  </td>
                </tr>
              </table>
              <div style="background:#fafafa;border:1px solid #eaeaea;border-radius:16px;padding:20px 24px;margin-top:20px;">
                <p style="margin:0 0 8px;font-size:11px;font-weight:700;letter-spacing:0.8px;text-transform:uppercase;color:#71717a;font-family:\'Plus Jakarta Sans\',sans-serif;">Customer Message</p>
                <div style="font-size:14px;color:#18181b;line-height:1.6;white-space:pre-wrap;font-family:\'Plus Jakarta Sans\',sans-serif;">' . nl2br( esc_html( $message ) ) . '</div>
              </div>
              <table width="100%" cellpadding="0" cellspacing="0" style="border-top:1px solid #f0f0f0;margin-top:32px;text-align:center;">
                <tr>
                  <td align="center" style="padding-top:24px;">
                    <p style="margin:0;font-size:11px;color:#a1a1aa;letter-spacing:0.2px;font-family:\'Plus Jakarta Sans\',sans-serif;">&copy; Exacoat Staff Desk</p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
        </table>
      </td>
    </tr>
    <tr><td height="48" style="height:48px;line-height:48px;font-size:0;">&nbsp;</td></tr>
  </table>
</body>
</html>';

		$email_class = class_exists( 'Exacoat_Email_Engine' ) ? 'Exacoat_Email_Engine' : ( class_exists( 'Artmatter_Email_Engine' ) ? 'Artmatter_Email_Engine' : false );
		$support_result = $email_class ? $email_class::send_email( 'website_contact', 'support@exacoat.com', 'Exacoat Support', [
			'subject'    => $email_title,
			'htmlbody'   => $staff_html,
			'from_email' => 'support@exacoat.com',
			'from_name'  => 'Exacoat Website',
			'reply_to'   => $email,
			'reply_name' => $name,
		] ) : [ 'success' => true ];

		if ( empty( $support_result['success'] ) ) {
			return new WP_Error( 'contact_delivery_failed', 'Your message could not be sent. Please contact support@exacoat.com directly.', [ 'status' => 502 ] );
		}

		// Send customer confirmation receipt email
		if ( $email_class && is_email( $email ) ) {
			$customer_subject = sprintf( "We've received your inquiry: %s | Exacoat®", $subject );
			$customer_html    = self::render_contact_confirmation_html( [
				'name'         => $name,
				'email'        => $email,
				'topic_label'  => $topic_label,
				'subject'      => $subject,
				'order_number' => $order,
				'message'      => $message,
			] );

			$email_class::send_email( 'website_contact_confirmation', $email, $name, [
				'subject'    => $customer_subject,
				'htmlbody'   => $customer_html,
				'from_email' => 'support@exacoat.com',
				'from_name'  => 'Exacoat Support',
				'reply_to'   => 'support@exacoat.com',
				'reply_name' => 'Exacoat Support',
			] );
		}

		return rest_ensure_response( [
			'success' => true,
			'message' => 'Your message has been received by the Exacoat team and a confirmation email has been sent to your inbox.',
		] );
	}

	public static function render_contact_confirmation_html( array $data ): string {
		$name         = esc_html( $data['name'] ?? 'Customer' );
		$topic_label  = esc_html( $data['topic_label'] ?? 'General inquiry' );
		$subject      = esc_html( $data['subject'] ?? 'Contact inquiry' );
		$order_number = esc_html( $data['order_number'] ?? '' );
		$message      = nl2br( esc_html( $data['message'] ?? '' ) );

		$logo_html = class_exists( 'Exacoat_Email_Engine' )
			? Exacoat_Email_Engine::get_brand_logo_html()
			: '<a href="https://exacoat.com" target="_blank" rel="noopener noreferrer" style="display:inline-block;text-decoration:none;"><img src="https://exacoat.com/assets/brand/exacoat-logo.png" alt="Exacoat" width="136" height="24" border="0" style="display:block;border:0;width:136px;height:24px;" /></a>';

		$order_row = '';
		if ( ! empty( $order_number ) && 'Not provided' !== $order_number ) {
			$order_clean = ltrim( $order_number, '#' );
			$order_row = '<tr><td style="padding:7px 16px 7px 0;color:#71717a;font-size:13px;vertical-align:top;white-space:nowrap;font-family:\'Plus Jakarta Sans\',-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,sans-serif;">Order Number</td><td style="padding:7px 0;color:#111111;font-size:13.5px;font-weight:600;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;">#' . $order_clean . '</td></tr>';
		}

		return '<!doctype html>
<html lang="en" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>' . esc_html( $subject ) . '</title>
  <style>
    @import url(\'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap\');
    body {
      margin: 0;
      padding: 0;
      width: 100% !important;
      -webkit-text-size-adjust: 100%;
      -ms-text-size-adjust: 100%;
      background-color: #f7f7f7;
      font-family: \'Plus Jakarta Sans\', -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif;
      -webkit-font-smoothing: antialiased;
    }
    table {
      border-collapse: collapse;
      mso-table-lspace: 0pt;
      mso-table-rspace: 0pt;
    }
    img {
      border: 0;
      outline: none;
      text-decoration: none;
      display: block;
    }
    @media only screen and (max-width: 620px) {
      .container-table { width: 100% !important; border-radius: 0 !important; }
      .mobile-padding { padding-left: 24px !important; padding-right: 24px !important; }
    }
  </style>
</head>
<body bgcolor="#f7f7f7" style="margin:0;padding:0;background-color:#f7f7f7;font-family:\'Plus Jakarta Sans\',-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,Helvetica,Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#f7f7f7" style="border-collapse:collapse;background-color:#f7f7f7;">
    <tbody>
      <tr>
        <td height="48" style="height:48px;line-height:48px;font-size:0;mso-line-height-rule:exactly;">&nbsp;</td>
      </tr>
      <tr>
        <td align="center" style="padding:0 16px;">
          <!-- Main Card -->
          <table class="container-table" width="600" cellpadding="0" cellspacing="0" border="0" style="max-width:600px;background:#ffffff;border:1px solid #e5e5e5;border-radius:20px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,0.04);">
            <tbody>
              <!-- Top Header (Logo + Badge) -->
              <tr>
                <td style="padding:28px 40px 22px;border-bottom:1px solid #f0f0f0;" class="mobile-padding">
                  <table width="100%" cellpadding="0" cellspacing="0">
                    <tr>
                      <td valign="middle">
                        ' . $logo_html . '
                      </td>
                      <td align="right" valign="middle">
                        <span style="display:inline-block;padding:5px 13px;background:#f4f4f5;color:#3f3f46;font-size:11px;font-weight:600;border-radius:999px;border:1px solid #e4e4e7;letter-spacing:0.3px;font-family:\'Plus Jakarta Sans\',-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,sans-serif;">Inquiry received</span>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>

              <!-- Message Headline & Body -->
              <tr>
                <td style="padding:36px 40px 32px;" class="mobile-padding">
                  <h1 style="margin:0 0 20px;font-size:26px;font-weight:800;color:#111111;letter-spacing:-0.6px;line-height:1.25;font-family:\'Plus Jakarta Sans\',-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,sans-serif;">We\'ve received your message</h1>
                  <p style="margin:0 0 14px;font-size:15px;font-weight:600;color:#18181b;font-family:\'Plus Jakarta Sans\',-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,sans-serif;">Hi ' . $name . ',</p>
                  <p style="margin:0 0 20px;font-size:14.5px;line-height:1.7;color:#3f3f46;font-family:\'Plus Jakarta Sans\',-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,sans-serif;">Thank you for reaching out to Exacoat. We’ve received your inquiry and our support team is reviewing the details.</p>

                  <!-- Inquiry Recap Card -->
                  <table width="100%" cellpadding="0" cellspacing="0" style="background:#fafafa;border:1px solid #eaeaea;border-radius:16px;margin:24px 0;">
                    <tr>
                      <td style="padding:20px 24px;">
                        <p style="margin:0 0 12px;font-size:11px;font-weight:700;letter-spacing:0.8px;text-transform:uppercase;color:#71717a;font-family:\'Plus Jakarta Sans\',-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,sans-serif;">Inquiry Details</p>
                        <table width="100%" cellpadding="0" cellspacing="0" border="0">
                          <tr>
                            <td style="padding:7px 16px 7px 0;color:#71717a;font-size:13px;vertical-align:top;white-space:nowrap;font-family:\'Plus Jakarta Sans\',-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,sans-serif;">Topic</td>
                            <td style="padding:7px 0;color:#111111;font-size:13.5px;font-weight:600;font-family:\'Plus Jakarta Sans\',-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,sans-serif;">' . $topic_label . '</td>
                          </tr>
                          <tr>
                            <td style="padding:7px 16px 7px 0;color:#71717a;font-size:13px;vertical-align:top;white-space:nowrap;font-family:\'Plus Jakarta Sans\',-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,sans-serif;">Subject</td>
                            <td style="padding:7px 0;color:#111111;font-size:13.5px;font-weight:600;font-family:\'Plus Jakarta Sans\',-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,sans-serif;">' . $subject . '</td>
                          </tr>
                          ' . $order_row . '
                        </table>
                        <div style="margin-top:16px;padding-top:16px;border-top:1px solid #e5e5e5;">
                          <p style="margin:0 0 6px;font-size:11px;font-weight:700;letter-spacing:0.8px;text-transform:uppercase;color:#71717a;font-family:\'Plus Jakarta Sans\',-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,sans-serif;">Your Message</p>
                          <div style="font-size:13.5px;color:#3f3f46;line-height:1.6;white-space:pre-wrap;font-family:\'Plus Jakarta Sans\',-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,sans-serif;">' . $message . '</div>
                        </div>
                      </td>
                    </tr>
                  </table>

                  <!-- Response Time & WhatsApp Assistance -->
                  <p style="margin:0 0 8px;font-size:13.5px;color:#52525b;line-height:1.6;font-family:\'Plus Jakarta Sans\',-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,sans-serif;">
                    Our customer care team typically responds within <strong style="color:#111111;">24 business hours</strong> (Monday to Saturday, 09:00 – 18:00 UTC+7).
                  </p>
                  <p style="margin:0 0 18px;font-size:13.5px;color:#52525b;line-height:1.6;font-family:\'Plus Jakarta Sans\',-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,sans-serif;">
                    For urgent inquiries or in-transit delivery support, reach our team directly via WhatsApp:
                  </p>
                  <table cellpadding="0" cellspacing="0" border="0" style="margin-bottom:8px;">
                    <tr>
                      <td align="center" style="background-color:#f3aa18;border-radius:100px;">
                        <a href="https://api.whatsapp.com/send?phone=628975556000" target="_blank" rel="noopener noreferrer" style="display:inline-block;padding:12px 28px;font-size:13.5px;font-weight:700;color:#111111;text-decoration:none;border-radius:100px;letter-spacing:0.2px;font-family:\'Plus Jakarta Sans\',-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,sans-serif;">
                          Chat on WhatsApp (+62 897-555-6000) &rarr;
                        </a>
                      </td>
                    </tr>
                  </table>

                  <!-- Dedicated Spacer -->
                  <table width="100%" cellpadding="0" cellspacing="0">
                    <tr>
                      <td height="36" style="height:36px;font-size:0;line-height:0;">&nbsp;</td>
                    </tr>
                  </table>

                  <!-- Help & Assistance Section -->
                  <table width="100%" cellpadding="0" cellspacing="0" style="border-top:1px solid #f0f0f0;text-align:center;">
                    <tr>
                      <td align="center" style="padding-top:28px;">
                        <p style="margin:0 0 10px;font-size:12px;line-height:1.65;color:#71717a;font-family:\'Plus Jakarta Sans\',-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,sans-serif;">
                          Have questions about your inquiry? Reach our team at <a href="mailto:support@exacoat.com" style="color:#111111;text-decoration:underline;font-weight:500;">support@exacoat.com</a>
                        </p>
                        <p style="margin:0;font-size:11px;color:#a1a1aa;letter-spacing:0.2px;font-family:\'Plus Jakarta Sans\',-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,sans-serif;">
                          &copy; Exacoat
                        </p>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
            </tbody>
          </table>
        </td>
      </tr>
      <tr>
        <td height="48" style="height:48px;line-height:48px;font-size:0;mso-line-height-rule:exactly;">&nbsp;</td>
      </tr>
    </tbody>
  </table>
</body>
</html>';
	}

	public function rest_get_settings( WP_REST_Request $request ) {
		$settings = self::get_settings();
		$environment_values = [
			'gemini_api_key'        => defined( 'EXA_GEMINI_API_KEY' ) ? EXA_GEMINI_API_KEY : ( defined( 'AM_GEMINI_API_KEY' ) ? AM_GEMINI_API_KEY : ( defined( 'GEMINI_API_KEY' ) ? GEMINI_API_KEY : getenv( 'EXA_GEMINI_API_KEY' ) ) ),
			'openai_api_key'        => defined( 'EXA_OPENAI_API_KEY' ) ? EXA_OPENAI_API_KEY : ( defined( 'AM_OPENAI_API_KEY' ) ? AM_OPENAI_API_KEY : ( defined( 'OPENAI_API_KEY' ) ? OPENAI_API_KEY : getenv( 'EXA_OPENAI_API_KEY' ) ) ),
			'pushover_app_token'    => defined( 'EXA_PUSHOVER_APP_TOKEN' ) ? EXA_PUSHOVER_APP_TOKEN : ( defined( 'AM_PUSHOVER_APP_TOKEN' ) ? AM_PUSHOVER_APP_TOKEN : ( getenv( 'EXA_PUSHOVER_APP_TOKEN' ) ?: getenv( 'AM_PUSHOVER_APP_TOKEN' ) ) ),
			'pushover_user_key'     => defined( 'EXA_PUSHOVER_USER_KEY' ) ? EXA_PUSHOVER_USER_KEY : ( defined( 'AM_PUSHOVER_USER_KEY' ) ? AM_PUSHOVER_USER_KEY : ( getenv( 'EXA_PUSHOVER_USER_KEY' ) ?: getenv( 'AM_PUSHOVER_USER_KEY' ) ) ),
			'telegram_bot_token'    => defined( 'EXA_TELEGRAM_BOT_TOKEN' ) ? EXA_TELEGRAM_BOT_TOKEN : ( defined( 'AM_TELEGRAM_BOT_TOKEN' ) ? AM_TELEGRAM_BOT_TOKEN : ( getenv( 'EXA_TELEGRAM_BOT_TOKEN' ) ?: getenv( 'AM_TELEGRAM_BOT_TOKEN' ) ) ),
			'telegram_chat_id'      => defined( 'EXA_TELEGRAM_CHAT_ID' ) ? EXA_TELEGRAM_CHAT_ID : ( defined( 'AM_TELEGRAM_CHAT_ID' ) ? AM_TELEGRAM_CHAT_ID : ( getenv( 'EXA_TELEGRAM_CHAT_ID' ) ?: getenv( 'AM_TELEGRAM_CHAT_ID' ) ) ),
			'telegram_thread_id'    => defined( 'EXA_TELEGRAM_THREAD_ID' ) ? EXA_TELEGRAM_THREAD_ID : ( defined( 'AM_TELEGRAM_THREAD_ID' ) ? AM_TELEGRAM_THREAD_ID : ( getenv( 'EXA_TELEGRAM_THREAD_ID' ) ?: getenv( 'AM_TELEGRAM_THREAD_ID' ) ) ),
			'r2_account_id'         => defined( 'AM_R2_ACCOUNT_ID' ) ? AM_R2_ACCOUNT_ID : getenv( 'AM_R2_ACCOUNT_ID' ),
			'r2_bucket'             => defined( 'AM_R2_BUCKET' ) ? AM_R2_BUCKET : getenv( 'AM_R2_BUCKET' ),
			'r2_access_key'         => defined( 'AM_R2_ACCESS_KEY' ) ? AM_R2_ACCESS_KEY : getenv( 'AM_R2_ACCESS_KEY' ),
			'r2_secret_key'         => defined( 'AM_R2_SECRET_KEY' ) ? AM_R2_SECRET_KEY : getenv( 'AM_R2_SECRET_KEY' ),
			'cloudflare_zone_id'    => defined( 'EXA_CLOUDFLARE_ZONE_ID' ) ? EXA_CLOUDFLARE_ZONE_ID : ( defined( 'EXACOAT_CLOUDFLARE_ZONE_ID' ) ? EXACOAT_CLOUDFLARE_ZONE_ID : ( defined( 'AM_CLOUDFLARE_ZONE_ID' ) ? AM_CLOUDFLARE_ZONE_ID : ( defined( 'CLOUDFLARE_ZONE_ID' ) ? CLOUDFLARE_ZONE_ID : ( getenv( 'EXA_CLOUDFLARE_ZONE_ID' ) ?: ( getenv( 'EXACOAT_CLOUDFLARE_ZONE_ID' ) ?: getenv( 'AM_CLOUDFLARE_ZONE_ID' ) ) ) ) ) ),
			'cloudflare_api_token'  => defined( 'EXA_CLOUDFLARE_API_TOKEN' ) ? EXA_CLOUDFLARE_API_TOKEN : ( defined( 'EXACOAT_CLOUDFLARE_API_TOKEN' ) ? EXACOAT_CLOUDFLARE_API_TOKEN : ( defined( 'AM_CLOUDFLARE_API_TOKEN' ) ? AM_CLOUDFLARE_API_TOKEN : ( defined( 'CLOUDFLARE_API_TOKEN' ) ? CLOUDFLARE_API_TOKEN : ( getenv( 'EXA_CLOUDFLARE_API_TOKEN' ) ?: ( getenv( 'EXACOAT_CLOUDFLARE_API_TOKEN' ) ?: getenv( 'AM_CLOUDFLARE_API_TOKEN' ) ) ) ) ) ),
			'drime_access_token'     => defined( 'AM_DRIME_ACCESS_TOKEN' ) ? AM_DRIME_ACCESS_TOKEN : getenv( 'AM_DRIME_ACCESS_TOKEN' ),
			'drime_workspace_id'     => defined( 'AM_DRIME_WORKSPACE_ID' ) ? AM_DRIME_WORKSPACE_ID : getenv( 'AM_DRIME_WORKSPACE_ID' ),
			'drime_parent_folder_id' => defined( 'AM_DRIME_PARENT_FOLDER_ID' ) ? AM_DRIME_PARENT_FOLDER_ID : getenv( 'AM_DRIME_PARENT_FOLDER_ID' ),
			'supabase_service_role_key' => defined( 'AM_SUPABASE_SERVICE_ROLE_KEY' ) ? AM_SUPABASE_SERVICE_ROLE_KEY : getenv( 'AM_SUPABASE_SERVICE_ROLE_KEY' ),
		];
		foreach ( [ 'r2_account_id', 'r2_bucket', 'cloudflare_zone_id', 'drime_workspace_id', 'drime_parent_folder_id', 'telegram_chat_id', 'telegram_thread_id' ] as $public_environment_key ) {
			if ( ! empty( $environment_values[ $public_environment_key ] ) ) {
				$settings[ $public_environment_key ] = $environment_values[ $public_environment_key ];
			}
		}

		// Defaults for Telegram Notification Gateway
		if ( empty( $settings['telegram_bot_token'] ) ) {
			$settings['telegram_bot_token'] = ! empty( $environment_values['telegram_bot_token'] ) ? $environment_values['telegram_bot_token'] : '5576968403:AAFxQrqNYAfO9GSi6QElD6fMI0-yPUTtcFA';
		}
		if ( empty( $settings['telegram_chat_id'] ) ) {
			$settings['telegram_chat_id'] = ! empty( $environment_values['telegram_chat_id'] ) ? $environment_values['telegram_chat_id'] : '-1002257662366';
		}
		if ( ! isset( $settings['telegram_thread_id'] ) || $settings['telegram_thread_id'] === '' ) {
			$settings['telegram_thread_id'] = ! empty( $environment_values['telegram_thread_id'] ) ? $environment_values['telegram_thread_id'] : '774';
		}
		if ( ! isset( $settings['telegram_enabled'] ) ) {
			$settings['telegram_enabled'] = 1;
		}
		if ( ! isset( $settings['telegram_notify_new_sale'] ) ) {
			$settings['telegram_notify_new_sale'] = 1;
		}
		if ( ! isset( $settings['telegram_notify_kyc'] ) ) {
			$settings['telegram_notify_kyc'] = 1;
		}
		if ( ! isset( $settings['telegram_notify_affiliate_register'] ) ) {
			$settings['telegram_notify_affiliate_register'] = 1;
		}
		if ( ! isset( $settings['telegram_notify_affiliate_payout'] ) ) {
			$settings['telegram_notify_affiliate_payout'] = 1;
		}
		if ( ! isset( $settings['telegram_notify_inventory'] ) ) {
			$settings['telegram_notify_inventory'] = 1;
		}
		if ( ! isset( $settings['telegram_notify_errors'] ) ) {
			$settings['telegram_notify_errors'] = 1;
		}

		// Ensure Pushover keys and event defaults
		if ( empty( $settings['pushover_app_token'] ) && ! empty( $environment_values['pushover_app_token'] ) ) {
			$settings['pushover_app_token'] = $environment_values['pushover_app_token'];
		}
		if ( empty( $settings['pushover_user_key'] ) && ! empty( $environment_values['pushover_user_key'] ) ) {
			$settings['pushover_user_key'] = $environment_values['pushover_user_key'];
		}
		if ( ! isset( $settings['pushover_notify_affiliate_register'] ) ) {
			$settings['pushover_notify_affiliate_register'] = 1;
		}
		if ( ! isset( $settings['pushover_notify_affiliate_payout'] ) ) {
			$settings['pushover_notify_affiliate_payout'] = 1;
		}

		$secret_status = [];
		foreach ( $environment_values as $key => $environment_value ) {
			$secret_status[ $key ] = [
				'configured' => ! empty( $environment_value ) || ! empty( $settings[ $key ] ),
				'source'     => ! empty( $environment_value ) ? 'environment' : ( ! empty( $settings[ $key ] ) ? 'settings' : 'missing' ),
			];
		}
		foreach ( [ 'gemini_api_key', 'openai_api_key', 'r2_access_key', 'r2_secret_key', 'cloudflare_api_token', 'drime_access_token', 'drime_access_key', 'drime_secret_key', 'zeptomail_token', 'supabase_service_role_key', 'webhook_secret' ] as $secret_key ) {
			unset( $settings[ $secret_key ] );
		}

		if ( empty( $settings['currency_rates'] ) && class_exists( 'Exacoat_Store_Enhancements' ) ) {
			$settings['currency_rates'] = Exacoat_Store_Enhancements::get_currency_rates();
		}
		if ( ! isset( $settings['currency_global_markup'] ) ) {
			$settings['currency_global_markup'] = 1.8;
		}
		if ( ( empty( $settings['shipping_zones'] ) || empty( $settings['shipping_target_method_ids'] ) ) && class_exists( 'Exacoat_Store_Enhancements' ) ) {
			$ship_cfg = Exacoat_Store_Enhancements::get_shipping_config();
			if ( empty( $settings['shipping_zones'] ) ) {
				$settings['shipping_zones'] = $ship_cfg['zones'];
			}
			if ( empty( $settings['shipping_target_method_ids'] ) ) {
				$settings['shipping_target_method_ids'] = implode( ', ', $ship_cfg['target_method_ids'] );
			}
		}
		if ( empty( $settings['logistics_carriers'] ) && class_exists( 'Exacoat_Shipping_Tracker' ) ) {
			$settings['logistics_carriers'] = Exacoat_Shipping_Tracker::get_carrier_registry();
		}

		return rest_ensure_response( [
			'success'  => true,
			'settings' => $settings,
			'secret_status' => $secret_status,
		] );
	}

	public function rest_handle_currency_settings( WP_REST_Request $request ) {
		if ( $request->get_method() === 'POST' ) {
			$params = $request->get_json_params() ?: $request->get_params();
			$current = self::get_settings();

			if ( isset( $params['currency_rates'] ) && is_array( $params['currency_rates'] ) ) {
				$clean_rates = [];
				foreach ( $params['currency_rates'] as $code => $data ) {
					$clean_code = strtoupper( sanitize_text_field( $code ) );
					if ( empty( $clean_code ) ) continue;
					$clean_rates[ $clean_code ] = [
						'symbol'   => sanitize_text_field( $data['symbol'] ?? '$' ),
						'rate'     => floatval( $data['rate'] ?? 0 ),
						'rounding' => sanitize_text_field( $data['rounding'] ?? '9_end' ),
					];
				}
				$current['currency_rates'] = $clean_rates;
			}

			if ( isset( $params['currency_global_markup'] ) ) {
				$current['currency_global_markup'] = max( 1.0, floatval( $params['currency_global_markup'] ) );
			}

			if ( isset( $params['currency_auto_sync_aelia'] ) ) {
				$current['currency_auto_sync_aelia'] = ! empty( $params['currency_auto_sync_aelia'] );
			}

			update_option( 'exacoat_core_settings', $current );
			update_option( 'artmatter_core_settings', $current );
			self::clear_settings_cache();

			$rates = $current['currency_rates'] ?? ( class_exists( 'Exacoat_Store_Enhancements' ) ? Exacoat_Store_Enhancements::get_currency_rates() : [] );
			$markup = floatval( $current['currency_global_markup'] ?? 1.8 );

			return rest_ensure_response( [
				'success'                    => true,
				'message'                    => 'Currency settings saved successfully',
				'currency_rates'             => $rates,
				'currency_global_markup'     => $markup,
				'currency_auto_sync_aelia'   => ! empty( $current['currency_auto_sync_aelia'] ),
				'currency_last_synced_aelia' => $current['currency_last_synced_aelia'] ?? null,
			] );
		}

		$current = self::get_settings();
		$rates = $current['currency_rates'] ?? ( class_exists( 'Exacoat_Store_Enhancements' ) ? Exacoat_Store_Enhancements::get_currency_rates() : [] );
		$markup = floatval( $current['currency_global_markup'] ?? 1.8 );

		$aelia_rates = class_exists( 'Exacoat_Store_Enhancements' ) ? Exacoat_Store_Enhancements::get_aelia_exchange_rates() : [];

		return rest_ensure_response( [
			'success'                    => true,
			'currency_rates'             => $rates,
			'currency_global_markup'     => $markup,
			'currency_auto_sync_aelia'   => ! empty( $current['currency_auto_sync_aelia'] ),
			'currency_last_synced_aelia' => $current['currency_last_synced_aelia'] ?? null,
			'aelia_detected'             => ! empty( $aelia_rates ),
			'aelia_rates'                => $aelia_rates,
		] );
	}

	public function rest_sync_currency_aelia( WP_REST_Request $request ) {
		if ( ! class_exists( 'Exacoat_Store_Enhancements' ) ) {
			return rest_ensure_response( [
				'success' => false,
				'message' => 'Store Enhancements module is not loaded.',
			] );
		}

		$result = Exacoat_Store_Enhancements::sync_rates_from_aelia();
		return rest_ensure_response( $result );
	}

	public function rest_handle_shipping_settings( WP_REST_Request $request ) {
		if ( $request->get_method() === 'POST' ) {
			$params = $request->get_json_params() ?: $request->get_params();
			$current = self::get_settings();

			if ( isset( $params['shipping_zones'] ) && is_array( $params['shipping_zones'] ) ) {
				$clean_zones = [];
				foreach ( $params['shipping_zones'] as $key => $zone ) {
					$clean_key = sanitize_key( $key );
					if ( empty( $clean_key ) ) continue;
					$clean_zones[ $clean_key ] = [
						'name'        => sanitize_text_field( $zone['name'] ?? ucfirst( $clean_key ) ),
						'countries'   => sanitize_text_field( $zone['countries'] ?? '' ),
						'currency'    => strtoupper( sanitize_text_field( $zone['currency'] ?? 'USD' ) ),
						'free'        => floatval( $zone['free'] ?? 0 ),
						'filter_text' => sanitize_text_field( $zone['filter_text'] ?? '' ),
					];
				}
				$current['shipping_zones'] = $clean_zones;
			}

			if ( isset( $params['shipping_target_method_ids'] ) ) {
				$current['shipping_target_method_ids'] = sanitize_text_field( $params['shipping_target_method_ids'] );
			}

			if ( isset( $params['logistics_carriers'] ) && is_array( $params['logistics_carriers'] ) ) {
				$clean_carriers = [];
				foreach ( $params['logistics_carriers'] as $key => $carrier ) {
					$clean_key = sanitize_key( $key );
					if ( empty( $clean_key ) ) continue;
					$clean_carriers[ $clean_key ] = [
						'name' => sanitize_text_field( $carrier['name'] ?? ucfirst( $clean_key ) ),
						'url'  => esc_url_raw( $carrier['url'] ?? '' ),
					];
				}
				$current['logistics_carriers'] = $clean_carriers;
			}

			update_option( 'exacoat_core_settings', $current );
			update_option( 'artmatter_core_settings', $current );
			self::clear_settings_cache();

			$ship_cfg = class_exists( 'Exacoat_Store_Enhancements' ) ? Exacoat_Store_Enhancements::get_shipping_config() : [ 'zones' => [], 'target_method_ids' => [] ];
			$carriers = class_exists( 'Exacoat_Shipping_Tracker' ) ? Exacoat_Shipping_Tracker::get_carrier_registry() : [];

			return rest_ensure_response( [
				'success'                    => true,
				'message'                    => 'Shipping settings saved successfully',
				'shipping_zones'             => $current['shipping_zones'] ?? $ship_cfg['zones'],
				'shipping_target_method_ids' => $current['shipping_target_method_ids'] ?? implode( ', ', $ship_cfg['target_method_ids'] ),
				'logistics_carriers'         => $current['logistics_carriers'] ?? $carriers,
			] );
		}

		$current  = self::get_settings();
		$ship_cfg = class_exists( 'Exacoat_Store_Enhancements' ) ? Exacoat_Store_Enhancements::get_shipping_config() : [ 'zones' => [], 'target_method_ids' => [] ];
		$carriers = class_exists( 'Exacoat_Shipping_Tracker' ) ? Exacoat_Shipping_Tracker::get_carrier_registry() : [];

		return rest_ensure_response( [
			'success'                    => true,
			'shipping_zones'             => $current['shipping_zones'] ?? $ship_cfg['zones'],
			'shipping_target_method_ids' => $current['shipping_target_method_ids'] ?? implode( ', ', $ship_cfg['target_method_ids'] ),
			'logistics_carriers'         => $current['logistics_carriers'] ?? $carriers,
		] );
	}

	/**
	 * Retrieve registered URL redirections with fallback seeds
	 */
	public static function get_redirections(): array {
		$redirects = get_option( 'exacoat_redirections', null );
		if ( ! is_array( $redirects ) ) {
			// Seed default redirections
			$redirects = [
				[
					'id'          => 'red_cs',
					'source'      => '/cs',
					'target'      => 'https://api.whatsapp.com/send?phone=628975556000',
					'status_code' => 307,
					'enabled'     => true,
					'label'       => 'Customer Service WhatsApp',
					'hits'        => 0,
					'created_at'  => current_time( 'mysql' ),
					'updated_at'  => current_time( 'mysql' ),
				],
				[
					'id'          => 'red_care',
					'source'      => '/care',
					'target'      => 'https://api.whatsapp.com/send?phone=628975556000',
					'status_code' => 307,
					'enabled'     => true,
					'label'       => 'Exacoat Care WhatsApp',
					'hits'        => 0,
					'created_at'  => current_time( 'mysql' ),
					'updated_at'  => current_time( 'mysql' ),
				],
				[
					'id'          => 'red_wa',
					'source'      => '/wa',
					'target'      => 'https://api.whatsapp.com/send?phone=628975556000',
					'status_code' => 307,
					'enabled'     => true,
					'label'       => 'WhatsApp Direct',
					'hits'        => 0,
					'created_at'  => current_time( 'mysql' ),
					'updated_at'  => current_time( 'mysql' ),
				],
			];
			update_option( 'exacoat_redirections', $redirects );
		}
		return $redirects;
	}

	public function rest_get_redirects( WP_REST_Request $request ) {
		$redirects = self::get_redirections();
		$response = rest_ensure_response( [
			'success'   => true,
			'redirects' => $redirects,
		] );
		$response->header( 'Cache-Control', 'public, max-age=30, stale-while-revalidate=120' );
		return $response;
	}

	public function rest_save_redirects( WP_REST_Request $request ) {
		$params = $request->get_json_params() ?: $request->get_params();
		$raw_list = $params['redirects'] ?? $params;

		if ( ! is_array( $raw_list ) ) {
			return new WP_Error( 'invalid_data', 'Redirects payload must be an array of rules.', [ 'status' => 400 ] );
		}

		$clean_redirects = [];
		foreach ( $raw_list as $index => $item ) {
			if ( ! is_array( $item ) ) continue;

			$source = trim( (string) ( $item['source'] ?? '' ) );
			$target = trim( (string) ( $item['target'] ?? '' ) );

			if ( empty( $source ) || empty( $target ) ) {
				continue;
			}

			// Ensure source starts with /
			if ( ! str_starts_with( $source, '/' ) ) {
				$source = '/' . $source;
			}
			// Disallow redirecting root / itself
			if ( $source === '/' ) {
				continue;
			}

			$id = sanitize_text_field( $item['id'] ?? ( 'red_' . substr( md5( $source . microtime() ), 0, 8 ) ) );
			$status_code = in_array( (int) ( $item['status_code'] ?? 307 ), [ 301, 302, 307, 308 ], true ) ? (int) $item['status_code'] : 307;
			$enabled = isset( $item['enabled'] ) ? (bool) $item['enabled'] : true;
			$label = sanitize_text_field( $item['label'] ?? '' );
			$hits = max( 0, (int) ( $item['hits'] ?? 0 ) );
			$created_at = sanitize_text_field( $item['created_at'] ?? current_time( 'mysql' ) );

			$clean_redirects[] = [
				'id'          => $id,
				'source'      => $source,
				'target'      => $target,
				'status_code' => $status_code,
				'enabled'     => $enabled,
				'label'       => $label,
				'hits'        => $hits,
				'created_at'  => $created_at,
				'updated_at'  => current_time( 'mysql' ),
			];
		}

		update_option( 'exacoat_redirections', $clean_redirects );

		if ( class_exists( 'Exacoat_Logger' ) ) {
			Exacoat_Logger::log( 'info', 'redirects', 'Updated URL redirections from Exacoat Manager ERP: ' . count( $clean_redirects ) . ' rules' );
		}

		return rest_ensure_response( [
			'success'   => true,
			'message'   => 'Redirections updated successfully.',
			'redirects' => $clean_redirects,
		] );
	}

	public function rest_track_redirect( WP_REST_Request $request ) {
		$params = $request->get_json_params() ?: $request->get_params();
		$source = trim( (string) ( $params['source'] ?? '' ) );
		$id = trim( (string) ( $params['id'] ?? '' ) );

		if ( empty( $source ) && empty( $id ) ) {
			return rest_ensure_response( [ 'success' => false ] );
		}

		$redirects = self::get_redirections();
		$updated = false;

		foreach ( $redirects as &$r ) {
			if ( ( ! empty( $id ) && $r['id'] === $id ) || ( ! empty( $source ) && strtolower( $r['source'] ) === strtolower( $source ) ) ) {
				$r['hits'] = ( $r['hits'] ?? 0 ) + 1;
				$r['last_accessed_at'] = current_time( 'mysql' );
				$updated = true;
				break;
			}
		}

		if ( $updated ) {
			update_option( 'exacoat_redirections', $redirects );
		}

		return rest_ensure_response( [ 'success' => true ] );
	}

	public function rest_get_public_feelform_settings() {
		if ( ! class_exists( 'Artmatter_Feelform_3D' ) ) {
			return new WP_Error( 'feelform_unavailable', 'FeelForm settings are unavailable.', [ 'status' => 503 ] );
		}

		$response = rest_ensure_response( [
			'success'  => true,
			'settings' => Artmatter_Feelform_3D::get_options(),
		] );
		$response->header( 'Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0' );
		return $response;
	}

	public function rest_save_settings( WP_REST_Request $request ) {
		$new_settings = $request->get_json_params() ?: $request->get_params();
		if ( empty( $new_settings ) || ! is_array( $new_settings ) ) {
			return new WP_Error( 'invalid_data', 'Settings payload must be an object', [ 'status' => 400 ] );
		}

		$current = self::get_settings();
		$secret_keys = [
			'gemini_api_key',
			'openai_api_key',
			'r2_secret_key',
			'r2_access_key',
			'cloudflare_api_token',
			'drime_access_token',
			'drime_secret_key',
			'zeptomail_token',
			'acumbamail_token',
			'pushover_app_token',
			'pushover_user_key',
			'telegram_bot_token',
		];

		foreach ( $new_settings as $key => $val ) {
			if ( $val !== null ) {
				$clean_val = is_string( $val ) ? trim( $val ) : $val;
				if ( in_array( $key, $secret_keys, true ) && $clean_val === '' && ! empty( $current[ $key ] ) ) {
					continue;
				}
				$current[ sanitize_key( $key ) ] = $clean_val;
			}
		}

		$target_gemini_model = sanitize_text_field( $new_settings['gemini_model'] ?? $new_settings['ai_model'] ?? '' );
		if ( ! empty( $target_gemini_model ) ) {
			$current['gemini_model'] = $target_gemini_model;
			$current['ai_model']     = $target_gemini_model;
		}

		$target_openai_model = sanitize_text_field( $new_settings['openai_model'] ?? '' );
		if ( ! empty( $target_openai_model ) ) {
			$current['openai_model'] = $target_openai_model;
		}

		$target_r2_bucket = sanitize_text_field( $new_settings['r2_bucket_name'] ?? $new_settings['r2_bucket'] ?? '' );
		if ( ! empty( $target_r2_bucket ) ) {
			$current['r2_bucket_name'] = $target_r2_bucket;
			$current['r2_bucket']      = $target_r2_bucket;
		}

		update_option( 'exacoat_core_settings', $current );
		update_option( 'artmatter_core_settings', $current );
		self::clear_settings_cache();

		$saved_keys = implode( ', ', array_keys( $new_settings ) );
		if ( class_exists( 'Exacoat_Logger' ) ) {
			Exacoat_Logger::log( 'success', 'settings', "Remote Settings Update via Exacoat Manager ERP: [{$saved_keys}]", [ 'updated_keys' => array_keys( $new_settings ) ] );
		} elseif ( class_exists( 'Artmatter_Logger' ) ) {
			Artmatter_Logger::log( 'success', 'settings', "Remote Settings Update via Exacoat Manager ERP: [{$saved_keys}]", [ 'updated_keys' => array_keys( $new_settings ) ] );
		}

		return rest_ensure_response( [
			'success'  => true,
			'message'  => 'Plugin settings saved successfully',
			'settings' => $current,
		] );
	}

	/**
	 * Retrieve WordPress staff accounts (administrators and shop managers)
	 */
	public function rest_get_team_members( WP_REST_Request $request ) {
		$wp_users = get_users( [
			'role__in' => [ 'administrator', 'shop_manager', 'manager', 'editor' ],
			'orderby'  => 'registered',
			'order'    => 'ASC',
		] );

		$members = [];
		foreach ( $wp_users as $user ) {
			$roles = (array) $user->roles;
			$role = 'manager';
			if ( in_array( 'administrator', $roles, true ) ) {
				$role = 'super_admin';
			} elseif ( in_array( 'shop_manager', $roles, true ) ) {
				$role = 'shop_manager';
			} elseif ( in_array( 'editor', $roles, true ) || in_array( 'manager', $roles, true ) ) {
				$role = 'manager';
			}

			$full_name = trim( $user->first_name . ' ' . $user->last_name );
			if ( empty( $full_name ) ) {
				$full_name = $user->display_name ?: $user->user_login;
			}

			$members[] = [
				'id'                 => (string) $user->ID,
				'email'              => $user->user_email,
				'full_name'          => $full_name,
				'role'               => $role,
				'wp_roles'           => array_values( $roles ),
				'avatar_url'         => get_avatar_url( $user->ID ),
				'created_at'         => $user->user_registered ? gmdate( 'c', strtotime( $user->user_registered ) ) : gmdate( 'c' ),
				'email_confirmed_at' => $user->user_registered ? gmdate( 'c', strtotime( $user->user_registered ) ) : gmdate( 'c' ),
				'last_sign_in_at'    => get_user_meta( $user->ID, '_last_login', true ) ?: ( get_user_meta( $user->ID, 'last_login', true ) ?: null ),
			];
		}

		return rest_ensure_response( [
			'success' => true,
			'users'   => $members,
			'total'   => count( $members ),
		] );
	}

	/**
	 * Update WordPress staff user role
	 */
	public function rest_update_team_user_role( WP_REST_Request $request ) {
		$user_id = (int) $request->get_param( 'id' );
		$params  = $request->get_json_params() ?: $request->get_params();
		$new_role = sanitize_key( $params['role'] ?? '' );

		$user = get_user_by( 'id', $user_id );
		if ( ! $user instanceof WP_User ) {
			return new WP_Error( 'user_not_found', 'WordPress user not found.', [ 'status' => 404 ] );
		}

		$wp_role = 'shop_manager';
		if ( 'super_admin' === $new_role ) {
			$wp_role = 'administrator';
		} elseif ( 'shop_manager' === $new_role ) {
			$wp_role = 'shop_manager';
		} elseif ( 'manager' === $new_role ) {
			$wp_role = 'shop_manager';
		}

		$user->set_role( $wp_role );

		return rest_ensure_response( [
			'success' => true,
			'message' => "WordPress user {$user->user_email} role updated to {$wp_role}.",
			'user_id' => $user_id,
			'role'    => $new_role,
			'wp_role' => $wp_role,
		] );
	}

	/**
	 * Create a new WordPress staff user account
	 */
	public function rest_create_team_member( WP_REST_Request $request ) {
		$params    = $request->get_json_params() ?: $request->get_params();
		$email     = sanitize_email( (string) ( $params['email'] ?? '' ) );
		$password  = (string) ( $params['password'] ?? '' );
		$full_name = sanitize_text_field( (string) ( $params['full_name'] ?? $params['fullName'] ?? '' ) );
		$role      = sanitize_key( (string) ( $params['role'] ?? 'shop_manager' ) );

		if ( ! $email || ! is_email( $email ) ) {
			return new WP_Error( 'invalid_email', 'A valid email address is required.', [ 'status' => 400 ] );
		}

		if ( strlen( $password ) < 8 ) {
			return new WP_Error( 'weak_password', 'Password must be at least 8 characters.', [ 'status' => 400 ] );
		}

		if ( email_exists( $email ) ) {
			return new WP_Error( 'email_exists', 'A WordPress account with this email already exists.', [ 'status' => 409 ] );
		}

		$wp_role = 'shop_manager';
		if ( 'super_admin' === $role ) {
			$wp_role = 'administrator';
		} elseif ( 'shop_manager' === $role ) {
			$wp_role = 'shop_manager';
		}

		$username = sanitize_user( current( explode( '@', $email ) ), true );
		if ( username_exists( $username ) ) {
			$username .= '_' . wp_rand( 100, 999 );
		}

		$name_parts  = preg_split( '/\s+/', trim( $full_name ), 2 );
		$first_name  = $name_parts[0] ?? '';
		$last_name   = $name_parts[1] ?? '';

		$user_id = wp_insert_user( [
			'user_login'   => $username,
			'user_email'   => $email,
			'user_pass'    => $password,
			'display_name' => $full_name ?: $username,
			'first_name'   => $first_name,
			'last_name'    => $last_name,
			'role'         => $wp_role,
		] );

		if ( is_wp_error( $user_id ) ) {
			return new WP_Error( 'create_failed', $user_id->get_error_message(), [ 'status' => 400 ] );
		}

		$new_user = get_user_by( 'id', $user_id );

		return rest_ensure_response( [
			'success' => true,
			'message' => "WordPress staff account created for {$email}.",
			'user'    => [
				'id'                 => (string) $new_user->ID,
				'email'              => $new_user->user_email,
				'full_name'          => $full_name ?: $username,
				'role'               => $role,
				'wp_roles'           => (array) $new_user->roles,
				'avatar_url'         => get_avatar_url( $new_user->ID ),
				'created_at'         => gmdate( 'c', strtotime( $new_user->user_registered ) ),
				'email_confirmed_at' => gmdate( 'c', strtotime( $new_user->user_registered ) ),
			],
		] );
	}

	/**
	 * Delete a WordPress staff user account
	 */
	public function rest_delete_team_member( WP_REST_Request $request ) {
		$user_id = (int) $request->get_param( 'id' );
		$user = get_user_by( 'id', $user_id );
		if ( ! $user instanceof WP_User ) {
			return new WP_Error( 'user_not_found', 'WordPress user not found.', [ 'status' => 404 ] );
		}

		if ( in_array( 'administrator', (array) $user->roles, true ) ) {
			$admins = get_users( [ 'role' => 'administrator' ] );
			if ( count( $admins ) <= 1 ) {
				return new WP_Error( 'cannot_delete_last_admin', 'Cannot delete the primary administrator account.', [ 'status' => 403 ] );
			}
		}

		require_once ABSPATH . 'wp-admin/includes/user.php';
		$admin_users = get_users( [ 'role' => 'administrator', 'number' => 1 ] );
		$reassign_id = ! empty( $admin_users ) ? (int) $admin_users[0]->ID : null;

		$deleted = wp_delete_user( $user_id, $reassign_id );
		if ( ! $deleted ) {
			return new WP_Error( 'delete_failed', 'Could not delete WordPress user.', [ 'status' => 500 ] );
		}

		return rest_ensure_response( [
			'success' => true,
			'message' => "WordPress user {$user->user_email} deleted.",
		] );
	}

	public static function log( $message, $level = 'info', $channel = 'general', $context = [] ) {
		if ( class_exists( 'Exacoat_Logger' ) ) {
			Exacoat_Logger::log( $level, $channel, $message, $context );
		} elseif ( class_exists( 'Artmatter_Logger' ) ) {
			Artmatter_Logger::log( $level, $channel, $message, $context );
		} elseif ( function_exists( 'wc_get_logger' ) ) {
			$logger  = wc_get_logger();
			$wc_context = [ 'source' => 'exacoat-' . $channel ];
			if ( $level === 'error' ) {
				$logger->error( $message, $wc_context );
			} elseif ( $level === 'warning' ) {
				$logger->warning( $message, $wc_context );
			} else {
				$logger->info( $message, $wc_context );
			}
		}
	}
}

}
