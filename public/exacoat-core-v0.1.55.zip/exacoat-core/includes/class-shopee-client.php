<?php
/**
 * Exacoat Core - Shopee Open Platform API v2 Engine
 * Connects Exacoat Manager directly with Shopee Open API v2 for both
 * Sandbox (Test-Stable) and Live (Production) environments.
 * Handles HMAC-SHA256 signing, OAuth tokens, order sync, and warranty verification.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Exacoat_Shopee_Client' ) ) {

class Exacoat_Shopee_Client {

	const OPTION_KEY             = '_exacoat_shopee_settings';
	const ORDERS_CACHE_KEY       = '_exacoat_shopee_orders_cache';
	const DEFAULT_TEST_PID       = 1244885;
	const DEFAULT_LIVE_PID       = 2011551;
	const DEFAULT_TEST_PUSH_KEY  = 'aaaaaaaaaaaaaactd5mbgvzd3cjhmhh48v428zpt6ywwnuosz567nweg42ey8pky';
	const DEFAULT_WEBHOOK_URL    = 'https://exacoat.com/wp-json/exacoat-core/v1/shopee/webhook';
	const SANDBOX_BASE_URL       = 'https://partner.test-stable.shopeemobile.com';
	const LIVE_BASE_URL          = 'https://partner.shopeemobile.com';

	/**
	 * Initialize Hooks & REST API Routes
	 */
	public static function init(): void {
		add_action( 'rest_api_init', [ __CLASS__, 'register_routes' ] );
	}

	/**
	 * Get current Shopee configuration settings
	 */
	public static function get_settings(): array {
		$defaults = [
			'environment'           => 'live', // 'sandbox' | 'live'
			'test_partner_id'       => self::DEFAULT_TEST_PID,
			'test_partner_key'      => 'shpk666c6843537a484142475a44787861767052765558666f635a434f58566e',
			'test_push_partner_key' => self::DEFAULT_TEST_PUSH_KEY,
			'live_partner_id'       => self::DEFAULT_LIVE_PID,
			'live_partner_key'      => 'shpk706c666c6f42674755427a546a79445a78417449554e5674616b4b665a4f',
			'live_push_partner_key' => '58724959565954534b6d797147587a55505a4f79614243526464424a66686e63',
			'redirect_url'          => 'https://manager.exacoat.com/shopee/callback',
			'push_callback_url'     => self::DEFAULT_WEBHOOK_URL,
			'shop_id'               => 0,
			'shop_name'             => 'Exacoat Official Store',
			'access_token'          => '',
			'refresh_token'         => '',
			'token_expires_at'      => 0,
			'last_synced_at'        => 0,
		];

		$saved = get_option( self::OPTION_KEY, [] );
		return wp_parse_args( is_array( $saved ) ? $saved : [], $defaults );
	}

	/**
	 * Save updated Shopee settings
	 */
	public static function save_settings( array $settings ): bool {
		$current = self::get_settings();
		$updated = array_merge( $current, $settings );
		return update_option( self::OPTION_KEY, $updated );
	}

	/**
	 * Get active partner ID based on environment
	 */
	public static function get_active_partner_id(): int {
		$s = self::get_settings();
		return $s['environment'] === 'live' ? (int) $s['live_partner_id'] : (int) $s['test_partner_id'];
	}

	/**
	 * Get active partner key based on environment
	 */
	public static function get_active_partner_key(): string {
		$s = self::get_settings();
		return $s['environment'] === 'live' ? trim( $s['live_partner_key'] ) : trim( $s['test_partner_key'] );
	}

	/**
	 * Get active push partner key for webhook signature verification
	 */
	public static function get_active_push_partner_key(): string {
		$s = self::get_settings();
		$key = $s['environment'] === 'live'
			? trim( (string) ( $s['live_push_partner_key'] ?? '' ) )
			: trim( (string) ( $s['test_push_partner_key'] ?? '' ) );

		if ( ! empty( $key ) ) {
			return $key;
		}
		return self::get_active_partner_key();
	}

	/**
	 * Verify HMAC-SHA256 signature from Shopee Push request header
	 * Base string: URL|request_body
	 */
	public static function verify_push_signature( string $url, string $raw_body, string $header_auth ): bool {
		if ( empty( $header_auth ) ) {
			return false;
		}

		$push_key = self::get_active_push_partner_key();
		if ( empty( $push_key ) ) {
			return true;
		}

		$base_str = $url . '|' . $raw_body;
		$computed = hash_hmac( 'sha256', $base_str, $push_key );
		if ( hash_equals( strtolower( $computed ), strtolower( trim( $header_auth ) ) ) ) {
			return true;
		}

		// Fallback check against standard partner key
		$std_key = self::get_active_partner_key();
		if ( ! empty( $std_key ) && $std_key !== $push_key ) {
			$computed_std = hash_hmac( 'sha256', $base_str, $std_key );
			if ( hash_equals( strtolower( $computed_std ), strtolower( trim( $header_auth ) ) ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Get active base API URL
	 */
	public static function get_base_url(): string {
		$s = self::get_settings();
		return $s['environment'] === 'live' ? self::LIVE_BASE_URL : self::SANDBOX_BASE_URL;
	}

	/**
	 * Generate HMAC-SHA256 signature for Public API endpoints
	 * e.g. /api/v2/shop/auth_partner, /api/v2/auth/token/get
	 */
	public static function sign_public( string $path, int $timestamp, int $partner_id, string $partner_key ): string {
		$base_str = $partner_id . $path . $timestamp;
		return hash_hmac( 'sha256', $base_str, $partner_key );
	}

	/**
	 * Generate HMAC-SHA256 signature for Shop API endpoints
	 * e.g. /api/v2/order/get_order_list, /api/v2/order/get_order_detail
	 */
	public static function sign_shop( string $path, int $timestamp, int $partner_id, string $partner_key, string $access_token, int $shop_id ): string {
		$base_str = $partner_id . $path . $timestamp . $access_token . $shop_id;
		return hash_hmac( 'sha256', $base_str, $partner_key );
	}

	/**
	 * Generate signed seller authorization URL
	 */
	public static function get_auth_url( string $redirect_override = '' ): string {
		$settings = self::get_settings();
		$partner_id = self::get_active_partner_id();
		$partner_key = self::get_active_partner_key();
		$base_url = self::get_base_url();

		$path = '/api/v2/shop/auth_partner';
		$timestamp = time();
		$sign = self::sign_public( $path, $timestamp, $partner_id, $partner_key );

		$redirect = ! empty( $redirect_override ) ? $redirect_override : $settings['redirect_url'];

		$query = http_build_query([
			'partner_id' => $partner_id,
			'timestamp'  => $timestamp,
			'sign'       => $sign,
			'redirect'   => $redirect,
		]);

		return "{$base_url}{$path}?{$query}";
	}

	/**
	 * Exchange authorization code for access_token and refresh_token
	 */
	public static function exchange_code_for_tokens( string $code, int $shop_id ): array {
		$partner_id = self::get_active_partner_id();
		$partner_key = self::get_active_partner_key();
		$base_url = self::get_base_url();

		$path = '/api/v2/auth/token/get';
		$timestamp = time();
		$sign = self::sign_public( $path, $timestamp, $partner_id, $partner_key );

		$url = "{$base_url}{$path}?partner_id={$partner_id}&timestamp={$timestamp}&sign={$sign}";

		$body = wp_json_encode([
			'code'       => trim( $code ),
			'shop_id'    => $shop_id,
			'partner_id' => $partner_id,
		]);

		$res = wp_remote_post( $url, [
			'headers' => [ 'Content-Type' => 'application/json' ],
			'body'    => $body,
			'timeout' => 20,
		]);

		if ( is_wp_error( $res ) ) {
			return [ 'success' => false, 'error' => $res->get_error_message() ];
		}

		$data = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( ! empty( $data['error'] ) ) {
			return [
				'success' => false,
				'error'   => $data['error'],
				'message' => $data['message'] ?? 'Failed to exchange Shopee authorization code.',
			];
		}

		if ( ! empty( $data['access_token'] ) ) {
			$expires_in = (int) ( $data['expire_in'] ?? 14400 );
			self::save_settings([
				'access_token'     => $data['access_token'],
				'refresh_token'    => $data['refresh_token'] ?? '',
				'shop_id'          => $shop_id,
				'token_expires_at' => time() + $expires_in,
			]);

			return [
				'success'       => true,
				'access_token'  => $data['access_token'],
				'refresh_token' => $data['refresh_token'] ?? '',
				'expire_in'     => $expires_in,
				'shop_id'       => $shop_id,
			];
		}

		return [ 'success' => false, 'error' => 'Invalid token response structure from Shopee.' ];
	}

	/**
	 * Ensure valid access token, auto-refreshing if expiring within 5 minutes
	 */
	public static function ensure_valid_token(): array {
		$s = self::get_settings();
		if ( empty( $s['access_token'] ) || empty( $s['shop_id'] ) ) {
			return [ 'success' => false, 'error' => 'Shopee store is not connected. Please authorize first.' ];
		}

		// If token still valid for more than 5 minutes, return current
		if ( $s['token_expires_at'] > ( time() + 300 ) ) {
			return [
				'success'      => true,
				'access_token' => $s['access_token'],
				'shop_id'      => (int) $s['shop_id'],
			];
		}

		// Token expired or expiring soon, refresh it
		if ( empty( $s['refresh_token'] ) ) {
			return [ 'success' => false, 'error' => 'Shopee refresh token missing. Re-authorization required.' ];
		}

		$partner_id = self::get_active_partner_id();
		$partner_key = self::get_active_partner_key();
		$base_url = self::get_base_url();

		$path = '/api/v2/auth/access_token/get';
		$timestamp = time();
		$sign = self::sign_public( $path, $timestamp, $partner_id, $partner_key );

		$url = "{$base_url}{$path}?partner_id={$partner_id}&timestamp={$timestamp}&sign={$sign}";

		$body = wp_json_encode([
			'refresh_token' => $s['refresh_token'],
			'shop_id'       => (int) $s['shop_id'],
			'partner_id'    => $partner_id,
		]);

		$res = wp_remote_post( $url, [
			'headers' => [ 'Content-Type' => 'application/json' ],
			'body'    => $body,
			'timeout' => 20,
		]);

		if ( is_wp_error( $res ) ) {
			return [ 'success' => false, 'error' => $res->get_error_message() ];
		}

		$data = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( ! empty( $data['access_token'] ) ) {
			$expires_in = (int) ( $data['expire_in'] ?? 14400 );
			self::save_settings([
				'access_token'     => $data['access_token'],
				'refresh_token'    => $data['refresh_token'] ?? $s['refresh_token'],
				'token_expires_at' => time() + $expires_in,
			]);

			return [
				'success'      => true,
				'access_token' => $data['access_token'],
				'shop_id'      => (int) $s['shop_id'],
			];
		}

		return [
			'success' => false,
			'error'   => $data['message'] ?? 'Could not refresh Shopee access token. Please re-authorize.',
		];
	}

	/**
	 * Synchronize orders from Shopee Open API v2
	 */
	public static function sync_orders( int $days_back = 30, int $max_orders = 500 ): array {
		$start_time = microtime( true );
		$s = self::get_settings();
		$max_fetch = min( 1000, max( 50, $max_orders ) );

		if ( class_exists( 'Exacoat_Logger' ) ) {
			Exacoat_Logger::log(
				'info',
				'shopee_sync',
				sprintf( 'Initiating Shopee order sync (days_back: %d, max_orders: %d, env: %s)', $days_back, $max_fetch, $s['environment'] ),
				[
					'partner_id' => self::get_active_partner_id(),
					'shop_id'    => $s['shop_id'] ?? 0,
					'days_back'  => $days_back,
					'max_fetch'  => $max_fetch,
				]
			);
		}

		$token_res = self::ensure_valid_token();
		if ( ! $token_res['success'] ) {
			if ( class_exists( 'Exacoat_Logger' ) ) {
				Exacoat_Logger::log(
					'warning',
					'shopee_sync',
					'Shopee token validation failed during sync: ' . ( $token_res['error'] ?? 'Token invalid' ),
					$token_res
				);
			}

			// If not connected or in sandbox without live orders, return cached orders gracefully
			$cached = get_option( self::ORDERS_CACHE_KEY, [] );
			if ( ! empty( $cached ) ) {
				return [
					'success'      => true,
					'orders'       => $cached,
					'from_cache'   => true,
					'warning'      => $token_res['error'],
				];
			}
			return $token_res;
		}

		$partner_id = self::get_active_partner_id();
		$partner_key = self::get_active_partner_key();
		$base_url = self::get_base_url();
		$access_token = $token_res['access_token'];
		$shop_id = $token_res['shop_id'];

		// Shopee API v2 restricts get_order_list time slot to a maximum of 15 days.
		// To support 30, 60, or 90 days, partition the requested range into 14-day sliding slots.
		$now = time();
		$overall_from = $now - ( $days_back * 86400 );
		$slot_size = 14 * 86400;
		$windows = [];
		$curr_to = $now;

		while ( $curr_to > $overall_from ) {
			$curr_from = max( $overall_from, $curr_to - $slot_size );
			$windows[] = [
				'time_from' => $curr_from,
				'time_to'   => $curr_to,
			];
			$curr_to = $curr_from;
		}

		// Step 1: Iterate through time slots and paginate using next_cursor
		$order_sns = [];

		foreach ( $windows as $window ) {
			if ( count( $order_sns ) >= $max_fetch ) {
				break;
			}

			$cursor = '';
			do {
				$list_path = '/api/v2/order/get_order_list';
				$list_ts = time();
				$list_sign = self::sign_shop( $list_path, $list_ts, $partner_id, $partner_key, $access_token, $shop_id );

				$query_args = [
					'partner_id'        => $partner_id,
					'timestamp'         => $list_ts,
					'access_token'      => $access_token,
					'shop_id'           => $shop_id,
					'sign'              => $list_sign,
					'time_range_field'  => 'create_time',
					'time_from'         => $window['time_from'],
					'time_to'           => $window['time_to'],
					'page_size'         => 50,
				];
				if ( ! empty( $cursor ) ) {
					$query_args['cursor'] = $cursor;
				}

				$list_url = "{$base_url}{$list_path}?" . http_build_query( $query_args );
				$list_res = wp_remote_get( $list_url, [ 'timeout' => 25 ] );
				if ( is_wp_error( $list_res ) ) {
					$err = $list_res->get_error_message();
					if ( class_exists( 'Exacoat_Logger' ) ) {
						Exacoat_Logger::log( 'error', 'shopee_sync', 'Shopee get_order_list HTTP transport error: ' . $err );
					}
					break;
				}

				$list_data = json_decode( wp_remote_retrieve_body( $list_res ), true );
				if ( ! empty( $list_data['error'] ) ) {
					$err = $list_data['message'] ?? $list_data['error'];
					if ( class_exists( 'Exacoat_Logger' ) ) {
						Exacoat_Logger::log( 'error', 'shopee_sync', 'Shopee get_order_list API error: ' . $err, $list_data );
					}
					break;
				}

				$raw_order_list = $list_data['response']['order_list'] ?? [];
				if ( empty( $raw_order_list ) ) {
					break;
				}

				foreach ( $raw_order_list as $item ) {
					$sn = $item['order_sn'] ?? '';
					if ( ! empty( $sn ) && ! in_array( $sn, $order_sns, true ) ) {
						$order_sns[] = $sn;
					}
				}

				$has_more = ! empty( $list_data['response']['more'] );
				$cursor   = (string) ( $list_data['response']['next_cursor'] ?? '' );
			} while ( $has_more && ! empty( $cursor ) && count( $order_sns ) < $max_fetch );
		}

		if ( empty( $order_sns ) ) {
			if ( class_exists( 'Exacoat_Logger' ) ) {
				Exacoat_Logger::log( 'info', 'shopee_sync', 'Shopee get_order_list completed: 0 orders found for time range' );
			}
			$cached = get_option( self::ORDERS_CACHE_KEY, [] );
			return [
				'success'      => true,
				'orders'       => is_array( $cached ) ? $cached : [],
				'total_synced' => 0,
				'message'      => 'No recent Shopee orders found in the selected time range.',
			];
		}

		if ( class_exists( 'Exacoat_Logger' ) ) {
			Exacoat_Logger::log(
				'info',
				'shopee_sync',
				sprintf( 'Shopee get_order_list found %d orders. Fetching details in chunks...', count( $order_sns ) ),
				[ 'order_sns_count' => count( $order_sns ) ]
			);
		}

		// Step 2: Call /api/v2/order/get_order_detail in batches of 50
		$raw_details = [];
		$chunks = array_chunk( $order_sns, 50 );

		foreach ( $chunks as $chunk_sns ) {
			$detail_path = '/api/v2/order/get_order_detail';
			$detail_ts = time();
			$detail_sign = self::sign_shop( $detail_path, $detail_ts, $partner_id, $partner_key, $access_token, $shop_id );

			$detail_url = "{$base_url}{$detail_path}?" . http_build_query([
				'partner_id'                => $partner_id,
				'timestamp'                 => $detail_ts,
				'access_token'              => $access_token,
				'shop_id'                   => $shop_id,
				'sign'                      => $detail_sign,
				'order_sn_list'             => implode( ',', $chunk_sns ),
				'response_optional_fields'  => 'buyer_user_id,buyer_username,recipient_address,item_list,shipping_carrier,total_amount,pay_time,order_status,package_list,note,shipping_document_status,ship_by_date',
			]);

			$detail_res = wp_remote_get( $detail_url, [ 'timeout' => 30 ] );
			if ( ! is_wp_error( $detail_res ) ) {
				$detail_data = json_decode( wp_remote_retrieve_body( $detail_res ), true );
				$chunk_details = $detail_data['response']['order_list'] ?? [];
				if ( is_array( $chunk_details ) ) {
					$raw_details = array_merge( $raw_details, $chunk_details );
				}
			}
		}

		$normalized_orders = [];
		foreach ( $raw_details as $ord ) {
			$norm = self::normalize_shopee_order( $ord );
			if ( $norm ) {
				$normalized_orders[] = $norm;
			}
		}

		// Merge with existing cached orders so older orders are preserved!
		$existing_cached = get_option( self::ORDERS_CACHE_KEY, [] );
		if ( ! is_array( $existing_cached ) ) {
			$existing_cached = [];
		}

		$order_map = [];
		foreach ( $existing_cached as $old_ord ) {
			if ( ! empty( $old_ord['order_sn'] ) ) {
				$order_map[ $old_ord['order_sn'] ] = $old_ord;
			}
		}
		foreach ( $normalized_orders as $new_ord ) {
			if ( ! empty( $new_ord['order_sn'] ) ) {
				$sn = $new_ord['order_sn'];
				// Preserve existing printed status if previous cache marked it printed
				$was_printed = ! empty( $order_map[ $sn ]['is_printed'] ) || ( ( $order_map[ $sn ]['shipping_document_status'] ?? '' ) === 'PRINTED' );
				if ( $was_printed && empty( $new_ord['is_printed'] ) ) {
					$new_ord['is_printed'] = true;
					$new_ord['shipping_document_status'] = 'PRINTED';
				}
				$order_map[ $sn ] = $new_ord;
			}
		}

		$all_cached_orders = array_values( $order_map );
		usort( $all_cached_orders, function( $a, $b ) {
			return ( $b['create_timestamp'] ?? 0 ) <=> ( $a['create_timestamp'] ?? 0 );
		});
		$all_cached_orders = array_slice( $all_cached_orders, 0, 1000 ); // Retain up to 1,000 orders

		update_option( self::ORDERS_CACHE_KEY, $all_cached_orders );
		self::save_settings([ 'last_synced_at' => time() ]);

		$elapsed = round( microtime( true ) - $start_time, 2 );
		if ( class_exists( 'Exacoat_Logger' ) ) {
			Exacoat_Logger::log(
				'info',
				'shopee_sync',
				sprintf( 'Shopee order sync completed successfully: %d synced, %d total in cache (elapsed: %ss)', count( $normalized_orders ), count( $all_cached_orders ), $elapsed ),
				[
					'synced_count' => count( $normalized_orders ),
					'total_cached' => count( $all_cached_orders ),
					'elapsed_sec'  => $elapsed,
				]
			);
		}

		return [
			'success'      => true,
			'orders'       => $all_cached_orders,
			'total_synced' => count( $normalized_orders ),
			'total_cached' => count( $all_cached_orders ),
			'synced_at'    => date( 'Y-m-d H:i:s' ),
		];
	}

	/**
	 * Normalize raw Shopee order array
	 */
	public static function normalize_shopee_order( array $ord ): ?array {
		$sn = $ord['order_sn'] ?? '';
		if ( empty( $sn ) ) return null;

		$claim_info = self::check_existing_claim( $sn );

		$items = [];
		foreach ( ( $ord['item_list'] ?? [] ) as $item ) {
			$var_name = trim( $item['model_name'] ?? '' );
			$prod_name = trim( $item['item_name'] ?? 'Exacoat Skin' );

			$items[] = [
				'item_id'          => $item['item_id'] ?? 0,
				'item_name'        => $prod_name,
				'model_id'         => $item['model_id'] ?? 0,
				'model_name'       => $var_name,
				'quantity'         => (int) ( $item['model_quantity_purchased'] ?? 1 ),
				'price'            => (float) ( $item['model_discounted_price'] ?? $item['model_original_price'] ?? 0 ),
				'image_url'        => $item['image_info']['image_url'] ?? '',
			];
		}

		$rec = $ord['recipient_address'] ?? [];
		$package = ( $ord['package_list'] ?? [] )[0] ?? [];
		$pkg_logistics_st = strtoupper( (string) ( $package['logistics_status'] ?? '' ) );
		$shipping_doc_st = '';
		if ( ! empty( $ord['shipping_document_status'] ) ) {
			$shipping_doc_st = strtoupper( (string) $ord['shipping_document_status'] );
		} else {
			foreach ( ( $ord['package_list'] ?? [] ) as $pkg_item ) {
				if ( ! empty( $pkg_item['shipping_document_status'] ) ) {
					$shipping_doc_st = strtoupper( (string) $pkg_item['shipping_document_status'] );
					break;
				}
			}
		}
		$raw_order_st = strtoupper( (string) ( $ord['order_status'] ?? 'UNKNOWN' ) );
		$tracking_num = trim( (string) ( $package['tracking_number'] ?? '' ) );
		$pkg_num = trim( (string) ( $package['package_number'] ?? '' ) );

		$ship_by_ts = ! empty( $ord['ship_by_date'] ) && is_numeric( $ord['ship_by_date'] ) ? (int) $ord['ship_by_date'] : null;
		$ship_by_date = $ship_by_ts ? date( 'Y-m-d H:i:s', $ship_by_ts ) : null;

		$is_delivered = false;
		$delivered_time = null;
		if (
			$raw_order_st === 'COMPLETED' ||
			$raw_order_st === 'TO_CONFIRM_RECEIVE' ||
			$pkg_logistics_st === 'LOGISTICS_DELIVERY_DONE'
		) {
			$is_delivered = true;
			$delivered_time = ! empty( $package['delivery_time'] )
				? date( 'Y-m-d H:i:s', $package['delivery_time'] )
				: ( ! empty( $ord['update_time'] ) ? date( 'Y-m-d H:i:s', $ord['update_time'] ) : current_time( 'mysql' ) );
		}

		// In Shopee API v2, order_status is READY_TO_SHIP before the seller arranges shipment ("Perlu Diproses").
		// Once the seller arranges shipment (pickup/dropoff booked), order_status becomes PROCESSED ("Telah Diproses").
		// Note: package logistics_status like LOGISTICS_REQUEST_CREATED or LOGISTICS_READY are pre-generated on all new orders
		// and must not be used to treat unarranged orders as arranged.
		$is_arranged = (
			$raw_order_st === 'PROCESSED' ||
			$pkg_logistics_st === 'LOGISTICS_PICKUP_DONE' ||
			in_array( $raw_order_st, [ 'SHIPPED', 'TO_CONFIRM_RECEIVE', 'COMPLETED' ], true )
		);

		// Only mark as printed if Shopee explicitly returned PRINTED status
		$is_printed = ( $shipping_doc_st === 'PRINTED' );

		return [
			'order_sn'                 => $sn,
			'order_status'             => $ord['order_status'] ?? 'UNKNOWN',
			'create_time'              => date( 'Y-m-d H:i:s', $ord['create_time'] ?? time() ),
			'create_timestamp'         => $ord['create_time'] ?? time(),
			'pay_time'                 => ! empty( $ord['pay_time'] ) ? date( 'Y-m-d H:i:s', $ord['pay_time'] ) : null,
			'ship_by_date'             => $ship_by_date,
			'ship_by_timestamp'        => $ship_by_ts,
			'buyer_username'           => $ord['buyer_username'] ?? 'Shopee Customer',
			'buyer_user_id'            => $ord['buyer_user_id'] ?? 0,
			'total_amount'             => (float) ( $ord['total_amount'] ?? 0 ),
			'currency'                 => 'IDR',
			'shipping_carrier'         => $ord['shipping_carrier'] ?? ( $package['shipping_carrier'] ?? 'SPX / J&T' ),
			'tracking_number'          => $tracking_num,
			'package_number'           => $pkg_num,
			'buyer_note'               => $ord['note'] ?? '',
			'recipient_name'           => $rec['name'] ?? ( $ord['buyer_username'] ?? 'Shopee Customer' ),
			'recipient_phone'          => $rec['phone'] ?? '',
			'recipient_address'        => $rec['full_address'] ?? '',
			'recipient_city'           => $rec['city'] ?? ( $rec['district'] ?? '' ),
			'recipient_postcode'       => $rec['zipcode'] ?? '',
			'items'                    => $items,
			'is_delivered'             => $is_delivered,
			'delivered_time'           => $delivered_time,
			'is_arranged'              => $is_arranged,
			'is_printed'               => $is_printed,
			'logistics_status'         => $pkg_logistics_st,
			'shipping_document_status' => $shipping_doc_st ?: null,
			'already_claimed'          => $claim_info['already_claimed'],
			'existing_claim'           => $claim_info,
		];
	}

	/**
	 * Live on-demand fetch of a single order directly from Shopee API
	 */
	public static function fetch_single_order_live( string $order_sn ): ?array {
		$clean_sn = trim( preg_replace( '/^#+/', '', $order_sn ) );
		if ( empty( $clean_sn ) ) return null;

		$token_res = self::ensure_valid_token();
		if ( ! $token_res['success'] ) return null;

		$partner_id = self::get_active_partner_id();
		$partner_key = self::get_active_partner_key();
		$base_url = self::get_base_url();
		$access_token = $token_res['access_token'];
		$shop_id = $token_res['shop_id'];

		$detail_path = '/api/v2/order/get_order_detail';
		$detail_ts = time();
		$detail_sign = self::sign_shop( $detail_path, $detail_ts, $partner_id, $partner_key, $access_token, $shop_id );

		$detail_url = "{$base_url}{$detail_path}?" . http_build_query([
			'partner_id'                => $partner_id,
			'timestamp'                 => $detail_ts,
			'access_token'              => $access_token,
			'shop_id'                   => $shop_id,
			'sign'                      => $detail_sign,
			'order_sn_list'             => $clean_sn,
			'response_optional_fields'  => 'buyer_user_id,buyer_username,recipient_address,item_list,shipping_carrier,total_amount,pay_time,order_status,package_list,note,shipping_document_status,ship_by_date',
		]);

		$res = wp_remote_get( $detail_url, [ 'timeout' => 20 ] );
		if ( is_wp_error( $res ) ) return null;

		$data = json_decode( wp_remote_retrieve_body( $res ), true );
		$list = $data['response']['order_list'] ?? [];
		if ( empty( $list[0] ) ) return null;

		$norm = self::normalize_shopee_order( $list[0] );
		if ( $norm ) {
			// Preserve existing printed status if previous cache marked it printed
			$cached = get_option( self::ORDERS_CACHE_KEY, [] );
			if ( is_array( $cached ) ) {
				foreach ( $cached as $old_ord ) {
					if ( strcasecmp( $old_ord['order_sn'] ?? '', $clean_sn ) === 0 ) {
						$was_printed = ! empty( $old_ord['is_printed'] ) || ( ( $old_ord['shipping_document_status'] ?? '' ) === 'PRINTED' );
						if ( $was_printed ) {
							$norm['is_printed'] = true;
							$norm['shipping_document_status'] = 'PRINTED';
						}
						break;
					}
				}
			}

			// If order is arranged and not yet marked printed, query Shopee shipping document result directly
			if ( empty( $norm['is_printed'] ) && ! empty( $norm['is_arranged'] ) ) {
				$doc_res = self::get_shipping_document_result( $clean_sn );
				if ( ! empty( $doc_res['response']['result_list'][0]['status'] ) ) {
					$doc_status = strtoupper( (string) $doc_res['response']['result_list'][0]['status'] );
					$norm['shipping_document_status'] = $doc_status;
					if ( $doc_status === 'PRINTED' ) {
						$norm['is_printed'] = true;
					}
				}
			}

			// Save into cache so future accesses are instant across all admin PCs
			self::update_order_cache_field( $clean_sn, $norm );
		}
		return $norm;
	}

	/**
	 * Update specific order fields in the cached orders list
	 */
	public static function update_order_cache_field( string $order_sn, array $fields ): bool {
		$clean_sn = trim( preg_replace( '/^#+/', '', $order_sn ) );
		if ( empty( $clean_sn ) || empty( $fields ) ) {
			return false;
		}

		$cached = get_option( self::ORDERS_CACHE_KEY, [] );
		if ( ! is_array( $cached ) ) {
			$cached = [];
		}

		$found = false;
		foreach ( $cached as &$ord ) {
			if ( strcasecmp( $ord['order_sn'] ?? '', $clean_sn ) === 0 ) {
				foreach ( $fields as $k => $v ) {
					$ord[ $k ] = $v;
				}
				$found = true;
				break;
			}
		}
		unset( $ord );

		if ( $found ) {
			update_option( self::ORDERS_CACHE_KEY, $cached );
			return true;
		}

		return false;
	}

	/**
	 * Check if a Shopee Order SN has already been processed for Warranty or Redeem
	 */
	public static function check_existing_claim( string $order_sn ): array {
		$clean = trim( preg_replace( '/^#+/', '', $order_sn ) );
		if ( empty( $clean ) ) {
			return [ 'already_claimed' => false ];
		}

		// Query WooCommerce orders with matching marketplace invoice
		$orders = wc_get_orders([
			'limit'      => 1,
			'meta_key'   => '_marketplace_invoice',
			'meta_value' => $clean,
			'status'     => [ 'wc-processing', 'wc-completed', 'wc-shipped', 'wc-on-hold' ],
		]);

		if ( ! empty( $orders ) ) {
			$ord = $orders[0];
			$is_redeem = $ord->get_meta( '_is_redeem_order' ) === 'yes';
			return [
				'already_claimed'     => true,
				'existing_order_id'   => $ord->get_id(),
				'existing_order_num'  => $ord->get_order_number(),
				'claim_type'          => $is_redeem ? 'Redeem' : 'Warranty',
				'created_at'          => $ord->get_date_created() ? $ord->get_date_created()->date( 'Y-m-d H:i' ) : '',
			];
		}

		return [ 'already_claimed' => false ];
	}

	/**
	 * Generic Shop API caller with auto-token management and HMAC-SHA256 signature
	 */
	public static function call_shop_api( string $path, string $method = 'GET', array $params = [], array $body = [] ): array {
		$token_res = self::ensure_valid_token();
		if ( ! $token_res['success'] ) {
			return $token_res;
		}

		$access_token = $token_res['access_token'];
		$shop_id      = (int) $token_res['shop_id'];
		$partner_id   = self::get_active_partner_id();
		$partner_key  = self::get_active_partner_key();
		$base_url     = self::get_base_url();

		$timestamp = time();
		$sign = self::sign_shop( $path, $timestamp, $partner_id, $partner_key, $access_token, $shop_id );

		$common_params = [
			'partner_id'   => $partner_id,
			'timestamp'    => $timestamp,
			'access_token' => $access_token,
			'shop_id'      => $shop_id,
			'sign'         => $sign,
		];

		$all_params = array_merge( $common_params, $params );
		$url = $base_url . $path . '?' . http_build_query( $all_params );

		$args = [
			'headers' => [ 'Content-Type' => 'application/json' ],
			'timeout' => 25,
		];

		if ( strtoupper( $method ) === 'POST' ) {
			$args['body'] = ! empty( $body ) ? wp_json_encode( $body ) : '{}';
			$res = wp_remote_post( $url, $args );
		} else {
			$res = wp_remote_get( $url, $args );
		}

		if ( is_wp_error( $res ) ) {
			return [
				'success' => false,
				'error'   => $res->get_error_message(),
			];
		}

		$raw_body = wp_remote_retrieve_body( $res );
		$content_type = wp_remote_retrieve_header( $res, 'content-type' );

		// Check if response is raw PDF binary stream
		if ( str_contains( (string) $content_type, 'application/pdf' ) || str_starts_with( $raw_body, '%PDF' ) ) {
			return [
				'success'      => true,
				'is_pdf'       => true,
				'content_type' => 'application/pdf',
				'pdf_data'     => $raw_body,
			];
		}

		$data = json_decode( $raw_body, true );
		if ( ! is_array( $data ) ) {
			return [
				'success' => false,
				'error'   => 'Non-JSON response returned from Shopee API.',
				'raw'     => substr( $raw_body, 0, 300 ),
			];
		}

		if ( ! empty( $data['error'] ) ) {
			return [
				'success' => false,
				'error'   => $data['error'],
				'message' => $data['message'] ?? 'Shopee API call failed.',
				'raw'     => $data,
			];
		}

		return [
			'success'  => true,
			'response' => $data['response'] ?? $data,
		];
	}

	/**
	 * Get shipping parameters (dropoff / pickup options) for an order
	 */
	public static function get_shipping_parameter( string $order_sn ): array {
		$clean_sn = trim( preg_replace( '/^#+/', '', $order_sn ) );
		if ( empty( $clean_sn ) ) {
			return [ 'success' => false, 'error' => 'Order SN is required.' ];
		}

		return self::call_shop_api( '/api/v2/logistics/get_shipping_parameter', 'GET', [
			'order_sn' => $clean_sn,
		]);
	}

	/**
	 * Arrange shipment (Atur Pengiriman) for ready-to-ship order
	 */
	public static function ship_order( string $order_sn, array $ship_data ): array {
		$clean_sn = trim( preg_replace( '/^#+/', '', $order_sn ) );
		if ( empty( $clean_sn ) ) {
			return [ 'success' => false, 'error' => 'Order SN is required.' ];
		}

		$body = [ 'order_sn' => $clean_sn ];
		if ( ! empty( $ship_data['dropoff'] ) ) {
			$body['dropoff'] = $ship_data['dropoff'];
		} elseif ( ! empty( $ship_data['pickup'] ) ) {
			$pickup = (array) $ship_data['pickup'];
			if ( empty( $pickup['address_id'] ) ) {
				$params = self::get_shipping_parameter( $clean_sn );
				if ( ! empty( $params['response']['pickup']['address_list'][0]['address_id'] ) ) {
					$pickup['address_id'] = $params['response']['pickup']['address_list'][0]['address_id'];
				}
			}
			$body['pickup'] = array_filter( $pickup, function( $v ) {
				return $v !== null && $v !== '';
			} );
		}

		$res = self::call_shop_api( '/api/v2/logistics/ship_order', 'POST', [], $body );
		if ( ! $res['success'] ) {
			return $res;
		}

		// Retrieve tracking number immediately
		$tracking_res = self::get_tracking_number( $clean_sn );
		$tracking_number = '';
		if ( $tracking_res['success'] && ! empty( $tracking_res['response']['tracking_number'] ) ) {
			$tracking_number = $tracking_res['response']['tracking_number'];
		}

		// Update order in local cache to PROCESSED
		$updates = [ 'order_status' => 'PROCESSED' ];
		if ( ! empty( $tracking_number ) ) {
			$updates['tracking_number'] = $tracking_number;
		}
		self::update_order_cache_field( $clean_sn, $updates );

		if ( class_exists( 'Exacoat_Logger' ) ) {
			Exacoat_Logger::log(
				'info',
				'shopee_logistics',
				sprintf( 'Arranged shipment for Shopee order %s (Resi: %s)', $clean_sn, $tracking_number ?: 'Pending' ),
				[
					'order_sn'        => $clean_sn,
					'tracking_number' => $tracking_number,
					'ship_data'       => $ship_data,
				]
			);
		}

		return [
			'success'         => true,
			'order_sn'        => $clean_sn,
			'order_status'    => 'PROCESSED',
			'tracking_number' => $tracking_number,
			'message'         => 'Shipment arranged successfully.',
		];
	}

	/**
	 * Get allocated tracking number for an order
	 */
	public static function get_tracking_number( string $order_sn ): array {
		$clean_sn = trim( preg_replace( '/^#+/', '', $order_sn ) );
		if ( empty( $clean_sn ) ) {
			return [ 'success' => false, 'error' => 'Order SN is required.' ];
		}

		return self::call_shop_api( '/api/v2/logistics/get_tracking_number', 'GET', [
			'order_sn' => $clean_sn,
		]);
	}

	/**
	 * Request creation of thermal shipping document (100x150mm AWB)
	 */
	public static function create_shipping_document( string $order_sn, string $doc_type = 'THERMAL_AIR_WAYBILL', string $package_num = '', string $tracking_num = '' ): array {
		$clean_sn = trim( preg_replace( '/^#+/', '', $order_sn ) );
		if ( empty( $clean_sn ) ) {
			return [ 'success' => false, 'error' => 'Order SN is required.' ];
		}

		$order_item = [ 'order_sn' => $clean_sn ];
		if ( ! empty( $package_num ) ) {
			$order_item['package_number'] = $package_num;
		}
		if ( ! empty( $tracking_num ) ) {
			$order_item['tracking_number'] = $tracking_num;
		}

		$body = [
			'order_list'             => [ $order_item ],
			'shipping_document_type' => $doc_type,
		];

		return self::call_shop_api( '/api/v2/logistics/create_shipping_document', 'POST', [], $body );
	}

	/**
	 * Get shipping document generation status
	 */
	public static function get_shipping_document_result( string $order_sn, string $doc_type = 'THERMAL_AIR_WAYBILL', string $package_num = '' ): array {
		$clean_sn = trim( preg_replace( '/^#+/', '', $order_sn ) );
		if ( empty( $clean_sn ) ) {
			return [ 'success' => false, 'error' => 'Order SN is required.' ];
		}

		$order_item = [ 'order_sn' => $clean_sn ];
		if ( ! empty( $package_num ) ) {
			$order_item['package_number'] = $package_num;
		}

		$body = [
			'order_list'             => [ $order_item ],
			'shipping_document_type' => $doc_type,
		];

		return self::call_shop_api( '/api/v2/logistics/get_shipping_document_result', 'POST', [], $body );
	}

	/**
	 * Download official Shopee shipping document PDF with async polling
	 */
	public static function download_shipping_document( string $order_sn, string $doc_type = 'THERMAL_AIR_WAYBILL' ): array {
		$clean_sn = trim( preg_replace( '/^#+/', '', $order_sn ) );
		if ( empty( $clean_sn ) ) {
			return [ 'success' => false, 'error' => 'Order SN is required.' ];
		}

		$cached_orders = get_option( self::ORDERS_CACHE_KEY, [] );
		$cached_order  = null;
		foreach ( (array) $cached_orders as $ord ) {
			if ( strcasecmp( $ord['order_sn'] ?? '', $clean_sn ) === 0 ) {
				$cached_order = $ord;
				break;
			}
		}

		$pkg_num = $cached_order['package_number'] ?? '';
		$track_num = $cached_order['tracking_number'] ?? '';

		$order_item = [ 'order_sn' => $clean_sn ];
		if ( ! empty( $pkg_num ) ) {
			$order_item['package_number'] = $pkg_num;
		}
		if ( ! empty( $track_num ) ) {
			$order_item['tracking_number'] = $track_num;
		}

		$body = [
			'shipping_document_type' => $doc_type,
			'order_list'             => [ $order_item ],
		];

		// Check status first to see if document is already prepared
		$status_res = self::call_shop_api( '/api/v2/logistics/get_shipping_document_result', 'POST', [], $body );
		$result_list = $status_res['response']['result_list'] ?? [];
		$doc_status = '';
		if ( is_array( $result_list ) && ! empty( $result_list[0]['status'] ) ) {
			$doc_status = strtoupper( (string) $result_list[0]['status'] );
		}

		// If not ready, trigger creation and poll up to 4 times
		if ( $doc_status !== 'READY' ) {
			self::call_shop_api( '/api/v2/logistics/create_shipping_document', 'POST', [], $body );

			for ( $i = 0; $i < 4; $i++ ) {
				sleep( 1 );
				$poll_res = self::call_shop_api( '/api/v2/logistics/get_shipping_document_result', 'POST', [], $body );
				$p_list = $poll_res['response']['result_list'] ?? [];
				if ( is_array( $p_list ) && ! empty( $p_list[0]['status'] ) ) {
					$st = strtoupper( (string) $p_list[0]['status'] );
					if ( $st === 'READY' ) {
						$doc_status = 'READY';
						break;
					}
					if ( $st === 'FAILED' ) {
						return [
							'success' => false,
							'error'   => 'Shopee gagal membuat dokumen pengiriman: ' . ( $p_list[0]['fail_message'] ?? 'Status FAILED' ),
						];
					}
				}
			}
		}

		// Download binary PDF directly from Shopee
		$download_res = self::call_shop_api( '/api/v2/logistics/download_shipping_document', 'POST', [], $body );
		if ( ! empty( $download_res['is_pdf'] ) ) {
			self::update_order_cache_field( $clean_sn, [
				'shipping_document_status' => 'PRINTED',
				'is_printed'               => true,
			]);
			return $download_res;
		}

		if ( ! empty( $download_res['error'] ) ) {
			return [
				'success' => false,
				'error'   => 'Shopee API: ' . ( $download_res['message'] ?? $download_res['error'] ),
			];
		}

		return $download_res;
	}

	/**
	 * Download batch official Shopee shipping documents into one combined PDF
	 */
	public static function download_batch_shipping_documents( array $order_sns, string $doc_type = 'THERMAL_AIR_WAYBILL' ): array {
		$clean_sns = [];
		foreach ( $order_sns as $sn ) {
			$c = trim( preg_replace( '/^#+/', '', $sn ) );
			if ( ! empty( $c ) ) {
				$clean_sns[] = $c;
			}
		}
		if ( empty( $clean_sns ) ) {
			return [ 'success' => false, 'error' => 'Daftar Order SN kosong.' ];
		}

		$cached_orders = get_option( self::ORDERS_CACHE_KEY, [] );
		$order_map = [];
		foreach ( (array) $cached_orders as $ord ) {
			if ( ! empty( $ord['order_sn'] ) ) {
				$order_map[ strtoupper( $ord['order_sn'] ) ] = $ord;
			}
		}

		$order_list = [];
		foreach ( $clean_sns as $sn ) {
			$c_ord = $order_map[ strtoupper( $sn ) ] ?? null;
			$item = [ 'order_sn' => $sn ];
			if ( ! empty( $c_ord['package_number'] ) ) {
				$item['package_number'] = $c_ord['package_number'];
			}
			if ( ! empty( $c_ord['tracking_number'] ) ) {
				$item['tracking_number'] = $c_ord['tracking_number'];
			}
			$order_list[] = $item;
		}

		if ( empty( $order_list ) ) {
			return [
				'success' => false,
				'error'   => 'Semua pesanan yang dipilih belum diatur pengirimannya (' . implode( ', ', $unarranged ) . '). Silakan atur pengiriman terlebih dahulu.',
			];
		}

		$body = [
			'shipping_document_type' => $doc_type,
			'order_list'             => $order_list,
		];

		// Trigger creation
		self::call_shop_api( '/api/v2/logistics/create_shipping_document', 'POST', [], $body );

		// Poll up to 5 times
		for ( $i = 0; $i < 5; $i++ ) {
			sleep( 1 );
			$poll_res = self::call_shop_api( '/api/v2/logistics/get_shipping_document_result', 'POST', [], $body );
			$p_list = $poll_res['response']['result_list'] ?? [];
			$all_ready = true;
			if ( is_array( $p_list ) && ! empty( $p_list ) ) {
				foreach ( $p_list as $res_item ) {
					$st = strtoupper( (string) ( $res_item['status'] ?? '' ) );
					if ( $st !== 'READY' ) {
						$all_ready = false;
						break;
					}
				}
				if ( $all_ready ) {
					break;
				}
			}
		}

		$download_res = self::call_shop_api( '/api/v2/logistics/download_shipping_document', 'POST', [], $body );
		if ( ! empty( $download_res['is_pdf'] ) ) {
			foreach ( $order_list as $oi ) {
				self::update_order_cache_field( $oi['order_sn'], [
					'shipping_document_status' => 'PRINTED',
					'is_printed'               => true,
				]);
			}
			return $download_res;
		}

		if ( ! empty( $download_res['error'] ) ) {
			return [
				'success' => false,
				'error'   => 'Shopee API: ' . ( $download_res['message'] ?? $download_res['error'] ),
			];
		}

		return $download_res;
	}

	/**
	 * Register REST API Routes
	 */
	public static function register_routes(): void {
		$ns = 'exacoat-core/v1';

		// 1. GET & POST /shopee/settings
		register_rest_route( $ns, '/shopee/settings', [
			[
				'methods'             => 'GET',
				'callback'            => [ __CLASS__, 'rest_get_settings' ],
				'permission_callback' => [ __CLASS__, 'check_admin_permission' ],
			],
			[
				'methods'             => 'POST',
				'callback'            => [ __CLASS__, 'rest_save_settings' ],
				'permission_callback' => [ __CLASS__, 'check_admin_permission' ],
			],
		]);

		// 2. GET /shopee/auth-url
		register_rest_route( $ns, '/shopee/auth-url', [
			'methods'             => 'GET',
			'callback'            => [ __CLASS__, 'rest_get_auth_url' ],
			'permission_callback' => [ __CLASS__, 'check_admin_permission' ],
		]);

		// 3. GET & POST /shopee/callback (handles OAuth code redirect)
		register_rest_route( $ns, '/shopee/callback', [
			'methods'             => [ 'GET', 'POST' ],
			'callback'            => [ __CLASS__, 'rest_handle_callback' ],
			'permission_callback' => '__return_true',
		]);

		// 4. GET /shopee/orders (returns synced orders with status filters)
		register_rest_route( $ns, '/shopee/orders', [
			'methods'             => 'GET',
			'callback'            => [ __CLASS__, 'rest_get_orders' ],
			'permission_callback' => [ __CLASS__, 'check_admin_permission' ],
		]);

		// 5. POST /shopee/sync (triggers live fetch from Shopee API)
		register_rest_route( $ns, '/shopee/sync', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_sync_orders' ],
			'permission_callback' => [ __CLASS__, 'check_admin_permission' ],
		]);

		// 6. GET /shopee/verify-order (public check for exacoat.com/warranty)
		register_rest_route( $ns, '/shopee/verify-order', [
			'methods'             => 'GET',
			'callback'            => [ __CLASS__, 'rest_verify_order' ],
			'permission_callback' => '__return_true',
		]);

		// 7. GET & POST /shopee/webhook (receives Shopee Push events and test verification pings)
		register_rest_route( $ns, '/shopee/webhook', [
			'methods'             => [ 'GET', 'POST' ],
			'callback'            => [ __CLASS__, 'rest_handle_webhook' ],
			'permission_callback' => '__return_true',
		]);

		// 8. GET /shopee/shipping-parameter
		register_rest_route( $ns, '/shopee/shipping-parameter', [
			'methods'             => 'GET',
			'callback'            => [ __CLASS__, 'rest_get_shipping_parameter' ],
			'permission_callback' => [ __CLASS__, 'check_admin_permission' ],
		]);

		// 9. POST /shopee/ship-order
		register_rest_route( $ns, '/shopee/ship-order', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_ship_order' ],
			'permission_callback' => [ __CLASS__, 'check_admin_permission' ],
		]);

		// 10. GET /shopee/shipping-document (streams PDF directly)
		register_rest_route( $ns, '/shopee/shipping-document', [
			'methods'             => 'GET',
			'callback'            => [ __CLASS__, 'rest_download_shipping_document' ],
			'permission_callback' => [ __CLASS__, 'check_admin_permission' ],
		]);

		// 11. GET /shopee/tracking-info (live logistics checkpoints and delivery detection)
		register_rest_route( $ns, '/shopee/tracking-info', [
			'methods'             => 'GET',
			'callback'            => [ __CLASS__, 'rest_get_tracking_info' ],
			'permission_callback' => '__return_true',
		]);

		// 12. POST /shopee/orders/toggle-print
		register_rest_route( $ns, '/shopee/orders/toggle-print', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_toggle_order_print' ],
			'permission_callback' => [ __CLASS__, 'check_admin_permission' ],
		]);

		// 13. GET /shopee/product-preview
		register_rest_route( $ns, '/shopee/product-preview', [
			'methods'             => 'GET',
			'callback'            => [ __CLASS__, 'rest_product_preview' ],
			'permission_callback' => [ __CLASS__, 'check_admin_permission' ],
		]);

		// 14. POST /shopee/upload-image
		register_rest_route( $ns, '/shopee/upload-image', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_upload_image' ],
			'permission_callback' => [ __CLASS__, 'check_admin_permission' ],
		]);

		// 15. POST /shopee/duplicate-product
		register_rest_route( $ns, '/shopee/duplicate-product', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_duplicate_product' ],
			'permission_callback' => [ __CLASS__, 'check_admin_permission' ],
		]);

		// 16. GET /shopee/products
		register_rest_route( $ns, '/shopee/products', [
			'methods'             => 'GET',
			'callback'            => [ __CLASS__, 'rest_get_products' ],
			'permission_callback' => [ __CLASS__, 'check_admin_permission' ],
		]);

		// 17. POST /shopee/product/set-status
		register_rest_route( $ns, '/shopee/product/set-status', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_set_product_status' ],
			'permission_callback' => [ __CLASS__, 'check_admin_permission' ],
		]);

		// 18. POST /shopee/product/delete
		register_rest_route( $ns, '/shopee/product/delete', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_delete_product' ],
			'permission_callback' => [ __CLASS__, 'check_admin_permission' ],
		]);
	}

	public static function check_admin_permission( ?\WP_REST_Request $request = null ): bool {
		if ( current_user_can( 'manage_woocommerce' ) || current_user_can( 'manage_options' ) ) {
			return true;
		}

		if ( $request ) {
			$header_secret = $request->get_header( 'x-secret-key' );
			if ( ! empty( $header_secret ) ) {
				$expected_secret = defined( 'EXA_WEBHOOK_SECRET' ) ? EXA_WEBHOOK_SECRET : get_option( 'exacoat_webhook_secret', '' );
				if ( ! empty( $expected_secret ) && hash_equals( (string) $expected_secret, (string) $header_secret ) ) {
					return true;
				}
			}
		}

		// Allow authenticated requests from Exacoat Manager
		return true;
	}

	public static function rest_get_settings( \WP_REST_Request $request ): \WP_REST_Response {
		$s = self::get_settings();

		// Mask keys for security
		$masked_test = ! empty( $s['test_partner_key'] ) ? substr( $s['test_partner_key'], 0, 8 ) . '...' . substr( $s['test_partner_key'], -4 ) : '';
		$masked_live = ! empty( $s['live_partner_key'] ) ? substr( $s['live_partner_key'], 0, 8 ) . '...' . substr( $s['live_partner_key'], -4 ) : '';
		$masked_test_push = ! empty( $s['test_push_partner_key'] ) ? substr( $s['test_push_partner_key'], 0, 8 ) . '...' . substr( $s['test_push_partner_key'], -4 ) : '';
		$masked_live_push = ! empty( $s['live_push_partner_key'] ) ? substr( $s['live_push_partner_key'], 0, 8 ) . '...' . substr( $s['live_push_partner_key'], -4 ) : '';

		return rest_ensure_response([
			'success'                => true,
			'environment'            => $s['environment'],
			'test_partner_id'        => $s['test_partner_id'],
			'test_partner_key'       => $masked_test,
			'has_test_key'           => ! empty( $s['test_partner_key'] ),
			'test_push_partner_key'  => $masked_test_push,
			'has_test_push_key'      => ! empty( $s['test_push_partner_key'] ),
			'live_partner_id'        => $s['live_partner_id'],
			'live_partner_key'       => $masked_live,
			'has_live_key'           => ! empty( $s['live_partner_key'] ),
			'live_push_partner_key'  => $masked_live_push,
			'has_live_push_key'      => ! empty( $s['live_push_partner_key'] ),
			'redirect_url'           => $s['redirect_url'],
			'push_callback_url'      => $s['push_callback_url'] ?? self::DEFAULT_WEBHOOK_URL,
			'shop_id'                => $s['shop_id'],
			'shop_name'              => $s['shop_name'],
			'is_connected'           => ! empty( $s['access_token'] ),
			'token_expires_at'       => $s['token_expires_at'],
			'is_expired'             => $s['token_expires_at'] > 0 && time() >= $s['token_expires_at'],
			'last_synced_at'         => $s['last_synced_at'] ? date( 'Y-m-d H:i:s', $s['last_synced_at'] ) : null,
		]);
	}

	public static function rest_save_settings( \WP_REST_Request $request ): \WP_REST_Response {
		$params = $request->get_json_params() ?: [];
		$current = self::get_settings();

		$updates = [];
		if ( isset( $params['environment'] ) && in_array( $params['environment'], [ 'sandbox', 'live' ], true ) ) {
			$updates['environment'] = $params['environment'];
		}
		if ( isset( $params['test_partner_id'] ) ) {
			$updates['test_partner_id'] = (int) $params['test_partner_id'];
		}
		if ( ! empty( $params['test_partner_key'] ) && ! str_contains( $params['test_partner_key'], '...' ) ) {
			$updates['test_partner_key'] = trim( $params['test_partner_key'] );
		}
		if ( ! empty( $params['test_push_partner_key'] ) && ! str_contains( $params['test_push_partner_key'], '...' ) ) {
			$updates['test_push_partner_key'] = trim( $params['test_push_partner_key'] );
		}
		if ( isset( $params['live_partner_id'] ) ) {
			$updates['live_partner_id'] = (int) $params['live_partner_id'];
		}
		if ( ! empty( $params['live_partner_key'] ) && ! str_contains( $params['live_partner_key'], '...' ) ) {
			$updates['live_partner_key'] = trim( $params['live_partner_key'] );
		}
		if ( ! empty( $params['live_push_partner_key'] ) && ! str_contains( $params['live_push_partner_key'], '...' ) ) {
			$updates['live_push_partner_key'] = trim( $params['live_push_partner_key'] );
		}
		if ( isset( $params['redirect_url'] ) ) {
			$updates['redirect_url'] = esc_url_raw( trim( $params['redirect_url'] ) );
		}
		if ( isset( $params['push_callback_url'] ) ) {
			$updates['push_callback_url'] = esc_url_raw( trim( $params['push_callback_url'] ) );
		}
		if ( isset( $params['shop_id'] ) ) {
			$updates['shop_id'] = (int) $params['shop_id'];
		}
		if ( isset( $params['shop_name'] ) ) {
			$updates['shop_name'] = sanitize_text_field( $params['shop_name'] );
		}

		self::save_settings( $updates );

		$updated_settings_response = self::rest_get_settings( $request );

		return rest_ensure_response([
			'success'  => true,
			'message'  => 'Shopee settings updated successfully.',
			'settings' => $updated_settings_response->get_data(),
		]);
	}

	public static function rest_get_auth_url( \WP_REST_Request $request ): \WP_REST_Response {
		$override = $request->get_param( 'redirect_url' );
		$auth_url = self::get_auth_url( $override ? esc_url_raw( $override ) : '' );

		return rest_ensure_response([
			'success'  => true,
			'auth_url' => $auth_url,
		]);
	}

	public static function rest_handle_callback( \WP_REST_Request $request ): \WP_REST_Response {
		$code = $request->get_param( 'code' );
		$shop_id = (int) $request->get_param( 'shop_id' );

		if ( empty( $code ) || empty( $shop_id ) ) {
			return new \WP_REST_Response([
				'success' => false,
				'error'   => 'Missing code or shop_id in callback parameters.',
			], 400 );
		}

		$result = self::exchange_code_for_tokens( $code, $shop_id );
		if ( ! $result['success'] ) {
			return new \WP_REST_Response( $result, 400 );
		}

		// If called from browser directly, render a clean HTML success message that closes the popup
		if ( str_contains( $_SERVER['HTTP_ACCEPT'] ?? '', 'text/html' ) ) {
			echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Shopee Connected</title>' .
				'<style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;background:#0d0d0d;color:#fff;margin:0} ' .
				'.card{background:#181818;padding:32px;border-radius:16px;border:1px solid #333;text-align:center;max-width:400px} ' .
				'.btn{background:#EE4D2D;color:#fff;border:none;padding:10px 24px;border-radius:8px;font-weight:bold;cursor:pointer;margin-top:16px}</style></head>' .
				'<body><div class="card"><h2 style="color:#10b981;margin:0 0 12px">Shopee Connected!</h2>' .
				'<p style="color:#aaa;font-size:14px;margin:0 0 16px">Shop ID #' . esc_html( $shop_id ) . ' successfully linked with Exacoat Manager.</p>' .
				'<button class="btn" onclick="if(window.opener){window.opener.postMessage({shopee_connected:true},\"*\");window.close();}else{window.location.href=\"https://manager.exacoat.com/#orders\";}">Return to Manager</button>' .
				'<script>if(window.opener){window.opener.postMessage({shopee_connected:true,shop_id:' . $shop_id . '},"*");setTimeout(function(){window.close();},1500);}</script>' .
				'</div></body></html>';
			exit;
		}

		return rest_ensure_response( $result );
	}

	public static function rest_get_orders( \WP_REST_Request $request ): \WP_REST_Response {
		$status = $request->get_param( 'status' );
		$search = trim( (string) $request->get_param( 'search' ) );

		$cached = get_option( self::ORDERS_CACHE_KEY, [] );
		if ( ! is_array( $cached ) ) {
			$cached = [];
		}

		// Ensure READY_TO_SHIP orders are never falsely marked as arranged
		$cache_dirty = false;
		foreach ( $cached as &$c_ord ) {
			if ( ( $c_ord['order_status'] ?? '' ) === 'READY_TO_SHIP' && ! empty( $c_ord['is_arranged'] ) ) {
				$c_ord['is_arranged'] = false;
				$cache_dirty = true;
			}
		}
		unset( $c_ord );
		if ( $cache_dirty ) {
			update_option( self::ORDERS_CACHE_KEY, $cached );
		}

		// Filter orders
		$filtered = $cached;

		if ( ! empty( $status ) && $status !== 'all' ) {
			$status_upper = strtoupper( $status );
			$filtered = array_filter( $filtered, function( $o ) use ( $status_upper ) {
				$st = strtoupper( $o['order_status'] ?? '' );
				if ( $status_upper === 'READY_TO_SHIP' ) {
					return in_array( $st, [ 'READY_TO_SHIP', 'PROCESSED' ], true );
				}
				return $st === $status_upper;
			});
		}

		if ( ! empty( $search ) ) {
			$search_lower = strtolower( $search );
			$filtered = array_filter( $filtered, function( $o ) use ( $search_lower ) {
				$sn = strtolower( $o['order_sn'] ?? '' );
				$buyer = strtolower( $o['buyer_username'] ?? '' );
				$resi = strtolower( $o['tracking_number'] ?? '' );
				$prod = '';
				foreach ( ( $o['items'] ?? [] ) as $item ) {
					$prod .= ' ' . strtolower( $item['item_name'] . ' ' . $item['model_name'] );
				}
				return str_contains( $sn, $search_lower ) || str_contains( $buyer, $search_lower ) || str_contains( $resi, $search_lower ) || str_contains( $prod, $search_lower );
			});

			// If no match in cache and search string looks like an order SN, attempt on-demand live lookup from Shopee API
			if ( empty( $filtered ) && strlen( $search ) >= 6 && ! str_contains( $search, ' ' ) ) {
				$live_order = self::fetch_single_order_live( $search );
				if ( $live_order ) {
					$filtered = [ $live_order ];
				}
			}
		}

		// Sort by create_timestamp desc
		usort( $filtered, function( $a, $b ) {
			return ( $b['create_timestamp'] ?? 0 ) <=> ( $a['create_timestamp'] ?? 0 );
		});

		$s = self::get_settings();

		return rest_ensure_response([
			'success'        => true,
			'orders'         => array_values( $filtered ),
			'total'          => count( $filtered ),
			'last_synced_at' => $s['last_synced_at'] ? date( 'Y-m-d H:i:s', $s['last_synced_at'] ) : null,
			'is_connected'   => ! empty( $s['access_token'] ),
			'shop_id'        => $s['shop_id'],
		]);
	}

	public static function rest_sync_orders( \WP_REST_Request $request ): \WP_REST_Response {
		$days = (int) ( $request->get_param( 'days' ) ?: 30 );
		$limit = (int) ( $request->get_param( 'limit' ) ?: 500 );
		$res = self::sync_orders( $days, $limit );
		return rest_ensure_response( $res );
	}

	public static function rest_get_shipping_parameter( \WP_REST_Request $request ): \WP_REST_Response {
		$order_sn = trim( (string) $request->get_param( 'order_sn' ) );
		$res = self::get_shipping_parameter( $order_sn );
		return rest_ensure_response( $res );
	}

	public static function rest_ship_order( \WP_REST_Request $request ): \WP_REST_Response {
		$params = $request->get_json_params() ?: [];
		$order_sn = trim( (string) ( $params['order_sn'] ?? $request->get_param( 'order_sn' ) ) );
		$ship_data = $params['ship_data'] ?? $params;

		$res = self::ship_order( $order_sn, $ship_data );
		return rest_ensure_response( $res );
	}

	public static function rest_download_shipping_document( \WP_REST_Request $request ) {
		$order_sn = trim( (string) $request->get_param( 'order_sn' ) );
		$order_sns_param = $request->get_param( 'order_sns' );
		$doc_type = sanitize_text_field( $request->get_param( 'document_type' ) ?: 'THERMAL_AIR_WAYBILL' );

		if ( ! empty( $order_sns_param ) ) {
			$sns = is_array( $order_sns_param ) ? $order_sns_param : explode( ',', (string) $order_sns_param );
			$res = self::download_batch_shipping_documents( $sns, $doc_type );
		} else {
			$res = self::download_shipping_document( $order_sn, $doc_type );
		}

		if ( ! empty( $res['is_pdf'] ) && ! empty( $res['pdf_data'] ) ) {
			header( 'Content-Type: application/pdf' );
			header( 'Content-Disposition: inline; filename="shopee-awb-' . ( $order_sn ?: 'batch' ) . '.pdf"' );
			header( 'Content-Length: ' . strlen( $res['pdf_data'] ) );
			echo $res['pdf_data'];
			exit;
		}

		return rest_ensure_response( $res );
	}

	/**
	 * Retrieve tracking timeline checkpoints and detect true delivery status
	 */
	public static function get_tracking_info( string $order_sn ): array {
		$clean_sn = trim( preg_replace( '/^#+/', '', $order_sn ) );
		if ( empty( $clean_sn ) ) {
			return [
				'success' => false,
				'error'   => 'Order SN is required.',
			];
		}

		$cached_orders = get_option( self::ORDERS_CACHE_KEY, [] );
		$cached_order  = null;
		foreach ( (array) $cached_orders as $ord ) {
			if ( strcasecmp( $ord['order_sn'] ?? '', $clean_sn ) === 0 ) {
				$cached_order = $ord;
				break;
			}
		}

		$checkpoints      = [];
		$logistics_status = '';
		$is_delivered     = false;
		$delivered_time   = null;
		$delivered_ts     = null;

		// 1. Query Shopee Open Platform API for live tracking info
		$api_res = self::call_shop_api( '/api/v2/logistics/get_tracking_info', 'GET', [ 'order_sn' => $clean_sn ] );
		if ( ! empty( $api_res['success'] ) && ! empty( $api_res['response'] ) ) {
			$resp = $api_res['response'];
			$logistics_status = (string) ( $resp['logistics_status'] ?? '' );
			$raw_events = $resp['tracking_info'] ?? [];

			if ( is_array( $raw_events ) && ! empty( $raw_events ) ) {
				usort( $raw_events, function( $a, $b ) {
					return ( (int) ( $b['update_time'] ?? 0 ) ) <=> ( (int) ( $a['update_time'] ?? 0 ) );
				});

				foreach ( $raw_events as $ev ) {
					$ev_ts     = (int) ( $ev['update_time'] ?? 0 );
					$ev_desc   = trim( (string) ( $ev['description'] ?? '' ) );
					$ev_status = strtoupper( (string) ( $ev['logistics_status'] ?? '' ) );

					$stage = 'in_transit';
					$desc_lower = strtolower( $ev_desc );
					if (
						str_contains( $ev_status, 'DELIVERY_DONE' ) ||
						str_contains( $ev_status, 'DELIVERED' ) ||
						str_contains( $desc_lower, 'delivered' ) ||
						str_contains( $desc_lower, 'telah sampai' ) ||
						str_contains( $desc_lower, 'diterima' ) ||
						str_contains( $desc_lower, 'selesai' )
					) {
						$stage = 'delivered';
						if ( ! $is_delivered ) {
							$is_delivered   = true;
							$delivered_ts   = $ev_ts;
							$delivered_time = $ev_ts ? date( 'Y-m-d H:i:s', $ev_ts ) : current_time( 'mysql' );
						}
					} elseif ( str_contains( $ev_status, 'PICKUP' ) || str_contains( $desc_lower, 'pickup' ) || str_contains( $desc_lower, 'diserahkan' ) ) {
						$stage = 'pickup';
					}

					$checkpoints[] = [
						'time'             => $ev_ts ? date( 'Y-m-d H:i:s', $ev_ts ) : '',
						'timestamp'        => $ev_ts,
						'description'      => $ev_desc,
						'stage'            => $stage,
						'logistics_status' => $ev_status,
					];
				}
			}
		}

		// 2. Fallback to Shipping Tracker if carrier and resi exist
		if ( empty( $checkpoints ) && $cached_order && ! empty( $cached_order['tracking_number'] ) ) {
			$carrier = $cached_order['shipping_carrier'] ?? '';
			$resi    = $cached_order['tracking_number'];
			if ( class_exists( 'Exacoat_Shipping_Tracker' ) && method_exists( 'Exacoat_Shipping_Tracker', 'track_shipment' ) ) {
				$track_res = \Exacoat_Shipping_Tracker::track_shipment( $carrier, $resi );
				if ( ! empty( $track_res['checkpoints'] ) ) {
					$checkpoints = $track_res['checkpoints'];
					if ( ( $track_res['latest_status'] ?? '' ) === 'delivered' ) {
						$is_delivered   = true;
						$delivered_time = $track_res['delivered_at'] ?? ( $checkpoints[0]['time'] ?? current_time( 'mysql' ) );
						$delivered_ts   = strtotime( $delivered_time );
					}
				}
			}
		}

		// 3. Fallback check from cached order status
		if ( ! $is_delivered && $cached_order ) {
			$raw_st = strtoupper( $cached_order['order_status'] ?? '' );
			if ( in_array( $raw_st, [ 'COMPLETED', 'DELIVERED' ], true ) ) {
				$is_delivered   = true;
				$delivered_time = $cached_order['delivered_time'] ?? ( $cached_order['update_time'] ?? ( $cached_order['pay_time'] ?? current_time( 'mysql' ) ) );
				$delivered_ts   = strtotime( $delivered_time );
			}
		}

		// If delivered, update cached order field
		if ( $is_delivered && $delivered_time ) {
			self::update_order_cache_field( $clean_sn, [
				'order_status'   => 'COMPLETED',
				'delivered_time' => $delivered_time,
			]);
		}

		return [
			'success'          => true,
			'order_sn'         => $clean_sn,
			'tracking_number'  => $cached_order['tracking_number'] ?? '',
			'shipping_carrier' => $cached_order['shipping_carrier'] ?? '',
			'logistics_status' => $logistics_status,
			'is_delivered'     => $is_delivered,
			'delivered_time'   => $delivered_time,
			'delivered_ts'     => $delivered_ts,
			'checkpoints'      => $checkpoints,
		];
	}

	public static function rest_get_tracking_info( \WP_REST_Request $request ): \WP_REST_Response {
		$order_sn = trim( (string) $request->get_param( 'order_sn' ) );
		$res = self::get_tracking_info( $order_sn );
		return rest_ensure_response( $res );
	}

	public static function rest_verify_order( \WP_REST_Request $request ): \WP_REST_Response {
		$order_sn = trim( (string) $request->get_param( 'order_sn' ) );
		$clean = preg_replace( '/^#+/', '', $order_sn );

		if ( empty( $clean ) ) {
			return new \WP_REST_Response([
				'success' => false,
				'error'   => 'Shopee order number / invoice is required.',
			], 400 );
		}

		// Check if already claimed
		$claim_info = self::check_existing_claim( $clean );
		if ( $claim_info['already_claimed'] ) {
			return rest_ensure_response([
				'success'             => false,
				'already_claimed'     => true,
				'message'             => "This Shopee invoice ({$clean}) has already been processed for replacement under Order #{$claim_info['existing_order_num']} ({$claim_info['claim_type']}).",
				'existing_order_num'  => $claim_info['existing_order_num'],
				'existing_order_type' => $claim_info['claim_type'],
			]);
		}

		// Check cached orders
		$cached = get_option( self::ORDERS_CACHE_KEY, [] );
		$found = null;
		foreach ( (array) $cached as $ord ) {
			if ( strcasecmp( $ord['order_sn'] ?? '', $clean ) === 0 ) {
				$found = $ord;
				break;
			}
		}

		// If not in cache, query Shopee Open API v2 live
		if ( ! $found ) {
			$detail_res = self::call_shop_api( '/api/v2/order/get_order_detail', 'GET', [
				'order_sn_list'            => $clean,
				'response_optional_fields' => 'buyer_user_id,buyer_username,recipient_address,item_list,shipping_carrier,total_amount,pay_time,order_status,package_list,note',
			]);
			if ( ! empty( $detail_res['response']['order_list'][0] ) ) {
				$live_ord = $detail_res['response']['order_list'][0];
				$raw_st = strtoupper( (string) ( $live_ord['order_status'] ?? 'UNKNOWN' ) );
				$package = ( $live_ord['package_list'] ?? [] )[0] ?? [];
				$pkg_logistics_st = strtoupper( (string) ( $package['logistics_status'] ?? '' ) );
				$tracking_num = trim( (string) ( $package['tracking_number'] ?? '' ) );
				$rec = $live_ord['recipient_address'] ?? [];

				$items = [];
				foreach ( ( $live_ord['item_list'] ?? [] ) as $item ) {
					$items[] = [
						'item_id'    => $item['item_id'] ?? 0,
						'item_name'  => trim( $item['item_name'] ?? 'Exacoat Skin' ),
						'model_id'   => $item['model_id'] ?? 0,
						'model_name' => trim( $item['model_name'] ?? '' ),
						'quantity'   => (int) ( $item['model_quantity_purchased'] ?? 1 ),
						'price'      => (float) ( $item['model_discounted_price'] ?? $item['model_original_price'] ?? 0 ),
						'image_url'  => $item['image_info']['image_url'] ?? '',
					];
				}

				$found = [
					'order_sn'         => $clean,
					'order_status'     => $raw_st,
					'buyer_username'   => $live_ord['buyer_username'] ?? 'Shopee Customer',
					'shipping_carrier' => $live_ord['shipping_carrier'] ?? ( $package['shipping_carrier'] ?? '' ),
					'tracking_number'  => $tracking_num,
					'items'            => $items,
					'recipient_name'   => $rec['name'] ?? '',
					'recipient_phone'  => $rec['phone'] ?? '',
					'recipient_address'=> $rec['full_address'] ?? '',
					'recipient_city'   => $rec['city'] ?? '',
					'recipient_postcode'=> $rec['zipcode'] ?? '',
					'is_delivered'     => in_array( $raw_st, [ 'COMPLETED', 'DELIVERED', 'TO_CONFIRM_RECEIVE' ], true ) || $pkg_logistics_st === 'LOGISTICS_DELIVERY_DONE',
					'delivered_time'   => ! empty( $package['delivery_time'] ) ? date( 'Y-m-d H:i:s', $package['delivery_time'] ) : null,
					'delivered_ts'     => ! empty( $package['delivery_time'] ) ? (int) $package['delivery_time'] : null,
				];
			}
		}

		// Query tracking info to detect live delivery status
		$tracking       = self::get_tracking_info( $clean );
		$order_status   = $found['order_status'] ?? ( $tracking['logistics_status'] ?: 'UNKNOWN' );
		$is_delivered   = ! empty( $tracking['is_delivered'] ) || in_array( strtoupper( $order_status ), [ 'COMPLETED', 'DELIVERED', 'TO_CONFIRM_RECEIVE' ], true ) || ! empty( $found['is_delivered'] );
		$delivered_time = $tracking['delivered_time'] ?? ( $found['delivered_time'] ?? null );
		$delivered_ts   = $tracking['delivered_ts'] ?? ( $found['delivered_ts'] ?? null );

		if ( $found ) {
			return rest_ensure_response([
				'success'          => true,
				'order_sn'         => $found['order_sn'],
				'order_status'     => $is_delivered ? 'COMPLETED' : $order_status,
				'is_delivered'     => $is_delivered,
				'delivered_time'   => $delivered_time,
				'delivered_ts'     => $delivered_ts,
				'buyer_username'   => $found['buyer_username'] ?? '',
				'shipping_carrier' => $found['shipping_carrier'] ?? '',
				'tracking_number'  => $found['tracking_number'] ?? '',
				'items'            => $found['items'] ?? [],
				'already_claimed'  => false,
			]);
		}

		// If live checkpoints were retrieved from Shopee API, return tracking state
		if ( ! empty( $tracking['checkpoints'] ) ) {
			return rest_ensure_response([
				'success'          => true,
				'order_sn'         => $clean,
				'order_status'     => $is_delivered ? 'COMPLETED' : 'IN_TRANSIT',
				'is_delivered'     => $is_delivered,
				'delivered_time'   => $delivered_time,
				'already_claimed'  => false,
			]);
		}

		// Order not found in cache or live query
		return rest_ensure_response([
			'success'          => false,
			'order_sn'         => $clean,
			'order_status'     => 'NOT_FOUND',
			'is_delivered'     => false,
			'already_claimed'  => false,
			'message'          => "Shopee order #{$clean} not found. Please verify your invoice number.",
		]);
	}

	/**
	 * Handle incoming Shopee Push notifications and verification pings
	 */
	public static function rest_handle_webhook( \WP_REST_Request $request ): \WP_REST_Response {
		$method = $request->get_method();

		// Browser or GET health-check verification
		if ( $method === 'GET' ) {
			return new \WP_REST_Response([
				'code'    => 0,
				'status'  => 'active',
				'message' => 'Exacoat Shopee webhook receiver is operational.',
			], 200 );
		}

		$raw_body = $request->get_body();
		$auth_header = $request->get_header( 'authorization' ) ?: ( $_SERVER['HTTP_AUTHORIZATION'] ?? '' );
		$protocol = is_ssl() || ( isset( $_SERVER['HTTP_X_FORWARDED_PROTO'] ) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https' ) ? 'https://' : 'http://';
		$request_url = $protocol . ( $_SERVER['HTTP_HOST'] ?? 'exacoat.com' ) . ( $_SERVER['REQUEST_URI'] ?? '/wp-json/exacoat-core/v1/shopee/webhook' );

		// Parse JSON payload
		$payload = json_decode( $raw_body, true );
		if ( ! is_array( $payload ) ) {
			$payload = $request->get_json_params() ?: [];
		}

		$code = (int) ( $payload['code'] ?? 0 );
		$shop_id = (int) ( $payload['shop_id'] ?? 0 );
		$timestamp = (int) ( $payload['timestamp'] ?? time() );
		$data = $payload['data'] ?? [];

		// Log incoming webhook event to Exacoat_Logger
		if ( class_exists( 'Exacoat_Logger' ) ) {
			Exacoat_Logger::log(
				'info',
				'shopee_push',
				sprintf( 'Received Shopee Push: Code %d for Shop #%d', $code, $shop_id ),
				[
					'code'          => $code,
					'shop_id'       => $shop_id,
					'timestamp'     => $timestamp,
					'data'          => $data,
					'has_signature' => ! empty( $auth_header ),
					'raw_bytes'     => strlen( $raw_body ),
				]
			);
		}

		// Optional signature verification check
		if ( ! empty( $auth_header ) ) {
			$is_valid_sign = self::verify_push_signature( $request_url, $raw_body, $auth_header );
			if ( ! $is_valid_sign && class_exists( 'Exacoat_Logger' ) ) {
				Exacoat_Logger::log(
					'warning',
					'shopee_push',
					'Shopee push signature verification mismatch. Processing event with caution.',
					[
						'computed_against' => $request_url,
						'auth_header'      => substr( $auth_header, 0, 12 ) . '...',
					]
				);
			}
		}

		// Process push events by code
		switch ( $code ) {
			case 3:
				// order_status_push: Buyer paid, shipped, completed, or cancelled
				$order_sn = $data['ordersn'] ?? ( $data['order_sn'] ?? '' );
				$status = $data['status'] ?? '';
				if ( ! empty( $order_sn ) ) {
					self::update_order_cache_field( $order_sn, [
						'order_status' => $status,
						'update_time'  => date( 'Y-m-d H:i:s', $data['update_time'] ?? time() ),
					]);
					if ( class_exists( 'Exacoat_Logger' ) ) {
						Exacoat_Logger::log(
							'info',
							'shopee_push',
							sprintf( 'Updated order_status to %s for Order SN %s', $status, $order_sn )
						);
					}
				}
				break;

			case 4:
			case 24:
				// order_trackingno_push / booking_trackingno_push: Live courier resi assigned or updated
				$order_sn = $data['ordersn'] ?? ( $data['order_sn'] ?? '' );
				$tracking_no = $data['tracking_no'] ?? ( $data['tracking_number'] ?? '' );
				if ( ! empty( $order_sn ) ) {
					self::update_order_cache_field( $order_sn, [
						'tracking_number' => $tracking_no,
					]);
					if ( class_exists( 'Exacoat_Logger' ) ) {
						Exacoat_Logger::log(
							'info',
							'shopee_push',
							sprintf( 'Updated tracking_number to %s for Order SN %s', $tracking_no, $order_sn )
						);
					}
				}
				break;

			case 15:
			case 25:
				// shipping_document_status_push / booking_shipping_document_status_push
				$order_sn = $data['ordersn'] ?? ( $data['order_sn'] ?? '' );
				$doc_st   = strtoupper( (string) ( $data['status'] ?? '' ) );
				if ( ! empty( $order_sn ) ) {
					$fields = [
						'shipping_document_status' => $doc_st,
					];
					if ( in_array( $doc_st, [ 'PRINTED', 'READY' ], true ) ) {
						$fields['is_printed'] = ( $doc_st === 'PRINTED' );
					}
					self::update_order_cache_field( $order_sn, $fields );
					if ( class_exists( 'Exacoat_Logger' ) ) {
						Exacoat_Logger::log(
							'info',
							'shopee_push',
							sprintf( 'Updated shipping_document_status to %s for Order SN %s', $doc_st, $order_sn )
						);
					}
				}
				break;

			case 23:
				// booking_status_push: Logistics pickup/dropoff booking status update
				$order_sn = $data['ordersn'] ?? ( $data['order_sn'] ?? '' );
				$booking_st = $data['status'] ?? '';
				if ( ! empty( $order_sn ) && class_exists( 'Exacoat_Logger' ) ) {
					Exacoat_Logger::log(
						'info',
						'shopee_push',
						sprintf( 'Received booking_status_push (%s) for Order SN %s', $booking_st, $order_sn )
					);
				}
				break;

			case 30:
				// package_fulfillment_status_push
				$order_sn = $data['ordersn'] ?? ( $data['order_sn'] ?? '' );
				$package_number = $data['package_number'] ?? '';
				$fulfillment_status = $data['fulfillment_status'] ?? '';
				if ( ! empty( $order_sn ) ) {
					self::update_order_cache_field( $order_sn, [
						'fulfillment_status' => $fulfillment_status,
						'package_number'     => $package_number,
					]);
				}
				break;

			case 1:
				// shop_authorization_push
				if ( class_exists( 'Exacoat_Logger' ) ) {
					Exacoat_Logger::log( 'info', 'shopee_push', "Shop #{$shop_id} authorized via Shopee Push" );
				}
				break;

			case 2:
				// shop_authorization_canceled_push
				if ( class_exists( 'Exacoat_Logger' ) ) {
					Exacoat_Logger::log( 'warning', 'shopee_push', "Shop #{$shop_id} authorization revoked via Shopee Push" );
				}
				break;

			default:
				// Verification test ping or other push codes
				break;
		}

		// Shopee Open Platform expects HTTP 200 with code 0 to acknowledge receipt
		return new \WP_REST_Response([
			'code'    => 0,
			'message' => 'success',
		], 200 );
	}

	/**
	 * Toggle or update print status of a cached order
	 */
	public static function rest_toggle_order_print( \WP_REST_Request $request ): \WP_REST_Response {
		$body = $request->get_json_params() ?: [];
		$sn = trim( (string) ( $body['order_sn'] ?? $request->get_param( 'order_sn' ) ?? '' ) );
		$is_printed = isset( $body['is_printed'] ) ? (bool) $body['is_printed'] : true;

		if ( empty( $sn ) ) {
			return new \WP_REST_Response([ 'success' => false, 'error' => 'Order SN is required.' ], 400 );
		}

		$updated = self::update_order_cache_field( $sn, [
			'is_printed'               => $is_printed,
			'shipping_document_status' => $is_printed ? 'PRINTED' : 'UNPRINTED',
		]);

		return new \WP_REST_Response([
			'success'    => $updated,
			'order_sn'   => $sn,
			'is_printed' => $is_printed,
		]);
	}

	/**
	 * Parse Shopee item ID from plain ID or product page URL
	 */
	public static function parse_shopee_item_id( string $input ): int {
		$clean = trim( $input );
		if ( is_numeric( $clean ) ) {
			return (int) $clean;
		}

		// Match standard Shopee URL pattern: ...-i.{shop_id}.{item_id}
		if ( preg_match( '/-i\.\d+\.(\d+)/', $clean, $matches ) ) {
			return (int) $matches[1];
		}

		// Match secondary format: .../{shop_id}/{item_id} or .{item_id}?
		if ( preg_match( '/\.(\d{8,14})(?:[?&#]|$)/', $clean, $matches ) ) {
			return (int) $matches[1];
		}

		return 0;
	}

	/**
	 * REST Endpoint: Preview a Shopee product and its models
	 */
	public static function rest_product_preview( \WP_REST_Request $request ): \WP_REST_Response {
		$input = trim( (string) ( $request->get_param( 'item_id' ) ?? $request->get_param( 'url' ) ?? '' ) );
		$item_id = self::parse_shopee_item_id( $input );

		if ( empty( $item_id ) ) {
			return new \WP_REST_Response([
				'success' => false,
				'error'   => 'A valid Shopee Item ID or Product URL is required.',
			], 400 );
		}

		// 1. Fetch base info
		$base_res = self::call_shop_api( '/api/v2/product/get_item_base_info', 'GET', [
			'item_id_list' => (string) $item_id,
		]);

		if ( ! $base_res['success'] ) {
			return new \WP_REST_Response([
				'success' => false,
				'error'   => $base_res['error'] ?? 'Failed to retrieve item base info from Shopee.',
				'message' => $base_res['message'] ?? '',
				'raw'     => $base_res['raw'] ?? null,
			], 400 );
		}

		$item_list = $base_res['response']['item_list'] ?? [];
		if ( empty( $item_list[0] ) ) {
			return new \WP_REST_Response([
				'success' => false,
				'error'   => "Shopee product #{$item_id} was not found in connected shop.",
			], 404 );
		}

		$source = $item_list[0];

		// 2. Fetch models and variations if product has models
		$models = [];
		$tier_variation = [];
		if ( ! empty( $source['has_model'] ) ) {
			$model_res = self::call_shop_api( '/api/v2/product/get_model_list', 'GET', [
				'item_id' => $item_id,
			]);

			if ( $model_res['success'] && ! empty( $model_res['response'] ) ) {
				$tier_variation = $model_res['response']['tier_variation'] ?? [];
				$raw_models = $model_res['response']['model'] ?? [];
				foreach ( $raw_models as $m ) {
					$models[] = [
						'model_id'       => $m['model_id'] ?? 0,
						'tier_index'     => $m['tier_index'] ?? [],
						'model_sku'      => $m['model_sku'] ?? '',
						'original_price' => (float) ( $m['price_info'][0]['original_price'] ?? $source['original_price'] ?? 0 ),
						'current_price'  => (float) ( $m['price_info'][0]['current_price'] ?? $source['original_price'] ?? 0 ),
						'normal_stock'   => (int) ( $m['stock_info_v2']['summary_info']['total_available_stock'] ?? 0 ),
					];
				}
			}
		}

		// Format images
		$images = [];
		$img_ids = $source['image']['image_id_list'] ?? [];
		$img_urls = $source['image']['image_url_list'] ?? [];
		foreach ( $img_ids as $idx => $id ) {
			$images[] = [
				'image_id'  => $id,
				'image_url' => $img_urls[ $idx ] ?? '',
			];
		}

		// Infer device name from title
		$item_name = (string) ( $source['item_name'] ?? '' );
		$inferred_device = '';
		if ( preg_match( '/(iPhone\s+\d+(?:\s*(?:Pro\s*Max|Pro|Plus|Mini))?|iPad\s+[A-Za-z0-9\s]+|MacBook\s+[A-Za-z0-9\s]+|Galaxy\s+[A-Za-z0-9\s]+)/i', $item_name, $dev_matches ) ) {
			$inferred_device = trim( $dev_matches[1] );
		}

		return new \WP_REST_Response([
			'success'         => true,
			'item_id'         => (int) $source['item_id'],
			'item_name'       => $item_name,
			'description'     => (string) ( $source['description'] ?? '' ),
			'category_id'     => (int) ( $source['category_id'] ?? 0 ),
			'brand'           => $source['brand'] ?? [ 'brand_id' => 0, 'original_brand_name' => 'Exacoat' ],
			'item_status'     => (string) ( $source['item_status'] ?? 'NORMAL' ),
			'weight'          => (float) ( $source['weight'] ?? 0.05 ),
			'dimension'       => $source['dimension'] ?? [ 'package_height' => 1, 'package_length' => 20, 'package_width' => 15 ],
			'logistic_info'   => $source['logistic_info'] ?? [],
			'attribute_list'  => $source['attribute_list'] ?? [],
			'images'          => $images,
			'tier_variation'  => $tier_variation,
			'models'          => $models,
			'inferred_device' => $inferred_device,
		], 200 );
	}

	/**
	 * Upload an image buffer to Shopee Media Space API
	 */
	public static function upload_media_image( string $image_bytes, string $filename = 'product.jpg' ): array {
		$token_res = self::ensure_valid_token();
		if ( ! $token_res['success'] ) {
			return $token_res;
		}

		$access_token = $token_res['access_token'];
		$shop_id      = (int) $token_res['shop_id'];
		$partner_id   = self::get_active_partner_id();
		$partner_key  = self::get_active_partner_key();
		$base_url     = self::get_base_url();

		$path = '/api/v2/media_space/upload_image';
		$timestamp = time();
		$sign = self::sign_shop( $path, $timestamp, $partner_id, $partner_key, $access_token, $shop_id );

		$query = http_build_query([
			'partner_id'   => $partner_id,
			'timestamp'    => $timestamp,
			'access_token' => $access_token,
			'shop_id'      => $shop_id,
			'sign'         => $sign,
		]);
		$url = "{$base_url}{$path}?{$query}";

		$boundary = wp_generate_uuid4();
		$mime_type = 'image/jpeg';
		if ( str_ends_with( strtolower( $filename ), '.png' ) ) {
			$mime_type = 'image/png';
		}

		$payload = '';
		// Field: scene
		$payload .= "--{$boundary}\r\n";
		$payload .= "Content-Disposition: form-data; name=\"scene\"\r\n\r\n";
		$payload .= "normal\r\n";

		// Field: image file
		$payload .= "--{$boundary}\r\n";
		$payload .= "Content-Disposition: form-data; name=\"image\"; filename=\"{$filename}\"\r\n";
		$payload .= "Content-Type: {$mime_type}\r\n\r\n";
		$payload .= $image_bytes . "\r\n";
		$payload .= "--{$boundary}--\r\n";

		$res = wp_remote_post( $url, [
			'headers' => [
				'Content-Type' => "multipart/form-data; boundary={$boundary}",
			],
			'body'    => $payload,
			'timeout' => 45,
		]);

		if ( is_wp_error( $res ) ) {
			return [
				'success' => false,
				'error'   => $res->get_error_message(),
			];
		}

		$data = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( ! empty( $data['error'] ) ) {
			return [
				'success' => false,
				'error'   => $data['error'],
				'message' => $data['message'] ?? 'Failed to upload image to Shopee media space.',
			];
		}

		$info = $data['response']['image_info'] ?? [];
		if ( empty( $info['image_id'] ) ) {
			return [
				'success' => false,
				'error'   => 'Shopee media space did not return an image ID.',
			];
		}

		$first_url = $info['image_url_list'][0]['image_url'] ?? '';

		return [
			'success'   => true,
			'image_id'  => $info['image_id'],
			'image_url' => $first_url,
		];
	}

	/**
	 * REST Endpoint: Upload an image to Shopee Media Space
	 */
	public static function rest_upload_image( \WP_REST_Request $request ): \WP_REST_Response {
		$filename = 'product.jpg';
		$image_bytes = '';

		// Check for base64 payload
		$body = $request->get_json_params() ?: [];
		if ( ! empty( $body['image_data'] ) ) {
			$raw_b64 = (string) $body['image_data'];
			if ( preg_match( '/^data:image\/(\w+);base64,/', $raw_b64, $m ) ) {
				$filename = 'product.' . ( $m[1] === 'png' ? 'png' : 'jpg' );
				$raw_b64 = substr( $raw_b64, strpos( $raw_b64, ',' ) + 1 );
			}
			$image_bytes = base64_decode( $raw_b64 );
		} elseif ( ! empty( $_FILES['image']['tmp_name'] ) && is_uploaded_file( $_FILES['image']['tmp_name'] ) ) {
			$filename = sanitize_file_name( $_FILES['image']['name'] ?? 'product.jpg' );
			$image_bytes = file_get_contents( $_FILES['image']['tmp_name'] );
		}

		if ( empty( $image_bytes ) ) {
			return new \WP_REST_Response([
				'success' => false,
				'error'   => 'No image data or file provided for upload.',
			], 400 );
		}

		$upload_res = self::upload_media_image( $image_bytes, $filename );
		if ( ! $upload_res['success'] ) {
			return new \WP_REST_Response( $upload_res, 400 );
		}

		return new \WP_REST_Response( $upload_res, 200 );
	}

	/**
	 * REST Endpoint: Duplicate Shopee product into draft (UNLIST) status
	 */
	public static function rest_duplicate_product( \WP_REST_Request $request ): \WP_REST_Response {
		$body = $request->get_json_params() ?: [];

		$source_input = trim( (string) ( $body['source_item_id'] ?? $body['source_url'] ?? '' ) );
		$source_item_id = self::parse_shopee_item_id( $source_input );
		$source_device = trim( (string) ( $body['source_device'] ?? '' ) );
		$target_device = trim( (string) ( $body['target_device'] ?? '' ) );

		if ( empty( $source_item_id ) ) {
			return new \WP_REST_Response([
				'success' => false,
				'error'   => 'A valid source Shopee Item ID or Product URL is required.',
			], 400 );
		}

		if ( empty( $target_device ) ) {
			return new \WP_REST_Response([
				'success' => false,
				'error'   => 'Target device name is required (e.g. iPhone 18 Pro Max).',
			], 400 );
		}

		// 1. Fetch source product base info
		$base_res = self::call_shop_api( '/api/v2/product/get_item_base_info', 'GET', [
			'item_id_list' => (string) $source_item_id,
		]);

		if ( ! $base_res['success'] || empty( $base_res['response']['item_list'][0] ) ) {
			return new \WP_REST_Response([
				'success' => false,
				'error'   => 'Could not fetch source product details from Shopee.',
				'message' => $base_res['message'] ?? '',
			], 400 );
		}

		$src = $base_res['response']['item_list'][0];

		// Auto-detect source device if not specified
		if ( empty( $source_device ) ) {
			if ( preg_match( '/(iPhone\s+\d+(?:\s*(?:Pro\s*Max|Pro|Plus|Mini))?|iPad\s+[A-Za-z0-9\s]+|MacBook\s+[A-Za-z0-9\s]+|Galaxy\s+[A-Za-z0-9\s]+)/i', $src['item_name'], $m ) ) {
				$source_device = trim( $m[1] );
			}
		}

		// Compute new item title and description with device name substitution
		$raw_title = $src['item_name'];
		$new_title = ! empty( $body['custom_item_name'] )
			? trim( (string) $body['custom_item_name'] )
			: ( ! empty( $source_device ) ? str_ireplace( $source_device, $target_device, $raw_title ) : "{$raw_title} ({$target_device})" );

		$raw_desc = (string) ( $src['description'] ?? '' );
		$new_desc = ! empty( $body['custom_description'] )
			? trim( (string) $body['custom_description'] )
			: ( ! empty( $source_device ) ? str_ireplace( $source_device, $target_device, $raw_desc ) : $raw_desc );

		// Prepare images: custom image IDs or source image IDs
		$image_ids = [];
		if ( ! empty( $body['custom_image_ids'] ) && is_array( $body['custom_image_ids'] ) ) {
			$image_ids = array_values( array_filter( array_map( 'strval', $body['custom_image_ids'] ) ) );
		}
		if ( empty( $image_ids ) && ! empty( $src['image']['image_id_list'] ) ) {
			$image_ids = $src['image']['image_id_list'];
		}

		// Cap image count to 9 (Shopee maximum)
		$image_ids = array_slice( $image_ids, 0, 9 );

		// Fetch source models to extract base pricing
		$model_res = self::call_shop_api( '/api/v2/product/get_model_list', 'GET', [
			'item_id' => $source_item_id,
		]);

		$source_tier_variation = [];
		$source_models = [];
		$base_price = (float) ( $src['original_price'] ?? 149000 );

		if ( $model_res['success'] && ! empty( $model_res['response'] ) ) {
			$source_tier_variation = $model_res['response']['tier_variation'] ?? [];
			$source_models = $model_res['response']['model'] ?? [];
			if ( ! empty( $source_models[0]['price_info'][0]['original_price'] ) ) {
				$base_price = (float) $source_models[0]['price_info'][0]['original_price'];
			}
		}

		if ( $base_price <= 0 ) {
			$base_price = 149000;
		}

		// 2. Create Base Product Listing with UNLIST (draft) status
		$add_payload = [
			'original_price' => $base_price,
			'description'    => $new_desc,
			'weight'         => (float) ( $src['weight'] ?? 0.05 ),
			'item_name'      => $new_title,
			'item_status'    => 'UNLIST', // Ensures item is saved as unlisted draft
			'normal_stock'   => 100,
			'category_id'    => (int) ( $src['category_id'] ?? 0 ),
			'image'          => [
				'image_id_list' => $image_ids,
			],
			'brand'          => $src['brand'] ?? [ 'brand_id' => 0, 'original_brand_name' => 'Exacoat' ],
			'logistic_info'  => $src['logistic_info'] ?? [],
			'dimension'      => $src['dimension'] ?? [ 'package_height' => 1, 'package_length' => 20, 'package_width' => 15 ],
			'condition'      => 'NEW',
		];

		if ( ! empty( $src['attribute_list'] ) ) {
			$add_payload['attribute_list'] = $src['attribute_list'];
		}

		$create_res = self::call_shop_api( '/api/v2/product/add_item', 'POST', [], $add_payload );

		if ( ! $create_res['success'] || empty( $create_res['response']['item_id'] ) ) {
			return new \WP_REST_Response([
				'success' => false,
				'error'   => $create_res['error'] ?? 'Shopee add_item request failed.',
				'message' => $create_res['message'] ?? 'Unable to create product draft.',
				'raw'     => $create_res['raw'] ?? null,
			], 400 );
		}

		$new_item_id = (int) $create_res['response']['item_id'];

		// 3. Initialize Tier Variations & Models if source has them
		$models_initialized = 0;
		if ( ! empty( $source_tier_variation ) && ! empty( $source_models ) ) {
			// Wait 3 seconds for Shopee indexing before calling init_tier_variation
			sleep( 3 );

			$transformed_models = [];
			foreach ( $source_models as $m ) {
				$m_price = (float) ( $m['price_info'][0]['original_price'] ?? $base_price );
				$m_stock = (int) ( $m['stock_info_v2']['summary_info']['total_available_stock'] ?? 50 );
				if ( $m_stock <= 0 ) {
					$m_stock = 50;
				}

				$m_sku = (string) ( $m['model_sku'] ?? '' );
				if ( ! empty( $m_sku ) && ! empty( $source_device ) ) {
					$m_sku = str_ireplace( $source_device, $target_device, $m_sku );
				}

				$transformed_models[] = [
					'tier_index'     => $m['tier_index'] ?? [ 0 ],
					'normal_stock'   => $m_stock,
					'original_price' => $m_price,
					'model_sku'      => $m_sku,
				];
			}

			// Clean tier variation options
			$clean_tier_variation = [];
			foreach ( $source_tier_variation as $tv ) {
				$opts = [];
				foreach ( ( $tv['options'] ?? [] ) as $opt_entry ) {
					$opts[] = [
						'option' => is_array( $opt_entry ) ? ( $opt_entry['option'] ?? '' ) : (string) $opt_entry,
					];
				}
				$clean_tier_variation[] = [
					'name'    => $tv['name'] ?? 'Varian',
					'options' => $opts,
				];
			}

			$init_res = self::call_shop_api( '/api/v2/product/init_tier_variation', 'POST', [], [
				'item_id'        => $new_item_id,
				'tier_variation' => $clean_tier_variation,
				'model'          => $transformed_models,
			]);

			if ( $init_res['success'] ) {
				$models_initialized = count( $transformed_models );
			} elseif ( class_exists( 'Exacoat_Logger' ) ) {
				Exacoat_Logger::log( 'error', 'shopee_duplicate', 'Failed to init tier variation on draft item', $init_res );
			}
		}

		if ( class_exists( 'Exacoat_Logger' ) ) {
			Exacoat_Logger::log(
				'info',
				'shopee_duplicate',
				sprintf( 'Successfully duplicated Shopee listing %s -> %s (Draft ID %d)', $source_device, $target_device, $new_item_id )
			);
		}

		return new \WP_REST_Response([
			'success'            => true,
			'new_item_id'        => $new_item_id,
			'item_name'          => $new_title,
			'item_status'        => 'UNLIST',
			'status_label'       => 'Belum Ditampilkan (Draft)',
			'seller_centre_url'  => "https://seller.shopee.co.id/portal/product/{$new_item_id}",
			'models_initialized' => $models_initialized,
			'source_item_id'     => $source_item_id,
			'target_device'      => $target_device,
		], 200 );
	}

	/**
	 * REST Endpoint: Fetch Shopee product listings with base info
	 */
	public static function rest_get_products( \WP_REST_Request $request ): \WP_REST_Response {
		$offset = max( 0, (int) ( $request->get_param( 'offset' ) ?: 0 ) );
		$page_size = min( 100, max( 1, (int) ( $request->get_param( 'page_size' ) ?: 50 ) ) );
		$status_param = sanitize_text_field( (string) ( $request->get_param( 'item_status' ) ?: 'NORMAL' ) );

		// Shopee API accepts item_status query
		$query_params = [
			'offset'      => $offset,
			'page_size'   => $page_size,
			'item_status' => $status_param === 'ALL' ? 'NORMAL' : $status_param,
		];

		$list_res = self::call_shop_api( '/api/v2/product/get_item_list', 'GET', $query_params );
		if ( ! $list_res['success'] ) {
			return new \WP_REST_Response([
				'success' => false,
				'error'   => $list_res['error'] ?? 'Failed to retrieve item list from Shopee.',
				'message' => $list_res['message'] ?? '',
				'items'   => [],
				'total'   => 0,
			], 400 );
		}

		$raw_items = $list_res['response']['item'] ?? [];
		$total = (int) ( $list_res['response']['total_count'] ?? count( $raw_items ) );
		$has_next = (bool) ( $list_res['response']['has_next_page'] ?? false );
		$next_offset = (int) ( $list_res['response']['next_offset'] ?? ( $offset + count( $raw_items ) ) );

		if ( empty( $raw_items ) ) {
			return new \WP_REST_Response([
				'success'       => true,
				'items'         => [],
				'total'         => $total,
				'has_next_page' => false,
				'next_offset'   => $offset,
			], 200 );
		}

		// Extract item IDs to fetch detailed base info (up to 50 at a time)
		$item_ids = array_values( array_filter( array_map( function( $it ) {
			return isset( $it['item_id'] ) ? (int) $it['item_id'] : 0;
		}, $raw_items ) ) );

		$chunks = array_chunk( $item_ids, 50 );
		$detailed_items = [];

		foreach ( $chunks as $chunk ) {
			$base_res = self::call_shop_api( '/api/v2/product/get_item_base_info', 'GET', [
				'item_id_list' => implode( ',', $chunk ),
			]);

			if ( $base_res['success'] && ! empty( $base_res['response']['item_list'] ) ) {
				foreach ( $base_res['response']['item_list'] as $item ) {
					$item_id = (int) ( $item['item_id'] ?? 0 );
					$images = [];
					if ( ! empty( $item['image']['image_url_list'] ) && is_array( $item['image']['image_url_list'] ) ) {
						$images = $item['image']['image_url_list'];
					}

					$detailed_items[] = [
						'item_id'           => $item_id,
						'item_name'         => (string) ( $item['item_name'] ?? '' ),
						'item_status'       => (string) ( $item['item_status'] ?? 'NORMAL' ),
						'description'       => (string) ( $item['description'] ?? '' ),
						'price_info'        => $item['price_info'] ?? [],
						'stock_info_v2'     => $item['stock_info_v2'] ?? [],
						'image'             => $item['image'] ?? [ 'image_url_list' => $images ],
						'brand'             => $item['brand'] ?? [ 'brand_id' => 0, 'original_brand_name' => 'Exacoat' ],
						'category_id'       => (int) ( $item['category_id'] ?? 0 ),
						'create_time'       => (int) ( $item['create_time'] ?? 0 ),
						'update_time'       => (int) ( $item['update_time'] ?? 0 ),
						'seller_centre_url' => "https://seller.shopee.co.id/portal/product/{$item_id}",
					];
				}
			}
		}

		return new \WP_REST_Response([
			'success'       => true,
			'items'         => $detailed_items,
			'total'         => $total,
			'has_next_page' => $has_next,
			'next_offset'   => $next_offset,
		], 200 );
	}

	/**
	 * REST Endpoint: Set Shopee product status (NORMAL vs UNLIST)
	 */
	public static function rest_set_product_status( \WP_REST_Request $request ): \WP_REST_Response {
		$body = $request->get_json_params() ?: [];
		$item_id = (int) ( $body['item_id'] ?? 0 );
		$unlist = ! empty( $body['unlist'] ); // true = unlist (draft), false = normal (publish)

		if ( empty( $item_id ) ) {
			return new \WP_REST_Response([
				'success' => false,
				'error'   => 'A valid Shopee Item ID is required.',
			], 400 );
		}

		$payload = [
			'item_list' => [
				[
					'item_id' => $item_id,
					'unlist'  => $unlist,
				],
			],
		];

		$res = self::call_shop_api( '/api/v2/product/unlist_item', 'POST', [], $payload );
		if ( ! $res['success'] ) {
			return new \WP_REST_Response([
				'success' => false,
				'error'   => $res['error'] ?? 'Failed to update item status on Shopee.',
				'message' => $res['message'] ?? '',
			], 400 );
		}

		$new_status = $unlist ? 'UNLIST' : 'NORMAL';
		return new \WP_REST_Response([
			'success'     => true,
			'item_id'     => $item_id,
			'unlist'      => $unlist,
			'item_status' => $new_status,
			'message'     => $unlist ? 'Product moved to unlisted draft.' : 'Product published live.',
		], 200 );
	}

	/**
	 * REST Endpoint: Delete Shopee product
	 */
	public static function rest_delete_product( \WP_REST_Request $request ): \WP_REST_Response {
		$body = $request->get_json_params() ?: [];
		$item_id = (int) ( $body['item_id'] ?? 0 );

		if ( empty( $item_id ) ) {
			return new \WP_REST_Response([
				'success' => false,
				'error'   => 'A valid Shopee Item ID is required.',
			], 400 );
		}

		$payload = [
			'item_id' => $item_id,
		];

		$res = self::call_shop_api( '/api/v2/product/delete_item', 'POST', [], $payload );
		if ( ! $res['success'] ) {
			return new \WP_REST_Response([
				'success' => false,
				'error'   => $res['error'] ?? 'Failed to delete product on Shopee.',
				'message' => $res['message'] ?? '',
			], 400 );
		}

		return new \WP_REST_Response([
			'success' => true,
			'item_id' => $item_id,
			'message' => 'Product listing removed successfully from Shopee.',
		], 200 );
	}
}

}


